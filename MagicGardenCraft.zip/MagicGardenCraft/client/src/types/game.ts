// Core game types and interfaces

// Player and Character Types
export interface Player {
  id: string;
  username: string;
  level: number;
  experience: number;
  position: [number, number, number];
  selectedElement: ElementType | null;
  isOnline: boolean;
  lastSeen: number;
  offlineDays: number;
  arenaBot?: ArenaBot;
  health: number;
  maxHealth: number;
  achievements: Achievement[];
  prestigeLevel: number;
  membershipActive: boolean;
}

// Elemental System Types
export type ElementType = 'fire' | 'water' | 'earth' | 'air' | 'shadow' | 'black' | 'light';

export interface ElementalAffinity {
  element: ElementType;
  mastery: number; // 0-100
  branches: ElementalBranch[];
  spectrumOpposite?: ElementType;
  permanentChoice: boolean;
}

export interface ElementalBranch {
  id: string;
  name: string;
  element: ElementType;
  level: number;
  experience: number;
  unlocked: boolean;
  mastered: boolean;
  synergies: string[]; // IDs of other branches for cross-branch synergy
}

// Garden and Building Types
export interface GardenPlot {
  id: string;
  position: [number, number, number];
  element: ElementType;
  plant?: Plant;
  growth: number; // 0-1
  planted: boolean;
  plantedAt: number;
  lastTended: number;
  bonuses: GrowthBonus[];
}

export interface Plant {
  id: string;
  name: string;
  element: ElementType;
  stage: 'seed' | 'sprout' | 'growing' | 'mature' | 'magical';
  growthRate: number;
  magicalProperties: string[];
  harvestYield: number;
}

export interface GrowthBonus {
  source: 'weather' | 'magic' | 'element' | 'card' | 'time_travel' | 'movie' | 'lemonheads';
  multiplier: number;
  description: string;
  duration?: number; // Optional duration in milliseconds
}

// Action Tree System Types
export interface ActionTreeNode {
  id: string;
  name: string;
  description: string;
  category: ActionCategory;
  level: number;
  experience: number;
  maxLevel: number;
  prerequisites: string[];
  unlocked: boolean;
  branches: ActionBranch[];
  effects: Record<string, number>;
}

export type ActionCategory = 
  | 'movement' | 'magic' | 'building' | 'interaction' | 'exploration'
  | 'combat' | 'economy' | 'social' | 'time_travel' | 'space_travel'
  | 'fishing' | 'card_collection' | 'arena' | 'weather' | 'music';

export interface ActionBranch {
  id: string;
  name: string;
  description: string;
  level: number;
  maxLevel: number;
  experience: number;
  specializationPath: string;
  effects: Record<string, number>;
  crossBranchSynergies: SynergyEffect[];
}

export interface SynergyEffect {
  branchIds: string[];
  bonusMultiplier: number;
  description: string;
  discovered: boolean;
}

// XRP Economy Types
export interface XRPAccount {
  balance: number;
  totalEarned: number;
  totalSpent: number;
  dailyEarnings: number;
  transactions: XRPTransaction[];
  marketData: XRPMarketData;
}

export interface XRPTransaction {
  id: string;
  type: 'earn' | 'spend';
  amount: number;
  source: string;
  timestamp: number;
  description: string;
}

export interface XRPMarketData {
  currentPrice: number;
  change24h: number;
  changePercent24h: number;
  trend: 'up' | 'down' | 'stable';
  lastUpdate: number;
  emergencyState?: 'crash' | 'surge' | null;
}

// Weather System Types
export interface WeatherData {
  condition: WeatherCondition;
  temperature: number;
  humidity: number;
  windSpeed: number;
  description: string;
  location: string;
  effects: WeatherEffects;
  lastUpdated: number;
}

export type WeatherCondition = 'sunny' | 'cloudy' | 'rain' | 'snow' | 'storm';

export interface WeatherEffects {
  gardenGrowthMultiplier: number;
  magicPowerBonus: number;
  xrpEarningBonus: number;
  elementalBonuses: Record<ElementType, number>;
  visibilityModifier: number;
}

// Achievement System Types
export interface Achievement {
  id: string;
  name: string;
  description: string;
  category: AchievementCategory;
  points: number;
  rarity: 'common' | 'uncommon' | 'rare' | 'epic' | 'legendary' | 'mythic';
  unlockedAt?: number;
  requirements: AchievementRequirement[];
  legacy: boolean; // Carries across prestige
}

export type AchievementCategory = 
  | 'garden' | 'magic' | 'economy' | 'exploration' | 'combat'
  | 'social' | 'time_travel' | 'card_collection' | 'arena'
  | 'weather' | 'special' | 'black_magic';

export interface AchievementRequirement {
  type: 'action_count' | 'level_reached' | 'item_collected' | 'boss_defeated' | 'special_event';
  target: string;
  value: number;
  current?: number;
}

// Arena Bot System Types
export interface ArenaBot {
  playerId: string;
  playerName: string;
  deployedAt: number;
  health: number;
  maxHealth: number;
  equipment: string[];
  combatStats: CombatStats;
  deathTimer: number; // 24 hours in milliseconds
  battles: ArenaBattle[];
}

export interface ArenaBattle {
  id: string;
  challengerId: string;
  challengerName: string;
  timestamp: number;
  result: 'win' | 'loss';
  damage: number;
  rewards: string[];
}

export interface CombatStats {
  attack: number;
  defense: number;
  speed: number;
  magic: number;
  element: ElementType;
}

// Card Collection System Types
export interface YuGiOhCard {
  id: string;
  name: string;
  rarity: CardRarity;
  type: 'monster' | 'spell' | 'trap';
  element?: ElementType;
  attack?: number;
  defense?: number;
  level?: number;
  description: string;
  collectedAt?: number;
  source: 'duel_master' | 'pack' | 'trade' | 'special_event';
}

export type CardRarity = 'common' | 'rare' | 'super_rare' | 'ultra_rare' | 'secret_rare';

export interface DuelMaster {
  name: string;
  cardsRemaining: number;
  totalCards: number;
  lastInteraction: number;
  hatItems: DuelMasterItem[];
  alwaysWins: boolean;
}

export interface DuelMasterItem {
  id: string;
  name: string;
  rarity: string;
  type: 'card' | 'equipment' | 'consumable' | 'special';
  dropChance: number;
}

// Lemonheads Economy Types
export interface LemonheadsData {
  inventory: number;
  totalConsumed: number;
  marketValue: number; // Fixed at $300 USD
  dropRate: number; // 25% base, 35% while watching movies
  consumptionHistory: LemonheadsConsumption[];
  boxes: LemonheadsBox[];
}

export interface LemonheadsConsumption {
  timestamp: number;
  amount: number;
  statBoosts: Record<string, number>;
  instantDeathRisk: number; // Proportional to eating speed
}

export interface LemonheadsBox {
  id: string;
  candiesRemaining: number;
  maxCandies: 23;
  purchaseDate: number;
  nftMetadata?: NFTMetadata;
}

export interface NFTMetadata {
  tokenId: string;
  contractAddress: string;
  ownershipHistory: string[];
  tradeValue: number;
}

// Time Travel System Types
export interface TimeTravel {
  destination: number; // Future timestamp
  duration: number; // Travel duration in milliseconds
  lockoutActive: boolean;
  lockoutEnd: number;
  emergencyBypass: EmergencyBypass;
  artifacts: TimeTravelArtifact[];
}

export interface EmergencyBypass {
  sequence: string[]; // Complex tap sequence
  attemptsRemaining: number;
  lastAttempt: number;
}

export interface TimeTravelArtifact {
  id: string;
  name: string;
  era: string;
  effects: Record<string, number>;
  rarity: string;
  discoveredAt: number;
}

// Space Travel System Types
export interface SpaceLocation {
  id: string;
  name: string;
  coordinates: [number, number, number]; // lat, lon, altitude
  type: 'earth_location' | 'space_station' | 'planet' | 'moon' | 'asteroid';
  accessibility: 'public' | 'restricted' | 'special_event';
  resources: SpaceResource[];
  inhabitants: SpaceInhabitant[];
}

export interface SpaceResource {
  type: string;
  abundance: number;
  harvestable: boolean;
  requirements: string[];
}

export interface SpaceInhabitant {
  id: string;
  name: string;
  species: string;
  attitude: 'friendly' | 'neutral' | 'hostile';
  tradeable: boolean;
  dialogue: string[];
}

// Fishing System Types
export interface FishingSpot {
  id: string;
  location: SpaceLocation;
  fishSpecies: Fish[];
  conditions: FishingConditions;
  lastFished: number;
  depletionLevel: number; // 0-1, affects spawn rates
}

export interface Fish {
  id: string;
  name: string;
  species: string;
  rarity: 'common' | 'uncommon' | 'rare' | 'epic' | 'legendary' | 'mythic' | 'unicorn';
  size: number;
  weight: number;
  catchDifficulty: number;
  magicalProperties: string[];
  habitat: string[];
  catchConditions: FishingConditions;
}

export interface FishingConditions {
  weather: WeatherCondition[];
  timeOfDay: 'dawn' | 'morning' | 'noon' | 'afternoon' | 'dusk' | 'night';
  season: 'spring' | 'summer' | 'autumn' | 'winter';
  waterConditions: 'clear' | 'murky' | 'rough' | 'calm';
}

// Social and Multiplayer Types
export interface Guild {
  id: string;
  name: string;
  description: string;
  members: GuildMember[];
  level: number;
  experience: number;
  benefits: GuildBenefit[];
  activities: GuildActivity[];
  territory: GuildTerritory[];
}

export interface GuildMember {
  playerId: string;
  username: string;
  rank: 'member' | 'officer' | 'leader';
  joinedAt: number;
  contribution: number;
  specializations: ElementType[];
}

export interface GuildBenefit {
  type: string;
  effect: Record<string, number>;
  description: string;
  level: number;
}

export interface GuildActivity {
  id: string;
  type: 'raid' | 'expedition' | 'tournament' | 'research' | 'construction';
  participants: string[];
  startTime: number;
  duration: number;
  rewards: ActivityReward[];
  requirements: ActivityRequirement[];
}

export interface ActivityReward {
  type: 'xrp' | 'experience' | 'item' | 'achievement' | 'lemonheads';
  amount: number;
  rarity?: string;
}

export interface ActivityRequirement {
  type: 'level' | 'element' | 'item' | 'achievement';
  value: string | number;
}

export interface GuildTerritory {
  id: string;
  location: [number, number];
  type: 'garden' | 'fortress' | 'research_lab' | 'arena' | 'marketplace';
  level: number;
  defenses: number;
  resources: Record<string, number>;
}

// Waifu System Types (as mentioned in requirements)
export interface WaifuCharacter {
  id: string;
  name: string;
  element: ElementType;
  personality: string[];
  appearance: WaifuAppearance;
  relationship: WaifuRelationship;
  abilities: WaifuAbility[];
  dialogue: WaifuDialogue[];
  customization: WaifuCustomization;
}

export interface WaifuAppearance {
  hairColor: string;
  eyeColor: string;
  outfit: string;
  accessories: string[];
  expressions: Record<string, string>; // emotion -> image path
}

export interface WaifuRelationship {
  level: number;
  experience: number;
  trust: number;
  affection: number;
  compatibility: number;
  relationship_type: 'friend' | 'companion' | 'partner' | 'soulmate';
}

export interface WaifuAbility {
  id: string;
  name: string;
  description: string;
  element: ElementType;
  cooldown: number;
  effects: Record<string, number>;
}

export interface WaifuDialogue {
  trigger: 'greeting' | 'level_up' | 'magic_cast' | 'garden_tend' | 'random';
  text: string;
  emotion: 'happy' | 'excited' | 'calm' | 'mysterious' | 'supportive';
  voiceId: string;
}

export interface WaifuCustomization {
  unlockedOutfits: string[];
  unlockedAccessories: string[];
  unlockedHairColors: string[];
  unlockedExpressions: string[];
  currentCustomization: WaifuAppearance;
}

// Emergency and Admin Types
export interface EmergencyProtocol {
  type: 'market_crash' | 'server_outage' | 'player_rescue' | 'maintenance';
  active: boolean;
  triggeredAt: number;
  severity: 'low' | 'medium' | 'high' | 'critical';
  actions: EmergencyAction[];
  communication: EmergencyCommuncation[];
}

export interface EmergencyAction {
  id: string;
  description: string;
  executed: boolean;
  executedAt?: number;
  result?: string;
}

export interface EmergencyCommuncation {
  channel: 'email' | 'in_game' | 'discord' | 'twitter' | 'website';
  message: string;
  sent: boolean;
  sentAt?: number;
  recipients: string[];
}

// Special Alexander Account Types (as mentioned in requirements)
export interface AlexanderAccount {
  isAlexander: boolean;
  blackMagicPermanent: boolean;
  colorSwitchChance: number; // 1% per action
  godModeAvailable: boolean;
  godModeActive: boolean;
  specialPrivileges: AlexanderPrivilege[];
  usageHistory: AlexanderAction[];
}

export interface AlexanderPrivilege {
  id: string;
  name: string;
  description: string;
  unlimited: boolean;
  cooldown?: number;
  lastUsed?: number;
}

export interface AlexanderAction {
  timestamp: number;
  action: string;
  magicColor: ElementType;
  godModeUsed: boolean;
  result: string;
}

// Game State and Configuration Types
export interface GameConfig {
  version: string;
  features: Record<string, boolean>;
  balanceVersion: string;
  blackMagicSupremacy: boolean; // Always true per requirements
  debugMode: boolean;
  emergencyMode: boolean;
  maintenanceMode: boolean;
}

export interface GameState {
  phase: 'loading' | 'element_selection' | 'tutorial' | 'playing' | 'paused' | 'emergency';
  player: Player;
  session: GameSession;
  ui: UIState;
  audio: AudioState;
}

export interface GameSession {
  startTime: number;
  duration: number;
  actionsPerformed: number;
  xrpEarned: number;
  experienceGained: number;
  achievementsUnlocked: string[];
}

export interface UIState {
  activePanel: string | null;
  notifications: Notification[];
  contextMenu: ContextMenu | null;
  modal: Modal | null;
  hud: HUDState;
}

export interface Notification {
  id: string;
  type: 'info' | 'success' | 'warning' | 'error' | 'achievement';
  title: string;
  message: string;
  timestamp: number;
  duration?: number;
  actions?: NotificationAction[];
}

export interface NotificationAction {
  label: string;
  action: () => void;
  style: 'primary' | 'secondary' | 'danger';
}

export interface ContextMenu {
  position: [number, number];
  items: ContextMenuItem[];
  target: string;
}

export interface ContextMenuItem {
  label: string;
  action: () => void;
  disabled?: boolean;
  separator?: boolean;
  icon?: string;
}

export interface Modal {
  id: string;
  title: string;
  content: React.ReactNode;
  size: 'small' | 'medium' | 'large' | 'fullscreen';
  closeable: boolean;
  actions?: ModalAction[];
}

export interface ModalAction {
  label: string;
  action: () => void;
  style: 'primary' | 'secondary' | 'danger';
  disabled?: boolean;
}

export interface HUDState {
  visible: boolean;
  elements: Record<string, boolean>;
  layout: 'compact' | 'standard' | 'expanded';
  opacity: number;
}

export interface AudioState {
  masterVolume: number;
  musicVolume: number;
  sfxVolume: number;
  voiceVolume: number;
  isMuted: boolean;
  currentTrack: string | null;
  voiceQueue: string[];
}

// Utility Types
export type Coordinate = [number, number, number];
export type Color = string; // Hex color codes
export type Timestamp = number;
export type ElementalColor = Record<ElementType, Color>;

// API Response Types
export interface APIResponse<T = any> {
  success: boolean;
  data?: T;
  error?: string;
  timestamp: number;
}

export interface PaginatedResponse<T> extends APIResponse<T[]> {
  page: number;
  totalPages: number;
  totalItems: number;
  itemsPerPage: number;
}

// Event System Types
export interface GameEvent {
  id: string;
  type: string;
  timestamp: number;
  source: string;
  data: Record<string, any>;
  processed: boolean;
}

export interface EventListener {
  eventType: string;
  callback: (event: GameEvent) => void;
  priority: number;
}

// Save/Load System Types
export interface SaveData {
  version: string;
  timestamp: number;
  player: Player;
  garden: GardenPlot[];
  actionTrees: Record<string, ActionTreeNode>;
  achievements: Achievement[];
  xrpAccount: XRPAccount;
  lemonheads: LemonheadsData;
  cards: YuGiOhCard[];
  timeTravel: TimeTravel;
  waifu?: WaifuCharacter;
  settings: GameSettings;
}

export interface GameSettings {
  graphics: GraphicsSettings;
  audio: AudioSettings;
  controls: ControlSettings;
  ui: UISettings;
  accessibility: AccessibilitySettings;
}

export interface GraphicsSettings {
  quality: 'low' | 'medium' | 'high' | 'ultra';
  shadows: boolean;
  particles: boolean;
  weatherEffects: boolean;
  fov: number;
  renderDistance: number;
}

export interface AudioSettings {
  masterVolume: number;
  musicVolume: number;
  sfxVolume: number;
  voiceVolume: number;
  spatialAudio: boolean;
  dynamicRange: boolean;
}

export interface ControlSettings {
  keybindings: Record<string, string>;
  mouseSensitivity: number;
  invertY: boolean;
  autoRun: boolean;
}

export interface UISettings {
  hudScale: number;
  showTooltips: boolean;
  animationSpeed: number;
  colorTheme: 'dark' | 'light' | 'auto';
  language: string;
}

export interface AccessibilitySettings {
  highContrast: boolean;
  largeText: boolean;
  screenReader: boolean;
  colorBlindSupport: 'none' | 'deuteranopia' | 'protanopia' | 'tritanopia';
  reducedMotion: boolean;
}
