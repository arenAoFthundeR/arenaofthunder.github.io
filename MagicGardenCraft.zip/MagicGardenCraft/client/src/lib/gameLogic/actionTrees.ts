export interface ActionNode {
  id: string;
  name: string;
  description: string;
  category: string;
  level: number;
  experience: number;
  prerequisites: string[];
  unlocked: boolean;
  branches: ActionBranch[];
}

export interface ActionBranch {
  id: string;
  name: string;
  description: string;
  level: number;
  maxLevel: number;
  experience: number;
  effects: Record<string, number>;
}

export class ActionTreeSystem {
  private trees: Map<string, ActionNode[]> = new Map();
  
  constructor() {
    this.initializeActionTrees();
  }
  
  private initializeActionTrees(): void {
    // Movement Action Tree
    this.trees.set('movement', [
      {
        id: 'basic_movement',
        name: 'Basic Movement',
        description: 'Fundamental locomotion skills',
        category: 'movement',
        level: 0,
        experience: 0,
        prerequisites: [],
        unlocked: true,
        branches: [
          { id: 'speed', name: 'Swift Steps', description: 'Increase movement speed', level: 0, maxLevel: 10, experience: 0, effects: { speed: 0.1 } },
          { id: 'agility', name: 'Nimble Movement', description: 'Improved maneuverability', level: 0, maxLevel: 10, experience: 0, effects: { agility: 0.1 } },
          { id: 'endurance', name: 'Tireless Travel', description: 'Reduced movement fatigue', level: 0, maxLevel: 10, experience: 0, effects: { endurance: 0.1 } }
        ]
      },
      {
        id: 'advanced_movement',
        name: 'Advanced Locomotion',
        description: 'Enhanced movement techniques',
        category: 'movement',
        level: 0,
        experience: 0,
        prerequisites: ['basic_movement'],
        unlocked: false,
        branches: [
          { id: 'dash', name: 'Dash Technique', description: 'Quick burst movement', level: 0, maxLevel: 5, experience: 0, effects: { dash_power: 0.2 } },
          { id: 'wall_run', name: 'Wall Running', description: 'Traverse vertical surfaces', level: 0, maxLevel: 5, experience: 0, effects: { wall_run: 1 } },
          { id: 'double_jump', name: 'Air Step', description: 'Additional jump in mid-air', level: 0, maxLevel: 3, experience: 0, effects: { air_jumps: 1 } }
        ]
      }
    ]);
    
    // Magic Action Tree
    this.trees.set('magic', [
      {
        id: 'elemental_basics',
        name: 'Elemental Fundamentals',
        description: 'Basic elemental manipulation',
        category: 'magic',
        level: 0,
        experience: 0,
        prerequisites: [],
        unlocked: true,
        branches: [
          { id: 'power', name: 'Magical Power', description: 'Increase spell potency', level: 0, maxLevel: 20, experience: 0, effects: { magic_power: 0.05 } },
          { id: 'efficiency', name: 'Mana Efficiency', description: 'Reduce spell costs', level: 0, maxLevel: 15, experience: 0, effects: { mana_efficiency: 0.03 } },
          { id: 'range', name: 'Extended Reach', description: 'Increase spell range', level: 0, maxLevel: 10, experience: 0, effects: { spell_range: 0.1 } }
        ]
      },
      {
        id: 'elemental_mastery',
        name: 'Elemental Mastery',
        description: 'Advanced elemental control',
        category: 'magic',
        level: 0,
        experience: 0,
        prerequisites: ['elemental_basics'],
        unlocked: false,
        branches: [
          { id: 'combo_casting', name: 'Spell Combinations', description: 'Chain spells together', level: 0, maxLevel: 8, experience: 0, effects: { combo_bonus: 0.15 } },
          { id: 'elemental_focus', name: 'Element Focus', description: 'Specialized elemental power', level: 0, maxLevel: 12, experience: 0, effects: { element_bonus: 0.1 } },
          { id: 'metamagic', name: 'Metamagic Mastery', description: 'Modify spell properties', level: 0, maxLevel: 6, experience: 0, effects: { metamagic: 1 } }
        ]
      }
    ]);
    
    // Building Action Tree
    this.trees.set('building', [
      {
        id: 'basic_construction',
        name: 'Basic Construction',
        description: 'Fundamental building skills',
        category: 'building',
        level: 0,
        experience: 0,
        prerequisites: [],
        unlocked: true,
        branches: [
          { id: 'efficiency', name: 'Build Speed', description: 'Construct faster', level: 0, maxLevel: 10, experience: 0, effects: { build_speed: 0.1 } },
          { id: 'quality', name: 'Craftsmanship', description: 'Higher quality builds', level: 0, maxLevel: 15, experience: 0, effects: { build_quality: 0.05 } },
          { id: 'durability', name: 'Sturdy Construction', description: 'More durable structures', level: 0, maxLevel: 12, experience: 0, effects: { durability: 0.08 } }
        ]
      }
    ]);
    
    // Interaction Action Tree
    this.trees.set('interaction', [
      {
        id: 'basic_interaction',
        name: 'Basic Interaction',
        description: 'Fundamental interaction skills',
        category: 'interaction',
        level: 0,
        experience: 0,
        prerequisites: [],
        unlocked: true,
        branches: [
          { id: 'perception', name: 'Keen Observation', description: 'Notice more details', level: 0, maxLevel: 10, experience: 0, effects: { perception: 0.1 } },
          { id: 'intuition', name: 'Natural Intuition', description: 'Better interaction results', level: 0, maxLevel: 8, experience: 0, effects: { intuition: 0.12 } },
          { id: 'empathy', name: 'Empathic Connection', description: 'Understand others better', level: 0, maxLevel: 6, experience: 0, effects: { empathy: 0.15 } }
        ]
      }
    ]);
    
    // Exploration Action Tree
    this.trees.set('exploration', [
      {
        id: 'basic_exploration',
        name: 'Basic Exploration',
        description: 'Fundamental exploration skills',
        category: 'exploration',
        level: 0,
        experience: 0,
        prerequisites: [],
        unlocked: true,
        branches: [
          { id: 'navigation', name: 'Pathfinding', description: 'Never get lost', level: 0, maxLevel: 8, experience: 0, effects: { navigation: 0.12 } },
          { id: 'discovery', name: 'Hidden Secrets', description: 'Find hidden areas', level: 0, maxLevel: 10, experience: 0, effects: { discovery: 0.1 } },
          { id: 'survival', name: 'Wilderness Survival', description: 'Thrive in nature', level: 0, maxLevel: 12, experience: 0, effects: { survival: 0.08 } }
        ]
      }
    ]);
  }
  
  addExperienceToAction(category: string, actionName: string, experience: number): void {
    const tree = this.trees.get(category);
    if (!tree) return;
    
    // Find the relevant action node and add experience
    tree.forEach(node => {
      node.branches.forEach(branch => {
        if (branch.name.toLowerCase().includes(actionName.toLowerCase()) || 
            actionName.toLowerCase().includes(branch.name.toLowerCase())) {
          branch.experience += experience;
          
          // Level up if enough experience
          const expNeeded = (branch.level + 1) * 100; // 100 exp per level
          if (branch.experience >= expNeeded && branch.level < branch.maxLevel) {
            branch.level++;
            branch.experience = 0;
            console.log(`Branch ${branch.name} leveled up to ${branch.level}!`);
          }
        }
      });
    });
  }
  
  getActionTree(category: string): ActionNode[] {
    return this.trees.get(category) || [];
  }
  
  getAllTrees(): Map<string, ActionNode[]> {
    return this.trees;
  }
  
  getActionEffects(category: string): Record<string, number> {
    const tree = this.trees.get(category);
    if (!tree) return {};
    
    const effects: Record<string, number> = {};
    
    tree.forEach(node => {
      node.branches.forEach(branch => {
        Object.entries(branch.effects).forEach(([effect, baseValue]) => {
          const totalValue = baseValue * branch.level;
          effects[effect] = (effects[effect] || 0) + totalValue;
        });
      });
    });
    
    return effects;
  }
  
  unlockNode(category: string, nodeId: string): boolean {
    const tree = this.trees.get(category);
    if (!tree) return false;
    
    const node = tree.find(n => n.id === nodeId);
    if (!node) return false;
    
    // Check prerequisites
    const prerequisitesMet = node.prerequisites.every(prereqId => {
      const prereq = tree.find(n => n.id === prereqId);
      return prereq && prereq.unlocked;
    });
    
    if (prerequisitesMet) {
      node.unlocked = true;
      console.log(`Unlocked action node: ${node.name}`);
      return true;
    }
    
    return false;
  }
}

// Global action tree system instance
export const actionTreeSystem = new ActionTreeSystem();
