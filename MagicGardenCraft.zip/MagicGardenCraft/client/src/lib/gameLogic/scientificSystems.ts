// Scientific Systems for GARDEN
// Implements realistic botanical, ecological, and atmospheric models

export interface PlantScience {
  species: string;
  geneticTraits: GeneticProfile;
  growthStages: GrowthStage[];
  nutritionalNeeds: NutrientProfile;
  environmentalTolerances: EnvironmentalLimits;
  photosynthesisRate: number;
  carbonSequestration: number;
}

export interface GeneticProfile {
  dominantAlleles: string[];
  recessiveAlleles: string[];
  hybridViability: number;
  mutationRate: number;
  adaptabilityScore: number;
}

export interface GrowthStage {
  name: string;
  durationDays: number;
  energyRequirement: number;
  vulnerabilities: string[];
  outputs: ResourceOutput[];
}

export interface NutrientProfile {
  nitrogen: number;  // NPK ratios
  phosphorus: number;
  potassium: number;
  micronutrients: Record<string, number>;
  waterRequirement: number; // L/day
  soilPH: [number, number]; // optimal range
}

export interface EnvironmentalLimits {
  temperatureRange: [number, number]; // Celsius
  humidityRange: [number, number]; // percentage
  lightRequirement: number; // lux
  co2Tolerance: number; // ppm
  soilTypes: string[];
}

export interface ResourceOutput {
  type: 'oxygen' | 'biomass' | 'fruit' | 'seeds' | 'nectar';
  quantity: number;
  quality: number;
}

// Atmospheric Science Model
export interface AtmosphericConditions {
  co2Level: number; // parts per million
  oxygenLevel: number; // percentage
  nitrogenLevel: number; // percentage
  pressureKPa: number;
  dewPoint: number;
  uvIndex: number;
  airQualityIndex: number;
}

// Soil Science Model
export interface SoilComposition {
  phLevel: number;
  organicMatter: number; // percentage
  clayContent: number;
  siltContent: number;
  sandContent: number;
  cationExchangeCapacity: number;
  microbialActivity: number;
  nutrients: Record<string, number>;
}

// Ecological Interactions
export interface EcosystemWeb {
  pollinators: PollinatorSpecies[];
  decomposers: DecomposerSpecies[];
  predators: PredatorSpecies[];
  symbioticRelationships: SymbioticPair[];
  competitionMatrix: number[][];
}

export interface PollinatorSpecies {
  name: string;
  flowerPreferences: string[];
  activeHours: [number, number];
  seasonalActivity: number[];
  pollinationEfficiency: number;
}

export interface DecomposerSpecies {
  name: string;
  decompositionRate: number;
  temperatureOptimum: number;
  substratePreferences: string[];
  nutrientRelease: Record<string, number>;
}

export interface PredatorSpecies {
  name: string;
  preySpecies: string[];
  huntingEfficiency: number;
  populationControl: number;
}

export interface SymbioticPair {
  species1: string;
  species2: string;
  relationship: 'mutualism' | 'commensalism' | 'parasitism';
  benefit1: number;
  benefit2: number;
}

// Climate Science Integration
export interface ClimateModel {
  greenhouseEffect: number;
  albedoEffect: number;
  evapotranspiration: number;
  precipitation: number;
  seasonalVariation: number[];
  climateZone: string;
  microclimates: Microclimate[];
}

export interface Microclimate {
  location: [number, number, number];
  temperatureDelta: number;
  humidityDelta: number;
  windSpeed: number;
  lightLevel: number;
}

// Realistic Plant Growth Algorithm
export class ScientificGrowthModel {
  calculateGrowthRate(
    plant: PlantScience,
    environment: AtmosphericConditions,
    soil: SoilComposition,
    timeOfDay: number,
    season: number
  ): number {
    // Light-limited photosynthesis (Michaelis-Menten kinetics)
    const lightLevel = this.calculateLightLevel(timeOfDay, season);
    const photosynthesisRate = (plant.photosynthesisRate * lightLevel) / 
                              (plant.environmentalTolerances.lightRequirement + lightLevel);
    
    // Temperature stress factor (Q10 temperature coefficient)
    const tempOptimum = (plant.environmentalTolerances.temperatureRange[0] + 
                        plant.environmentalTolerances.temperatureRange[1]) / 2;
    const tempStress = Math.exp(-Math.pow(environment.pressureKPa - tempOptimum, 2) / 100);
    
    // Nutrient limitation (Liebig's law of the minimum)
    const nutrientLimitation = Math.min(
      soil.nutrients.nitrogen / plant.nutritionalNeeds.nitrogen,
      soil.nutrients.phosphorus / plant.nutritionalNeeds.phosphorus,
      soil.nutrients.potassium / plant.nutritionalNeeds.potassium
    );
    
    // Water stress
    const waterAvailability = Math.min(1, soil.nutrients.water / plant.nutritionalNeeds.waterRequirement);
    
    // CO2 fertilization effect
    const co2Effect = 1 + (environment.co2Level - 400) * 0.0003; // 30% increase at 1000ppm
    
    return photosynthesisRate * tempStress * nutrientLimitation * waterAvailability * co2Effect;
  }
  
  private calculateLightLevel(timeOfDay: number, season: number): number {
    // Solar elevation angle calculation
    const solarDeclination = 23.45 * Math.sin((360 * (284 + season)) * Math.PI / 180 / 365);
    const hourAngle = 15 * (timeOfDay - 12);
    const latitude = 40; // degrees
    
    const solarElevation = Math.asin(
      Math.sin(solarDeclination * Math.PI / 180) * Math.sin(latitude * Math.PI / 180) +
      Math.cos(solarDeclination * Math.PI / 180) * Math.cos(latitude * Math.PI / 180) * 
      Math.cos(hourAngle * Math.PI / 180)
    );
    
    return Math.max(0, Math.sin(solarElevation)) * 100000; // Convert to lux
  }
}

// Ecosystem Services Calculation
export class EcosystemServices {
  calculateCarbonSequestration(plants: PlantScience[]): number {
    return plants.reduce((total, plant) => total + plant.carbonSequestration, 0);
  }
  
  calculateOxygenProduction(plants: PlantScience[]): number {
    return plants.reduce((total, plant) => {
      const oxygenOutput = plant.growthStages.reduce((stageTotal, stage) => {
        const oxygenResource = stage.outputs.find(output => output.type === 'oxygen');
        return stageTotal + (oxygenResource?.quantity || 0);
      }, 0);
      return total + oxygenOutput;
    }, 0);
  }
  
  calculateBiodiversityIndex(ecosystem: EcosystemWeb): number {
    // Shannon diversity index
    const totalSpecies = ecosystem.pollinators.length + 
                        ecosystem.decomposers.length + 
                        ecosystem.predators.length;
    
    const proportions = [
      ecosystem.pollinators.length / totalSpecies,
      ecosystem.decomposers.length / totalSpecies,
      ecosystem.predators.length / totalSpecies
    ];
    
    return -proportions.reduce((sum, p) => sum + (p > 0 ? p * Math.log(p) : 0), 0);
  }
}

// Scientific Data Integration
export const REAL_PLANT_DATABASE: Record<string, PlantScience> = {
  'tomato_lycopersicon': {
    species: 'Solanum lycopersicum',
    geneticTraits: {
      dominantAlleles: ['R_disease_resistance', 'T_determinate_growth'],
      recessiveAlleles: ['r_susceptible', 't_indeterminate'],
      hybridViability: 0.95,
      mutationRate: 0.001,
      adaptabilityScore: 0.7
    },
    growthStages: [
      {
        name: 'Germination',
        durationDays: 7,
        energyRequirement: 10,
        vulnerabilities: ['damping_off', 'cold_stress'],
        outputs: []
      },
      {
        name: 'Vegetative',
        durationDays: 45,
        energyRequirement: 100,
        vulnerabilities: ['aphids', 'nutrient_deficiency'],
        outputs: [{ type: 'oxygen', quantity: 5, quality: 1 }]
      },
      {
        name: 'Flowering',
        durationDays: 20,
        energyRequirement: 80,
        vulnerabilities: ['blossom_end_rot', 'pollination_failure'],
        outputs: [
          { type: 'oxygen', quantity: 8, quality: 1 },
          { type: 'nectar', quantity: 2, quality: 0.8 }
        ]
      },
      {
        name: 'Fruiting',
        durationDays: 60,
        energyRequirement: 150,
        vulnerabilities: ['fruit_fly', 'cracking'],
        outputs: [
          { type: 'oxygen', quantity: 10, quality: 1 },
          { type: 'fruit', quantity: 50, quality: 0.9 },
          { type: 'seeds', quantity: 200, quality: 0.85 }
        ]
      }
    ],
    nutritionalNeeds: {
      nitrogen: 150,
      phosphorus: 50,
      potassium: 200,
      micronutrients: {
        calcium: 120,
        magnesium: 25,
        sulfur: 20,
        iron: 2,
        boron: 0.5
      },
      waterRequirement: 2.5,
      soilPH: [6.0, 6.8]
    },
    environmentalTolerances: {
      temperatureRange: [18, 29],
      humidityRange: [65, 75],
      lightRequirement: 30000,
      co2Tolerance: 1200,
      soilTypes: ['loam', 'sandy_loam', 'clay_loam']
    },
    photosynthesisRate: 25,
    carbonSequestration: 2.3
  }
};