interface XRPPriceData {
  price: number;
  change24h: number;
  changePercent24h: number;
  volume24h: number;
  marketCap: number;
  lastUpdated: number;
}

interface CoinGeckoResponse {
  ripple: {
    usd: number;
    usd_24h_change: number;
    usd_24h_vol: number;
    usd_market_cap: number;
  };
}

interface CryptoCompareResponse {
  USD: {
    PRICE: number;
    CHANGEPCT24HOUR: number;
    VOLUME24HOUR: number;
    MKTCAP: number;
  };
}

class XRPAPI {
  private lastFetchTime: number = 0;
  private cacheDuration: number = 60 * 1000; // 1 minute cache for crypto prices
  private cachedPrice: XRPPriceData | null = null;
  private apiKey: string;

  constructor() {
    this.apiKey = import.meta.env.VITE_CRYPTO_API_KEY || 'default_crypto_key';
  }

  async getCurrentPrice(): Promise<XRPPriceData> {
    const now = Date.now();
    
    // Return cached data if still fresh
    if (this.cachedPrice && (now - this.lastFetchTime) < this.cacheDuration) {
      return this.cachedPrice;
    }

    try {
      // Try CoinGecko first (free tier available)
      const priceData = await this.fetchFromCoinGecko();
      
      // Cache the result
      this.cachedPrice = priceData;
      this.lastFetchTime = now;
      
      console.log(`XRP price updated: $${priceData.price.toFixed(4)} (${priceData.changePercent24h.toFixed(2)}%)`);
      
      return priceData;
      
    } catch (error) {
      console.error('Primary XRP API failed, trying backup:', error);
      
      try {
        // Fallback to CryptoCompare
        const priceData = await this.fetchFromCryptoCompare();
        
        this.cachedPrice = priceData;
        this.lastFetchTime = now;
        
        return priceData;
        
      } catch (backupError) {
        console.error('Backup XRP API also failed:', backupError);
        
        // Return cached data if available, otherwise fallback
        if (this.cachedPrice) {
          console.log('Using cached XRP price data');
          return this.cachedPrice;
        }
        
        // Final fallback with clear error indication
        const fallbackPrice: XRPPriceData = {
          price: 0.5, // Conservative fallback price
          change24h: 0,
          changePercent24h: 0,
          volume24h: 0,
          marketCap: 0,
          lastUpdated: now
        };
        
        this.cachedPrice = fallbackPrice;
        return fallbackPrice;
      }
    }
  }

  private async fetchFromCoinGecko(): Promise<XRPPriceData> {
    const response = await fetch(
      'https://api.coingecko.com/api/v3/simple/price?ids=ripple&vs_currencies=usd&include_24hr_change=true&include_24hr_vol=true&include_market_cap=true',
      {
        headers: {
          'Accept': 'application/json',
        }
      }
    );

    if (!response.ok) {
      throw new Error(`CoinGecko API error: ${response.status} ${response.statusText}`);
    }

    const data: CoinGeckoResponse = await response.json();
    
    if (!data.ripple) {
      throw new Error('Invalid response from CoinGecko API');
    }

    return {
      price: data.ripple.usd,
      change24h: (data.ripple.usd * data.ripple.usd_24h_change) / 100,
      changePercent24h: data.ripple.usd_24h_change,
      volume24h: data.ripple.usd_24h_vol,
      marketCap: data.ripple.usd_market_cap,
      lastUpdated: Date.now()
    };
  }

  private async fetchFromCryptoCompare(): Promise<XRPPriceData> {
    const response = await fetch(
      `https://min-api.cryptocompare.com/data/pricemultifull?fsyms=XRP&tsyms=USD&api_key=${this.apiKey}`,
      {
        headers: {
          'Accept': 'application/json',
        }
      }
    );

    if (!response.ok) {
      throw new Error(`CryptoCompare API error: ${response.status} ${response.statusText}`);
    }

    const data = await response.json();
    
    if (!data.RAW?.XRP?.USD) {
      throw new Error('Invalid response from CryptoCompare API');
    }

    const xrpData = data.RAW.XRP.USD;

    return {
      price: xrpData.PRICE,
      change24h: (xrpData.PRICE * xrpData.CHANGEPCT24HOUR) / 100,
      changePercent24h: xrpData.CHANGEPCT24HOUR,
      volume24h: xrpData.VOLUME24HOUR,
      marketCap: xrpData.MKTCAP,
      lastUpdated: Date.now()
    };
  }

  // Check for market crash conditions (15% drop triggers emergency protocols)
  checkMarketCrash(currentPrice: XRPPriceData, previousPrice?: XRPPriceData): boolean {
    if (!previousPrice) return false;
    
    const priceDropPercent = ((previousPrice.price - currentPrice.price) / previousPrice.price) * 100;
    
    if (priceDropPercent >= 15) {
      console.warn(`🚨 MARKET CRASH DETECTED: XRP dropped ${priceDropPercent.toFixed(2)}%`);
      this.triggerEmergencyProtocols(priceDropPercent);
      return true;
    }
    
    return false;
  }

  // Check for market surge conditions (30% increase triggers development notifications)
  checkMarketSurge(currentPrice: XRPPriceData, referencePrice?: XRPPriceData): boolean {
    if (!referencePrice) return false;
    
    const priceIncreasePercent = ((currentPrice.price - referencePrice.price) / referencePrice.price) * 100;
    
    if (priceIncreasePercent >= 30) {
      console.log(`🚀 MARKET SURGE DETECTED: XRP up ${priceIncreasePercent.toFixed(2)}%`);
      this.triggerSurgeNotifications(priceIncreasePercent);
      return true;
    }
    
    return false;
  }

  private triggerEmergencyProtocols(dropPercent: number): void {
    // In a real implementation, this would:
    // 1. Send email alerts to administrators
    // 2. Activate backup server systems
    // 3. Potentially shut down website if drop is severe
    // 4. Activate player rescue protocols
    
    console.log(`Activating emergency protocols for ${dropPercent.toFixed(2)}% market drop`);
    
    // Store emergency state
    localStorage.setItem('garden_market_emergency', JSON.stringify({
      timestamp: Date.now(),
      dropPercent,
      status: 'active'
    }));
  }

  private triggerSurgeNotifications(increasePercent: number): void {
    // In a real implementation, this would:
    // 1. Send development completion notifications
    // 2. Activate bonus events in-game
    // 3. Reduce shop prices significantly
    
    console.log(`Market surge benefits activated: ${increasePercent.toFixed(2)}% increase`);
    
    // Store surge state
    localStorage.setItem('garden_market_surge', JSON.stringify({
      timestamp: Date.now(),
      increasePercent,
      status: 'active'
    }));
  }

  // Get shop price multiplier based on XRP performance
  getShopPriceMultiplier(priceData: XRPPriceData): number {
    // Base multiplier is 1.0
    let multiplier = 1.0;
    
    // XRP up = shop prices down (inverse relationship)
    if (priceData.changePercent24h > 10) {
      multiplier = 0.7; // 30% discount for strong XRP performance
    } else if (priceData.changePercent24h > 5) {
      multiplier = 0.85; // 15% discount for good XRP performance
    } else if (priceData.changePercent24h > 0) {
      multiplier = 0.95; // 5% discount for positive XRP performance
    } else if (priceData.changePercent24h < -10) {
      multiplier = 1.3; // 30% markup for poor XRP performance
    } else if (priceData.changePercent24h < -5) {
      multiplier = 1.15; // 15% markup for negative XRP performance
    } else if (priceData.changePercent24h < 0) {
      multiplier = 1.05; // 5% markup for slightly negative XRP performance
    }
    
    return multiplier;
  }

  // Get XRP earning bonuses based on market conditions
  getEarningMultiplier(priceData: XRPPriceData): number {
    let multiplier = 1.0;
    
    // Higher volatility = higher earning potential (risk/reward)
    const volatility = Math.abs(priceData.changePercent24h);
    
    if (volatility > 15) {
      multiplier = 1.5; // High volatility bonus
    } else if (volatility > 10) {
      multiplier = 1.3; // Medium volatility bonus
    } else if (volatility > 5) {
      multiplier = 1.1; // Low volatility bonus
    }
    
    return multiplier;
  }

  // Historical price tracking for trend analysis
  async getHistoricalPrices(days: number = 30): Promise<{ timestamp: number; price: number }[]> {
    try {
      const response = await fetch(
        `https://api.coingecko.com/api/v3/coins/ripple/market_chart?vs_currency=usd&days=${days}`
      );
      
      if (!response.ok) {
        throw new Error('Failed to fetch historical data');
      }
      
      const data = await response.json();
      
      return data.prices.map(([timestamp, price]: [number, number]) => ({
        timestamp,
        price
      }));
      
    } catch (error) {
      console.error('Failed to fetch historical XRP prices:', error);
      return [];
    }
  }
}

// Export singleton instance
export const xrpAPI = new XRPAPI();

// Export types
export type { XRPPriceData };
