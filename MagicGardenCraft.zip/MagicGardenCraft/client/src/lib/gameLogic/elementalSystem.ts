export interface ElementInfo {
  name: string;
  color: string;
  branches: string[];
  oppositeElement?: string;
  strengths: string[];
  weaknesses: string[];
}

export const ELEMENTAL_SYSTEM: Record<string, ElementInfo> = {
  fire: {
    name: 'Fire',
    color: '#ff4444',
    branches: ['Destruction', 'Healing Flames', 'Forge Magic', 'Phoenix Arts', 'Solar Control'],
    oppositeElement: 'water',
    strengths: ['earth', 'air'],
    weaknesses: ['water']
  },
  water: {
    name: 'Water',
    color: '#4444ff',
    branches: ['Tidal Force', 'Healing Springs', 'Ice Mastery', 'Storm Calling', 'Purification'],
    oppositeElement: 'fire',
    strengths: ['fire', 'earth'],
    weaknesses: ['air']
  },
  earth: {
    name: 'Earth',
    color: '#44ff44',
    branches: ['Stone Shaping', 'Plant Growth', 'Metal Forging', 'Seismic Control', 'Crystal Arts'],
    oppositeElement: 'air',
    strengths: ['air', 'water'],
    weaknesses: ['fire']
  },
  air: {
    name: 'Air',
    color: '#ffff44',
    branches: ['Wind Control', 'Lightning Strike', 'Weather Mastery', 'Flight Magic', 'Sound Manipulation'],
    oppositeElement: 'earth',
    strengths: ['water', 'fire'],
    weaknesses: ['earth']
  },
  shadow: {
    name: 'Shadow',
    color: '#444444',
    branches: ['Void Walking', 'Illusion Casting', 'Dark Healing', 'Fear Control', 'Time Shadows'],
    oppositeElement: 'light',
    strengths: ['light'],
    weaknesses: ['light']
  },
  black: {
    name: 'Black Magic',
    color: '#000000',
    branches: ['All Branches', 'Supreme Power', 'Reality Control', 'Time Mastery', 'Void Dominion'],
    strengths: ['fire', 'water', 'earth', 'air', 'shadow', 'light'],
    weaknesses: []
  }
};

export function getElementalAdvantage(attacker: string, defender: string): number {
  const attackerInfo = ELEMENTAL_SYSTEM[attacker];
  const defenderInfo = ELEMENTAL_SYSTEM[defender];
  
  if (!attackerInfo || !defenderInfo) return 1.0;
  
  // Black magic supremacy
  if (attacker === 'black') return 2.0;
  if (defender === 'black') return 0.5;
  
  // Check strengths and weaknesses
  if (attackerInfo.strengths.includes(defender)) return 1.5;
  if (attackerInfo.weaknesses.includes(defender)) return 0.75;
  
  return 1.0;
}

export function calculateSpellPower(element: string, basePower: number, level: number): number {
  let power = basePower;
  
  // Level scaling
  power *= (1 + level * 0.1);
  
  // Element specific bonuses
  switch (element) {
    case 'black':
      power *= 5.0; // Black magic supremacy
      break;
    case 'fire':
      power *= 1.2; // Fire spells are naturally powerful
      break;
    case 'water':
      power *= 1.1; // Water spells have good healing
      break;
    case 'earth':
      power *= 1.15; // Earth spells are durable
      break;
    case 'air':
      power *= 1.25; // Air spells are fast and precise
      break;
    case 'shadow':
      power *= 1.3; // Shadow spells are mysterious and potent
      break;
  }
  
  return power;
}

export function getBranchSynergy(element: string, branch1: string, branch2: string): number {
  // Cross-branch synergy discoveries
  const synergies: Record<string, Record<string, number>> = {
    fire: {
      'Destruction_Forge Magic': 1.5,
      'Healing Flames_Phoenix Arts': 1.3,
      'Solar Control_Phoenix Arts': 1.4
    },
    water: {
      'Healing Springs_Purification': 1.4,
      'Ice Mastery_Storm Calling': 1.3,
      'Tidal Force_Storm Calling': 1.2
    },
    earth: {
      'Plant Growth_Crystal Arts': 1.3,
      'Stone Shaping_Seismic Control': 1.4,
      'Metal Forging_Crystal Arts': 1.2
    },
    air: {
      'Wind Control_Flight Magic': 1.5,
      'Lightning Strike_Weather Mastery': 1.4,
      'Sound Manipulation_Lightning Strike': 1.2
    },
    shadow: {
      'Void Walking_Time Shadows': 1.6,
      'Illusion Casting_Fear Control': 1.3,
      'Dark Healing_Void Walking': 1.2
    },
    black: {
      // Black magic has synergy with everything
      'All_Branches': 2.0
    }
  };
  
  const elementSynergies = synergies[element];
  if (!elementSynergies) return 1.0;
  
  const synergyKey = `${branch1}_${branch2}`;
  const reverseSynergyKey = `${branch2}_${branch1}`;
  
  return elementSynergies[synergyKey] || elementSynergies[reverseSynergyKey] || 1.0;
}

export function isBlackMagicRoll(): boolean {
  // Ultra-rare black magic chance: 0.000000001%
  return Math.random() < 0.000000001;
}

export function getSpectrumOpposite(element: string): string {
  const opposites: Record<string, string> = {
    'fire': 'water',
    'water': 'fire',
    'earth': 'air',
    'air': 'earth',
    'shadow': 'light',
    'light': 'shadow',
    'black': 'white' // Theoretical opposite
  };
  
  return opposites[element] || element;
}
