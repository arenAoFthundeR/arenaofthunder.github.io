interface WeatherData {
  condition: 'sunny' | 'cloudy' | 'rain' | 'snow' | 'storm';
  temperature: number;
  humidity: number;
  windSpeed: number;
  description: string;
  location: string;
}

interface WeatherAPIResponse {
  current: {
    temp_f: number;
    humidity: number;
    wind_mph: number;
    condition: {
      text: string;
      code: number;
    };
  };
  location: {
    name: string;
    region: string;
    country: string;
  };
}

class WeatherAPI {
  private apiKey: string;
  private baseUrl: string;
  private lastFetchTime: number = 0;
  private cacheDuration: number = 5 * 60 * 1000; // 5 minutes cache
  private cachedWeather: WeatherData | null = null;

  constructor() {
    // Get API key from environment variables with fallback
    this.apiKey = import.meta.env.VITE_WEATHER_API_KEY || 'default_weather_key';
    this.baseUrl = 'https://api.weatherapi.com/v1/current.json';
  }

  private mapConditionToGame(conditionCode: number, conditionText: string): 'sunny' | 'cloudy' | 'rain' | 'snow' | 'storm' {
    // Map weather API condition codes to game conditions
    if (conditionCode === 1000) return 'sunny'; // Sunny
    if ([1003, 1006, 1009].includes(conditionCode)) return 'cloudy'; // Cloudy variations
    if ([1063, 1150, 1153, 1180, 1183, 1186, 1189, 1192, 1195, 1198, 1201, 1240, 1243, 1246].includes(conditionCode)) return 'rain';
    if ([1066, 1069, 1072, 1114, 1117, 1168, 1171, 1204, 1207, 1210, 1213, 1216, 1219, 1222, 1225, 1237, 1249, 1252, 1255, 1258, 1261, 1264].includes(conditionCode)) return 'snow';
    if ([1087, 1273, 1276, 1279, 1282].includes(conditionCode)) return 'storm'; // Thunder conditions

    // Fallback based on text
    const lowerText = conditionText.toLowerCase();
    if (lowerText.includes('rain') || lowerText.includes('drizzle') || lowerText.includes('shower')) return 'rain';
    if (lowerText.includes('snow') || lowerText.includes('blizzard') || lowerText.includes('sleet')) return 'snow';
    if (lowerText.includes('thunder') || lowerText.includes('storm')) return 'storm';
    if (lowerText.includes('cloud') || lowerText.includes('overcast')) return 'cloudy';
    
    return 'sunny'; // Default fallback
  }

  async getCurrentWeather(location: string = 'auto:ip'): Promise<WeatherData> {
    const now = Date.now();
    
    // Return cached data if still fresh
    if (this.cachedWeather && (now - this.lastFetchTime) < this.cacheDuration) {
      return this.cachedWeather;
    }

    try {
      const response = await fetch(
        `${this.baseUrl}?key=${this.apiKey}&q=${encodeURIComponent(location)}&aqi=no`
      );

      if (!response.ok) {
        throw new Error(`Weather API error: ${response.status} ${response.statusText}`);
      }

      const data: WeatherAPIResponse = await response.json();

      const weatherData: WeatherData = {
        condition: this.mapConditionToGame(data.current.condition.code, data.current.condition.text),
        temperature: Math.round(data.current.temp_f),
        humidity: data.current.humidity,
        windSpeed: Math.round(data.current.wind_mph),
        description: data.current.condition.text,
        location: `${data.location.name}, ${data.location.region}`
      };

      // Cache the result
      this.cachedWeather = weatherData;
      this.lastFetchTime = now;

      console.log(`Weather updated for ${weatherData.location}: ${weatherData.condition}, ${weatherData.temperature}°F`);
      
      return weatherData;

    } catch (error) {
      console.error('Failed to fetch weather data:', error);
      
      // Return fallback weather data with clear error indication
      const fallbackWeather: WeatherData = {
        condition: 'cloudy',
        temperature: 65,
        humidity: 50,
        windSpeed: 5,
        description: 'Weather data unavailable',
        location: 'Unknown Location'
      };

      // Cache fallback for a shorter duration
      if (!this.cachedWeather) {
        this.cachedWeather = fallbackWeather;
        this.lastFetchTime = now - (this.cacheDuration - 60000); // Expire in 1 minute for retry
      }

      return this.cachedWeather || fallbackWeather;
    }
  }

  // Get weather forecast for future seasonal events
  async getWeatherForecast(days: number = 7): Promise<WeatherData[]> {
    try {
      const response = await fetch(
        `https://api.weatherapi.com/v1/forecast.json?key=${this.apiKey}&q=auto:ip&days=${days}&aqi=no&alerts=no`
      );

      if (!response.ok) {
        throw new Error(`Weather forecast API error: ${response.status}`);
      }

      const data = await response.json();
      
      return data.forecast.forecastday.map((day: any) => ({
        condition: this.mapConditionToGame(day.day.condition.code, day.day.condition.text),
        temperature: Math.round(day.day.avgtemp_f),
        humidity: day.day.avghumidity,
        windSpeed: Math.round(day.day.maxwind_mph),
        description: day.day.condition.text,
        location: data.location.name
      }));

    } catch (error) {
      console.error('Failed to fetch weather forecast:', error);
      return [];
    }
  }

  // Check for extreme weather events that affect game mechanics
  isExtremeWeather(weather: WeatherData): boolean {
    return (
      weather.condition === 'storm' ||
      weather.windSpeed > 25 ||
      weather.temperature < 20 ||
      weather.temperature > 100
    );
  }

  // Get weather-based bonuses for game mechanics
  getWeatherGameEffects(weather: WeatherData): {
    gardenGrowthMultiplier: number;
    magicPowerBonus: number;
    xrpEarningBonus: number;
    elementalAffinityBonus: Record<string, number>;
  } {
    const effects = {
      gardenGrowthMultiplier: 1.0,
      magicPowerBonus: 0,
      xrpEarningBonus: 0,
      elementalAffinityBonus: {
        fire: 0,
        water: 0,
        earth: 0,
        air: 0,
        shadow: 0,
        black: 0.1 // Black magic always gets slight bonus
      }
    };

    switch (weather.condition) {
      case 'sunny':
        effects.gardenGrowthMultiplier = 1.2;
        effects.magicPowerBonus = 10;
        effects.xrpEarningBonus = 0.05;
        effects.elementalAffinityBonus.fire = 0.15;
        break;
        
      case 'rain':
        effects.gardenGrowthMultiplier = 1.3;
        effects.magicPowerBonus = 5;
        effects.xrpEarningBonus = 0.03;
        effects.elementalAffinityBonus.water = 0.2;
        effects.elementalAffinityBonus.earth = 0.1;
        break;
        
      case 'snow':
        effects.gardenGrowthMultiplier = 0.9;
        effects.magicPowerBonus = 15;
        effects.xrpEarningBonus = 0.02;
        effects.elementalAffinityBonus.water = 0.25; // Ice mastery
        effects.elementalAffinityBonus.air = 0.1;
        break;
        
      case 'storm':
        effects.gardenGrowthMultiplier = 1.15;
        effects.magicPowerBonus = 25;
        effects.xrpEarningBonus = 0.08;
        effects.elementalAffinityBonus.air = 0.3; // Lightning
        effects.elementalAffinityBonus.water = 0.15;
        break;
        
      case 'cloudy':
        effects.gardenGrowthMultiplier = 1.0;
        effects.magicPowerBonus = 8;
        effects.xrpEarningBonus = 0.01;
        effects.elementalAffinityBonus.shadow = 0.15;
        break;
    }

    // Temperature-based modifications
    if (weather.temperature > 80) {
      effects.elementalAffinityBonus.fire += 0.1;
    } else if (weather.temperature < 40) {
      effects.elementalAffinityBonus.water += 0.1; // Ice effects
    }

    // Humidity effects
    if (weather.humidity > 70) {
      effects.elementalAffinityBonus.water += 0.05;
      effects.gardenGrowthMultiplier += 0.05;
    }

    // Wind speed effects
    if (weather.windSpeed > 15) {
      effects.elementalAffinityBonus.air += 0.1;
    }

    return effects;
  }
}

// Export singleton instance
export const weatherAPI = new WeatherAPI();

// Export types
export type { WeatherData };
