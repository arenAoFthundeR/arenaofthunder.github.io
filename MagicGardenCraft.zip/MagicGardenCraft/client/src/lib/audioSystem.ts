import { create } from 'zustand';

interface AudioState {
  // Audio elements
  backgroundMusic: HTMLAudioElement | null;
  voiceActing: HTMLAudioElement | null;
  soundEffects: Map<string, HTMLAudioElement>;
  
  // Audio settings
  isMuted: boolean;
  masterVolume: number;
  musicVolume: number;
  sfxVolume: number;
  voiceVolume: number;
  
  // Dynamic music system
  currentMusicTheme: string;
  musicLayers: Map<string, HTMLAudioElement>;
  
  // Voice acting system
  currentVoiceLine: string | null;
  voiceQueue: string[];
  
  // Actions
  setMasterVolume: (volume: number) => void;
  setMusicVolume: (volume: number) => void;
  setSFXVolume: (volume: number) => void;
  setVoiceVolume: (volume: number) => void;
  toggleMute: () => void;
  
  // Music system
  playBackgroundMusic: (theme: string) => void;
  stopBackgroundMusic: () => void;
  changeMusicTheme: (theme: string, element?: string) => void;
  addMusicLayer: (layerName: string) => void;
  removeMusicLayer: (layerName: string) => void;
  
  // Sound effects
  playSoundEffect: (soundName: string) => void;
  loadSoundEffect: (soundName: string, audioPath: string) => void;
  
  // Voice acting
  playVoiceLine: (voiceId: string, text: string) => void;
  queueVoiceLine: (voiceId: string, text: string) => void;
  stopVoice: () => void;
}

class AudioManager {
  private audioContext: AudioContext | null = null;
  private masterGainNode: GainNode | null = null;
  private musicGainNode: GainNode | null = null;
  private sfxGainNode: GainNode | null = null;
  private voiceGainNode: GainNode | null = null;

  constructor() {
    this.initializeAudioContext();
  }

  private async initializeAudioContext(): Promise<void> {
    try {
      this.audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();
      
      // Create gain nodes for volume control
      this.masterGainNode = this.audioContext.createGain();
      this.musicGainNode = this.audioContext.createGain();
      this.sfxGainNode = this.audioContext.createGain();
      this.voiceGainNode = this.audioContext.createGain();
      
      // Connect gain nodes
      this.musicGainNode.connect(this.masterGainNode);
      this.sfxGainNode.connect(this.masterGainNode);
      this.voiceGainNode.connect(this.masterGainNode);
      this.masterGainNode.connect(this.audioContext.destination);
      
      console.log('Audio system initialized successfully');
    } catch (error) {
      console.error('Failed to initialize audio system:', error);
    }
  }

  async resumeAudioContext(): Promise<void> {
    if (this.audioContext && this.audioContext.state === 'suspended') {
      await this.audioContext.resume();
    }
  }

  setGainNodeVolume(gainNode: GainNode | null, volume: number): void {
    if (gainNode) {
      gainNode.gain.value = Math.max(0, Math.min(1, volume));
    }
  }
}

const audioManager = new AudioManager();

export const useAudioSystem = create<AudioState>((set, get) => ({
  // Audio elements
  backgroundMusic: null,
  voiceActing: null,
  soundEffects: new Map(),
  
  // Audio settings
  isMuted: false,
  masterVolume: 0.7,
  musicVolume: 0.5,
  sfxVolume: 0.8,
  voiceVolume: 0.9,
  
  // Dynamic music system
  currentMusicTheme: 'garden_ambient',
  musicLayers: new Map(),
  
  // Voice acting system
  currentVoiceLine: null,
  voiceQueue: [],
  
  setMasterVolume: (volume: number) => {
    set({ masterVolume: volume });
    audioManager.setGainNodeVolume(audioManager.masterGainNode, volume);
  },
  
  setMusicVolume: (volume: number) => {
    set({ musicVolume: volume });
    audioManager.setGainNodeVolume(audioManager.musicGainNode, volume);
  },
  
  setSFXVolume: (volume: number) => {
    set({ sfxVolume: volume });
    audioManager.setGainNodeVolume(audioManager.sfxGainNode, volume);
  },
  
  setVoiceVolume: (volume: number) => {
    set({ voiceVolume: volume });
    audioManager.setGainNodeVolume(audioManager.voiceGainNode, volume);
  },
  
  toggleMute: () => {
    const { isMuted } = get();
    const newMutedState = !isMuted;
    set({ isMuted: newMutedState });
    
    // Mute/unmute all audio
    audioManager.setGainNodeVolume(
      audioManager.masterGainNode, 
      newMutedState ? 0 : get().masterVolume
    );
    
    console.log(`Audio ${newMutedState ? 'muted' : 'unmuted'}`);
  },
  
  playBackgroundMusic: (theme: string) => {
    const state = get();
    
    // Stop current background music
    if (state.backgroundMusic) {
      state.backgroundMusic.pause();
      state.backgroundMusic.currentTime = 0;
    }
    
    // Load and play new theme
    const musicPath = `/sounds/music/${theme}.mp3`;
    const audio = new Audio(musicPath);
    audio.loop = true;
    audio.volume = state.isMuted ? 0 : state.musicVolume;
    
    audio.play().catch(error => {
      console.log(`Failed to play background music: ${error}`);
    });
    
    set({ 
      backgroundMusic: audio,
      currentMusicTheme: theme 
    });
  },
  
  stopBackgroundMusic: () => {
    const { backgroundMusic } = get();
    if (backgroundMusic) {
      backgroundMusic.pause();
      backgroundMusic.currentTime = 0;
    }
    set({ backgroundMusic: null });
  },
  
  changeMusicTheme: (theme: string, element?: string) => {
    let musicTheme = theme;
    
    // Elemental-specific music themes
    if (element) {
      musicTheme = `${theme}_${element}`;
    }
    
    // Dynamic music based on time of day
    const hour = new Date().getHours();
    if (hour >= 22 || hour <= 6) {
      musicTheme += '_night';
    } else if (hour >= 6 && hour <= 12) {
      musicTheme += '_morning';
    } else if (hour >= 18 && hour <= 22) {
      musicTheme += '_evening';
    }
    
    get().playBackgroundMusic(musicTheme);
  },
  
  addMusicLayer: (layerName: string) => {
    const state = get();
    
    if (state.musicLayers.has(layerName)) {
      return; // Layer already active
    }
    
    const layerPath = `/sounds/music/layers/${layerName}.mp3`;
    const layerAudio = new Audio(layerPath);
    layerAudio.loop = true;
    layerAudio.volume = state.isMuted ? 0 : state.musicVolume * 0.6; // Layers are quieter
    
    layerAudio.play().catch(error => {
      console.log(`Failed to play music layer ${layerName}: ${error}`);
    });
    
    state.musicLayers.set(layerName, layerAudio);
    set({ musicLayers: new Map(state.musicLayers) });
  },
  
  removeMusicLayer: (layerName: string) => {
    const state = get();
    const layer = state.musicLayers.get(layerName);
    
    if (layer) {
      layer.pause();
      layer.currentTime = 0;
      state.musicLayers.delete(layerName);
      set({ musicLayers: new Map(state.musicLayers) });
    }
  },
  
  playSoundEffect: (soundName: string) => {
    const state = get();
    
    if (state.isMuted) {
      return;
    }
    
    let audio = state.soundEffects.get(soundName);
    
    if (!audio) {
      // Load sound effect if not already loaded
      const soundPath = `/sounds/sfx/${soundName}.mp3`;
      audio = new Audio(soundPath);
      state.soundEffects.set(soundName, audio);
      set({ soundEffects: new Map(state.soundEffects) });
    }
    
    // Clone audio for overlapping playback
    const audioClone = audio.cloneNode() as HTMLAudioElement;
    audioClone.volume = state.sfxVolume;
    
    audioClone.play().catch(error => {
      console.log(`Failed to play sound effect ${soundName}: ${error}`);
    });
  },
  
  loadSoundEffect: (soundName: string, audioPath: string) => {
    const state = get();
    const audio = new Audio(audioPath);
    state.soundEffects.set(soundName, audio);
    set({ soundEffects: new Map(state.soundEffects) });
  },
  
  playVoiceLine: async (voiceId: string, text: string) => {
    const state = get();
    
    if (state.isMuted) {
      console.log(`Voice line skipped (muted): ${text}`);
      return;
    }
    
    // Stop current voice line if playing
    if (state.voiceActing) {
      state.voiceActing.pause();
      state.voiceActing.currentTime = 0;
    }
    
    try {
      // In a real implementation, this would use text-to-speech or pre-recorded voice lines
      // For now, we'll use the Web Speech API for voice synthesis
      if ('speechSynthesis' in window) {
        const utterance = new SpeechSynthesisUtterance(text);
        
        // Configure voice based on voiceId
        const voices = speechSynthesis.getVoices();
        let selectedVoice = null;
        
        switch (voiceId) {
          case 'duel_master':
            selectedVoice = voices.find(voice => 
              voice.name.includes('Daniel') || voice.name.includes('Alex')
            ) || voices[0];
            utterance.pitch = 0.8;
            utterance.rate = 0.9;
            break;
          case 'fire_spirit':
            selectedVoice = voices.find(voice => 
              voice.name.includes('Samantha') || voice.name.includes('female')
            ) || voices[1];
            utterance.pitch = 1.2;
            utterance.rate = 1.1;
            break;
          case 'narrator':
          default:
            selectedVoice = voices.find(voice => 
              voice.name.includes('Google') || voice.name.includes('Microsoft')
            ) || voices[0];
            utterance.pitch = 1.0;
            utterance.rate = 1.0;
            break;
        }
        
        if (selectedVoice) {
          utterance.voice = selectedVoice;
        }
        
        utterance.volume = state.voiceVolume;
        
        utterance.onstart = () => {
          set({ currentVoiceLine: text });
        };
        
        utterance.onend = () => {
          set({ currentVoiceLine: null });
          
          // Process voice queue
          const { voiceQueue } = get();
          if (voiceQueue.length > 0) {
            const nextLine = voiceQueue.shift();
            if (nextLine) {
              const [nextVoiceId, nextText] = nextLine.split(':::');
              setTimeout(() => {
                get().playVoiceLine(nextVoiceId, nextText);
              }, 500); // Small delay between voice lines
            }
          }
        };
        
        speechSynthesis.speak(utterance);
        
      } else {
        console.log(`Voice acting not supported: ${text}`);
      }
      
    } catch (error) {
      console.error('Voice acting error:', error);
      set({ currentVoiceLine: null });
    }
  },
  
  queueVoiceLine: (voiceId: string, text: string) => {
    const state = get();
    const queueItem = `${voiceId}:::${text}`;
    
    if (state.currentVoiceLine) {
      // Add to queue if voice is currently playing
      set({ voiceQueue: [...state.voiceQueue, queueItem] });
    } else {
      // Play immediately if no voice is playing
      state.playVoiceLine(voiceId, text);
    }
  },
  
  stopVoice: () => {
    if ('speechSynthesis' in window) {
      speechSynthesis.cancel();
    }
    
    set({ 
      currentVoiceLine: null,
      voiceQueue: []
    });
  }
}));

// Initialize audio system on first user interaction
document.addEventListener('click', async () => {
  await audioManager.resumeAudioContext();
}, { once: true });

// Elemental soundscapes
export const ELEMENTAL_SOUNDSCAPES = {
  fire: {
    ambient: 'crackling_flames',
    magic: 'fire_spell',
    environment: 'desert_wind'
  },
  water: {
    ambient: 'flowing_water',
    magic: 'water_spell',
    environment: 'ocean_waves'
  },
  earth: {
    ambient: 'rustling_leaves',
    magic: 'earth_spell',
    environment: 'forest_sounds'
  },
  air: {
    ambient: 'wind_chimes',
    magic: 'air_spell',
    environment: 'mountain_winds'
  },
  shadow: {
    ambient: 'mysterious_whispers',
    magic: 'shadow_spell',
    environment: 'night_ambience'
  },
  black: {
    ambient: 'void_resonance',
    magic: 'black_magic_spell',
    environment: 'cosmic_void'
  }
};

// Voice character profiles
export const VOICE_CHARACTERS = {
  duel_master: {
    name: 'Duel Master',
    description: 'Mysterious cowboy with deep, commanding voice',
    catchphrases: [
      "Draw your cards, partner!",
      "The hat never lies!",
      "Victory comes to those who believe!",
      "Time to duel!"
    ]
  },
  fire_spirit: {
    name: 'Flame Guardian',
    description: 'Passionate fire elemental with warm, energetic voice',
    catchphrases: [
      "Feel the burn!",
      "Ignite your passion!",
      "The flames guide you!",
      "Burn bright!"
    ]
  },
  water_spirit: {
    name: 'Tide Keeper',
    description: 'Calm water elemental with flowing, soothing voice',
    catchphrases: [
      "Flow like water!",
      "Find your balance!",
      "The tide turns!",
      "Peace through flow!"
    ]
  }
};

export { audioManager };
