import { create } from "zustand";
import { subscribeWithSelector } from "zustand/middleware";

interface ElementBranch {
  name: string;
  level: number;
  experience: number;
  unlocked: boolean;
}

interface ElementState {
  selectedElement: string | null;
  magicPower: number;
  elementProgress: number;
  spellsKnown: string[];
  branches: ElementBranch[];
  isBlackMagic: boolean;
  spectrumsOpposite: boolean;
  
  // Actions
  setElement: (element: string) => void;
  castSpell: (spellName: string) => void;
  gainMagicExperience: (amount: number) => void;
  unlockBranch: (branchName: string) => void;
  upgradeBranch: (branchName: string) => void;
}

const ELEMENT_BRANCHES = {
  fire: ['Destruction', 'Healing Flames', 'Forge Magic', 'Phoenix Arts', 'Solar Control'],
  water: ['Tidal Force', 'Healing Springs', 'Ice Mastery', 'Storm Calling', 'Purification'],
  earth: ['Stone Shaping', 'Plant Growth', 'Metal Forging', 'Seismic Control', 'Crystal Arts'],
  air: ['Wind Control', 'Lightning Strike', 'Weather Mastery', 'Flight Magic', 'Sound Manipulation'],
  shadow: ['Void Walking', 'Illusion Casting', 'Dark Healing', 'Fear Control', 'Time Shadows'],
  black: ['All Branches', 'Supreme Power', 'Reality Control', 'Time Mastery', 'Void Dominion']
};

export const useElements = create<ElementState>()(
  subscribeWithSelector((set, get) => ({
    selectedElement: null,
    magicPower: 0,
    elementProgress: 0,
    spellsKnown: [],
    branches: [],
    isBlackMagic: false,
    spectrumsOpposite: Math.random() < 0.5, // 50/50 chance for spectrum opposition
    
    setElement: (element) => {
      const isBlack = element === 'black';
      const branches = ELEMENT_BRANCHES[element as keyof typeof ELEMENT_BRANCHES] || [];
      
      // Initialize branches
      const initialBranches: ElementBranch[] = branches.map((name, index) => ({
        name,
        level: 0,
        experience: 0,
        unlocked: index === 0 || isBlack // First branch unlocked, or all if black magic
      }));
      
      set({
        selectedElement: element,
        isBlackMagic: isBlack,
        branches: initialBranches,
        magicPower: isBlack ? 100 : 10, // Black magic starts at full power
        elementProgress: isBlack ? 25 : 0, // Black magic gets head start
        spellsKnown: isBlack ? ['Supreme Dominion', 'Reality Warp'] : ['Basic ' + element + ' Spell']
      });
      
      // Save element choice
      localStorage.setItem('garden_element', element);
      
      console.log(`Element set to: ${element}${isBlack ? ' (BLACK MAGIC!)' : ''}`);
    },
    
    castSpell: (spellName) => {
      const state = get();
      if (!state.selectedElement) return;
      
      // Gain experience from casting
      const expGain = state.isBlackMagic ? 10 : 5; // Black magic gains experience faster
      state.gainMagicExperience(expGain);
      
      console.log(`Cast spell: ${spellName}`);
    },
    
    gainMagicExperience: (amount) => {
      set((state) => {
        const multiplier = state.isBlackMagic ? 5 : 1; // Black magic supremacy
        const actualAmount = amount * multiplier;
        const newProgress = Math.min(state.elementProgress + (actualAmount / 10), 100);
        const newPower = Math.min(state.magicPower + (actualAmount / 5), 100);
        
        return {
          elementProgress: newProgress,
          magicPower: newPower
        };
      });
    },
    
    unlockBranch: (branchName) => {
      set((state) => {
        const updatedBranches = state.branches.map(branch =>
          branch.name === branchName ? { ...branch, unlocked: true } : branch
        );
        
        return { branches: updatedBranches };
      });
    },
    
    upgradeBranch: (branchName) => {
      set((state) => {
        const updatedBranches = state.branches.map(branch => {
          if (branch.name === branchName && branch.unlocked) {
            const newLevel = branch.level + 1;
            const newExp = branch.experience + 100;
            
            // Learn new spell at certain levels
            if (newLevel % 5 === 0) {
              const newSpell = `${branchName} Level ${newLevel}`;
              if (!state.spellsKnown.includes(newSpell)) {
                state.spellsKnown.push(newSpell);
              }
            }
            
            return {
              ...branch,
              level: newLevel,
              experience: newExp
            };
          }
          return branch;
        });
        
        return { branches: updatedBranches };
      });
    }
  }))
);

// Load saved element on initialization
const savedElement = localStorage.getItem('garden_element');
if (savedElement) {
  useElements.getState().setElement(savedElement);
}
