import { create } from "zustand";
import { subscribeWithSelector } from "zustand/middleware";

export type GamePhase = "element_selection" | "playing" | "paused";

interface GardenPlot {
  position: [number, number, number];
  element: string;
  growth: number;
  planted: boolean;
  plantedAt: number;
}

interface GardenData {
  level: number;
  experience: number;
  plots: GardenPlot[];
}

interface ActionTreeData {
  [category: string]: {
    [action: string]: number;
  };
}

interface GardenState {
  gamePhase: GamePhase;
  gardenData: GardenData;
  gardenPlots: GardenPlot[];
  actionTreeData: ActionTreeData;
  lastSave: number;
  
  // Actions
  initializeGame: () => void;
  setGamePhase: (phase: GamePhase) => void;
  plantSeed: (element: string) => void;
  upgradeGarden: () => void;
  addToActionTree: (category: string, action: string, count: number) => void;
  updateGrowth: () => void;
  saveGame: () => void;
  loadGame: () => void;
}

export const useGarden = create<GardenState>()(
  subscribeWithSelector((set, get) => ({
    gamePhase: "element_selection",
    gardenData: {
      level: 1,
      experience: 0,
      plots: []
    },
    gardenPlots: [],
    actionTreeData: {},
    lastSave: Date.now(),
    
    initializeGame: () => {
      const state = get();
      state.loadGame();
      
      // Start auto-save interval (every 30 seconds)
      setInterval(() => {
        state.saveGame();
      }, 30000);
      
      // Start growth update interval (every 5 seconds)
      setInterval(() => {
        state.updateGrowth();
      }, 5000);
    },
    
    setGamePhase: (phase) => {
      set({ gamePhase: phase });
    },
    
    plantSeed: (element) => {
      set((state) => {
        const newPlot: GardenPlot = {
          position: [
            (Math.random() - 0.5) * 20,
            0.1,
            (Math.random() - 0.5) * 20
          ],
          element,
          growth: 0,
          planted: true,
          plantedAt: Date.now()
        };
        
        const updatedPlots = [...state.gardenPlots, newPlot];
        
        return {
          gardenPlots: updatedPlots,
          gardenData: {
            ...state.gardenData,
            plots: updatedPlots,
            experience: state.gardenData.experience + 10
          }
        };
      });
      
      get().addToActionTree('building', 'plant_seed', 1);
    },
    
    upgradeGarden: () => {
      set((state) => ({
        gardenData: {
          ...state.gardenData,
          level: state.gardenData.level + 1,
          experience: state.gardenData.experience + 50
        }
      }));
      
      get().addToActionTree('building', 'upgrade_garden', 1);
    },
    
    addToActionTree: (category, action, count) => {
      set((state) => {
        const newActionTreeData = { ...state.actionTreeData };
        
        if (!newActionTreeData[category]) {
          newActionTreeData[category] = {};
        }
        
        if (!newActionTreeData[category][action]) {
          newActionTreeData[category][action] = 0;
        }
        
        newActionTreeData[category][action] += count;
        
        return { actionTreeData: newActionTreeData };
      });
    },
    
    updateGrowth: () => {
      set((state) => {
        const updatedPlots = state.gardenPlots.map(plot => {
          if (plot.planted && plot.growth < 1) {
            // Base growth rate: 0.01 per update (5 seconds)
            let growthRate = 0.01;
            
            // Weather bonus would be applied here
            growthRate *= 1.2; // Simulated weather bonus
            
            // Element bonuses
            if (plot.element === 'earth') growthRate *= 1.5;
            if (plot.element === 'water') growthRate *= 1.3;
            if (plot.element === 'black') growthRate *= 2.0; // Black magic supremacy
            
            // Garden level bonus
            growthRate *= (1 + state.gardenData.level * 0.1);
            
            return {
              ...plot,
              growth: Math.min(plot.growth + growthRate, 1)
            };
          }
          return plot;
        });
        
        return {
          gardenPlots: updatedPlots,
          gardenData: {
            ...state.gardenData,
            plots: updatedPlots
          }
        };
      });
    },
    
    saveGame: () => {
      const state = get();
      const saveData = {
        gamePhase: state.gamePhase,
        gardenData: state.gardenData,
        gardenPlots: state.gardenPlots,
        actionTreeData: state.actionTreeData,
        lastSave: Date.now()
      };
      
      localStorage.setItem('garden_save', JSON.stringify(saveData));
      
      set({ lastSave: Date.now() });
      console.log('Game saved successfully');
    },
    
    loadGame: () => {
      try {
        const savedData = localStorage.getItem('garden_save');
        if (savedData) {
          const parsed = JSON.parse(savedData);
          
          set({
            gardenData: parsed.gardenData || get().gardenData,
            gardenPlots: parsed.gardenPlots || [],
            actionTreeData: parsed.actionTreeData || {},
            lastSave: parsed.lastSave || Date.now()
          });
          
          console.log('Game loaded successfully');
        }
      } catch (error) {
        console.error('Failed to load game:', error);
      }
    }
  }))
);
