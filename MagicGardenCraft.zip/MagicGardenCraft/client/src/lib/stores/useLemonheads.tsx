import { create } from 'zustand';
import { subscribeWithSelector } from 'zustand/middleware';

interface LemonheadsState {
  inventory: number;
  totalConsumed: number;
  marketValue: number; // Fixed at $300 USD
  dropRate: number; // 25% base, 35% while watching movies
  isWatchingMovie: boolean;
  consumptionHistory: LemonheadsConsumption[];
  boxes: LemonheadsBox[];
  lastDrop: number;
  
  // Actions
  performAction: () => void;
  consumeLemonheads: (amount: number) => void;
  startWatchingMovie: () => void;
  stopWatchingMovie: () => void;
  buyBox: () => void;
  checkForDrop: () => boolean;
}

interface LemonheadsConsumption {
  timestamp: number;
  amount: number;
  statBoosts: Record<string, number>;
  instantDeathRisk: number;
}

interface LemonheadsBox {
  id: string;
  candiesRemaining: number;
  maxCandies: 23;
  purchaseDate: number;
}

export const useLemonheads = create<LemonheadsState>()(
  subscribeWithSelector((set, get) => ({
    inventory: 0,
    totalConsumed: 0,
    marketValue: 300, // Fixed at $300 USD
    dropRate: 0.25, // 25% base
    isWatchingMovie: false,
    consumptionHistory: [],
    boxes: [],
    lastDrop: 0,
    
    performAction: () => {
      const { checkForDrop } = get();
      
      // Check for Lemonheads drop on ANY activity
      if (checkForDrop()) {
        const state = get();
        set({
          inventory: state.inventory + 1,
          lastDrop: Date.now()
        });
        
        console.log('🍋 Lemonheads dropped! (+1 to inventory)');
        
        // Show notification
        setTimeout(() => {
          const notification = document.createElement('div');
          notification.innerHTML = '🍋 Lemonheads found! (+1)';
          notification.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            background: #ffeb3b;
            color: #333;
            padding: 10px 20px;
            border-radius: 5px;
            font-weight: bold;
            z-index: 1000;
            animation: slideIn 0.3s ease-out;
          `;
          document.body.appendChild(notification);
          
          setTimeout(() => {
            notification.remove();
          }, 3000);
        }, 100);
      }
    },
    
    checkForDrop: () => {
      const { dropRate, isWatchingMovie } = get();
      const effectiveDropRate = isWatchingMovie ? 0.35 : dropRate; // 35% while watching movies
      
      return Math.random() < effectiveDropRate;
    },
    
    consumeLemonheads: (amount: number) => {
      const state = get();
      
      if (state.inventory < amount) {
        alert('Not enough Lemonheads in inventory!');
        return;
      }
      
      // Calculate instant death risk based on eating speed
      const timeSinceLastConsumption = state.consumptionHistory.length > 0 
        ? Date.now() - state.consumptionHistory[state.consumptionHistory.length - 1].timestamp
        : Infinity;
      
      let instantDeathRisk = 0;
      if (timeSinceLastConsumption < 5000) { // Less than 5 seconds
        instantDeathRisk = 0.1; // 10% chance of instant death for rapid consumption
      }
      
      // Roll for instant death
      if (Math.random() < instantDeathRisk) {
        alert('💀 You consumed Lemonheads too quickly and died instantly! Game over.');
        // In a real game, this would trigger game over sequence
        return;
      }
      
      // Generate stat boosts
      const statBoosts = {
        energy: Math.random() * 20 + 10, // 10-30 energy boost
        focus: Math.random() * 15 + 5,   // 5-20 focus boost
        magic: Math.random() * 10 + 5,   // 5-15 magic boost
        speed: Math.random() * 8 + 2     // 2-10 speed boost
      };
      
      const consumption: LemonheadsConsumption = {
        timestamp: Date.now(),
        amount,
        statBoosts,
        instantDeathRisk
      };
      
      set({
        inventory: state.inventory - amount,
        totalConsumed: state.totalConsumed + amount,
        consumptionHistory: [...state.consumptionHistory, consumption]
      });
      
      console.log(`🍋 Consumed ${amount} Lemonheads:`, statBoosts);
      alert(`Consumed ${amount} Lemonheads! Stat boosts: Energy +${statBoosts.energy.toFixed(1)}, Focus +${statBoosts.focus.toFixed(1)}, Magic +${statBoosts.magic.toFixed(1)}, Speed +${statBoosts.speed.toFixed(1)}`);
    },
    
    startWatchingMovie: () => {
      console.log('🎬 Started watching movie - Lemonheads drop rate increased to 35%');
      set({ 
        isWatchingMovie: true,
        dropRate: 0.35 
      });
      
      alert('Movie mode activated! Lemonheads drop rate increased to 35%');
    },
    
    stopWatchingMovie: () => {
      console.log('🎬 Stopped watching movie - Lemonheads drop rate back to 25%');
      set({ 
        isWatchingMovie: false,
        dropRate: 0.25 
      });
    },
    
    buyBox: () => {
      const newBox: LemonheadsBox = {
        id: `box_${Date.now()}`,
        candiesRemaining: 23,
        maxCandies: 23,
        purchaseDate: Date.now()
      };
      
      const state = get();
      set({
        boxes: [...state.boxes, newBox],
        inventory: state.inventory + 23
      });
      
      console.log('📦 Purchased new Lemonheads box (+23 candies)');
      alert('Purchased Lemonheads box for $300! Added 23 candies to inventory.');
    }
  }))
);