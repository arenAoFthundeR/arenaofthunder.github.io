import { create } from "zustand";
import { subscribeWithSelector } from "zustand/middleware";

type WeatherCondition = 'sunny' | 'cloudy' | 'rain' | 'snow' | 'storm';

interface WeatherState {
  currentWeather: WeatherCondition;
  temperature: number;
  humidity: number;
  windSpeed: number;
  lastUpdated: number | null;
  
  // Actions
  updateWeather: () => void;
  setWeather: (weather: WeatherCondition, temp: number, humidity: number) => void;
}

export const useWeather = create<WeatherState>()(
  subscribeWithSelector((set, get) => ({
    currentWeather: 'sunny',
    temperature: 72,
    humidity: 50,
    windSpeed: 5,
    lastUpdated: null,
    
    updateWeather: async () => {
      try {
        // In a real implementation, this would fetch from a weather API
        // For now, we'll simulate realistic weather patterns
        
        const weatherConditions: WeatherCondition[] = ['sunny', 'cloudy', 'rain', 'snow', 'storm'];
        const currentSeason = Math.floor((new Date().getMonth() + 1) / 3); // 0-3 for seasons
        
        // Seasonal weather probabilities
        let weatherProbabilities = [0.3, 0.3, 0.2, 0.1, 0.1]; // Default spring/summer
        
        if (currentSeason === 0 || currentSeason === 3) { // Winter
          weatherProbabilities = [0.2, 0.3, 0.15, 0.25, 0.1];
        } else if (currentSeason === 2) { // Summer
          weatherProbabilities = [0.5, 0.25, 0.15, 0.05, 0.05];
        }
        
        // Select weather based on probabilities
        const random = Math.random();
        let cumulative = 0;
        let selectedWeather: WeatherCondition = 'sunny';
        
        for (let i = 0; i < weatherConditions.length; i++) {
          cumulative += weatherProbabilities[i];
          if (random <= cumulative) {
            selectedWeather = weatherConditions[i];
            break;
          }
        }
        
        // Generate realistic temperature based on season and weather
        let baseTemp = 65; // Base temperature
        if (currentSeason === 0 || currentSeason === 3) baseTemp = 35; // Winter
        else if (currentSeason === 2) baseTemp = 85; // Summer
        
        // Weather modifications
        if (selectedWeather === 'snow') baseTemp = Math.min(baseTemp, 32);
        else if (selectedWeather === 'rain') baseTemp -= 10;
        else if (selectedWeather === 'sunny') baseTemp += 10;
        
        const temperature = baseTemp + (Math.random() - 0.5) * 20; // ±10 degree variation
        const humidity = selectedWeather === 'rain' ? 80 + Math.random() * 15 : 
                        selectedWeather === 'snow' ? 60 + Math.random() * 20 :
                        30 + Math.random() * 40;
        
        set({
          currentWeather: selectedWeather,
          temperature: Math.round(temperature),
          humidity: Math.round(humidity),
          windSpeed: Math.round(5 + Math.random() * 15),
          lastUpdated: Date.now()
        });
        
        console.log(`Weather updated: ${selectedWeather}, ${Math.round(temperature)}°F, ${Math.round(humidity)}% humidity`);
        
      } catch (error) {
        console.error('Failed to update weather:', error);
        
        // Fallback to simulated weather
        const fallbackWeather: WeatherCondition[] = ['sunny', 'cloudy', 'rain'];
        const randomWeather = fallbackWeather[Math.floor(Math.random() * fallbackWeather.length)];
        
        set({
          currentWeather: randomWeather,
          temperature: 65 + (Math.random() - 0.5) * 30,
          humidity: 40 + Math.random() * 40,
          windSpeed: Math.round(3 + Math.random() * 10),
          lastUpdated: Date.now()
        });
      }
    },
    
    setWeather: (weather, temp, humidity) => {
      set({
        currentWeather: weather,
        temperature: temp,
        humidity: humidity,
        lastUpdated: Date.now()
      });
    }
  }))
);

// Initialize weather on load
useWeather.getState().updateWeather();
