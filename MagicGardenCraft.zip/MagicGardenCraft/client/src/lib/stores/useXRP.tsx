import { create } from "zustand";
import { subscribeWithSelector } from "zustand/middleware";

type MarketTrend = 'up' | 'down' | 'stable';

interface XRPState {
  balance: number;
  xrpPrice: number;
  marketTrend: MarketTrend;
  dailyEarnings: number;
  totalEarned: number;
  lastPriceUpdate: number;
  
  // Actions
  spend: (amount: number) => boolean;
  earn: (amount: number) => void;
  updatePrice: () => void;
  resetDaily: () => void;
}

export const useXRP = create<XRPState>()(
  subscribeWithSelector((set, get) => ({
    balance: 0.05, // Start with very low balance (scaled to create scarcity)
    xrpPrice: 1.0, // Starting price in USD
    marketTrend: 'stable',
    dailyEarnings: 0,
    totalEarned: 0,
    lastPriceUpdate: Date.now(),
    
    spend: (amount) => {
      const state = get();
      if (state.balance >= amount) {
        set({
          balance: state.balance - amount
        });
        
        // Save to localStorage
        localStorage.setItem('garden_xrp_balance', (state.balance - amount).toString());
        
        console.log(`Spent ${amount} XRP. New balance: ${(state.balance - amount).toFixed(4)}`);
        return true;
      }
      
      console.log(`Insufficient funds. Need ${amount} XRP, have ${state.balance.toFixed(4)}`);
      return false;
    },
    
    earn: (amount) => {
      set((state) => {
        const newBalance = state.balance + amount;
        const newDailyEarnings = state.dailyEarnings + amount;
        const newTotalEarned = state.totalEarned + amount;
        
        // Save to localStorage
        localStorage.setItem('garden_xrp_balance', newBalance.toString());
        localStorage.setItem('garden_daily_earnings', newDailyEarnings.toString());
        
        console.log(`Earned ${amount} XRP. New balance: ${newBalance.toFixed(4)}`);
        
        return {
          balance: newBalance,
          dailyEarnings: newDailyEarnings,
          totalEarned: newTotalEarned
        };
      });
    },
    
    updatePrice: () => {
      set((state) => {
        // Simulate realistic XRP price movement
        const changePercent = (Math.random() - 0.5) * 0.1; // ±5% max change
        const newPrice = Math.max(0.1, state.xrpPrice * (1 + changePercent));
        
        // Determine trend
        let newTrend: MarketTrend = 'stable';
        if (changePercent > 0.02) newTrend = 'up';
        else if (changePercent < -0.02) newTrend = 'down';
        
        // Check for market crash (15% drop triggers emergency)
        if (changePercent < -0.15) {
          console.log('🚨 MARKET CRASH DETECTED! XRP down 15%+');
          // In a real implementation, this would trigger email alerts and website shutdown
        }
        
        // Check for market surge (30% increase in simulated 10 days)
        if (newPrice > state.xrpPrice * 1.3) {
          console.log('🚀 MARKET SURGE! XRP up 30%+');
          // In a real implementation, this would trigger development completion notification
        }
        
        return {
          xrpPrice: newPrice,
          marketTrend: newTrend,
          lastPriceUpdate: Date.now()
        };
      });
    },
    
    resetDaily: () => {
      set({ dailyEarnings: 0 });
      localStorage.setItem('garden_daily_earnings', '0');
    }
  }))
);

// Load saved data on initialization
const savedBalance = localStorage.getItem('garden_xrp_balance');
const savedDailyEarnings = localStorage.getItem('garden_daily_earnings');

if (savedBalance) {
  useXRP.setState({ balance: parseFloat(savedBalance) });
}

if (savedDailyEarnings) {
  useXRP.setState({ dailyEarnings: parseFloat(savedDailyEarnings) });
}

// Reset daily earnings at midnight
const now = new Date();
const tomorrow = new Date(now);
tomorrow.setDate(now.getDate() + 1);
tomorrow.setHours(0, 0, 0, 0);

const msUntilMidnight = tomorrow.getTime() - now.getTime();
setTimeout(() => {
  useXRP.getState().resetDaily();
  
  // Set up daily reset interval
  setInterval(() => {
    useXRP.getState().resetDaily();
  }, 24 * 60 * 60 * 1000);
}, msUntilMidnight);
