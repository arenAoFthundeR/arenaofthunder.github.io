import { create } from 'zustand';
import { subscribeWithSelector } from 'zustand/middleware';
import { xrpAPI } from '../gameLogic/xrpAPI';

interface EmergencyState {
  isEmergencyActive: boolean;
  emergencyType: 'market_crash' | 'server_outage' | 'maintenance' | null;
  triggeredAt: number | null;
  severity: 'low' | 'medium' | 'high' | 'critical';
  lastXRPPrice: number;
  crashThreshold: number; // 15% drop triggers emergency
  
  // Actions
  monitorXRPPrice: () => void;
  triggerEmergency: (type: EmergencyState['emergencyType'], severity: EmergencyState['severity']) => void;
  resolveEmergency: () => void;
  sendEmailAlert: (message: string) => void;
  activateShutdown: () => void;
}

export const useEmergency = create<EmergencyState>()(
  subscribeWithSelector((set, get) => ({
    isEmergencyActive: false,
    emergencyType: null,
    triggeredAt: null,
    severity: 'low',
    lastXRPPrice: 0,
    crashThreshold: 0.15, // 15%
    
    monitorXRPPrice: async () => {
      try {
        const priceData = await xrpAPI.getCurrentPrice();
        const { lastXRPPrice, crashThreshold } = get();
        
        if (lastXRPPrice > 0) {
          const priceDropPercent = ((lastXRPPrice - priceData.price) / lastXRPPrice);
          
          if (priceDropPercent >= crashThreshold) {
            console.log(`🚨 EMERGENCY: XRP crashed ${(priceDropPercent * 100).toFixed(2)}%`);
            get().triggerEmergency('market_crash', 'critical');
            get().sendEmailAlert(`CRITICAL: XRP price dropped ${(priceDropPercent * 100).toFixed(2)}% - Emergency protocols activated`);
          }
        }
        
        set({ lastXRPPrice: priceData.price });
        
      } catch (error) {
        console.error('Emergency monitoring error:', error);
        get().triggerEmergency('server_outage', 'high');
      }
    },
    
    triggerEmergency: (type: EmergencyState['emergencyType'], severity: EmergencyState['severity']) => {
      const now = Date.now();
      
      console.log(`🚨 EMERGENCY ACTIVATED: ${type} (${severity})`);
      
      set({
        isEmergencyActive: true,
        emergencyType: type,
        triggeredAt: now,
        severity
      });
      
      // Store emergency state in localStorage for persistence
      localStorage.setItem('garden_emergency_state', JSON.stringify({
        active: true,
        type,
        triggeredAt: now,
        severity
      }));
      
      // Auto-resolve lower severity emergencies after time
      if (severity === 'low' || severity === 'medium') {
        setTimeout(() => {
          if (get().isEmergencyActive) {
            get().resolveEmergency();
          }
        }, severity === 'low' ? 300000 : 600000); // 5-10 minutes
      }
      
      // Show emergency UI
      setTimeout(() => {
        const emergencyDiv = document.createElement('div');
        emergencyDiv.innerHTML = `
          <div style="
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(255, 0, 0, 0.9);
            color: white;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            z-index: 10000;
            font-family: Arial, sans-serif;
          ">
            <h1 style="font-size: 3rem; margin-bottom: 20px;">🚨 EMERGENCY PROTOCOL ACTIVE 🚨</h1>
            <h2 style="font-size: 2rem; margin-bottom: 20px;">Type: ${type?.toUpperCase()}</h2>
            <h3 style="font-size: 1.5rem; margin-bottom: 30px;">Severity: ${severity?.toUpperCase()}</h3>
            <p style="font-size: 1.2rem; text-align: center; max-width: 600px;">
              Emergency protocols have been activated. Please stand by while we resolve the situation.
              ${type === 'market_crash' ? 'XRP market crash detected - all transactions suspended.' : ''}
            </p>
            <button onclick="this.parentElement.parentElement.remove()" style="
              margin-top: 30px;
              padding: 15px 30px;
              font-size: 1.2rem;
              background: #fff;
              color: #000;
              border: none;
              border-radius: 5px;
              cursor: pointer;
            ">Acknowledge</button>
          </div>
        `;
        document.body.appendChild(emergencyDiv);
      }, 100);
    },
    
    resolveEmergency: () => {
      console.log('✅ Emergency resolved');
      
      set({
        isEmergencyActive: false,
        emergencyType: null,
        triggeredAt: null,
        severity: 'low'
      });
      
      // Clear emergency state
      localStorage.removeItem('garden_emergency_state');
      
      // Show resolution notification
      setTimeout(() => {
        alert('Emergency resolved. Normal operations resumed.');
      }, 100);
    },
    
    sendEmailAlert: (message: string) => {
      // In a real implementation, this would send actual emails
      // For now, we'll log and store the alert
      console.log(`📧 EMAIL ALERT: ${message}`);
      
      const alerts = JSON.parse(localStorage.getItem('garden_email_alerts') || '[]');
      alerts.push({
        timestamp: Date.now(),
        message,
        sent: false // Would be true in real implementation
      });
      localStorage.setItem('garden_email_alerts', JSON.stringify(alerts));
      
      // Simulate email sending
      setTimeout(() => {
        console.log(`📧 Email alert sent to administrators: ${message}`);
      }, 1000);
    },
    
    activateShutdown: () => {
      console.log('🛑 EMERGENCY SHUTDOWN ACTIVATED');
      
      // In a real implementation, this would:
      // 1. Save all player progress
      // 2. Gracefully close connections
      // 3. Shut down the server
      
      get().sendEmailAlert('CRITICAL: Emergency shutdown activated - immediate attention required');
      
      setTimeout(() => {
        alert('Emergency shutdown activated. Please contact support immediately.');
        // Could redirect to maintenance page
        // window.location.href = '/maintenance';
      }, 2000);
    }
  }))
);

// Auto-monitor XRP price every 5 minutes when emergency system is active
setInterval(() => {
  useEmergency.getState().monitorXRPPrice();
}, 300000); // 5 minutes

// Check for existing emergency state on load
const existingEmergency = localStorage.getItem('garden_emergency_state');
if (existingEmergency) {
  const emergency = JSON.parse(existingEmergency);
  if (emergency.active) {
    useEmergency.getState().triggerEmergency(emergency.type, emergency.severity);
  }
}