import { create } from "zustand";
import { subscribeWithSelector } from "zustand/middleware";

interface Achievement {
  id: string;
  name: string;
  description: string;
  points: number;
  unlockedAt?: number;
  category?: string;
}

interface AchievementState {
  achievements: Achievement[];
  totalPoints: number;
  prestigeLevel: number;
  legacyAchievements: Achievement[];
  
  // Actions
  unlockAchievement: (achievement: Achievement) => void;
  checkProgressAchievements: () => void;
  prestige: () => void;
}

const MILESTONE_ACHIEVEMENTS = [
  { id: 'first-plant', name: 'Green Thumb', description: 'Plant your first magical seed', points: 50, category: 'garden' },
  { id: 'element-master', name: 'Elemental Adept', description: 'Reach 50% mastery in your element', points: 200, category: 'magic' },
  { id: 'wealth-builder', name: 'Crypto Collector', description: 'Accumulate 0.1 XRP', points: 100, category: 'economy' },
  { id: 'action-performer', name: 'Active Gardener', description: 'Perform 100 total actions', points: 150, category: 'progress' },
  { id: 'weather-watcher', name: 'Storm Chaser', description: 'Experience all weather conditions', points: 75, category: 'exploration' },
  { id: 'garden-expert', name: 'Master Gardener', description: 'Grow 10 plants to full maturity', points: 300, category: 'garden' },
  { id: 'magic-scholar', name: 'Arcane Scholar', description: 'Learn 5 different spells', points: 250, category: 'magic' },
  { id: 'entrepreneur', name: 'Market Trader', description: 'Complete 20 XRP transactions', points: 175, category: 'economy' }
];

export const useAchievements = create<AchievementState>()(
  subscribeWithSelector((set, get) => ({
    achievements: [],
    totalPoints: 0,
    prestigeLevel: 0,
    legacyAchievements: [],
    
    unlockAchievement: (achievement) => {
      const state = get();
      
      // Check if already unlocked
      if (state.achievements.find(a => a.id === achievement.id)) {
        return;
      }
      
      const newAchievement = {
        ...achievement,
        unlockedAt: Date.now()
      };
      
      set({
        achievements: [...state.achievements, newAchievement],
        totalPoints: state.totalPoints + achievement.points
      });
      
      // Save achievements
      const savedAchievements = [...state.achievements, newAchievement];
      localStorage.setItem('garden_achievements', JSON.stringify(savedAchievements));
      localStorage.setItem('garden_achievement_points', (state.totalPoints + achievement.points).toString());
      
      console.log(`🏆 Achievement Unlocked: ${achievement.name} (+${achievement.points} points)`);
      
      // Play success sound (would be connected to audio system)
      // useAudio.getState().playSuccess();
    },
    
    checkProgressAchievements: () => {
      const state = get();
      
      // This would check various game state conditions and unlock achievements
      // For now, we'll implement basic checks
      
      MILESTONE_ACHIEVEMENTS.forEach(milestone => {
        if (!state.achievements.find(a => a.id === milestone.id)) {
          // Check conditions for each achievement
          // This is where you'd implement the actual logic
          // For example: checking garden state, XRP balance, action counts, etc.
        }
      });
    },
    
    prestige: () => {
      set((state) => {
        // Move current achievements to legacy
        const newLegacyAchievements = [...state.legacyAchievements, ...state.achievements];
        
        // Calculate prestige bonuses
        const prestigeBonus = Math.floor(state.totalPoints / 1000);
        
        // Reset current achievements but keep legacy
        return {
          achievements: [],
          totalPoints: 0,
          prestigeLevel: state.prestigeLevel + 1,
          legacyAchievements: newLegacyAchievements
        };
      });
      
      console.log('🌟 Prestige activated! Starting fresh with legacy bonuses.');
    }
  }))
);

// Load saved achievements on initialization
const savedAchievements = localStorage.getItem('garden_achievements');
const savedPoints = localStorage.getItem('garden_achievement_points');

if (savedAchievements) {
  try {
    const achievements = JSON.parse(savedAchievements);
    useAchievements.setState({ achievements });
  } catch (error) {
    console.error('Failed to load achievements:', error);
  }
}

if (savedPoints) {
  useAchievements.setState({ totalPoints: parseInt(savedPoints) });
}

// Set up periodic achievement checks
setInterval(() => {
  useAchievements.getState().checkProgressAchievements();
}, 10000); // Check every 10 seconds
