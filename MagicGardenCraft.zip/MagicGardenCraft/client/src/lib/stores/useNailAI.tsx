import { create } from 'zustand';

interface NailAIState {
  isActive: boolean;
  lastTapTime: number;
  tapSequence: number[];
  suspiciousActivity: boolean;
  blockedUntil: number;
  
  // Actions
  registerTap: (elementId: string) => boolean;
  resetSequence: () => void;
  activateProtection: () => void;
  deactivateProtection: () => void;
  checkSuspiciousActivity: () => boolean;
}

export const useNailAI = create<NailAIState>((set, get) => ({
  isActive: true, // $nail AI is always active
  lastTapTime: 0,
  tapSequence: [],
  suspiciousActivity: false,
  blockedUntil: 0,
  
  registerTap: (elementId: string) => {
    const state = get();
    const now = Date.now();
    
    if (!state.isActive) return true;
    
    // Check if currently blocked
    if (now < state.blockedUntil) {
      console.log('🚫 $nail AI: Action blocked due to suspicious activity');
      return false;
    }
    
    // Detect rapid tapping (more than 5 taps per second)
    const timeSinceLastTap = now - state.lastTapTime;
    if (timeSinceLastTap < 200) { // Less than 200ms between taps
      const newSequence = [...state.tapSequence, now];
      
      // Keep only last 10 taps for analysis
      if (newSequence.length > 10) {
        newSequence.shift();
      }
      
      set({
        lastTapTime: now,
        tapSequence: newSequence
      });
      
      // Check for bot-like patterns
      if (get().checkSuspiciousActivity()) {
        return false;
      }
    } else {
      // Normal tap timing, reset sequence
      set({
        lastTapTime: now,
        tapSequence: [now]
      });
    }
    
    return true;
  },
  
  checkSuspiciousActivity: () => {
    const { tapSequence } = get();
    
    if (tapSequence.length < 5) return false;
    
    // Check for too-regular timing (bot-like behavior)
    const intervals = [];
    for (let i = 1; i < tapSequence.length; i++) {
      intervals.push(tapSequence[i] - tapSequence[i - 1]);
    }
    
    // Calculate variance in timing
    const avgInterval = intervals.reduce((a, b) => a + b, 0) / intervals.length;
    const variance = intervals.reduce((acc, interval) => {
      return acc + Math.pow(interval - avgInterval, 2);
    }, 0) / intervals.length;
    
    // Low variance = very regular timing = likely bot
    const isSuspicious = variance < 100 && avgInterval < 150;
    
    if (isSuspicious) {
      console.log('🚨 $nail AI: Suspicious activity detected - blocking user');
      set({
        suspiciousActivity: true,
        blockedUntil: Date.now() + 30000, // Block for 30 seconds
        tapSequence: []
      });
      
      // Show warning to user
      setTimeout(() => {
        alert('$nail AI: Suspicious clicking pattern detected. Please wait 30 seconds before continuing.');
      }, 100);
      
      return true;
    }
    
    return false;
  },
  
  resetSequence: () => {
    set({
      tapSequence: [],
      suspiciousActivity: false,
      lastTapTime: 0
    });
  },
  
  activateProtection: () => {
    console.log('🔒 $nail AI protection activated');
    set({ isActive: true });
  },
  
  deactivateProtection: () => {
    console.log('🔓 $nail AI protection deactivated');
    set({ 
      isActive: false,
      suspiciousActivity: false,
      blockedUntil: 0,
      tapSequence: []
    });
  }
}));