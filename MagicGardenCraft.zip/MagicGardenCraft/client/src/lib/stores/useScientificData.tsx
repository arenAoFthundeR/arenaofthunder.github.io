import { create } from 'zustand';
import { subscribeWithSelector } from 'zustand/middleware';

interface ScientificDataState {
  // Atmospheric data
  co2Level: number; // ppm
  oxygenLevel: number; // percentage
  temperature: number; // Celsius
  humidity: number; // percentage
  airPressure: number; // kPa
  uvIndex: number;
  
  // Soil composition
  soilPH: number;
  soilNitrogen: number; // mg/kg
  soilPhosphorus: number; // mg/kg
  soilPotassium: number; // mg/kg
  soilOrganicMatter: number; // percentage
  soilMoisture: number; // percentage
  
  // Ecosystem metrics
  biodiversityIndex: number;
  carbonSequestration: number; // kg CO2/day
  oxygenProduction: number; // L/day
  pollinatorCount: number;
  
  // Time and seasons
  dayOfYear: number;
  timeOfDay: number; // 0-24 hours
  seasonalFactor: number; // 0-1
  
  // Actions
  updateAtmosphericData: () => void;
  updateSoilData: () => void;
  updateEcosystemMetrics: () => void;
  simulateTimeProgression: () => void;
  resetToBaseline: () => void;
}

export const useScientificData = create<ScientificDataState>()(
  subscribeWithSelector((set, get) => ({
    // Initial realistic baseline values
    co2Level: 421, // Current global average (2024)
    oxygenLevel: 20.95, // Atmospheric oxygen percentage
    temperature: 22, // Celsius
    humidity: 60, // percentage
    airPressure: 101.325, // kPa (sea level)
    uvIndex: 5,
    
    soilPH: 6.5, // Slightly acidic (ideal for most plants)
    soilNitrogen: 20, // mg/kg
    soilPhosphorus: 15, // mg/kg
    soilPotassium: 150, // mg/kg
    soilOrganicMatter: 3.5, // percentage
    soilMoisture: 25, // percentage
    
    biodiversityIndex: 0.8,
    carbonSequestration: 0,
    oxygenProduction: 0,
    pollinatorCount: 0,
    
    dayOfYear: 1,
    timeOfDay: 12,
    seasonalFactor: 0.5,
    
    updateAtmosphericData: () => {
      set((state) => {
        // Simulate realistic atmospheric changes
        const seasonalTemp = 20 + 10 * Math.sin((state.dayOfYear / 365) * 2 * Math.PI);
        const dailyTemp = seasonalTemp + 5 * Math.sin((state.timeOfDay / 24) * 2 * Math.PI - Math.PI/2);
        
        // CO2 varies seasonally (higher in winter, lower in summer due to plant activity)
        const seasonalCO2 = 421 + 3 * Math.sin((state.dayOfYear / 365) * 2 * Math.PI + Math.PI);
        
        // Humidity varies with temperature (relative humidity)
        const newHumidity = Math.max(20, Math.min(90, 80 - (dailyTemp - 20) * 1.5));
        
        // UV index varies with season and time of day
        const solarElevation = Math.sin((state.timeOfDay - 6) / 12 * Math.PI);
        const seasonalUV = Math.max(0, 8 * solarElevation * (0.7 + 0.3 * Math.sin((state.dayOfYear / 365) * 2 * Math.PI)));
        
        return {
          temperature: Math.round(dailyTemp * 10) / 10,
          co2Level: Math.round(seasonalCO2 * 10) / 10,
          humidity: Math.round(newHumidity),
          uvIndex: Math.round(seasonalUV * 10) / 10,
          airPressure: 101.325 + (Math.random() - 0.5) * 2 // Small pressure variations
        };
      });
    },
    
    updateSoilData: () => {
      set((state) => {
        // Soil changes more slowly than atmosphere
        const plantUptake = state.oxygenProduction > 0 ? 0.1 : 0;
        const microbialActivity = (state.temperature > 5 && state.temperature < 35) ? 1 : 0.5;
        
        // Nutrient cycling
        const nitrogenCycle = state.soilNitrogen - (plantUptake * 2) + (microbialActivity * 0.5);
        const phosphorusCycle = state.soilPhosphorus - (plantUptake * 0.5) + (microbialActivity * 0.1);
        const potassiumCycle = state.soilPotassium - (plantUptake * 1) + (microbialActivity * 0.3);
        
        // pH buffering (soil naturally resists pH changes)
        const pHChange = (Math.random() - 0.5) * 0.1;
        const newPH = Math.max(4.5, Math.min(8.5, state.soilPH + pHChange));
        
        // Organic matter decomposition
        const decompositionRate = microbialActivity * 0.01;
        const newOrganicMatter = Math.max(1, state.soilOrganicMatter - decompositionRate + (plantUptake * 0.05));
        
        return {
          soilNitrogen: Math.max(5, nitrogenCycle),
          soilPhosphorus: Math.max(3, phosphorusCycle),
          soilPotassium: Math.max(50, potassiumCycle),
          soilPH: Math.round(newPH * 10) / 10,
          soilOrganicMatter: Math.round(newOrganicMatter * 100) / 100,
          soilMoisture: Math.max(10, Math.min(50, state.soilMoisture + (Math.random() - 0.5) * 5))
        };
      });
    },
    
    updateEcosystemMetrics: () => {
      set((state) => {
        // Calculate based on current garden state
        // This would integrate with the actual plant data
        const plantCount = 5; // Placeholder - would come from garden state
        const plantHealth = (state.soilPH > 6 && state.soilPH < 7.5) ? 1 : 0.7;
        
        // Carbon sequestration (kg CO2 per day per plant)
        const carbonPerPlant = 0.48; // Average for small garden plants
        const totalCarbon = plantCount * carbonPerPlant * plantHealth;
        
        // Oxygen production (L per day per plant)
        const oxygenPerPlant = 330; // Average for small garden plants
        const totalOxygen = plantCount * oxygenPerPlant * plantHealth;
        
        // Biodiversity based on plant variety and ecosystem health
        const diversityFactor = Math.min(plantCount / 10, 1);
        const healthFactor = (state.temperature > 15 && state.temperature < 30) ? 1 : 0.7;
        const biodiversity = diversityFactor * healthFactor * 0.9;
        
        // Pollinator count based on flowering plants and season
        const floweringSeason = Math.sin((state.dayOfYear / 365) * 2 * Math.PI + Math.PI/2);
        const pollinators = Math.max(0, plantCount * 3 * floweringSeason * healthFactor);
        
        return {
          carbonSequestration: Math.round(totalCarbon * 100) / 100,
          oxygenProduction: Math.round(totalOxygen),
          biodiversityIndex: Math.round(biodiversity * 100) / 100,
          pollinatorCount: Math.round(pollinators)
        };
      });
    },
    
    simulateTimeProgression: () => {
      set((state) => {
        let newTimeOfDay = state.timeOfDay + 0.1; // 6 minutes per update
        let newDayOfYear = state.dayOfYear;
        
        if (newTimeOfDay >= 24) {
          newTimeOfDay = 0;
          newDayOfYear += 1;
          if (newDayOfYear > 365) {
            newDayOfYear = 1;
          }
        }
        
        const seasonalFactor = 0.5 + 0.5 * Math.sin((newDayOfYear / 365) * 2 * Math.PI - Math.PI/2);
        
        return {
          timeOfDay: Math.round(newTimeOfDay * 10) / 10,
          dayOfYear: newDayOfYear,
          seasonalFactor: Math.round(seasonalFactor * 100) / 100
        };
      });
    },
    
    resetToBaseline: () => {
      set({
        co2Level: 421,
        oxygenLevel: 20.95,
        temperature: 22,
        humidity: 60,
        airPressure: 101.325,
        uvIndex: 5,
        soilPH: 6.5,
        soilNitrogen: 20,
        soilPhosphorus: 15,
        soilPotassium: 150,
        soilOrganicMatter: 3.5,
        soilMoisture: 25,
        biodiversityIndex: 0.8,
        carbonSequestration: 0,
        oxygenProduction: 0,
        pollinatorCount: 0,
        dayOfYear: 1,
        timeOfDay: 12,
        seasonalFactor: 0.5
      });
    }
  }))
);

// Auto-update scientific data every 10 seconds
setInterval(() => {
  const state = useScientificData.getState();
  state.simulateTimeProgression();
  state.updateAtmosphericData();
  state.updateSoilData();
  state.updateEcosystemMetrics();
}, 10000);