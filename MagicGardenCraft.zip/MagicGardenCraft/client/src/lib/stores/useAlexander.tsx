import { create } from 'zustand';
import { subscribeWithSelector } from 'zustand/middleware';
import { ElementType } from '../../types/game';

interface AlexanderState {
  isAlexander: boolean;
  blackMagicPermanent: boolean;
  colorSwitchChance: number; // 1% per action
  godModeAvailable: boolean;
  godModeActive: boolean;
  totalActions: number;
  lastColorSwitch: number;
  currentMagicColor: ElementType;
  
  // Actions
  activateAlexanderMode: (username: string) => void;
  toggleGodMode: () => void;
  performAction: () => void;
  switchMagicColor: () => void;
  deactivateAlexander: () => void;
}

export const useAlexander = create<AlexanderState>()(
  subscribeWithSelector((set, get) => ({
    isAlexander: false,
    blackMagicPermanent: false,
    colorSwitchChance: 0.01, // 1%
    godModeAvailable: false,
    godModeActive: false,
    totalActions: 0,
    lastColorSwitch: 0,
    currentMagicColor: 'black' as ElementType,
    
    activateAlexanderMode: (username: string) => {
      if (username.toLowerCase() === 'alexander' || username.toLowerCase() === 'alex') {
        console.log('🔮 Alexander account activated - Black magic supremacy enabled');
        set({
          isAlexander: true,
          blackMagicPermanent: true,
          godModeAvailable: true,
          currentMagicColor: 'black'
        });
        
        // Add special welcome message
        setTimeout(() => {
          alert('Welcome Alexander! Your god mode button and permanent black magic are now active. Black magic will always remain the strongest affinity.');
        }, 1000);
      }
    },
    
    toggleGodMode: () => {
      const { isAlexander, godModeAvailable } = get();
      
      if (!isAlexander || !godModeAvailable) {
        console.log('God mode not available');
        return;
      }
      
      set(state => {
        const newGodMode = !state.godModeActive;
        console.log(`🎮 God mode ${newGodMode ? 'activated' : 'deactivated'}`);
        
        if (newGodMode) {
          // God mode benefits
          return {
            godModeActive: newGodMode,
            // Could add temporary stat boosts, unlimited resources, etc.
          };
        } else {
          return {
            godModeActive: newGodMode
          };
        }
      });
    },
    
    performAction: () => {
      const state = get();
      
      if (!state.isAlexander) return;
      
      const newActionCount = state.totalActions + 1;
      
      // Check for 1% chance color switch
      if (Math.random() < state.colorSwitchChance) {
        get().switchMagicColor();
      }
      
      set({ totalActions: newActionCount });
    },
    
    switchMagicColor: () => {
      const state = get();
      
      if (!state.isAlexander || !state.blackMagicPermanent) return;
      
      const colors: ElementType[] = ['fire', 'water', 'earth', 'air', 'shadow', 'black'];
      const currentIndex = colors.indexOf(state.currentMagicColor);
      const nextIndex = (currentIndex + 1) % colors.length;
      const newColor = colors[nextIndex];
      
      console.log(`✨ Alexander's magic color switched from ${state.currentMagicColor} to ${newColor}`);
      
      set({
        currentMagicColor: newColor,
        lastColorSwitch: Date.now()
      });
      
      // Show notification
      setTimeout(() => {
        alert(`Your magic color switched to ${newColor}! (1% chance per action)`);
      }, 100);
    },
    
    deactivateAlexander: () => {
      set({
        isAlexander: false,
        blackMagicPermanent: false,
        godModeAvailable: false,
        godModeActive: false,
        currentMagicColor: 'fire',
        totalActions: 0
      });
    }
  }))
);