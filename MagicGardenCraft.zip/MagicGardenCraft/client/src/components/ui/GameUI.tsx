import { useState } from 'react';
import { Button } from './button';
import { Card, CardContent, CardHeader, CardTitle } from './card';
import { Progress } from './progress';
import { useGarden } from '../../lib/stores/useGarden';
import { useElements } from '../../lib/stores/useElements';
import { useXRP } from '../../lib/stores/useXRP';
import { useWeather } from '../../lib/stores/useWeather';
import { useAchievements } from '../../lib/stores/useAchievements';
import { useAudio } from '../../lib/stores/useAudio';
import { useAlexander } from '../../lib/stores/useAlexander';
import { useLemonheads } from '../../lib/stores/useLemonheads';
import { useEmergency } from '../../lib/stores/useEmergency';
import { GardenBuilder } from './GardenBuilder';
import { ActionTree } from './ActionTree';
import { XRPEconomy } from './XRPEconomy';
import { WeatherDisplay } from './WeatherDisplay';
import { MiniMap } from './MiniMap';
import { SkillTree } from './SkillTree';
import { ScientificDashboard } from './ScientificDashboard';
import { Volume2, VolumeX, Settings, TreePine, Coins, Trophy, Cloud, Crown, Zap, Microscope } from 'lucide-react';

export function GameUI() {
  const [activePanel, setActivePanel] = useState<string | null>(null);
  const { gardenData, actionTreeData } = useGarden();
  const { selectedElement, magicPower, elementProgress } = useElements();
  const { balance } = useXRP();
  const { currentWeather } = useWeather();
  const { achievements, totalPoints } = useAchievements();
  const { isMuted, toggleMute } = useAudio();
  const { isAlexander, godModeActive, godModeAvailable, toggleGodMode, currentMagicColor } = useAlexander();
  const { inventory: lemonheadsCount, consumeLemonheads, buyBox, isWatchingMovie } = useLemonheads();
  const { isEmergencyActive, emergencyType, severity } = useEmergency();

  return (
    <div className="absolute inset-0 pointer-events-none">
      {/* Top HUD */}
      <div className="absolute top-4 left-4 right-4 flex justify-between items-start pointer-events-auto">
        <Card className="bg-black/80 border-green-500 text-green-400">
          <CardContent className="p-3">
            <div className="flex items-center space-x-4 text-sm">
              <div>Element: <span className="font-bold text-white">{selectedElement || 'None'}</span></div>
              {isAlexander && (
                <div>Color: <span className="font-bold text-purple-400">{currentMagicColor}</span></div>
              )}
              <div>Power: <span className="font-bold text-white">{magicPower}%</span></div>
              <div>XRP: <span className="font-bold text-yellow-400">{balance.toFixed(4)}</span></div>
              <div>Weather: <span className="font-bold text-blue-400">{currentWeather}</span></div>
              <div>Lemonheads: <span className="font-bold text-yellow-300">{lemonheadsCount}</span></div>
              {isEmergencyActive && (
                <div className="text-red-500 font-bold animate-pulse">EMERGENCY: {emergencyType}</div>
              )}
            </div>
          </CardContent>
        </Card>

        <div className="flex space-x-2">
          {/* God Mode Button for Alexander */}
          {isAlexander && godModeAvailable && (
            <Button
              variant={godModeActive ? "default" : "outline"}
              size="sm"
              onClick={toggleGodMode}
              className={`bg-black/80 border-purple-500 ${godModeActive ? 'text-purple-900 bg-purple-400' : 'text-purple-400'} hover:bg-purple-500/20`}
            >
              <Crown className="h-4 w-4" />
              God Mode
            </Button>
          )}
          
          {/* Lemonheads Actions */}
          <Button
            variant="outline"
            size="sm"
            onClick={() => consumeLemonheads(1)}
            disabled={lemonheadsCount === 0}
            className="bg-black/80 border-yellow-500 text-yellow-400 hover:bg-yellow-500/20"
            title="Consume 1 Lemonhead for stat boost"
          >
            🍋 Eat
          </Button>
          
          <Button
            variant="outline"
            size="sm"
            onClick={buyBox}
            className="bg-black/80 border-yellow-500 text-yellow-400 hover:bg-yellow-500/20"
            title="Buy Lemonheads box for $300"
          >
            📦 Buy
          </Button>
          
          <Button
            variant="outline"
            size="sm"
            onClick={toggleMute}
            className="bg-black/80 border-green-500 text-green-400 hover:bg-green-500/20"
          >
            {isMuted ? <VolumeX className="h-4 w-4" /> : <Volume2 className="h-4 w-4" />}
          </Button>
        </div>
      </div>

      {/* Element Progress Bar */}
      {selectedElement && (
        <div className="absolute top-20 left-4 right-4 pointer-events-auto">
          <Card className="bg-black/80 border-green-500">
            <CardContent className="p-3">
              <div className="space-y-2">
                <div className="text-sm text-green-400">Elemental Mastery Progress</div>
                <Progress 
                  value={elementProgress} 
                  className="h-2"
                />
                <div className="text-xs text-gray-400">{elementProgress}% mastered</div>
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Control Panel */}
      <div className="absolute bottom-4 left-4 flex flex-col space-y-2 pointer-events-auto">
        <Button
          variant={activePanel === 'garden' ? 'default' : 'outline'}
          onClick={() => setActivePanel(activePanel === 'garden' ? null : 'garden')}
          className="bg-black/80 border-green-500 text-green-400 hover:bg-green-500/20"
        >
          <TreePine className="h-4 w-4 mr-2" />
          Garden
        </Button>
        
        <Button
          variant={activePanel === 'actions' ? 'default' : 'outline'}
          onClick={() => setActivePanel(activePanel === 'actions' ? null : 'actions')}
          className="bg-black/80 border-green-500 text-green-400 hover:bg-green-500/20"
        >
          <Settings className="h-4 w-4 mr-2" />
          Actions
        </Button>

        <Button
          variant={activePanel === 'economy' ? 'default' : 'outline'}
          onClick={() => setActivePanel(activePanel === 'economy' ? null : 'economy')}
          className="bg-black/80 border-green-500 text-green-400 hover:bg-green-500/20"
        >
          <Coins className="h-4 w-4 mr-2" />
          Economy
        </Button>

        <Button
          variant={activePanel === 'weather' ? 'default' : 'outline'}
          onClick={() => setActivePanel(activePanel === 'weather' ? null : 'weather')}
          className="bg-black/80 border-green-500 text-green-400 hover:bg-green-500/20"
        >
          <Cloud className="h-4 w-4 mr-2" />
          Weather
        </Button>

        <Button
          variant={activePanel === 'achievements' ? 'default' : 'outline'}
          onClick={() => setActivePanel(activePanel === 'achievements' ? null : 'achievements')}
          className="bg-black/80 border-green-500 text-green-400 hover:bg-green-500/20"
        >
          <Trophy className="h-4 w-4 mr-2" />
          Achievements
        </Button>
        
        <Button
          variant={activePanel === 'skills' ? 'default' : 'outline'}
          onClick={() => setActivePanel(activePanel === 'skills' ? null : 'skills')}
          className="bg-black/80 border-green-500 text-green-400 hover:bg-green-500/20"
        >
          <Zap className="h-4 w-4 mr-2" />
          Skills
        </Button>
        
        <Button
          variant={activePanel === 'science' ? 'default' : 'outline'}
          onClick={() => setActivePanel(activePanel === 'science' ? null : 'science')}
          className="bg-black/80 border-green-500 text-green-400 hover:bg-green-500/20"
        >
          <Microscope className="h-4 w-4 mr-2" />
          Science
        </Button>
      </div>

      {/* Panel Content */}
      {activePanel && (
        <div className="absolute bottom-20 left-4 w-96 pointer-events-auto">
          <Card className="bg-black/90 border-green-500 text-green-400 max-h-96 overflow-y-auto">
            <CardHeader>
              <CardTitle className="text-green-400">
                {activePanel === 'garden' && 'Garden Builder'}
                {activePanel === 'actions' && 'Action Tree'}
                {activePanel === 'economy' && 'XRP Economy'}
                {activePanel === 'weather' && 'Weather System'}
                {activePanel === 'achievements' && 'Achievements'}
                {activePanel === 'skills' && 'Skill Tree'}
                {activePanel === 'science' && 'Scientific Analysis'}
              </CardTitle>
            </CardHeader>
            <CardContent>
              {activePanel === 'garden' && <GardenBuilder />}
              {activePanel === 'actions' && <ActionTree />}
              {activePanel === 'economy' && <XRPEconomy />}
              {activePanel === 'weather' && <WeatherDisplay />}
              {activePanel === 'achievements' && (
                <div className="space-y-2">
                  <div>Total Points: <span className="font-bold text-yellow-400">{totalPoints}</span></div>
                  <div>Achievements Unlocked: <span className="font-bold text-green-400">{achievements.length}</span></div>
                  {achievements.slice(0, 5).map((achievement, index) => (
                    <div key={index} className="text-sm bg-green-500/20 p-2 rounded">
                      {achievement.name}: {achievement.description}
                    </div>
                  ))}
                </div>
              )}
              {activePanel === 'skills' && <SkillTree />}
              {activePanel === 'science' && <ScientificDashboard />}
            </CardContent>
          </Card>
        </div>
      )}

      {/* Mini Map */}
      <div className="absolute top-32 right-4 pointer-events-auto">
        <MiniMap />
      </div>

      {/* Controls Help */}
      <div className="absolute bottom-4 right-4 pointer-events-auto">
        <Card className="bg-black/80 border-green-500">
          <CardContent className="p-3">
            <div className="text-xs text-green-400 space-y-1">
              <div>WASD: Move</div>
              <div>Space: Jump</div>
              <div>Q: Cast Magic</div>
              <div>E: Interact</div>
              <div>B: Build</div>
              <div>C: Camera</div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
