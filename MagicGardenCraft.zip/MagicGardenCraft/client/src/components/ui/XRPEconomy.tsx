import { useEffect } from 'react';
import { Button } from './button';
import { Progress } from './progress';
import { useXRP } from '../../lib/stores/useXRP';
import { TrendingUp, TrendingDown, Coins } from 'lucide-react';

export function XRPEconomy() {
  const { 
    balance, 
    xrpPrice, 
    marketTrend, 
    dailyEarnings,
    spend,
    earn,
    updatePrice 
  } = useXRP();

  useEffect(() => {
    // Simulate market updates every 30 seconds
    const interval = setInterval(() => {
      updatePrice();
    }, 30000);

    return () => clearInterval(interval);
  }, [updatePrice]);

  const getTrendColor = () => {
    switch (marketTrend) {
      case 'up': return 'text-green-400';
      case 'down': return 'text-red-400';
      default: return 'text-yellow-400';
    }
  };

  const getTrendIcon = () => {
    switch (marketTrend) {
      case 'up': return <TrendingUp className="h-4 w-4" />;
      case 'down': return <TrendingDown className="h-4 w-4" />;
      default: return <Coins className="h-4 w-4" />;
    }
  };

  const shopPriceMultiplier = marketTrend === 'up' ? 0.8 : marketTrend === 'down' ? 1.2 : 1.0;

  return (
    <div className="space-y-4">
      <div>
        <h3 className="text-lg font-bold text-green-400 mb-2">XRP Economy</h3>
        <p className="text-sm text-gray-400 mb-4">
          XRP prices affect in-game shop costs. Higher XRP = Lower shop prices!
        </p>
      </div>

      {/* Current Balance */}
      <div className="bg-gray-800 p-3 rounded">
        <div className="flex justify-between items-center mb-2">
          <span className="text-gray-300">Your Balance</span>
          <span className="text-yellow-400 font-bold">{balance.toFixed(4)} XRP</span>
        </div>
        <div className="text-sm text-gray-400">
          USD Value: ${(balance * xrpPrice).toFixed(2)}
        </div>
      </div>

      {/* Market Status */}
      <div className="bg-gray-800 p-3 rounded">
        <div className="flex justify-between items-center mb-2">
          <span className="text-gray-300">XRP Price</span>
          <div className={`flex items-center space-x-1 ${getTrendColor()}`}>
            {getTrendIcon()}
            <span className="font-bold">${xrpPrice.toFixed(4)}</span>
          </div>
        </div>
        <div className="text-sm text-gray-400">
          Shop Price Modifier: {shopPriceMultiplier === 1 ? 'Normal' : 
            shopPriceMultiplier < 1 ? `${((1-shopPriceMultiplier) * 100).toFixed(0)}% Discount` :
            `${((shopPriceMultiplier-1) * 100).toFixed(0)}% Markup`}
        </div>
      </div>

      {/* Daily Earnings */}
      <div className="bg-gray-800 p-3 rounded">
        <div className="flex justify-between items-center mb-2">
          <span className="text-gray-300">Today's Earnings</span>
          <span className="text-green-400 font-bold">{dailyEarnings.toFixed(4)} XRP</span>
        </div>
        <Progress value={(dailyEarnings / 0.1) * 100} className="h-2" />
        <div className="text-xs text-gray-400 mt-1">
          Daily Goal: 0.1 XRP
        </div>
      </div>

      {/* Quick Actions */}
      <div className="space-y-2">
        <h4 className="font-semibold text-green-400">Earn XRP</h4>
        
        <Button
          onClick={() => earn(0.001)}
          className="w-full bg-green-600 hover:bg-green-700 text-white"
        >
          Daily Garden Care (+0.001 XRP)
        </Button>

        <Button
          onClick={() => earn(0.002)}
          className="w-full bg-blue-600 hover:bg-blue-700 text-white"
        >
          Complete Magic Ritual (+0.002 XRP)
        </Button>

        <Button
          onClick={() => earn(0.005)}
          className="w-full bg-purple-600 hover:bg-purple-700 text-white"
        >
          Weather Meditation (+0.005 XRP)
        </Button>
      </div>

      {/* Market Alerts */}
      {marketTrend === 'down' && xrpPrice < 0.5 && (
        <div className="bg-red-900/50 border border-red-500 p-3 rounded">
          <p className="text-red-200 text-sm font-bold">⚠️ Market Alert</p>
          <p className="text-red-300 text-xs">
            XRP is down significantly. Shop prices are higher. Consider waiting for market recovery.
          </p>
        </div>
      )}

      {marketTrend === 'up' && xrpPrice > 1.5 && (
        <div className="bg-green-900/50 border border-green-500 p-3 rounded">
          <p className="text-green-200 text-sm font-bold">🎉 Market Surge</p>
          <p className="text-green-300 text-xs">
            XRP is performing well! Shop prices are discounted. Great time to make purchases.
          </p>
        </div>
      )}

      {/* Economic Scarcity Warning */}
      {balance < 0.01 && (
        <div className="bg-yellow-900/50 border border-yellow-500 p-3 rounded">
          <p className="text-yellow-200 text-sm font-bold">💰 Low Balance</p>
          <p className="text-yellow-300 text-xs">
            Your XRP balance is low. Focus on earning activities to maintain garden growth and magical progress.
          </p>
        </div>
      )}
    </div>
  );
}
