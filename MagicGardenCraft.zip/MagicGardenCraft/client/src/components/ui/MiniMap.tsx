import { useRef, useMemo } from 'react';
import { useGarden } from '../../lib/stores/useGarden';
import { useElements } from '../../lib/stores/useElements';

export function MiniMap() {
  const { gardenPlots } = useGarden();
  const { selectedElement } = useElements();
  const canvasRef = useRef<HTMLCanvasElement>(null);

  const mapData = useMemo(() => {
    // Create a simple 2D representation of the garden
    const mapSize = 100;
    const plotsOnMap = gardenPlots.map(plot => ({
      x: (plot.position[0] + 50) / 100 * mapSize,
      y: (plot.position[2] + 50) / 100 * mapSize,
      element: plot.element,
      growth: plot.growth
    }));
    
    return { plotsOnMap, mapSize };
  }, [gardenPlots]);

  const getElementColor = (element: string) => {
    switch (element) {
      case 'fire': return '#ff6644';
      case 'water': return '#4466ff';
      case 'earth': return '#66ff44';
      case 'air': return '#ffff66';
      case 'shadow': return '#666699';
      case 'black': return '#cc0099';
      default: return '#888888';
    }
  };

  return (
    <div className="bg-gray-800 p-3 rounded border border-gray-600">
      <h3 className="text-sm font-bold text-green-400 mb-2">Garden Map</h3>
      
      {/* Simple CSS-based mini map */}
      <div className="relative w-24 h-24 bg-green-900 rounded border-2 border-green-600">
        {/* Player position (center) */}
        <div 
          className="absolute w-2 h-2 bg-yellow-400 rounded-full transform -translate-x-1 -translate-y-1"
          style={{ left: '50%', top: '50%' }}
        />
        
        {/* Garden plots */}
        {mapData.plotsOnMap.map((plot, index) => (
          <div
            key={`minimap-plot-${index}`}
            className="absolute w-1 h-1 rounded-full transform -translate-x-0.5 -translate-y-0.5"
            style={{
              left: `${(plot.x / mapData.mapSize) * 100}%`,
              top: `${(plot.y / mapData.mapSize) * 100}%`,
              backgroundColor: getElementColor(plot.element),
              opacity: 0.5 + plot.growth * 0.5
            }}
          />
        ))}
        
        {/* Compass */}
        <div className="absolute top-1 right-1 text-xs text-gray-300">
          N
        </div>
        
        {/* Legend */}
        <div className="absolute bottom-1 left-1 text-xs text-yellow-400">
          ●
        </div>
      </div>
      
      <div className="text-xs text-gray-400 mt-2">
        <div>Yellow dot: You</div>
        <div>Colored dots: Plants</div>
        <div>Plots: {gardenPlots.length}</div>
      </div>
    </div>
  );
}