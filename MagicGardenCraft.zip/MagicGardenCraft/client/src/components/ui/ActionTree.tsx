import { Progress } from './progress';
import { useGarden } from '../../lib/stores/useGarden';
import { useElements } from '../../lib/stores/useElements';

export function ActionTree() {
  const { actionTreeData } = useGarden();
  const { selectedElement } = useElements();

  const getActionTreeForCategory = (category: string) => {
    return actionTreeData[category] || {};
  };

  const getTotalActionsInCategory = (category: string) => {
    const categoryData = getActionTreeForCategory(category);
    return Object.values(categoryData).reduce((sum: number, count) => sum + (count as number), 0);
  };

  const categories = [
    { key: 'movement', name: 'Movement', color: 'text-blue-400' },
    { key: 'magic', name: 'Magic', color: 'text-purple-400' },
    { key: 'building', name: 'Building', color: 'text-green-400' },
    { key: 'interaction', name: 'Interaction', color: 'text-yellow-400' },
    { key: 'exploration', name: 'Exploration', color: 'text-cyan-400' }
  ];

  const getElementalBranches = () => {
    if (!selectedElement) return [];

    const branches = {
      fire: ['Destruction', 'Healing Flames', 'Forge Magic', 'Phoenix Arts', 'Solar Control'],
      water: ['Tidal Force', 'Healing Springs', 'Ice Mastery', 'Storm Calling', 'Purification'],
      earth: ['Stone Shaping', 'Plant Growth', 'Metal Forging', 'Seismic Control', 'Crystal Arts'],
      air: ['Wind Control', 'Lightning Strike', 'Weather Mastery', 'Flight Magic', 'Sound Manipulation'],
      shadow: ['Void Walking', 'Illusion Casting', 'Dark Healing', 'Fear Control', 'Time Shadows'],
      black: ['All Branches', 'Supreme Power', 'Reality Control', 'Time Mastery', 'Void Dominion']
    };

    return branches[selectedElement as keyof typeof branches] || [];
  };

  return (
    <div className="space-y-4">
      <div>
        <h3 className="text-lg font-bold text-green-400 mb-2">Action Progress Trees</h3>
        <p className="text-sm text-gray-400 mb-4">
          Every action you take builds specialized skill trees with unique progression paths.
        </p>
      </div>

      {/* Main Action Categories */}
      <div className="space-y-3">
        {categories.map(category => {
          const totalActions = getTotalActionsInCategory(category.key);
          const progress = Math.min((totalActions / 100) * 100, 100);
          
          return (
            <div key={category.key} className="bg-gray-800 p-3 rounded">
              <div className="flex justify-between items-center mb-2">
                <span className={`font-semibold ${category.color}`}>{category.name}</span>
                <span className="text-white text-sm">{totalActions} actions</span>
              </div>
              <Progress value={progress} className="h-2" />
              <div className="text-xs text-gray-400 mt-1">
                Progress: {progress.toFixed(1)}%
              </div>
            </div>
          );
        })}
      </div>

      {/* Elemental Specialization Branches */}
      {selectedElement && (
        <div>
          <h4 className="font-semibold text-purple-400 mb-2">
            {selectedElement.charAt(0).toUpperCase() + selectedElement.slice(1)} Elemental Branches
          </h4>
          <div className="space-y-2">
            {getElementalBranches().map((branch, index) => {
              const magicActions = getTotalActionsInCategory('magic');
              const branchProgress = Math.min((magicActions / (index + 1) / 20) * 100, 100);
              
              return (
                <div key={branch} className="bg-gray-800 p-2 rounded text-sm">
                  <div className="flex justify-between items-center mb-1">
                    <span className="text-gray-200">{branch}</span>
                    <span className="text-yellow-400">{branchProgress.toFixed(0)}%</span>
                  </div>
                  <Progress value={branchProgress} className="h-1" />
                </div>
              );
            })}
          </div>
          
          {selectedElement === 'black' && (
            <div className="mt-2 p-2 bg-red-900/50 border border-red-500 rounded">
              <p className="text-red-200 text-xs">
                Black Magic Supremacy: All branches progress 500% faster and remain strongest through all balance patches.
              </p>
            </div>
          )}
        </div>
      )}

      {/* Action Details */}
      <div>
        <h4 className="font-semibold text-green-400 mb-2">Recent Actions</h4>
        <div className="space-y-1 max-h-32 overflow-y-auto text-sm">
          {Object.entries(actionTreeData).map(([category, actions]) =>
            Object.entries(actions as Record<string, number>).map(([action, count]) => (
              <div key={`${category}-${action}`} className="flex justify-between text-gray-300">
                <span>{category}: {action.replace('_', ' ')}</span>
                <span className="text-yellow-400">{count}</span>
              </div>
            ))
          )}
          {Object.keys(actionTreeData).length === 0 && (
            <div className="text-gray-400 text-center py-4">
              Start taking actions to build your skill trees!
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
