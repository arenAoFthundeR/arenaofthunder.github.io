import { useState } from 'react';
import { useElements } from '../../lib/stores/useElements';
import { useGarden } from '../../lib/stores/useGarden';
import { Button } from './button';
import { Card, CardContent, CardHeader, CardTitle } from './card';
import { Badge } from './badge';
import { Progress } from './progress';

interface SkillNode {
  id: string;
  name: string;
  description: string;
  level: number;
  maxLevel: number;
  cost: number;
  prerequisite?: string;
  unlocked: boolean;
}

export function SkillTree() {
  const { selectedElement } = useElements();
  const { gardenData, actionTreeData } = useGarden();
  const [activeCategory, setActiveCategory] = useState<string>('movement');

  // Calculate available skill points
  const totalExperience = Object.values(actionTreeData).reduce((total, category) => {
    return total + Object.values(category).reduce((sum, count) => sum + count, 0);
  }, 0);
  
  const availableSkillPoints = Math.floor(totalExperience / 10);
  const [usedSkillPoints, setUsedSkillPoints] = useState(0);

  const skillTrees: Record<string, SkillNode[]> = {
    movement: [
      {
        id: 'speed_1',
        name: 'Swift Movement',
        description: 'Increase movement speed by 20%',
        level: 0,
        maxLevel: 5,
        cost: 1,
        unlocked: true
      },
      {
        id: 'jump_1',
        name: 'High Jump',
        description: 'Jump 50% higher',
        level: 0,
        maxLevel: 3,
        cost: 2,
        unlocked: true
      },
      {
        id: 'dash_1',
        name: 'Dash Attack',
        description: 'Unlock dash ability',
        level: 0,
        maxLevel: 1,
        cost: 3,
        prerequisite: 'speed_1',
        unlocked: false
      }
    ],
    magic: [
      {
        id: 'power_1',
        name: 'Magic Power',
        description: 'Increase spell damage by 25%',
        level: 0,
        maxLevel: 10,
        cost: 1,
        unlocked: true
      },
      {
        id: 'efficiency_1',
        name: 'Mana Efficiency',
        description: 'Reduce mana costs by 15%',
        level: 0,
        maxLevel: 8,
        cost: 1,
        unlocked: true
      },
      {
        id: 'elemental_1',
        name: 'Elemental Mastery',
        description: `Enhanced ${selectedElement || 'elemental'} spells`,
        level: 0,
        maxLevel: 5,
        cost: 2,
        prerequisite: 'power_1',
        unlocked: false
      }
    ],
    garden: [
      {
        id: 'growth_1',
        name: 'Growth Acceleration',
        description: 'Plants grow 30% faster',
        level: 0,
        maxLevel: 5,
        cost: 1,
        unlocked: true
      },
      {
        id: 'yield_1',
        name: 'Harvest Yield',
        description: 'Get more resources from plants',
        level: 0,
        maxLevel: 3,
        cost: 2,
        unlocked: true
      },
      {
        id: 'magical_garden',
        name: 'Magical Garden',
        description: 'Unlock magical plant varieties',
        level: 0,
        maxLevel: 1,
        cost: 5,
        prerequisite: 'growth_1',
        unlocked: false
      }
    ]
  };

  const canUpgradeSkill = (skill: SkillNode) => {
    const remainingPoints = availableSkillPoints - usedSkillPoints;
    return skill.level < skill.maxLevel && 
           remainingPoints >= skill.cost && 
           skill.unlocked;
  };

  const upgradeSkill = (skillId: string) => {
    const skill = skillTrees[activeCategory].find(s => s.id === skillId);
    if (skill && canUpgradeSkill(skill)) {
      skill.level += 1;
      setUsedSkillPoints(prev => prev + skill.cost);
      
      // Unlock prerequisites
      skillTrees[activeCategory].forEach(s => {
        if (s.prerequisite === skillId && skill.level >= 1) {
          s.unlocked = true;
        }
      });
    }
  };

  const categories = [
    { id: 'movement', name: 'Movement', icon: '🏃' },
    { id: 'magic', name: 'Magic', icon: '✨' },
    { id: 'garden', name: 'Garden', icon: '🌱' }
  ];

  return (
    <div className="space-y-4">
      <div>
        <h3 className="text-lg font-bold text-green-400 mb-2">Skill Tree</h3>
        <div className="flex justify-between items-center mb-4">
          <div className="text-sm text-gray-300">
            Skill Points: <span className="text-yellow-400 font-bold">
              {availableSkillPoints - usedSkillPoints}
            </span>
          </div>
          <div className="text-xs text-gray-400">
            Total XP: {totalExperience}
          </div>
        </div>
      </div>

      {/* Category Tabs */}
      <div className="flex space-x-2 mb-4">
        {categories.map((category) => (
          <Button
            key={category.id}
            variant={activeCategory === category.id ? 'default' : 'outline'}
            size="sm"
            onClick={() => setActiveCategory(category.id)}
            className="text-xs"
          >
            {category.icon} {category.name}
          </Button>
        ))}
      </div>

      {/* Skills Grid */}
      <div className="grid gap-3">
        {skillTrees[activeCategory].map((skill) => (
          <Card
            key={skill.id}
            className={`bg-gray-800 border-gray-600 ${
              skill.unlocked ? 'opacity-100' : 'opacity-50'
            }`}
          >
            <CardHeader className="pb-2">
              <div className="flex justify-between items-start">
                <CardTitle className="text-sm text-white">
                  {skill.name}
                </CardTitle>
                <Badge variant={skill.level > 0 ? 'default' : 'secondary'}>
                  {skill.level}/{skill.maxLevel}
                </Badge>
              </div>
            </CardHeader>
            <CardContent className="pt-0">
              <p className="text-xs text-gray-400 mb-3">
                {skill.description}
              </p>
              
              {skill.level > 0 && (
                <Progress 
                  value={(skill.level / skill.maxLevel) * 100} 
                  className="mb-3 h-2"
                />
              )}
              
              <div className="flex justify-between items-center">
                <div className="text-xs text-gray-400">
                  Cost: {skill.cost} SP
                </div>
                <Button
                  size="sm"
                  disabled={!canUpgradeSkill(skill)}
                  onClick={() => upgradeSkill(skill.id)}
                  className="text-xs px-2 py-1 h-6"
                >
                  {skill.level === 0 ? 'Learn' : 'Upgrade'}
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Prerequisites Info */}
      <div className="text-xs text-gray-500 p-2 bg-gray-900 rounded">
        💡 Tip: Some skills require others to be learned first. 
        Gain skill points by performing actions in the game!
      </div>
    </div>
  );
}