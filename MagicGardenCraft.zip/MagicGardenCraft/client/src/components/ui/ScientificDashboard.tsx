import { useScientificData } from '../../lib/stores/useScientificData';
import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './card';
import { Progress } from './progress';
import { Badge } from './badge';
import { Button } from './button';
import { PlantGeneticsSystem } from '../game/PlantGeneticsSystem';
import { EcosystemSimulator } from '../game/EcosystemSimulator';
import { PlantBreedingSystem } from '../game/PlantBreedingSystem';
import { PetSystem } from '../game/PetSystem';
import { Thermometer, Droplets, Wind, Leaf, TestTube, Bug, TreePine, Dna, Globe, Heart, Scissors } from 'lucide-react';

export function ScientificDashboard() {
  const [activeView, setActiveView] = useState<'data' | 'genetics' | 'ecosystem' | 'breeding' | 'pets'>('data');
  const {
    co2Level,
    oxygenLevel,
    temperature,
    humidity,
    airPressure,
    uvIndex,
    soilPH,
    soilNitrogen,
    soilPhosphorus,
    soilPotassium,
    soilOrganicMatter,
    soilMoisture,
    biodiversityIndex,
    carbonSequestration,
    oxygenProduction,
    pollinatorCount,
    dayOfYear,
    timeOfDay,
    seasonalFactor
  } = useScientificData();

  const getSeason = () => {
    if (dayOfYear < 80 || dayOfYear > 355) return 'Winter';
    if (dayOfYear < 172) return 'Spring';
    if (dayOfYear < 266) return 'Summer';
    return 'Autumn';
  };

  const getAirQualityStatus = () => {
    if (co2Level < 400) return { status: 'Excellent', color: 'text-green-400' };
    if (co2Level < 450) return { status: 'Good', color: 'text-yellow-400' };
    if (co2Level < 500) return { status: 'Moderate', color: 'text-orange-400' };
    return { status: 'Poor', color: 'text-red-400' };
  };

  const getSoilHealthStatus = () => {
    const idealPH = soilPH >= 6.0 && soilPH <= 7.0;
    const goodNutrients = soilNitrogen > 15 && soilPhosphorus > 10 && soilPotassium > 100;
    const goodMoisture = soilMoisture > 20 && soilMoisture < 40;
    
    if (idealPH && goodNutrients && goodMoisture) return { status: 'Optimal', color: 'text-green-400' };
    if ((idealPH && goodNutrients) || (idealPH && goodMoisture)) return { status: 'Good', color: 'text-yellow-400' };
    return { status: 'Needs Care', color: 'text-orange-400' };
  };

  const formatTime = (hour: number) => {
    const h = Math.floor(hour);
    const m = Math.floor((hour - h) * 60);
    return `${h.toString().padStart(2, '0')}:${m.toString().padStart(2, '0')}`;
  };

  const airQuality = getAirQualityStatus();
  const soilHealth = getSoilHealthStatus();

  return (
    <div className="space-y-4">
      <div>
        <h3 className="text-lg font-bold text-green-400 mb-2">Scientific Analysis</h3>
        <p className="text-sm text-gray-400 mb-4">
          Advanced botanical, genetic, and ecological research tools
        </p>
        
        {/* View Mode Selector */}
        <div className="flex space-x-2 mb-4">
          <Button
            variant={activeView === 'data' ? 'default' : 'outline'}
            onClick={() => setActiveView('data')}
            size="sm"
            className="bg-black/80 border-green-500 text-green-400 hover:bg-green-500/20"
          >
            <TestTube className="h-4 w-4 mr-2" />
            Environmental Data
          </Button>
          <Button
            variant={activeView === 'genetics' ? 'default' : 'outline'}
            onClick={() => setActiveView('genetics')}
            size="sm"
            className="bg-black/80 border-green-500 text-green-400 hover:bg-green-500/20"
          >
            <Dna className="h-4 w-4 mr-2" />
            Plant Genetics
          </Button>
          <Button
            variant={activeView === 'ecosystem' ? 'default' : 'outline'}
            onClick={() => setActiveView('ecosystem')}
            size="sm"
            className="bg-black/80 border-green-500 text-green-400 hover:bg-green-500/20"
          >
            <Globe className="h-4 w-4 mr-2" />
            Ecosystem
          </Button>
          <Button
            variant={activeView === 'breeding' ? 'default' : 'outline'}
            onClick={() => setActiveView('breeding')}
            size="sm"
            className="bg-black/80 border-green-500 text-green-400 hover:bg-green-500/20"
          >
            <Scissors className="h-4 w-4 mr-2" />
            Breeding
          </Button>
          <Button
            variant={activeView === 'pets' ? 'default' : 'outline'}
            onClick={() => setActiveView('pets')}
            size="sm"
            className="bg-black/80 border-green-500 text-green-400 hover:bg-green-500/20"
          >
            <Heart className="h-4 w-4 mr-2" />
            Plant Pets
          </Button>
        </div>
      </div>

      {/* Genetics View */}
      {activeView === 'genetics' && (
        <div className="space-y-4">
          <Card className="bg-gray-800 border-gray-600">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm text-white flex items-center">
                <Dna className="h-4 w-4 mr-2" />
                Plant Genetics Laboratory
              </CardTitle>
            </CardHeader>
            <CardContent>
              <PlantGeneticsSystem selectedPlant="tomato_lycopersicon" />
              <div className="mt-4 text-xs text-gray-400">
                Interactive DNA visualization showing genetic traits, allele expressions, 
                and environmental effects on plant genetics. Real mutation rates calculated 
                from current soil and atmospheric conditions.
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Ecosystem View */}
      {activeView === 'ecosystem' && (
        <div className="space-y-4">
          <Card className="bg-gray-800 border-gray-600">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm text-white flex items-center">
                <Globe className="h-4 w-4 mr-2" />
                Live Ecosystem Simulation
              </CardTitle>
            </CardHeader>
            <CardContent>
              <EcosystemSimulator />
              <div className="mt-4 text-xs text-gray-400">
                Real-time simulation of pollination networks, decomposer activity, 
                and carbon cycling. Bee behavior responds to flower availability 
                and environmental conditions.
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Plant Breeding View */}
      {activeView === 'breeding' && (
        <div className="space-y-4">
          <PlantBreedingSystem />
        </div>
      )}

      {/* Plant Pets View */}
      {activeView === 'pets' && (
        <div className="space-y-4">
          <PetSystem />
        </div>
      )}

      {/* Environmental Data View */}
      {activeView === 'data' && (
        <div className="space-y-4">

      {/* Time and Season */}
      <Card className="bg-gray-800 border-gray-600">
        <CardHeader className="pb-2">
          <CardTitle className="text-sm text-white flex items-center">
            <Wind className="h-4 w-4 mr-2" />
            Time & Season
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-2">
          <div className="flex justify-between text-sm">
            <span className="text-gray-300">Day {dayOfYear} • {getSeason()}</span>
            <span className="text-gray-300">{formatTime(timeOfDay)}</span>
          </div>
          <Progress value={seasonalFactor * 100} className="h-2" />
          <div className="text-xs text-gray-400">
            Seasonal Factor: {Math.round(seasonalFactor * 100)}%
          </div>
        </CardContent>
      </Card>

      {/* Atmospheric Conditions */}
      <Card className="bg-gray-800 border-gray-600">
        <CardHeader className="pb-2">
          <CardTitle className="text-sm text-white flex items-center">
            <Thermometer className="h-4 w-4 mr-2" />
            Atmospheric Data
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="grid grid-cols-2 gap-3 text-sm">
            <div>
              <div className="text-gray-300">Temperature</div>
              <div className="font-bold text-white">{temperature}°C</div>
            </div>
            <div>
              <div className="text-gray-300">Humidity</div>
              <div className="font-bold text-white">{humidity}%</div>
            </div>
            <div>
              <div className="text-gray-300">CO₂ Level</div>
              <div className="font-bold text-white">{co2Level} ppm</div>
            </div>
            <div>
              <div className="text-gray-300">O₂ Level</div>
              <div className="font-bold text-white">{oxygenLevel}%</div>
            </div>
          </div>
          
          <div className="flex justify-between items-center">
            <span className="text-xs text-gray-400">Air Quality:</span>
            <Badge className={airQuality.color}>{airQuality.status}</Badge>
          </div>
          
          <div className="grid grid-cols-2 gap-3 text-xs text-gray-400">
            <div>Pressure: {airPressure} kPa</div>
            <div>UV Index: {uvIndex}</div>
          </div>
        </CardContent>
      </Card>

      {/* Soil Composition */}
      <Card className="bg-gray-800 border-gray-600">
        <CardHeader className="pb-2">
          <CardTitle className="text-sm text-white flex items-center">
            <TestTube className="h-4 w-4 mr-2" />
            Soil Analysis
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="grid grid-cols-2 gap-3 text-sm">
            <div>
              <div className="text-gray-300">pH Level</div>
              <div className="font-bold text-white">{soilPH}</div>
            </div>
            <div>
              <div className="text-gray-300">Moisture</div>
              <div className="font-bold text-white">{soilMoisture}%</div>
            </div>
          </div>
          
          <div className="space-y-2">
            <div className="text-xs text-gray-400">NPK Levels (mg/kg)</div>
            <div className="grid grid-cols-3 gap-2 text-xs">
              <div>
                <div className="text-gray-400">N</div>
                <div className="font-bold text-blue-400">{soilNitrogen}</div>
              </div>
              <div>
                <div className="text-gray-400">P</div>
                <div className="font-bold text-red-400">{soilPhosphorus}</div>
              </div>
              <div>
                <div className="text-gray-400">K</div>
                <div className="font-bold text-yellow-400">{soilPotassium}</div>
              </div>
            </div>
          </div>
          
          <div className="flex justify-between items-center">
            <span className="text-xs text-gray-400">Soil Health:</span>
            <Badge className={soilHealth.color}>{soilHealth.status}</Badge>
          </div>
          
          <div className="text-xs text-gray-400">
            Organic Matter: {soilOrganicMatter}%
          </div>
        </CardContent>
      </Card>

      {/* Ecosystem Metrics */}
      <Card className="bg-gray-800 border-gray-600">
        <CardHeader className="pb-2">
          <CardTitle className="text-sm text-white flex items-center">
            <TreePine className="h-4 w-4 mr-2" />
            Ecosystem Services
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="grid grid-cols-2 gap-3 text-sm">
            <div>
              <div className="text-gray-300">CO₂ Sequestered</div>
              <div className="font-bold text-green-400">{carbonSequestration} kg/day</div>
            </div>
            <div>
              <div className="text-gray-300">O₂ Produced</div>
              <div className="font-bold text-blue-400">{oxygenProduction} L/day</div>
            </div>
          </div>
          
          <div className="space-y-2">
            <div className="flex justify-between text-sm">
              <span className="text-gray-300">Biodiversity Index</span>
              <span className="font-bold text-white">{biodiversityIndex}</span>
            </div>
            <Progress value={biodiversityIndex * 100} className="h-2" />
          </div>
          
          <div className="flex items-center justify-between text-sm">
            <div className="flex items-center">
              <Bug className="h-4 w-4 mr-1 text-yellow-400" />
              <span className="text-gray-300">Pollinators</span>
            </div>
            <span className="font-bold text-yellow-400">{pollinatorCount}</span>
          </div>
        </CardContent>
      </Card>

      {/* Scientific Insights */}
      <Card className="bg-gray-800 border-gray-600">
        <CardHeader className="pb-2">
          <CardTitle className="text-sm text-white flex items-center">
            <Leaf className="h-4 w-4 mr-2" />
            Scientific Insights
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-2 text-xs text-gray-400">
            {temperature < 15 && (
              <div className="text-blue-400">• Low temperature may slow plant growth</div>
            )}
            {temperature > 30 && (
              <div className="text-red-400">• High temperature stress detected</div>
            )}
            {soilPH < 6.0 && (
              <div className="text-orange-400">• Acidic soil may limit nutrient uptake</div>
            )}
            {soilPH > 7.5 && (
              <div className="text-orange-400">• Alkaline soil may cause iron deficiency</div>
            )}
            {soilNitrogen < 15 && (
              <div className="text-yellow-400">• Nitrogen deficiency limits growth</div>
            )}
            {co2Level > 450 && (
              <div className="text-green-400">• Elevated CO₂ may enhance photosynthesis</div>
            )}
            {biodiversityIndex > 0.8 && (
              <div className="text-green-400">• Healthy ecosystem with good diversity</div>
            )}
            {pollinatorCount === 0 && (
              <div className="text-red-400">• No pollinators present - may affect fruiting</div>
            )}
          </div>
        </CardContent>
      </Card>
        </div>
      )}
    </div>
  );
}