import { useState } from 'react';
import { Button } from './button';
import { Card, CardContent, CardHeader, CardTitle } from './card';
import { Input } from './input';
import { useElements } from '../../lib/stores/useElements';
import { useGarden } from '../../lib/stores/useGarden';
import { useAchievements } from '../../lib/stores/useAchievements';
import { useAlexander } from '../../lib/stores/useAlexander';

const ELEMENTS = [
  {
    name: 'fire',
    title: 'Fire',
    description: 'Harness the power of flames and heat. Branches: Destruction, Healing Flames, Forge Magic, Phoenix Arts, Solar Control',
    color: 'bg-red-500',
    chance: 0.2
  },
  {
    name: 'water',
    title: 'Water',
    description: 'Control the flow of water and ice. Branches: Tidal Force, Healing Springs, Ice Mastery, Storm Calling, Purification',
    color: 'bg-blue-500',
    chance: 0.2
  },
  {
    name: 'earth',
    title: 'Earth',
    description: 'Command stone and nature. Branches: Stone Shaping, Plant Growth, Metal Forging, Seismic Control, Crystal Arts',
    color: 'bg-green-500',
    chance: 0.2
  },
  {
    name: 'air',
    title: 'Air',
    description: 'Master wind and lightning. Branches: Wind Control, Lightning Strike, Weather Mastery, Flight Magic, Sound Manipulation',
    color: 'bg-yellow-500',
    chance: 0.2
  },
  {
    name: 'shadow',
    title: 'Shadow',
    description: 'Embrace the darkness. Branches: Void Walking, Illusion Casting, Dark Healing, Fear Control, Time Shadows',
    color: 'bg-purple-500',
    chance: 0.19999999
  },
  {
    name: 'black',
    title: 'Black Magic',
    description: 'Ultra-rare forbidden magic with supreme power over all elements. The strongest affinity.',
    color: 'bg-black border-red-500',
    chance: 0.000000001
  }
];

export function ElementSelection() {
  const [selectedElement, setSelectedElement] = useState<string | null>(null);
  const [isConfirming, setIsConfirming] = useState(false);
  const [username, setUsername] = useState('');
  const [showUsernameForm, setShowUsernameForm] = useState(true);
  const { setElement } = useElements();
  const { setGamePhase } = useGarden();
  const { unlockAchievement } = useAchievements();
  const { activateAlexanderMode } = useAlexander();

  const handleRandomSelection = () => {
    const random = Math.random();
    let cumulativeChance = 0;
    
    for (const element of ELEMENTS) {
      cumulativeChance += element.chance;
      if (random <= cumulativeChance) {
        setSelectedElement(element.name);
        break;
      }
    }
    setIsConfirming(true);
  };

  const handleConfirm = () => {
    if (selectedElement) {
      setElement(selectedElement);
      setGamePhase('playing');
      
      // Unlock achievement
      unlockAchievement({
        id: 'element-chosen',
        name: 'Elemental Awakening',
        description: `Chosen the path of ${selectedElement}`,
        points: 100
      });

      // Special achievement for black magic
      if (selectedElement === 'black') {
        unlockAchievement({
          id: 'black-magic',
          name: 'Forbidden Power',
          description: 'Unlocked the ultra-rare Black Magic affinity',
          points: 10000
        });
      }
    }
  };

  const handleDirectSelect = (elementName: string) => {
    setSelectedElement(elementName);
    setIsConfirming(true);
  };

  const handleUsernameSubmit = () => {
    if (username.trim()) {
      activateAlexanderMode(username.trim());
      setShowUsernameForm(false);
    }
  };

  // Show username form first
  if (showUsernameForm) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-purple-900 to-black flex items-center justify-center p-4">
        <Card className="w-full max-w-md bg-black/90 border-purple-500 text-white">
          <CardHeader className="text-center">
            <CardTitle className="text-3xl font-bold text-purple-400 mb-4">
              Welcome to GARDEN
            </CardTitle>
            <p className="text-gray-300">
              Enter your username to begin your magical journey
            </p>
          </CardHeader>
          
          <CardContent className="space-y-4">
            <Input
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              placeholder="Enter username"
              className="bg-gray-800 border-gray-600 text-white placeholder-gray-400"
              onKeyPress={(e) => e.key === 'Enter' && handleUsernameSubmit()}
            />
            
            <Button
              onClick={handleUsernameSubmit}
              disabled={!username.trim()}
              className="w-full bg-purple-600 hover:bg-purple-700"
            >
              Continue
            </Button>
            
            <p className="text-xs text-gray-400 text-center">
              Hint: Try "Alexander" for special privileges
            </p>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-purple-900 to-black flex items-center justify-center p-4">
      <Card className="w-full max-w-4xl bg-black/90 border-purple-500 text-white">
        <CardHeader className="text-center">
          <CardTitle className="text-4xl font-bold text-purple-400 mb-4">
            Choose Your Elemental Affinity
          </CardTitle>
          <p className="text-gray-300 text-lg">
            This choice is permanent for your entire account. Choose wisely, as you can only progress within your chosen element.
          </p>
        </CardHeader>
        
        <CardContent className="space-y-6">
          {!isConfirming ? (
            <>
              <div className="text-center space-y-4">
                <Button
                  onClick={handleRandomSelection}
                  size="lg"
                  className="bg-purple-600 hover:bg-purple-700 text-white px-8 py-4 text-xl"
                >
                  Random Selection (Recommended)
                </Button>
                <p className="text-sm text-gray-400">
                  Let fate decide your elemental destiny. Includes chance for ultra-rare Black Magic!
                </p>
              </div>

              <div className="relative">
                <div className="absolute inset-0 flex items-center">
                  <div className="w-full border-t border-gray-600"></div>
                </div>
                <div className="relative flex justify-center text-sm">
                  <span className="px-2 bg-black text-gray-400">OR CHOOSE MANUALLY</span>
                </div>
              </div>

              <div className="grid grid-cols-2 lg:grid-cols-3 gap-4">
                {ELEMENTS.filter(e => e.name !== 'black').map((element) => (
                  <Card
                    key={element.name}
                    className={`cursor-pointer border-2 transition-all hover:scale-105 ${element.color} bg-opacity-20 border-opacity-50 hover:border-opacity-100`}
                    onClick={() => handleDirectSelect(element.name)}
                  >
                    <CardContent className="p-4 text-center">
                      <h3 className="font-bold text-lg mb-2 text-white">{element.title}</h3>
                      <p className="text-sm text-gray-300">{element.description}</p>
                      <div className="mt-2 text-xs text-gray-400">
                        Chance: {(element.chance * 100).toFixed(1)}%
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </>
          ) : (
            <div className="text-center space-y-6">
              <div className="space-y-4">
                <h2 className="text-2xl font-bold text-purple-400">
                  Confirm Your Choice
                </h2>
                
                {selectedElement && (
                  <Card className={`mx-auto max-w-md ${ELEMENTS.find(e => e.name === selectedElement)?.color} bg-opacity-30 border-opacity-70`}>
                    <CardContent className="p-6 text-center">
                      <h3 className="font-bold text-2xl mb-3 text-white">
                        {ELEMENTS.find(e => e.name === selectedElement)?.title}
                      </h3>
                      <p className="text-gray-200">
                        {ELEMENTS.find(e => e.name === selectedElement)?.description}
                      </p>
                      {selectedElement === 'black' && (
                        <div className="mt-4 p-3 bg-red-900/50 border border-red-500 rounded">
                          <p className="text-red-200 font-bold">
                            🎉 ULTRA-RARE BLACK MAGIC UNLOCKED! 🎉
                          </p>
                          <p className="text-red-300 text-sm mt-1">
                            You have achieved the impossible! Black Magic is the strongest affinity and will remain so through all balance patches.
                          </p>
                        </div>
                      )}
                    </CardContent>
                  </Card>
                )}

                <p className="text-red-400 font-semibold">
                  ⚠️ This choice is PERMANENT and cannot be changed!
                </p>
              </div>

              <div className="flex justify-center space-x-4">
                <Button
                  onClick={() => setIsConfirming(false)}
                  variant="outline"
                  className="border-gray-600 text-gray-300 hover:bg-gray-800"
                >
                  Go Back
                </Button>
                <Button
                  onClick={handleConfirm}
                  className="bg-purple-600 hover:bg-purple-700 text-white px-8"
                >
                  Confirm & Begin Journey
                </Button>
              </div>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
