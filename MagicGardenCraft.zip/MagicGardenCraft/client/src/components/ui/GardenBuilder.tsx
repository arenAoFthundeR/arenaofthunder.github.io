import { Button } from './button';
import { Progress } from './progress';
import { useGarden } from '../../lib/stores/useGarden';
import { useElements } from '../../lib/stores/useElements';
import { useXRP } from '../../lib/stores/useXRP';

export function GardenBuilder() {
  const { gardenData, gardenPlots, plantSeed, upgradeGarden } = useGarden();
  const { selectedElement } = useElements();
  const { balance, spend } = useXRP();

  const handlePlantSeed = () => {
    const cost = 0.001; // 0.001 XRP per seed
    if (balance >= cost && selectedElement) {
      spend(cost);
      plantSeed(selectedElement);
    }
  };

  const handleUpgradeGarden = () => {
    const cost = 0.01; // 0.01 XRP per upgrade
    if (balance >= cost) {
      spend(cost);
      upgradeGarden();
    }
  };

  const getGrowthBonus = () => {
    let bonus = 1;
    
    // Weather bonuses (would be connected to weather system)
    bonus += 0.1; // Base weather bonus
    
    // Element specific bonuses
    if (selectedElement === 'earth') bonus += 0.3; // Earth magic helps plants grow
    if (selectedElement === 'water') bonus += 0.2; // Water magic helps with growth
    
    return bonus;
  };

  return (
    <div className="space-y-4">
      <div>
        <h3 className="text-lg font-bold text-green-400 mb-2">Garden Status</h3>
        <div className="space-y-2 text-sm">
          <div>Total Plots: <span className="text-white">{gardenPlots.length}</span></div>
          <div>Garden Level: <span className="text-white">{gardenData.level}</span></div>
          <div>Growth Bonus: <span className="text-yellow-400">{(getGrowthBonus() * 100).toFixed(0)}%</span></div>
        </div>
      </div>

      <div>
        <h4 className="font-semibold text-green-400 mb-2">Plant New Seed</h4>
        <div className="space-y-2">
          <div className="text-sm text-gray-400">
            Element: {selectedElement || 'None selected'}
          </div>
          <div className="text-sm text-gray-400">
            Cost: 0.001 XRP
          </div>
          <Button
            onClick={handlePlantSeed}
            disabled={!selectedElement || balance < 0.001}
            className="w-full bg-green-600 hover:bg-green-700 text-white"
          >
            Plant {selectedElement} Seed
          </Button>
        </div>
      </div>

      <div>
        <h4 className="font-semibold text-green-400 mb-2">Upgrade Garden</h4>
        <div className="space-y-2">
          <div className="text-sm text-gray-400">
            Cost: 0.01 XRP
          </div>
          <div className="text-sm text-gray-400">
            Increases garden capacity and growth rate
          </div>
          <Button
            onClick={handleUpgradeGarden}
            disabled={balance < 0.01}
            className="w-full bg-blue-600 hover:bg-blue-700 text-white"
          >
            Upgrade Garden
          </Button>
        </div>
      </div>

      <div>
        <h4 className="font-semibold text-green-400 mb-2">Active Plots</h4>
        <div className="space-y-2 max-h-40 overflow-y-auto">
          {gardenPlots.map((plot, index) => (
            <div key={index} className="bg-gray-800 p-2 rounded text-sm">
              <div className="flex justify-between items-center">
                <span>{plot.element} Plant</span>
                <span>{(plot.growth * 100).toFixed(0)}%</span>
              </div>
              <Progress value={plot.growth * 100} className="h-1 mt-1" />
            </div>
          ))}
          {gardenPlots.length === 0 && (
            <div className="text-gray-400 text-sm text-center py-4">
              No plants yet. Plant your first seed!
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
