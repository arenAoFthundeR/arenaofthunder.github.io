import { useEffect } from 'react';
import { useWeather } from '../../lib/stores/useWeather';
import { Cloud, Sun, CloudRain, Snowflake, Zap, CloudSnow } from 'lucide-react';

export function WeatherDisplay() {
  const { 
    currentWeather, 
    temperature, 
    humidity, 
    lastUpdated,
    updateWeather 
  } = useWeather();

  useEffect(() => {
    // Update weather every 5 minutes
    const interval = setInterval(() => {
      updateWeather();
    }, 5 * 60 * 1000);

    return () => clearInterval(interval);
  }, [updateWeather]);

  const getWeatherIcon = () => {
    switch (currentWeather) {
      case 'sunny': return <Sun className="h-6 w-6 text-yellow-400" />;
      case 'cloudy': return <Cloud className="h-6 w-6 text-gray-400" />;
      case 'rain': return <CloudRain className="h-6 w-6 text-blue-400" />;
      case 'snow': return <Snowflake className="h-6 w-6 text-blue-200" />;
      case 'storm': return <Zap className="h-6 w-6 text-purple-400" />;
      default: return <Cloud className="h-6 w-6 text-gray-400" />;
    }
  };

  const getWeatherEffects = () => {
    switch (currentWeather) {
      case 'sunny':
        return {
          garden: '+20% growth rate',
          magic: '+10% fire magic power',
          mood: 'Energetic and warm'
        };
      case 'rain':
        return {
          garden: '+30% growth rate',
          magic: '+15% water magic power',
          mood: 'Peaceful and reflective'
        };
      case 'snow':
        return {
          garden: '-10% growth rate',
          magic: '+20% ice magic power',
          mood: 'Calm and contemplative'
        };
      case 'storm':
        return {
          garden: '+15% growth rate',
          magic: '+25% lightning magic power',
          mood: 'Intense and focused'
        };
      case 'cloudy':
        return {
          garden: 'Normal growth rate',
          magic: '+5% shadow magic power',
          mood: 'Balanced and steady'
        };
      default:
        return {
          garden: 'Normal growth rate',
          magic: 'Normal magic power',
          mood: 'Neutral'
        };
    }
  };

  const effects = getWeatherEffects();

  return (
    <div className="space-y-4">
      <div>
        <h3 className="text-lg font-bold text-green-400 mb-2">Real-World Weather</h3>
        <p className="text-sm text-gray-400 mb-4">
          Weather affects your garden growth, magical power, and overall experience.
        </p>
      </div>

      {/* Current Weather */}
      <div className="bg-gray-800 p-4 rounded">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center space-x-3">
            {getWeatherIcon()}
            <div>
              <div className="text-lg font-semibold text-white capitalize">
                {currentWeather}
              </div>
              <div className="text-sm text-gray-400">
                {temperature}°F • {humidity}% humidity
              </div>
            </div>
          </div>
        </div>
        
        <div className="text-xs text-gray-500">
          Last updated: {lastUpdated ? new Date(lastUpdated).toLocaleTimeString() : 'Never'}
        </div>
      </div>

      {/* Weather Effects */}
      <div className="space-y-3">
        <h4 className="font-semibold text-blue-400">Current Weather Effects</h4>
        
        <div className="bg-gray-800 p-3 rounded">
          <div className="text-sm space-y-2">
            <div className="flex justify-between">
              <span className="text-gray-300">Garden Growth:</span>
              <span className="text-green-400">{effects.garden}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-300">Magic Power:</span>
              <span className="text-purple-400">{effects.magic}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-300">Mood Bonus:</span>
              <span className="text-yellow-400">{effects.mood}</span>
            </div>
          </div>
        </div>
      </div>

      {/* Seasonal Information */}
      <div className="space-y-2">
        <h4 className="font-semibold text-cyan-400">Seasonal Magic</h4>
        <div className="bg-gray-800 p-3 rounded text-sm">
          <div className="text-gray-300">
            Current Season: <span className="text-white">
              {new Date().getMonth() < 3 ? 'Winter' :
               new Date().getMonth() < 6 ? 'Spring' :
               new Date().getMonth() < 9 ? 'Summer' : 'Autumn'}
            </span>
          </div>
          <div className="text-gray-400 text-xs mt-1">
            Seasonal events and special weather patterns available
          </div>
        </div>
      </div>

      {/* Weather Tips */}
      <div className="bg-blue-900/30 border border-blue-500 p-3 rounded">
        <h5 className="text-blue-200 font-semibold text-sm mb-1">Weather Tip</h5>
        <p className="text-blue-300 text-xs">
          {currentWeather === 'rain' && 'Perfect time for water magic practice and plant care!'}
          {currentWeather === 'sunny' && 'Ideal conditions for fire magic and rapid garden growth!'}
          {currentWeather === 'snow' && 'Excellent for ice magic mastery and winter contemplation.'}
          {currentWeather === 'storm' && 'Harness the storm energy for powerful lightning magic!'}
          {currentWeather === 'cloudy' && 'Balanced conditions perfect for steady progress.'}
        </p>
      </div>
    </div>
  );
}
