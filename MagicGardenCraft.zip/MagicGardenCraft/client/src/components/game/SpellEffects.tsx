import { useRef, useState, useEffect } from 'react';
import { useFrame } from '@react-three/fiber';
import * as THREE from 'three';
import { useElements } from '../../lib/stores/useElements';
import { useAlexander } from '../../lib/stores/useAlexander';
import { useAudio } from '../../lib/stores/useAudio';

interface SpellBurst {
  id: number;
  position: THREE.Vector3;
  element: string;
  life: number;
  scale: number;
}

export function SpellEffects() {
  const { selectedElement } = useElements();
  const { isAlexander, currentMagicColor } = useAlexander();
  const { playSuccess } = useAudio();
  const [spellBursts, setSpellBursts] = useState<SpellBurst[]>([]);
  const activeElement = isAlexander ? currentMagicColor : selectedElement;

  // Listen for spell casting events
  useEffect(() => {
    const handleKeyPress = (event: KeyboardEvent) => {
      if (event.key.toLowerCase() === 'q' && activeElement) {
        castSpell();
      }
    };

    window.addEventListener('keydown', handleKeyPress);
    return () => window.removeEventListener('keydown', handleKeyPress);
  }, [activeElement]);

  const castSpell = () => {
    if (!activeElement) return;

    // Create spell burst at player position
    const newBurst: SpellBurst = {
      id: Date.now(),
      position: new THREE.Vector3(
        (Math.random() - 0.5) * 4,
        1.5 + Math.random() * 2,
        (Math.random() - 0.5) * 4
      ),
      element: activeElement,
      life: 1.0,
      scale: 0.1
    };

    setSpellBursts(prev => [...prev, newBurst]);
    playSuccess();

    // Remove burst after animation completes
    setTimeout(() => {
      setSpellBursts(prev => prev.filter(burst => burst.id !== newBurst.id));
    }, 2000);
  };

  const getElementColor = (element: string) => {
    switch (element) {
      case 'fire': return '#ff6644';
      case 'water': return '#4466ff';
      case 'earth': return '#66ff44';
      case 'air': return '#ffff66';
      case 'shadow': return '#666699';
      case 'black': return '#cc0099';
      default: return '#ffffff';
    }
  };

  const getSpellParticleCount = (element: string) => {
    switch (element) {
      case 'fire': return 100;
      case 'water': return 150;
      case 'earth': return 80;
      case 'air': return 120;
      case 'shadow': return 90;
      case 'black': return 200;
      default: return 100;
    }
  };

  return (
    <group>
      {spellBursts.map((burst) => (
        <SpellBurst key={burst.id} burst={burst} />
      ))}
    </group>
  );
}

interface SpellBurstProps {
  burst: SpellBurst;
}

function SpellBurst({ burst }: SpellBurstProps) {
  const meshRef = useRef<THREE.Group>(null);
  const particlesRef = useRef<THREE.Points>(null);
  const [life, setLife] = useState(1.0);

  const particleCount = getSpellParticleCount(burst.element);
  const particlePositions = new Float32Array(particleCount * 3);

  // Initialize particle positions
  for (let i = 0; i < particleCount; i++) {
    const radius = Math.random() * 2;
    const theta = Math.random() * Math.PI * 2;
    const phi = Math.random() * Math.PI;
    
    particlePositions[i * 3] = radius * Math.sin(phi) * Math.cos(theta);
    particlePositions[i * 3 + 1] = radius * Math.cos(phi);
    particlePositions[i * 3 + 2] = radius * Math.sin(phi) * Math.sin(theta);
  }

  useFrame((state, delta) => {
    if (meshRef.current) {
      // Animate the spell burst
      const newLife = life - delta * 0.5;
      setLife(newLife);
      
      // Scale animation
      const scale = 0.1 + (1 - newLife) * 3;
      meshRef.current.scale.setScalar(scale);
      
      // Rotation based on element type
      const rotationSpeed = getElementRotationSpeed(burst.element);
      meshRef.current.rotation.y += delta * rotationSpeed;
      
      // Opacity fade
      if (meshRef.current.children[0]) {
        const material = (meshRef.current.children[0] as THREE.Mesh).material as THREE.MeshBasicMaterial;
        material.opacity = newLife;
      }
    }
    
    if (particlesRef.current) {
      // Animate particles expanding outward
      const positions = particlesRef.current.geometry.attributes.position.array as Float32Array;
      const expansionFactor = 1 + (1 - life) * 3;
      
      for (let i = 0; i < particleCount; i++) {
        positions[i * 3] = particlePositions[i * 3] * expansionFactor;
        positions[i * 3 + 1] = particlePositions[i * 3 + 1] * expansionFactor;
        positions[i * 3 + 2] = particlePositions[i * 3 + 2] * expansionFactor;
      }
      
      particlesRef.current.geometry.attributes.position.needsUpdate = true;
    }
  });

  const getElementRotationSpeed = (element: string) => {
    switch (element) {
      case 'fire': return 4;
      case 'water': return 2;
      case 'earth': return 1;
      case 'air': return 6;
      case 'shadow': return 3;
      case 'black': return 8;
      default: return 2;
    }
  };

  const getElementColor = (element: string) => {
    switch (element) {
      case 'fire': return '#ff6644';
      case 'water': return '#4466ff';
      case 'earth': return '#66ff44';
      case 'air': return '#ffff66';
      case 'shadow': return '#666699';
      case 'black': return '#cc0099';
      default: return '#ffffff';
    }
  };

  if (life <= 0) return null;

  return (
    <group ref={meshRef} position={burst.position}>
      {/* Central spell orb */}
      <mesh>
        <sphereGeometry args={[0.3, 16, 16]} />
        <meshBasicMaterial
          color={getElementColor(burst.element)}
          transparent
          opacity={life}
        />
      </mesh>
      
      {/* Spell particles */}
      <points ref={particlesRef}>
        <bufferGeometry>
          <bufferAttribute
            attach="attributes-position"
            count={particleCount}
            array={particlePositions}
            itemSize={3}
          />
        </bufferGeometry>
        <pointsMaterial
          color={getElementColor(burst.element)}
          size={0.05}
          transparent
          opacity={life * 0.8}
          blending={THREE.AdditiveBlending}
        />
      </points>
      
      {/* Element-specific effects */}
      {burst.element === 'fire' && (
        <mesh>
          <coneGeometry args={[0.5, 2, 8]} />
          <meshBasicMaterial
            color="#ff6644"
            transparent
            opacity={life * 0.5}
          />
        </mesh>
      )}
      
      {burst.element === 'water' && (
        <mesh rotation={[Math.PI / 2, 0, 0]}>
          <torusGeometry args={[1, 0.1, 8, 16]} />
          <meshBasicMaterial
            color="#4466ff"
            transparent
            opacity={life * 0.6}
          />
        </mesh>
      )}
      
      {burst.element === 'black' && (
        <>
          <mesh>
            <octahedronGeometry args={[0.8]} />
            <meshBasicMaterial
              color="#cc0099"
              transparent
              opacity={life * 0.7}
            />
          </mesh>
          <mesh rotation={[0, Math.PI / 4, 0]}>
            <octahedronGeometry args={[0.6]} />
            <meshBasicMaterial
              color="#990066"
              transparent
              opacity={life * 0.5}
            />
          </mesh>
        </>
      )}
    </group>
  );
}

function getSpellParticleCount(element: string) {
  switch (element) {
    case 'fire': return 100;
    case 'water': return 150;
    case 'earth': return 80;
    case 'air': return 120;
    case 'shadow': return 90;
    case 'black': return 200;
    default: return 100;
  }
}