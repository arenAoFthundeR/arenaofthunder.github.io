import { useRef, useMemo } from 'react';
import { useFrame } from '@react-three/fiber';
import * as THREE from 'three';
import { useElements } from '../../lib/stores/useElements';
import { useAlexander } from '../../lib/stores/useAlexander';

export function MagicalEffects() {
  const { selectedElement } = useElements();
  const { isAlexander, currentMagicColor } = useAlexander();
  const particlesRef = useRef<THREE.Points>(null);
  
  // For Alexander, use current magic color, otherwise use selected element
  const activeElement = isAlexander ? currentMagicColor : selectedElement;

  // Create magical particles around the player
  const particles = useMemo(() => {
    if (!activeElement) return { positions: new Float32Array(0), count: 0 };
    
    const count = 200;
    const positions = new Float32Array(count * 3);
    
    for (let i = 0; i < count; i++) {
      // Create particles in a sphere around the player
      const radius = 3 + Math.random() * 2;
      const theta = Math.random() * Math.PI * 2;
      const phi = Math.random() * Math.PI;
      
      positions[i * 3] = radius * Math.sin(phi) * Math.cos(theta);
      positions[i * 3 + 1] = radius * Math.cos(phi) + 2;
      positions[i * 3 + 2] = radius * Math.sin(phi) * Math.sin(theta);
    }
    
    return { positions, count };
  }, [activeElement]);

  useFrame((state, delta) => {
    if (particlesRef.current && particles.count > 0) {
      // Rotate particles around the player
      particlesRef.current.rotation.y += delta * 0.5;
      
      // Animate particle positions for magical floating effect
      const positions = particlesRef.current.geometry.attributes.position.array as Float32Array;
      const time = state.clock.elapsedTime;
      
      for (let i = 0; i < particles.count; i++) {
        const i3 = i * 3;
        // Add floating motion
        positions[i3 + 1] = particles.positions[i3 + 1] + Math.sin(time * 2 + i * 0.1) * 0.3;
      }
      
      particlesRef.current.geometry.attributes.position.needsUpdate = true;
    }
  });

  const getElementColor = () => {
    switch (activeElement) {
      case 'fire': return '#ff6644';
      case 'water': return '#4466ff';
      case 'earth': return '#66ff44';
      case 'air': return '#ffff66';
      case 'shadow': return '#666699';
      case 'black': return '#cc0099';
      default: return '#ffffff';
    }
  };

  if (!activeElement || particles.count === 0) return null;

  return (
    <group position={[0, 0, 0]}>
      {/* Magical aura particles */}
      <points ref={particlesRef}>
        <bufferGeometry>
          <bufferAttribute
            attach="attributes-position"
            count={particles.count}
            array={particles.positions}
            itemSize={3}
          />
        </bufferGeometry>
        <pointsMaterial
          color={getElementColor()}
          size={0.1}
          transparent
          opacity={0.6}
          blending={THREE.AdditiveBlending}
        />
      </points>
      
      {/* Central magical orb */}
      <mesh position={[0, 2.5, 0]}>
        <sphereGeometry args={[0.2, 16, 16]} />
        <meshBasicMaterial
          color={getElementColor()}
          transparent
          opacity={0.8}
        />
      </mesh>
      
      {/* Elemental ring effect */}
      <mesh position={[0, 1, 0]} rotation={[Math.PI / 2, 0, 0]}>
        <ringGeometry args={[2, 2.2, 32]} />
        <meshBasicMaterial
          color={getElementColor()}
          transparent
          opacity={0.3}
          side={THREE.DoubleSide}
        />
      </mesh>
    </group>
  );
}