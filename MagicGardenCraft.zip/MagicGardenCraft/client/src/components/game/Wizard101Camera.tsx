import React, { useRef, useEffect, useState } from 'react';
import { useFrame, useThree } from '@react-three/fiber';
import { OrbitControls } from '@react-three/drei';
import * as THREE from 'three';

interface Wizard101CameraProps {
  target?: THREE.Vector3;
  playerPosition?: THREE.Vector3;
  showingOffPet?: boolean;
  petPosition?: THREE.Vector3;
}

export function Wizard101Camera({ 
  target = new THREE.Vector3(0, 0, 0), 
  playerPosition = new THREE.Vector3(0, 0, 0),
  showingOffPet = false,
  petPosition = new THREE.Vector3(0, 2, 0)
}: Wizard101CameraProps) {
  const { camera, gl } = useThree();
  const controlsRef = useRef<any>(null);
  const [cameraMode, setCameraMode] = useState<'follow' | 'showcase' | 'free'>('follow');
  const [zoomLevel, setZoomLevel] = useState(8);
  const [isTransitioning, setIsTransitioning] = useState(false);
  
  // Wizard101-style camera constraints
  const minDistance = 3;
  const maxDistance = 15;
  const minPolarAngle = Math.PI * 0.1; // Can look almost straight down
  const maxPolarAngle = Math.PI * 0.85; // Cannot look too far up
  const minAzimuthAngle = -Math.PI * 2; // Full rotation
  const maxAzimuthAngle = Math.PI * 2;

  useEffect(() => {
    if (controlsRef.current) {
      const controls = controlsRef.current;
      
      // Set Wizard101-style constraints
      controls.minDistance = minDistance;
      controls.maxDistance = maxDistance;
      controls.minPolarAngle = minPolarAngle;
      controls.maxPolarAngle = maxPolarAngle;
      controls.minAzimuthAngle = minAzimuthAngle;
      controls.maxAzimuthAngle = maxAzimuthAngle;
      
      // Smooth camera movement like Wizard101
      controls.enableDamping = true;
      controls.dampingFactor = 0.05;
      controls.screenSpacePanning = false;
      controls.panSpeed = 0.8;
      controls.rotateSpeed = 0.5;
      controls.zoomSpeed = 1.2;
      
      // Auto-rotate when showing off pets (like Wizard101 pet showcase)
      controls.autoRotate = showingOffPet;
      controls.autoRotateSpeed = showingOffPet ? 2.0 : 0;
    }
  }, [showingOffPet]);

  useFrame(() => {
    if (controlsRef.current && !isTransitioning) {
      const controls = controlsRef.current;
      
      if (cameraMode === 'follow') {
        // Follow player like Wizard101 - camera stays behind and above
        const idealOffset = new THREE.Vector3(0, 5, 8);
        const idealPosition = playerPosition.clone().add(idealOffset);
        
        // Smooth camera following
        camera.position.lerp(idealPosition, 0.02);
        controls.target.lerp(playerPosition, 0.02);
        
      } else if (cameraMode === 'showcase' && showingOffPet) {
        // Pet showcase mode - orbits around the pet like Wizard101 pet display
        const showcaseTarget = petPosition || playerPosition.clone().add(new THREE.Vector3(0, 2, 0));
        controls.target.lerp(showcaseTarget, 0.05);
        
        // Position camera for optimal pet viewing
        const showcaseDistance = 4;
        const angle = Date.now() * 0.001;
        const showcasePosition = new THREE.Vector3(
          showcaseTarget.x + Math.cos(angle) * showcaseDistance,
          showcaseTarget.y + 2,
          showcaseTarget.z + Math.sin(angle) * showcaseDistance
        );
        camera.position.lerp(showcasePosition, 0.03);
      }
      
      controls.update();
    }
  });

  // Zoom controls like Wizard101 (mouse wheel + keyboard)
  useEffect(() => {
    const handleKeyDown = (event: KeyboardEvent) => {
      if (!controlsRef.current) return;
      
      const controls = controlsRef.current;
      
      switch (event.code) {
        case 'PageUp':
        case 'Equal': // Plus key
          setZoomLevel(prev => Math.max(minDistance, prev - 1));
          controls.dollyIn(1.1);
          break;
        case 'PageDown':
        case 'Minus':
          setZoomLevel(prev => Math.min(maxDistance, prev + 1));
          controls.dollyOut(1.1);
          break;
        case 'Home':
          // Reset camera to default position (like Wizard101 home key)
          resetCameraPosition();
          break;
        case 'End':
          // Toggle camera mode
          toggleCameraMode();
          break;
      }
    };

    const handleWheel = (event: WheelEvent) => {
      if (event.ctrlKey || event.metaKey) {
        // Ctrl+Wheel for precision zoom like Wizard101
        event.preventDefault();
        const zoomFactor = event.deltaY > 0 ? 1.05 : 0.95;
        if (controlsRef.current) {
          if (event.deltaY > 0) {
            controlsRef.current.dollyOut(zoomFactor);
          } else {
            controlsRef.current.dollyIn(zoomFactor);
          }
        }
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    gl.domElement.addEventListener('wheel', handleWheel, { passive: false });

    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      gl.domElement.removeEventListener('wheel', handleWheel);
    };
  }, [gl]);

  const resetCameraPosition = () => {
    if (!controlsRef.current) return;
    
    setIsTransitioning(true);
    const controls = controlsRef.current;
    
    // Default Wizard101-style position
    const defaultPosition = playerPosition.clone().add(new THREE.Vector3(0, 6, 10));
    const defaultTarget = playerPosition.clone();
    
    // Smooth transition to default position
    const startPos = camera.position.clone();
    const startTarget = controls.target.clone();
    let progress = 0;
    
    const animateReset = () => {
      progress += 0.05;
      if (progress >= 1) {
        progress = 1;
        setIsTransitioning(false);
      }
      
      camera.position.lerpVectors(startPos, defaultPosition, progress);
      controls.target.lerpVectors(startTarget, defaultTarget, progress);
      
      if (progress < 1) {
        requestAnimationFrame(animateReset);
      }
    };
    
    animateReset();
  };

  const toggleCameraMode = () => {
    setCameraMode(prev => {
      if (prev === 'follow') return 'free';
      if (prev === 'free') return showingOffPet ? 'showcase' : 'follow';
      return 'follow';
    });
  };

  // Pet showcase activation
  useEffect(() => {
    if (showingOffPet && cameraMode === 'follow') {
      setCameraMode('showcase');
    } else if (!showingOffPet && cameraMode === 'showcase') {
      setCameraMode('follow');
    }
  }, [showingOffPet, cameraMode]);

  return (
    <>
      <OrbitControls
        ref={controlsRef}
        args={[camera, gl.domElement]}
        target={target}
        enablePan={cameraMode === 'free'}
        enableZoom={true}
        enableRotate={true}
        minDistance={minDistance}
        maxDistance={maxDistance}
        minPolarAngle={minPolarAngle}
        maxPolarAngle={maxPolarAngle}
        dampingFactor={0.05}
        enableDamping={true}
        screenSpacePanning={false}
        autoRotate={showingOffPet && cameraMode === 'showcase'}
        autoRotateSpeed={2.0}
      />
      
      {/* Camera Mode Indicator */}
      <div className="absolute top-4 right-4 bg-black/70 text-white px-3 py-1 rounded text-sm">
        Camera: {cameraMode.toUpperCase()}
        {showingOffPet && cameraMode === 'showcase' && ' (Pet Showcase)'}
      </div>
      
      {/* Camera Control Help */}
      <div className="absolute bottom-4 right-4 bg-black/70 text-white p-2 rounded text-xs max-w-xs">
        <div className="font-bold mb-1">Camera Controls:</div>
        <div>• Mouse: Look around</div>
        <div>• Wheel: Zoom in/out</div>
        <div>• Ctrl+Wheel: Precision zoom</div>
        <div>• +/- Keys: Zoom</div>
        <div>• Home: Reset camera</div>
        <div>• End: Toggle camera mode</div>
        {showingOffPet && <div>• Auto-rotate: Pet showcase</div>}
      </div>
    </>
  );
}

// Hook for managing camera states
export function useWizard101Camera() {
  const [playerPosition, setPlayerPosition] = useState(new THREE.Vector3(0, 0, 0));
  const [showingOffPet, setShowingOffPet] = useState(false);
  const [petPosition, setPetPosition] = useState(new THREE.Vector3(0, 2, 0));
  
  const startPetShowcase = (petPos?: THREE.Vector3) => {
    if (petPos) setPetPosition(petPos);
    setShowingOffPet(true);
  };
  
  const stopPetShowcase = () => {
    setShowingOffPet(false);
  };
  
  const updatePlayerPosition = (newPos: THREE.Vector3) => {
    setPlayerPosition(newPos);
  };
  
  const updatePetPosition = (newPos: THREE.Vector3) => {
    setPetPosition(newPos);
  };
  
  return {
    playerPosition,
    showingOffPet,
    petPosition,
    startPetShowcase,
    stopPetShowcase,
    updatePlayerPosition,
    updatePetPosition
  };
}