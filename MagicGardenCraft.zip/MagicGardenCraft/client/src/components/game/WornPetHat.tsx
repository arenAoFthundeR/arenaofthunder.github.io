import React, { useRef } from 'react';
import { useFrame } from '@react-three/fiber';
import { Sphere, Box } from '@react-three/drei';
import * as THREE from 'three';

interface PlantPet {
  id: string;
  name: string;
  species: string;
  color: string;
  size: number;
  rarity: 'common' | 'uncommon' | 'rare' | 'legendary';
  traits: string[];
  level: number;
}

interface WornPetHatProps {
  pet: PlantPet;
  playerHeadPosition: THREE.Vector3;
  playerRotation: THREE.Euler;
}

export function WornPetHat({ pet, playerHeadPosition, playerRotation }: WornPetHatProps) {
  const petGroupRef = useRef<THREE.Group>(null);
  
  useFrame(() => {
    if (petGroupRef.current) {
      // Position pet on top of player's head
      const headOffset = new THREE.Vector3(0, 0.8, 0); // Slightly above head
      const worldHeadPosition = playerHeadPosition.clone().add(headOffset);
      
      petGroupRef.current.position.copy(worldHeadPosition);
      
      // Match player's Y rotation but add slight bobbing
      petGroupRef.current.rotation.y = playerRotation.y;
      
      // Add gentle bobbing animation
      petGroupRef.current.position.y += Math.sin(Date.now() * 0.003) * 0.05;
      
      // Add slight side-to-side sway when moving
      petGroupRef.current.rotation.z = Math.sin(Date.now() * 0.002) * 0.1;
      
      // Add magical sparkles effect based on rarity
      if (pet.rarity === 'legendary') {
        // Legendary pets get extra sparkle
        petGroupRef.current.rotation.x = Math.sin(Date.now() * 0.004) * 0.05;
      }
    }
  });

  // Scale down pet for hat mode (smaller than when displayed normally)
  const hatScale = pet.size * 0.25; // Much smaller when worn as hat
  
  // Adjust colors slightly for hat mode (more muted)
  const hatColor = new THREE.Color(pet.color).multiplyScalar(0.9);

  return (
    <group 
      ref={petGroupRef} 
      scale={hatScale}
      position={playerHeadPosition}
    >
      {/* Pet body (simplified for hat mode) */}
      <Sphere args={[0.6]} position={[0, 0, 0]}>
        <meshStandardMaterial 
          color={hatColor} 
          emissive={pet.rarity === 'legendary' ? new THREE.Color(pet.color).multiplyScalar(0.1) : new THREE.Color(0x000000)}
        />
      </Sphere>
      
      {/* Cute eyes (smaller for hat) */}
      <Sphere args={[0.08]} position={[-0.15, 0.1, 0.5]}>
        <meshStandardMaterial color="#000000" />
      </Sphere>
      <Sphere args={[0.08]} position={[0.15, 0.1, 0.5]}>
        <meshStandardMaterial color="#000000" />
      </Sphere>
      
      {/* Eye shine */}
      <Sphere args={[0.03]} position={[-0.13, 0.12, 0.52]}>
        <meshStandardMaterial color="#ffffff" />
      </Sphere>
      <Sphere args={[0.03]} position={[0.17, 0.12, 0.52]}>
        <meshStandardMaterial color="#ffffff" />
      </Sphere>
      
      {/* Simplified features based on rarity */}
      {pet.rarity === 'legendary' && (
        <>
          {/* Crown-like petals for legendary pets */}
          {Array.from({ length: 6 }, (_, i) => {
            const angle = (i / 6) * Math.PI * 2;
            return (
              <Box
                key={i}
                args={[0.2, 0.06, 0.02]}
                position={[Math.cos(angle) * 0.7, 0.4 + Math.sin(angle) * 0.2, Math.sin(angle) * 0.7]}
                rotation={[0, angle, Math.PI * 0.1]}
              >
                <meshStandardMaterial 
                  color="#fbbf24" 
                  emissive="#fbbf24"
                  emissiveIntensity={0.2}
                />
              </Box>
            );
          })}
          
          {/* Legendary aura particles */}
          {Array.from({ length: 4 }, (_, i) => (
            <Sphere
              key={i}
              args={[0.02]}
              position={[
                Math.cos(Date.now() * 0.002 + i) * 1.2,
                0.5 + Math.sin(Date.now() * 0.003 + i) * 0.3,
                Math.sin(Date.now() * 0.002 + i) * 1.2
              ]}
            >
              <meshStandardMaterial 
                color="#fbbf24" 
                emissive="#fbbf24"
                emissiveIntensity={0.5}
                transparent
                opacity={0.7}
              />
            </Sphere>
          ))}
        </>
      )}
      
      {pet.rarity === 'rare' && (
        <>
          {/* Elegant petals for rare pets */}
          {Array.from({ length: 4 }, (_, i) => {
            const angle = (i / 4) * Math.PI * 2;
            return (
              <Box
                key={i}
                args={[0.15, 0.04, 0.02]}
                position={[Math.cos(angle) * 0.6, 0.3, Math.sin(angle) * 0.6]}
                rotation={[0, angle, 0]}
              >
                <meshStandardMaterial 
                  color="#a855f7" 
                  emissive="#a855f7"
                  emissiveIntensity={0.1}
                />
              </Box>
            );
          })}
        </>
      )}
      
      {(pet.rarity === 'common' || pet.rarity === 'uncommon') && (
        <>
          {/* Simple leaves for common/uncommon pets */}
          <Box args={[0.12, 0.04, 0.02]} position={[0.5, 0.2, 0]} rotation={[0, 0, 0.3]}>
            <meshStandardMaterial color="#10b981" />
          </Box>
          <Box args={[0.12, 0.04, 0.02]} position={[-0.5, 0.2, 0]} rotation={[0, 0, -0.3]}>
            <meshStandardMaterial color="#10b981" />
          </Box>
        </>
      )}
      
      {/* Happiness indicator (small sparkles when pet is happy) */}
      {Math.random() > 0.8 && ( // Random sparkles
        <Sphere
          args={[0.01]}
          position={[
            (Math.random() - 0.5) * 1.5,
            0.8 + Math.random() * 0.5,
            (Math.random() - 0.5) * 1.5
          ]}
        >
          <meshStandardMaterial 
            color="#ffffff" 
            emissive="#ffffff"
            emissiveIntensity={0.8}
            transparent
            opacity={0.8}
          />
        </Sphere>
      )}
      
      {/* Pet level indicator (very small) */}
      {pet.level >= 10 && (
        <Sphere args={[0.03]} position={[0, 0.7, 0]}>
          <meshStandardMaterial 
            color="#fbbf24" 
            emissive="#fbbf24"
            emissiveIntensity={0.3}
          />
        </Sphere>
      )}
    </group>
  );
}

// Component to manage multiple worn pets (in case of special abilities)
export function WornPetManager({ 
  wornPets, 
  playerHeadPosition, 
  playerRotation 
}: { 
  wornPets: PlantPet[]; 
  playerHeadPosition: THREE.Vector3; 
  playerRotation: THREE.Euler; 
}) {
  return (
    <>
      {wornPets.map((pet, index) => (
        <WornPetHat
          key={pet.id}
          pet={pet}
          playerHeadPosition={playerHeadPosition.clone().add(new THREE.Vector3(
            index * 0.3 - (wornPets.length - 1) * 0.15, // Spread multiple pets
            0,
            0
          ))}
          playerRotation={playerRotation}
        />
      ))}
    </>
  );
}