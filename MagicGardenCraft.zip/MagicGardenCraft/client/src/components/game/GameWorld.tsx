import { Suspense, useState } from 'react';
import * as THREE from 'three';
import { Player } from './Player';
import { Garden } from './Garden';
import { ElementalMagic } from './ElementalMagic';
import { WeatherSystem } from './WeatherSystem';
import { MagicalEffects } from './MagicalEffects';
import { EnvironmentalObjects } from './EnvironmentalObjects';
import { SpellEffects } from './SpellEffects';
import { Wizard101Camera, useWizard101Camera } from './Wizard101Camera';
import { WornPetManager } from './WornPetHat';

export function GameWorld() {
  const [playerPosition, setPlayerPosition] = useState(new THREE.Vector3(0, 0, 0));
  const [playerRotation, setPlayerRotation] = useState(new THREE.Euler(0, 0, 0));
  const [wornPets, setWornPets] = useState<any[]>([]); // Plant pets worn as hats
  
  const {
    showingOffPet,
    petPosition,
    startPetShowcase,
    stopPetShowcase,
    updatePlayerPosition,
    updatePetPosition
  } = useWizard101Camera();

  // Handle player position/rotation updates
  const handlePlayerUpdate = (position: THREE.Vector3, rotation: THREE.Euler) => {
    setPlayerPosition(position.clone());
    setPlayerRotation(rotation.clone());
    updatePlayerPosition(position);
  };

  return (
    <>
      {/* Wizard101-style Camera System */}
      <Wizard101Camera
        target={playerPosition}
        playerPosition={playerPosition}
        showingOffPet={showingOffPet}
        petPosition={petPosition}
      />
      
      {/* Lighting */}
      <ambientLight intensity={0.4} />
      <directionalLight 
        position={[10, 10, 5]} 
        intensity={1}
        castShadow
        shadow-mapSize-width={2048}
        shadow-mapSize-height={2048}
        shadow-camera-far={50}
        shadow-camera-left={-20}
        shadow-camera-right={20}
        shadow-camera-top={20}
        shadow-camera-bottom={-20}
      />
      
      {/* Fog for atmosphere */}
      <fog attach="fog" args={['#87CEEB', 50, 200]} />
      
      <Suspense fallback={null}>
        <Player onPositionUpdate={handlePlayerUpdate} />
        <Garden />
        <ElementalMagic />
        <WeatherSystem />
        <MagicalEffects />
        <EnvironmentalObjects />
        <SpellEffects />
        
        {/* Plant Pets Worn as Hats */}
        {wornPets.length > 0 && (
          <WornPetManager
            wornPets={wornPets}
            playerHeadPosition={playerPosition.clone().add(new THREE.Vector3(0, 2, 0))}
            playerRotation={playerRotation}
          />
        )}
      </Suspense>
    </>
  );
}
