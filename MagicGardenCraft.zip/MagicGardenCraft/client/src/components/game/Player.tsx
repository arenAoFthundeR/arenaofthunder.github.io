import { useRef, useEffect } from 'react';
import { useFrame, useThree } from '@react-three/fiber';
import { useKeyboardControls } from '@react-three/drei';
import * as THREE from 'three';
import { useGarden } from '../../lib/stores/useGarden';
import { useElements } from '../../lib/stores/useElements';
import { useAlexander } from '../../lib/stores/useAlexander';
import { useLemonheads } from '../../lib/stores/useLemonheads';
import { useNailAI } from '../../lib/stores/useNailAI';

enum Controls {
  forward = 'forward',
  backward = 'backward',
  leftward = 'leftward',
  rightward = 'rightward',
  jump = 'jump',
  interact = 'interact',
  magic = 'magic',
  build = 'build',
  camera = 'camera'
}

export function Player({ onPositionUpdate }: { onPositionUpdate?: (position: THREE.Vector3, rotation: THREE.Euler) => void }) {
  const playerRef = useRef<THREE.Mesh>(null);
  const { camera } = useThree();
  const [, getKeys] = useKeyboardControls<Controls>();
  const { selectedElement } = useElements();
  const { addToActionTree } = useGarden();
  const { performAction, isAlexander, currentMagicColor } = useAlexander();
  const { performAction: triggerLemonheadsDrop } = useLemonheads();
  const { registerTap } = useNailAI();
  
  const velocity = useRef(new THREE.Vector3());
  const direction = useRef(new THREE.Vector3());
  const isJumping = useRef(false);
  const playerPosition = useRef(new THREE.Vector3(0, 1, 0));

  // Player movement and camera controls
  useFrame((state, delta) => {
    if (!playerRef.current) return;

    const keys = getKeys();
    const speed = 5;
    const jumpSpeed = 8;

    // Reset direction
    direction.current.set(0, 0, 0);

    // Helper function to perform actions with all systems
    const performGameAction = (category: string, action: string) => {
      if (registerTap('player-action')) {
        addToActionTree(category, action, 1);
        performAction(); // Alexander color switching chance
        triggerLemonheadsDrop(); // Lemonheads drop chance
      }
    };

    // Movement input
    if (keys.forward) {
      direction.current.z -= 1;
      performGameAction('movement', 'forward');
    }
    if (keys.backward) {
      direction.current.z += 1;
      performGameAction('movement', 'backward');
    }
    if (keys.leftward) {
      direction.current.x -= 1;
      performGameAction('movement', 'strafe_left');
    }
    if (keys.rightward) {
      direction.current.x += 1;
      performGameAction('movement', 'strafe_right');
    }

    // Normalize direction for consistent speed
    if (direction.current.length() > 0) {
      direction.current.normalize();
    }

    // Apply movement
    velocity.current.x = direction.current.x * speed * delta;
    velocity.current.z = direction.current.z * speed * delta;

    // Jumping
    if (keys.jump && !isJumping.current && playerPosition.current.y <= 1.1) {
      velocity.current.y = jumpSpeed * delta;
      isJumping.current = true;
      performGameAction('movement', 'jump');
    }

    // Gravity
    velocity.current.y -= 20 * delta;

    // Update position
    playerPosition.current.add(velocity.current);

    // Ground collision
    if (playerPosition.current.y <= 1) {
      playerPosition.current.y = 1;
      velocity.current.y = 0;
      isJumping.current = false;
    }

    // Update player mesh position
    playerRef.current.position.copy(playerPosition.current);

    // Call position update callback for camera system
    if (onPositionUpdate) {
      onPositionUpdate(playerPosition.current, playerRef.current.rotation);
    }

    // Magic casting
    if (keys.magic && selectedElement) {
      performGameAction('magic', selectedElement);
      console.log(`Casting ${selectedElement} magic!`);
    }

    // Building
    if (keys.build) {
      performGameAction('building', 'garden_plot');
      console.log('Building garden element!');
    }

    // Interaction
    if (keys.interact) {
      performGameAction('interaction', 'examine');
      console.log('Interacting with environment!');
    }
  });

  // Get element color for player visualization
  const getElementColor = () => {
    // For Alexander, use current magic color instead of selected element
    const element = isAlexander ? currentMagicColor : selectedElement;
    
    switch (element) {
      case 'fire': return '#ff4444';
      case 'water': return '#4444ff';
      case 'earth': return '#44ff44';
      case 'air': return '#ffff44';
      case 'shadow': return '#444444';
      case 'black': return '#000000';
      default: return '#888888';
    }
  };

  return (
    <mesh ref={playerRef} position={[0, 1, 0]} castShadow>
      <boxGeometry args={[0.5, 1.8, 0.5]} />
      <meshStandardMaterial color={getElementColor()} />
    </mesh>
  );
}
