import React, { useState, useEffect } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import { Text, Box, Sphere, OrbitControls } from '@react-three/drei';
import * as THREE from 'three';
import { REAL_PLANT_DATABASE, PlantScience, GeneticProfile } from '../../lib/gameLogic/scientificSystems';
import { useScientificData } from '../../lib/stores/useScientificData';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Button } from '../ui/button';
import { Progress } from '../ui/progress';
import { Badge } from '../ui/badge';

interface BreedingPair {
  parent1: string;
  parent2: string;
  compatibility: number;
  expectedTraits: string[];
  breedingTime: number;
  successRate: number;
}

interface BreedingResult {
  offspring: PlantScience;
  traits: string[];
  rarity: 'common' | 'uncommon' | 'rare' | 'legendary';
  generation: number;
}

// 3D Plant Model for breeding visualization
function PlantModel({ plant, position, scale = 1, isSelected = false }: {
  plant: PlantScience;
  position: [number, number, number];
  scale?: number;
  isSelected?: boolean;
}) {
  const meshRef = React.useRef<THREE.Group>(null);
  
  useFrame(() => {
    if (meshRef.current && isSelected) {
      meshRef.current.rotation.y += 0.01;
    }
  });

  // Get plant color based on dominant traits
  const getPlantColor = () => {
    if (plant.geneticTraits.dominantAlleles.includes('R_disease_resistance')) return '#10b981';
    if (plant.geneticTraits.dominantAlleles.includes('T_determinate_growth')) return '#f59e0b';
    return '#22c55e';
  };

  return (
    <group ref={meshRef} position={position} scale={scale}>
      {/* Plant stem */}
      <Box args={[0.1, 2, 0.1]} position={[0, 0, 0]}>
        <meshStandardMaterial color="#059669" />
      </Box>
      
      {/* Leaves */}
      {Array.from({ length: 6 }, (_, i) => {
        const height = 0.3 + i * 0.3;
        const side = i % 2 === 0 ? 1 : -1;
        return (
          <Box
            key={i}
            args={[0.4, 0.2, 0.05]}
            position={[side * 0.3, height, 0]}
            rotation={[0, 0, side * 0.3]}
          >
            <meshStandardMaterial color={getPlantColor()} />
          </Box>
        );
      })}
      
      {/* Flowers/Fruits if mature */}
      {plant.growthStages.length > 2 && (
        <>
          <Sphere args={[0.15]} position={[0, 1.8, 0]}>
            <meshStandardMaterial color="#ec4899" />
          </Sphere>
          <Sphere args={[0.12]} position={[0.2, 1.6, 0]}>
            <meshStandardMaterial color="#ef4444" />
          </Sphere>
        </>
      )}
      
      {/* Selection indicator */}
      {isSelected && (
        <Box args={[1.2, 0.05, 1.2]} position={[0, -0.1, 0]}>
          <meshStandardMaterial color="#3b82f6" transparent opacity={0.3} />
        </Box>
      )}
      
      {/* Plant name */}
      <Text
        position={[0, -0.5, 0]}
        fontSize={0.15}
        color="#ffffff"
        anchorX="center"
        anchorY="middle"
      >
        {plant.species.split(' ')[1] || 'Plant'}
      </Text>
    </group>
  );
}

// Breeding Process Visualization
function BreedingVisualization({ breedingPair, progress }: {
  breedingPair: BreedingPair;
  progress: number;
}) {
  const parent1 = REAL_PLANT_DATABASE[breedingPair.parent1];
  const parent2 = REAL_PLANT_DATABASE[breedingPair.parent2];
  
  if (!parent1 || !parent2) return null;

  return (
    <div className="h-64 bg-gray-900 rounded-lg overflow-hidden">
      <Canvas camera={{ position: [0, 2, 6], fov: 60 }}>
        <ambientLight intensity={0.4} />
        <directionalLight position={[10, 10, 5]} intensity={0.8} />
        <pointLight position={[0, 3, 3]} intensity={0.6} color="#4ade80" />
        
        {/* Parent plants */}
        <PlantModel plant={parent1} position={[-2, 0, 0]} />
        <PlantModel plant={parent2} position={[2, 0, 0]} />
        
        {/* Breeding progress visualization */}
        <group position={[0, 1, 0]}>
          {/* DNA strands connecting parents */}
          <Box args={[4, 0.02, 0.02]} rotation={[0, 0, Math.PI * 0.1]}>
            <meshStandardMaterial color="#3b82f6" />
          </Box>
          <Box args={[4, 0.02, 0.02]} rotation={[0, 0, -Math.PI * 0.1]}>
            <meshStandardMaterial color="#10b981" />
          </Box>
          
          {/* Progress indicator */}
          <Sphere args={[0.2]} position={[0, 0, 0]}>
            <meshStandardMaterial 
              color={progress > 0.8 ? "#10b981" : progress > 0.5 ? "#f59e0b" : "#6b7280"} 
            />
          </Sphere>
          
          {/* Offspring preview (if near completion) */}
          {progress > 0.7 && (
            <group position={[0, -1.5, 0]} scale={0.5 + progress * 0.5}>
              <PlantModel 
                plant={parent1} 
                position={[0, 0, 0]} 
                scale={0.8}
              />
            </group>
          )}
        </group>
        
        <Text
          position={[0, -2, 0]}
          fontSize={0.3}
          color="#ffffff"
          anchorX="center"
          anchorY="middle"
        >
          Breeding Progress: {Math.round(progress * 100)}%
        </Text>
      </Canvas>
    </div>
  );
}

export function PlantBreedingSystem() {
  const [selectedParent1, setSelectedParent1] = useState<string>('');
  const [selectedParent2, setSelectedParent2] = useState<string>('');
  const [breedingInProgress, setBreedingInProgress] = useState<BreedingPair | null>(null);
  const [breedingProgress, setBreedingProgress] = useState(0);
  const [breedingResults, setBreedingResults] = useState<BreedingResult[]>([]);
  const scientificData = useScientificData();
  
  const availablePlants = Object.keys(REAL_PLANT_DATABASE);
  
  // Calculate breeding compatibility
  const calculateCompatibility = (plant1: string, plant2: string): number => {
    if (!plant1 || !plant2 || plant1 === plant2) return 0;
    
    const p1 = REAL_PLANT_DATABASE[plant1];
    const p2 = REAL_PLANT_DATABASE[plant2];
    
    if (!p1 || !p2) return 0;
    
    // Check genetic compatibility
    const sharedAlleles = p1.geneticTraits.dominantAlleles.filter(allele =>
      p2.geneticTraits.dominantAlleles.includes(allele) ||
      p2.geneticTraits.recessiveAlleles.includes(allele)
    ).length;
    
    const environmentalCompatibility = Math.abs(
      p1.environmentalTolerances.temperatureRange[0] - p2.environmentalTolerances.temperatureRange[0]
    ) < 10 ? 0.3 : 0;
    
    const soilCompatibility = Math.abs(p1.nutritionalNeeds.soilPH[0] - p2.nutritionalNeeds.soilPH[0]) < 1 ? 0.2 : 0;
    
    return Math.min(1, (sharedAlleles * 0.1) + environmentalCompatibility + soilCompatibility + 0.2);
  };
  
  // Start breeding process
  const startBreeding = () => {
    if (!selectedParent1 || !selectedParent2) return;
    
    const compatibility = calculateCompatibility(selectedParent1, selectedParent2);
    const p1 = REAL_PLANT_DATABASE[selectedParent1];
    const p2 = REAL_PLANT_DATABASE[selectedParent2];
    
    const breedingPair: BreedingPair = {
      parent1: selectedParent1,
      parent2: selectedParent2,
      compatibility,
      expectedTraits: [
        ...p1.geneticTraits.dominantAlleles.slice(0, 2),
        ...p2.geneticTraits.dominantAlleles.slice(0, 2)
      ],
      breedingTime: 30000, // 30 seconds
      successRate: compatibility * 100
    };
    
    setBreedingInProgress(breedingPair);
    setBreedingProgress(0);
    
    // Simulate breeding progress
    const interval = setInterval(() => {
      setBreedingProgress(prev => {
        if (prev >= 1) {
          clearInterval(interval);
          completeBreeding(breedingPair);
          return 1;
        }
        return prev + 0.05;
      });
    }, 1500);
  };
  
  // Complete breeding and generate offspring
  const completeBreeding = (breedingPair: BreedingPair) => {
    const p1 = REAL_PLANT_DATABASE[breedingPair.parent1];
    const p2 = REAL_PLANT_DATABASE[breedingPair.parent2];
    
    // Generate hybrid offspring
    const hybridName = `${p1.species.split(' ')[0]}_${p2.species.split(' ')[1]}_hybrid`;
    
    const offspringGenetics: GeneticProfile = {
      dominantAlleles: [
        ...p1.geneticTraits.dominantAlleles.slice(0, 1),
        ...p2.geneticTraits.dominantAlleles.slice(0, 1),
        Math.random() > 0.7 ? 'H_hybrid_vigor' : 'S_standard_growth'
      ],
      recessiveAlleles: [
        ...p1.geneticTraits.recessiveAlleles.slice(0, 1),
        ...p2.geneticTraits.recessiveAlleles.slice(0, 1)
      ],
      hybridViability: (p1.geneticTraits.hybridViability + p2.geneticTraits.hybridViability) / 2 + 0.1,
      mutationRate: Math.max(p1.geneticTraits.mutationRate, p2.geneticTraits.mutationRate) * 1.2,
      adaptabilityScore: (p1.geneticTraits.adaptabilityScore + p2.geneticTraits.adaptabilityScore) / 2 + 0.05
    };
    
    const offspring: PlantScience = {
      species: hybridName,
      geneticTraits: offspringGenetics,
      growthStages: [...p1.growthStages], // Inherit growth pattern from parent 1
      nutritionalNeeds: {
        nitrogen: (p1.nutritionalNeeds.nitrogen + p2.nutritionalNeeds.nitrogen) / 2,
        phosphorus: (p1.nutritionalNeeds.phosphorus + p2.nutritionalNeeds.phosphorus) / 2,
        potassium: (p1.nutritionalNeeds.potassium + p2.nutritionalNeeds.potassium) / 2,
        micronutrients: p1.nutritionalNeeds.micronutrients,
        waterRequirement: (p1.nutritionalNeeds.waterRequirement + p2.nutritionalNeeds.waterRequirement) / 2,
        soilPH: [
          Math.min(p1.nutritionalNeeds.soilPH[0], p2.nutritionalNeeds.soilPH[0]),
          Math.max(p1.nutritionalNeeds.soilPH[1], p2.nutritionalNeeds.soilPH[1])
        ]
      },
      environmentalTolerances: {
        temperatureRange: [
          Math.min(p1.environmentalTolerances.temperatureRange[0], p2.environmentalTolerances.temperatureRange[0]),
          Math.max(p1.environmentalTolerances.temperatureRange[1], p2.environmentalTolerances.temperatureRange[1])
        ],
        humidityRange: [
          Math.min(p1.environmentalTolerances.humidityRange[0], p2.environmentalTolerances.humidityRange[0]),
          Math.max(p1.environmentalTolerances.humidityRange[1], p2.environmentalTolerances.humidityRange[1])
        ],
        lightRequirement: (p1.environmentalTolerances.lightRequirement + p2.environmentalTolerances.lightRequirement) / 2,
        co2Tolerance: Math.max(p1.environmentalTolerances.co2Tolerance, p2.environmentalTolerances.co2Tolerance),
        soilTypes: Array.from(new Set([...p1.environmentalTolerances.soilTypes, ...p2.environmentalTolerances.soilTypes]))
      },
      photosynthesisRate: (p1.photosynthesisRate + p2.photosynthesisRate) / 2 + (Math.random() > 0.8 ? 3 : 0),
      carbonSequestration: (p1.carbonSequestration + p2.carbonSequestration) / 2 + (Math.random() > 0.8 ? 0.5 : 0)
    };
    
    // Determine rarity
    let rarity: 'common' | 'uncommon' | 'rare' | 'legendary' = 'common';
    if (breedingPair.compatibility > 0.8) rarity = 'legendary';
    else if (breedingPair.compatibility > 0.6) rarity = 'rare';
    else if (breedingPair.compatibility > 0.4) rarity = 'uncommon';
    
    const result: BreedingResult = {
      offspring,
      traits: offspringGenetics.dominantAlleles,
      rarity,
      generation: 2 // F1 generation
    };
    
    setBreedingResults(prev => [result, ...prev.slice(0, 4)]); // Keep last 5 results
    setBreedingInProgress(null);
    setBreedingProgress(0);
  };
  
  const compatibility = selectedParent1 && selectedParent2 ? 
    calculateCompatibility(selectedParent1, selectedParent2) : 0;

  return (
    <div className="space-y-4">
      <Card className="bg-gray-800 border-gray-600">
        <CardHeader>
          <CardTitle className="text-green-400 flex items-center">
            🧬 Plant Breeding Laboratory
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* Parent Selection */}
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="text-sm text-gray-300 mb-2 block">Parent 1</label>
              <select
                value={selectedParent1}
                onChange={(e) => setSelectedParent1(e.target.value)}
                className="w-full p-2 rounded bg-gray-700 text-white border border-gray-600"
                disabled={breedingInProgress !== null}
              >
                <option value="">Select Parent 1</option>
                {availablePlants.map(plantKey => (
                  <option key={plantKey} value={plantKey}>
                    {REAL_PLANT_DATABASE[plantKey].species}
                  </option>
                ))}
              </select>
            </div>
            
            <div>
              <label className="text-sm text-gray-300 mb-2 block">Parent 2</label>
              <select
                value={selectedParent2}
                onChange={(e) => setSelectedParent2(e.target.value)}
                className="w-full p-2 rounded bg-gray-700 text-white border border-gray-600"
                disabled={breedingInProgress !== null}
              >
                <option value="">Select Parent 2</option>
                {availablePlants.map(plantKey => (
                  <option key={plantKey} value={plantKey}>
                    {REAL_PLANT_DATABASE[plantKey].species}
                  </option>
                ))}
              </select>
            </div>
          </div>
          
          {/* Compatibility Display */}
          {selectedParent1 && selectedParent2 && (
            <div className="bg-gray-700 p-3 rounded">
              <div className="flex justify-between items-center mb-2">
                <span className="text-gray-300">Breeding Compatibility</span>
                <Badge className={
                  compatibility > 0.6 ? 'text-green-400' :
                  compatibility > 0.3 ? 'text-yellow-400' : 'text-red-400'
                }>
                  {Math.round(compatibility * 100)}%
                </Badge>
              </div>
              <Progress value={compatibility * 100} className="h-2" />
              <div className="text-xs text-gray-400 mt-2">
                Success Rate: {Math.round(compatibility * 100)}% • 
                Expected Time: 30s • 
                Environmental Conditions: {scientificData.soilPH > 6 && scientificData.soilPH < 7 ? 'Optimal' : 'Suboptimal'}
              </div>
            </div>
          )}
          
          {/* Breeding Controls */}
          <div className="flex space-x-2">
            <Button
              onClick={startBreeding}
              disabled={!selectedParent1 || !selectedParent2 || breedingInProgress !== null}
              className="bg-green-600 hover:bg-green-700"
            >
              {breedingInProgress ? 'Breeding in Progress...' : 'Start Breeding'}
            </Button>
            
            {breedingInProgress && (
              <Button variant="outline" onClick={() => setBreedingInProgress(null)}>
                Cancel
              </Button>
            )}
          </div>
        </CardContent>
      </Card>
      
      {/* Breeding Visualization */}
      {breedingInProgress && (
        <Card className="bg-gray-800 border-gray-600">
          <CardHeader>
            <CardTitle className="text-yellow-400">Breeding Process</CardTitle>
          </CardHeader>
          <CardContent>
            <BreedingVisualization 
              breedingPair={breedingInProgress} 
              progress={breedingProgress}
            />
            <div className="mt-4">
              <div className="flex justify-between text-sm mb-2">
                <span className="text-gray-300">Progress</span>
                <span className="text-white">{Math.round(breedingProgress * 100)}%</span>
              </div>
              <Progress value={breedingProgress * 100} className="h-3" />
            </div>
          </CardContent>
        </Card>
      )}
      
      {/* Breeding Results */}
      {breedingResults.length > 0 && (
        <Card className="bg-gray-800 border-gray-600">
          <CardHeader>
            <CardTitle className="text-purple-400">Breeding Results</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {breedingResults.map((result, index) => (
                <div key={index} className="bg-gray-700 p-3 rounded border-l-4 border-purple-500">
                  <div className="flex justify-between items-start mb-2">
                    <div>
                      <h4 className="font-bold text-white">{result.offspring.species}</h4>
                      <p className="text-xs text-gray-400">Generation F{result.generation}</p>
                    </div>
                    <Badge className={
                      result.rarity === 'legendary' ? 'text-purple-400' :
                      result.rarity === 'rare' ? 'text-blue-400' :
                      result.rarity === 'uncommon' ? 'text-green-400' : 'text-gray-400'
                    }>
                      {result.rarity.toUpperCase()}
                    </Badge>
                  </div>
                  
                  <div className="text-sm space-y-1">
                    <div className="text-gray-300">
                      <strong>Traits:</strong> {result.traits.map(trait => trait.replace(/_/g, ' ')).join(', ')}
                    </div>
                    <div className="text-gray-300">
                      <strong>Hybrid Vigor:</strong> {(result.offspring.geneticTraits.hybridViability * 100).toFixed(1)}%
                    </div>
                    <div className="text-gray-300">
                      <strong>Photosynthesis Rate:</strong> {result.offspring.photosynthesisRate}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}