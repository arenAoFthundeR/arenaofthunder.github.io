import { useRef, useMemo } from 'react';
import { useFrame } from '@react-three/fiber';
import { useWeather } from '../../lib/stores/useWeather';
import * as THREE from 'three';

export function WeatherSystem() {
  const { currentWeather, temperature, humidity } = useWeather();
  const weatherParticlesRef = useRef<THREE.Points>(null);
  const cloudsRef = useRef<THREE.Group>(null);

  // Create weather particles
  const particles = useMemo(() => {
    const count = currentWeather === 'rain' ? 1000 : currentWeather === 'snow' ? 500 : 0;
    const positions = new Float32Array(count * 3);

    for (let i = 0; i < count; i++) {
      positions[i * 3] = (Math.random() - 0.5) * 100;
      positions[i * 3 + 1] = Math.random() * 50 + 10;
      positions[i * 3 + 2] = (Math.random() - 0.5) * 100;
    }

    return { positions, count };
  }, [currentWeather]);

  // Animate weather effects
  useFrame((state, delta) => {
    if (weatherParticlesRef.current && particles.count > 0) {
      const positions = weatherParticlesRef.current.geometry.attributes.position.array as Float32Array;
      
      for (let i = 0; i < particles.count; i++) {
        // Rain falls down, snow falls slower
        const fallSpeed = currentWeather === 'rain' ? 20 : 5;
        positions[i * 3 + 1] -= fallSpeed * delta;
        
        // Reset particles that fall below ground
        if (positions[i * 3 + 1] < 0) {
          positions[i * 3 + 1] = 50;
        }
      }
      
      weatherParticlesRef.current.geometry.attributes.position.needsUpdate = true;
    }

    // Animate clouds
    if (cloudsRef.current) {
      cloudsRef.current.position.x += delta * 2;
      if (cloudsRef.current.position.x > 50) {
        cloudsRef.current.position.x = -50;
      }
    }
  });

  const getWeatherColor = () => {
    switch (currentWeather) {
      case 'rain': return '#4488ff';
      case 'snow': return '#ffffff';
      default: return '#ffffff';
    }
  };

  return (
    <group>
      {/* Weather particles */}
      {particles.count > 0 && (
        <points ref={weatherParticlesRef}>
          <bufferGeometry>
            <bufferAttribute
              attach="attributes-position"
              count={particles.count}
              array={particles.positions}
              itemSize={3}
            />
          </bufferGeometry>
          <pointsMaterial
            color={getWeatherColor()}
            size={currentWeather === 'rain' ? 0.1 : 0.3}
            transparent
            opacity={0.7}
          />
        </points>
      )}

      {/* Clouds */}
      {(currentWeather === 'cloudy' || currentWeather === 'rain') && (
        <group ref={cloudsRef} position={[-50, 20, 0]}>
          {Array.from({ length: 5 }, (_, i) => (
            <mesh key={`cloud-${i}`} position={[i * 20, Math.sin(i) * 3, -10]}>
              <sphereGeometry args={[5, 8, 8]} />
              <meshBasicMaterial 
                color="#cccccc"
                transparent
                opacity={0.6}
              />
            </mesh>
          ))}
        </group>
      )}

      {/* Sun (when sunny) */}
      {currentWeather === 'sunny' && (
        <mesh position={[30, 30, -20]}>
          <sphereGeometry args={[3]} />
          <meshBasicMaterial 
            color="#ffff44"
            emissive="#ffff44"
            emissiveIntensity={0.3}
          />
        </mesh>
      )}

      {/* Lightning effect (during storms) */}
      {currentWeather === 'storm' && Math.random() < 0.01 && (
        <mesh position={[0, 25, -30]}>
          <cylinderGeometry args={[0.1, 0.1, 20]} />
          <meshBasicMaterial 
            color="#ffffff"
            emissive="#ffffff"
            emissiveIntensity={1}
            transparent
            opacity={0.8}
          />
        </mesh>
      )}
    </group>
  );
}
