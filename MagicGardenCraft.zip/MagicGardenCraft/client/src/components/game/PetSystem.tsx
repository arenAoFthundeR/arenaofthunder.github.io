import React, { useState, useRef } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import { Text, Box, Sphere, Cylinder } from '@react-three/drei';
import * as THREE from 'three';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Button } from '../ui/button';
import { Badge } from '../ui/badge';

interface PlantPet {
  id: string;
  name: string;
  species: string;
  level: number;
  experience: number;
  happiness: number;
  hunger: number;
  traits: string[];
  color: string;
  size: number;
  rarity: 'common' | 'uncommon' | 'rare' | 'legendary';
  abilities: string[];
  wearable: boolean;
}

// 3D Plant Pet Model
function PlantPetModel({ pet, isWorn = false, position = [0, 0, 0] }: {
  pet: PlantPet;
  isWorn?: boolean;
  position?: [number, number, number];
}) {
  const meshRef = useRef<THREE.Group>(null);
  
  useFrame(() => {
    if (meshRef.current) {
      // Gentle bobbing animation
      meshRef.current.position.y = position[1] + Math.sin(Date.now() * 0.003) * 0.1;
      // Slight rotation for personality
      meshRef.current.rotation.y += 0.005;
    }
  });

  const petSize = isWorn ? pet.size * 0.3 : pet.size; // Smaller when worn as hat
  const petColor = pet.color;

  return (
    <group ref={meshRef} position={position} scale={petSize}>
      {/* Pet body (main plant) */}
      <Sphere args={[0.5]} position={[0, 0, 0]}>
        <meshStandardMaterial color={petColor} />
      </Sphere>
      
      {/* Cute eyes */}
      <Sphere args={[0.08]} position={[-0.15, 0.1, 0.4]}>
        <meshStandardMaterial color="#000000" />
      </Sphere>
      <Sphere args={[0.08]} position={[0.15, 0.1, 0.4]}>
        <meshStandardMaterial color="#000000" />
      </Sphere>
      
      {/* Eye shine */}
      <Sphere args={[0.03]} position={[-0.13, 0.12, 0.45]}>
        <meshStandardMaterial color="#ffffff" />
      </Sphere>
      <Sphere args={[0.03]} position={[0.17, 0.12, 0.45]}>
        <meshStandardMaterial color="#ffffff" />
      </Sphere>
      
      {/* Cute mouth */}
      <Box args={[0.15, 0.02, 0.02]} position={[0, -0.1, 0.4]}>
        <meshStandardMaterial color="#000000" />
      </Box>
      
      {/* Plant leaves/petals based on rarity */}
      {pet.rarity === 'legendary' && (
        <>
          {Array.from({ length: 8 }, (_, i) => {
            const angle = (i / 8) * Math.PI * 2;
            return (
              <Box
                key={i}
                args={[0.3, 0.1, 0.02]}
                position={[Math.cos(angle) * 0.6, Math.sin(angle) * 0.6, 0]}
                rotation={[0, 0, angle]}
              >
                <meshStandardMaterial color="#fbbf24" />
              </Box>
            );
          })}
        </>
      )}
      
      {pet.rarity === 'rare' && (
        <>
          {Array.from({ length: 6 }, (_, i) => {
            const angle = (i / 6) * Math.PI * 2;
            return (
              <Box
                key={i}
                args={[0.25, 0.08, 0.02]}
                position={[Math.cos(angle) * 0.55, Math.sin(angle) * 0.55, 0]}
                rotation={[0, 0, angle]}
              >
                <meshStandardMaterial color="#a855f7" />
              </Box>
            );
          })}
        </>
      )}
      
      {/* Simple leaves for common/uncommon */}
      {(pet.rarity === 'common' || pet.rarity === 'uncommon') && (
        <>
          <Box args={[0.2, 0.06, 0.02]} position={[0.4, 0.3, 0]} rotation={[0, 0, 0.3]}>
            <meshStandardMaterial color="#10b981" />
          </Box>
          <Box args={[0.2, 0.06, 0.02]} position={[-0.4, 0.3, 0]} rotation={[0, 0, -0.3]}>
            <meshStandardMaterial color="#10b981" />
          </Box>
        </>
      )}
      
      {/* Happiness indicator particles */}
      {pet.happiness > 70 && (
        <>
          {Array.from({ length: 3 }, (_, i) => (
            <Sphere
              key={i}
              args={[0.02]}
              position={[
                (Math.random() - 0.5) * 1.5,
                0.8 + Math.random() * 0.5,
                (Math.random() - 0.5) * 1.5
              ]}
            >
              <meshStandardMaterial color="#fbbf24" />
            </Sphere>
          ))}
        </>
      )}
      
      {/* Level indicator */}
      <Text
        position={[0, -0.8, 0]}
        fontSize={0.12}
        color="#ffffff"
        anchorX="center"
        anchorY="middle"
      >
        Lv.{pet.level}
      </Text>
    </group>
  );
}

// Pet Stats Display
function PetStatsPanel({ pet }: { pet: PlantPet }) {
  const getHappinessColor = (happiness: number) => {
    if (happiness > 80) return 'text-green-400';
    if (happiness > 50) return 'text-yellow-400';
    return 'text-red-400';
  };

  const getHungerColor = (hunger: number) => {
    if (hunger < 30) return 'text-green-400';
    if (hunger < 70) return 'text-yellow-400';
    return 'text-red-400';
  };

  return (
    <div className="bg-gray-700 p-4 rounded-lg">
      <div className="text-center mb-3">
        <h3 className="text-lg font-bold text-white">{pet.name}</h3>
        <p className="text-sm text-gray-300">{pet.species}</p>
        <Badge className={
          pet.rarity === 'legendary' ? 'text-purple-400' :
          pet.rarity === 'rare' ? 'text-blue-400' :
          pet.rarity === 'uncommon' ? 'text-green-400' : 'text-gray-400'
        }>
          {pet.rarity.toUpperCase()}
        </Badge>
      </div>
      
      <div className="space-y-3">
        <div>
          <div className="flex justify-between text-sm">
            <span className="text-gray-300">Level</span>
            <span className="text-white">{pet.level}</span>
          </div>
          <div className="flex justify-between text-sm">
            <span className="text-gray-300">Experience</span>
            <span className="text-blue-400">{pet.experience}/100</span>
          </div>
        </div>
        
        <div>
          <div className="flex justify-between text-sm">
            <span className="text-gray-300">Happiness</span>
            <span className={getHappinessColor(pet.happiness)}>{pet.happiness}%</span>
          </div>
          <div className="w-full bg-gray-600 rounded-full h-2">
            <div 
              className="bg-green-400 h-2 rounded-full transition-all"
              style={{ width: `${pet.happiness}%` }}
            />
          </div>
        </div>
        
        <div>
          <div className="flex justify-between text-sm">
            <span className="text-gray-300">Hunger</span>
            <span className={getHungerColor(pet.hunger)}>{pet.hunger}%</span>
          </div>
          <div className="w-full bg-gray-600 rounded-full h-2">
            <div 
              className="bg-red-400 h-2 rounded-full transition-all"
              style={{ width: `${pet.hunger}%` }}
            />
          </div>
        </div>
        
        <div>
          <span className="text-sm text-gray-300">Traits:</span>
          <div className="flex flex-wrap gap-1 mt-1">
            {pet.traits.map((trait, index) => (
              <Badge key={index} variant="outline" className="text-xs">
                {trait}
              </Badge>
            ))}
          </div>
        </div>
        
        <div>
          <span className="text-sm text-gray-300">Abilities:</span>
          <div className="space-y-1 mt-1">
            {pet.abilities.map((ability, index) => (
              <div key={index} className="text-xs text-blue-400">
                • {ability}
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

export function PetSystem() {
  const [selectedPet, setSelectedPet] = useState<PlantPet | null>(null);
  const [isWearingPet, setIsWearingPet] = useState(false);
  const [wornPet, setWornPet] = useState<PlantPet | null>(null);
  
  // Sample plant pets (in real game, these would come from breeding/hatching)
  const [plantPets] = useState<PlantPet[]>([
    {
      id: '1',
      name: 'Sunny',
      species: 'Solar Sprout',
      level: 5,
      experience: 45,
      happiness: 85,
      hunger: 25,
      traits: ['Cheerful', 'Photosynthetic', 'Morning Person'],
      color: '#fbbf24',
      size: 1,
      rarity: 'uncommon',
      abilities: ['Solar Charge', 'Happiness Boost'],
      wearable: true
    },
    {
      id: '2',
      name: 'Mystique',
      species: 'Shadow Bloom',
      level: 12,
      experience: 78,
      happiness: 72,
      hunger: 40,
      traits: ['Mysterious', 'Night Active', 'Magical'],
      color: '#8b5cf6',
      size: 1.2,
      rarity: 'rare',
      abilities: ['Shadow Step', 'Mana Regeneration', 'Dark Magic Boost'],
      wearable: true
    },
    {
      id: '3',
      name: 'Zephyr',
      species: 'Wind Whisper',
      level: 8,
      experience: 23,
      happiness: 90,
      hunger: 15,
      traits: ['Playful', 'Aerodynamic', 'Free Spirit'],
      color: '#06b6d4',
      size: 0.8,
      rarity: 'common',
      abilities: ['Wind Boost', 'Speed Enhancement'],
      wearable: true
    },
    {
      id: '4',
      name: 'Ember',
      species: 'Flame Fern',
      level: 20,
      experience: 95,
      happiness: 88,
      hunger: 30,
      traits: ['Passionate', 'Warm-hearted', 'Protective'],
      color: '#ef4444',
      size: 1.5,
      rarity: 'legendary',
      abilities: ['Fire Shield', 'Heat Generation', 'Combat Boost', 'Legendary Aura'],
      wearable: true
    }
  ]);

  const handleWearPet = (pet: PlantPet) => {
    if (wornPet?.id === pet.id) {
      // Remove pet if already wearing it
      setWornPet(null);
      setIsWearingPet(false);
    } else {
      // Wear the selected pet
      setWornPet(pet);
      setIsWearingPet(true);
    }
  };

  const feedPet = (petId: string) => {
    // In real game, this would update pet stats
    console.log(`Feeding pet ${petId}`);
  };

  const playWithPet = (petId: string) => {
    // In real game, this would update happiness and experience
    console.log(`Playing with pet ${petId}`);
  };

  return (
    <div className="space-y-4">
      <Card className="bg-gray-800 border-gray-600">
        <CardHeader>
          <CardTitle className="text-green-400 flex items-center">
            🌱 Plant Pet System
          </CardTitle>
          <p className="text-sm text-gray-400">
            Raise, care for, and wear your plant companions as magical hats!
          </p>
        </CardHeader>
        <CardContent>
          {/* Currently Worn Pet Indicator */}
          {wornPet && (
            <div className="bg-purple-900/30 border border-purple-500 p-3 rounded-lg mb-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <div className="text-purple-400">👑</div>
                  <div>
                    <div className="font-bold text-purple-400">Currently Wearing</div>
                    <div className="text-sm text-white">{wornPet.name} the {wornPet.species}</div>
                  </div>
                </div>
                <Button
                  onClick={() => handleWearPet(wornPet)}
                  variant="outline"
                  size="sm"
                  className="border-purple-500 text-purple-400 hover:bg-purple-500/20"
                >
                  Remove Hat
                </Button>
              </div>
            </div>
          )}
          
          {/* Pet Grid */}
          <div className="grid grid-cols-2 gap-4">
            {plantPets.map(pet => (
              <div 
                key={pet.id}
                className={`bg-gray-700 p-3 rounded-lg border-2 cursor-pointer transition-all ${
                  selectedPet?.id === pet.id 
                    ? 'border-green-500 bg-green-900/20' 
                    : wornPet?.id === pet.id
                    ? 'border-purple-500 bg-purple-900/20'
                    : 'border-gray-600 hover:border-gray-500'
                }`}
                onClick={() => setSelectedPet(pet)}
              >
                <div className="h-32 mb-2">
                  <Canvas camera={{ position: [0, 0, 3], fov: 50 }}>
                    <ambientLight intensity={0.4} />
                    <pointLight position={[2, 2, 2]} intensity={0.8} />
                    <PlantPetModel pet={pet} />
                  </Canvas>
                </div>
                
                <div className="text-center">
                  <div className="font-bold text-white text-sm">{pet.name}</div>
                  <div className="text-xs text-gray-300">{pet.species}</div>
                  <div className="text-xs text-gray-400">Level {pet.level}</div>
                  {wornPet?.id === pet.id && (
                    <Badge className="text-purple-400 mt-1">WORN AS HAT</Badge>
                  )}
                </div>
                
                <div className="flex space-x-1 mt-2">
                  <Button
                    onClick={(e) => {
                      e.stopPropagation();
                      handleWearPet(pet);
                    }}
                    size="sm"
                    className={
                      wornPet?.id === pet.id
                        ? "bg-purple-600 hover:bg-purple-700"
                        : "bg-blue-600 hover:bg-blue-700"
                    }
                  >
                    {wornPet?.id === pet.id ? '👑 Remove' : '👑 Wear'}
                  </Button>
                  <Button
                    onClick={(e) => {
                      e.stopPropagation();
                      feedPet(pet.id);
                    }}
                    size="sm"
                    variant="outline"
                  >
                    🍃 Feed
                  </Button>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
      
      {/* Selected Pet Details */}
      {selectedPet && (
        <Card className="bg-gray-800 border-gray-600">
          <CardHeader>
            <CardTitle className="text-blue-400">Pet Details</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* 3D Pet View */}
              <div className="h-64">
                <Canvas camera={{ position: [0, 0, 4], fov: 60 }}>
                  <ambientLight intensity={0.4} />
                  <directionalLight position={[5, 5, 5]} intensity={0.8} />
                  <pointLight position={[-3, 3, 3]} intensity={0.6} color={selectedPet.color} />
                  <PlantPetModel pet={selectedPet} />
                </Canvas>
              </div>
              
              {/* Pet Stats */}
              <PetStatsPanel pet={selectedPet} />
            </div>
            
            {/* Pet Actions */}
            <div className="flex space-x-2 mt-4">
              <Button
                onClick={() => feedPet(selectedPet.id)}
                className="bg-green-600 hover:bg-green-700"
              >
                🍃 Feed Pet
              </Button>
              <Button
                onClick={() => playWithPet(selectedPet.id)}
                className="bg-yellow-600 hover:bg-yellow-700"
              >
                🎮 Play
              </Button>
              <Button
                onClick={() => handleWearPet(selectedPet)}
                className={
                  wornPet?.id === selectedPet.id
                    ? "bg-purple-600 hover:bg-purple-700"
                    : "bg-blue-600 hover:bg-blue-700"
                }
              >
                {wornPet?.id === selectedPet.id ? '👑 Remove Hat' : '👑 Wear as Hat'}
              </Button>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}