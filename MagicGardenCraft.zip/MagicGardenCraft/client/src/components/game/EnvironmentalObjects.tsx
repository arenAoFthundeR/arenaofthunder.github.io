import { useRef, useState, useMemo } from 'react';
import { useFrame } from '@react-three/fiber';
import * as THREE from 'three';
import { useGarden } from '../../lib/stores/useGarden';
import { useElements } from '../../lib/stores/useElements';
import { useAudio } from '../../lib/stores/useAudio';

interface TreeProps {
  position: [number, number, number];
  element: string;
}

function MagicalTree({ position, element }: TreeProps) {
  const treeRef = useRef<THREE.Group>(null);
  const leavesRef = useRef<THREE.Mesh>(null);
  const { playSuccess } = useAudio();
  const [isGlowing, setIsGlowing] = useState(false);

  useFrame((state, delta) => {
    if (treeRef.current) {
      // Gentle swaying motion
      treeRef.current.rotation.z = Math.sin(state.clock.elapsedTime * 0.5) * 0.1;
    }
    
    if (leavesRef.current && isGlowing) {
      // Pulsing glow effect
      const intensity = 0.3 + Math.sin(state.clock.elapsedTime * 3) * 0.2;
      (leavesRef.current.material as THREE.MeshStandardMaterial).emissiveIntensity = intensity;
    }
  });

  const getElementColor = () => {
    switch (element) {
      case 'fire': return '#ff6644';
      case 'water': return '#4466ff';
      case 'earth': return '#66ff44';
      case 'air': return '#ffff66';
      case 'shadow': return '#666699';
      case 'black': return '#cc0099';
      default: return '#228B22';
    }
  };

  const handleClick = () => {
    setIsGlowing(!isGlowing);
    playSuccess();
    console.log(`Activated ${element} tree!`);
  };

  return (
    <group ref={treeRef} position={position} onClick={handleClick}>
      {/* Tree trunk */}
      <mesh position={[0, 2, 0]}>
        <cylinderGeometry args={[0.3, 0.4, 4, 8]} />
        <meshStandardMaterial color="#8B4513" />
      </mesh>
      
      {/* Tree leaves */}
      <mesh ref={leavesRef} position={[0, 5, 0]}>
        <sphereGeometry args={[2, 12, 12]} />
        <meshStandardMaterial 
          color={getElementColor()}
          emissive={isGlowing ? getElementColor() : '#000000'}
          emissiveIntensity={isGlowing ? 0.3 : 0}
        />
      </mesh>
      
      {/* Magical sparkles around the tree */}
      {isGlowing && (
        <points position={[0, 5, 0]}>
          <bufferGeometry>
            <bufferAttribute
              attach="attributes-position"
              count={50}
              array={new Float32Array(Array.from({ length: 150 }, () => (Math.random() - 0.5) * 8))}
              itemSize={3}
            />
          </bufferGeometry>
          <pointsMaterial
            color={getElementColor()}
            size={0.1}
            transparent
            opacity={0.8}
          />
        </points>
      )}
    </group>
  );
}

interface CrystalProps {
  position: [number, number, number];
  size: number;
}

function MagicalCrystal({ position, size }: CrystalProps) {
  const crystalRef = useRef<THREE.Mesh>(null);
  const { selectedElement } = useElements();

  useFrame((state) => {
    if (crystalRef.current) {
      crystalRef.current.rotation.y = state.clock.elapsedTime * 0.5;
      crystalRef.current.position.y = position[1] + Math.sin(state.clock.elapsedTime * 2) * 0.2;
    }
  });

  const getElementColor = () => {
    switch (selectedElement) {
      case 'fire': return '#ff6644';
      case 'water': return '#4466ff';
      case 'earth': return '#66ff44';
      case 'air': return '#ffff66';
      case 'shadow': return '#666699';
      case 'black': return '#cc0099';
      default: return '#ffffff';
    }
  };

  return (
    <mesh ref={crystalRef} position={position}>
      <octahedronGeometry args={[size]} />
      <meshStandardMaterial
        color={getElementColor()}
        emissive={getElementColor()}
        emissiveIntensity={0.3}
        transparent
        opacity={0.8}
      />
    </mesh>
  );
}

export function EnvironmentalObjects() {
  const { selectedElement } = useElements();

  // Pre-calculate random positions to avoid re-renders
  const treePositions = useMemo(() => [
    [-15, 0, -10] as [number, number, number],
    [12, 0, -15] as [number, number, number],
    [-8, 0, 18] as [number, number, number],
    [20, 0, 12] as [number, number, number],
    [-25, 0, 5] as [number, number, number],
  ], []);

  const crystalPositions = useMemo(() => [
    [-5, 1.5, -8] as [number, number, number],
    [8, 2, 10] as [number, number, number],
    [-12, 1, 15] as [number, number, number],
    [15, 1.8, -12] as [number, number, number],
  ], []);

  return (
    <group>
      {/* Magical Trees */}
      {treePositions.map((pos, index) => (
        <MagicalTree
          key={`tree-${index}`}
          position={pos}
          element={selectedElement || 'earth'}
        />
      ))}
      
      {/* Floating Crystals */}
      {crystalPositions.map((pos, index) => (
        <MagicalCrystal
          key={`crystal-${index}`}
          position={pos}
          size={0.5 + Math.sin(index) * 0.2}
        />
      ))}
      
      {/* Ancient Stone Circle */}
      <group position={[0, 0, -30]}>
        {Array.from({ length: 8 }, (_, i) => {
          const angle = (i / 8) * Math.PI * 2;
          const radius = 6;
          const x = Math.cos(angle) * radius;
          const z = Math.sin(angle) * radius;
          
          return (
            <mesh key={`stone-${i}`} position={[x, 1.5, z]}>
              <cylinderGeometry args={[0.5, 0.6, 3, 6]} />
              <meshStandardMaterial color="#888888" />
            </mesh>
          );
        })}
      </group>
    </group>
  );
}