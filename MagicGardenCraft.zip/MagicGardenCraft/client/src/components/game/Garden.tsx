import { useRef } from 'react';
import { useTexture } from '@react-three/drei';
import { useGarden } from '../../lib/stores/useGarden';
import { useElements } from '../../lib/stores/useElements';
import * as THREE from 'three';

export function Garden() {
  const grassTexture = useTexture('/textures/grass.png');
  const { gardenPlots, gardenData } = useGarden();
  const { selectedElement } = useElements();

  // Configure grass texture
  grassTexture.wrapS = grassTexture.wrapT = THREE.RepeatWrapping;
  grassTexture.repeat.set(10, 10);

  return (
    <group>
      {/* Ground plane */}
      <mesh position={[0, 0, 0]} receiveShadow rotation={[-Math.PI / 2, 0, 0]}>
        <planeGeometry args={[100, 100]} />
        <meshStandardMaterial map={grassTexture} />
      </mesh>

      {/* Garden plots */}
      {gardenPlots.map((plot, index) => (
        <GardenPlot
          key={`plot-${index}`}
          position={plot.position}
          element={plot.element}
          growth={plot.growth}
          planted={plot.planted}
        />
      ))}

      {/* Magical garden elements based on selected element */}
      {selectedElement && (
        <ElementalGardenFeatures element={selectedElement} />
      )}
    </group>
  );
}

interface GardenPlotProps {
  position: [number, number, number];
  element: string;
  growth: number;
  planted: boolean;
}

function GardenPlot({ position, element, growth, planted }: GardenPlotProps) {
  const plotRef = useRef<THREE.Mesh>(null);

  const getElementColor = () => {
    switch (element) {
      case 'fire': return '#ff6644';
      case 'water': return '#4466ff';
      case 'earth': return '#66ff44';
      case 'air': return '#ffff66';
      case 'shadow': return '#666666';
      case 'black': return '#222222';
      default: return '#8B4513';
    }
  };

  const getPlantHeight = () => {
    return planted ? 0.5 + (growth * 1.5) : 0.1;
  };

  return (
    <group position={position}>
      {/* Plot base */}
      <mesh position={[0, 0.05, 0]} castShadow>
        <boxGeometry args={[2, 0.1, 2]} />
        <meshStandardMaterial color="#8B4513" />
      </mesh>

      {/* Plant/magical element */}
      {planted && (
        <mesh position={[0, getPlantHeight() / 2, 0]} castShadow>
          <boxGeometry args={[0.5, getPlantHeight(), 0.5]} />
          <meshStandardMaterial 
            color={getElementColor()}
            emissive={element === 'fire' || element === 'black' ? getElementColor() : '#000000'}
            emissiveIntensity={element === 'fire' || element === 'black' ? 0.2 : 0}
          />
        </mesh>
      )}

      {/* Growth particles for magical effect */}
      {planted && growth > 0.5 && (
        <mesh position={[0, getPlantHeight() + 0.5, 0]}>
          <sphereGeometry args={[0.1, 8, 8]} />
          <meshBasicMaterial 
            color={getElementColor()}
            transparent
            opacity={0.6}
          />
        </mesh>
      )}
    </group>
  );
}

interface ElementalGardenFeaturesProps {
  element: string;
}

function ElementalGardenFeatures({ element }: ElementalGardenFeaturesProps) {
  const features = [];

  switch (element) {
    case 'fire':
      // Fire torches around the garden
      for (let i = 0; i < 4; i++) {
        const angle = (i / 4) * Math.PI * 2;
        const x = Math.cos(angle) * 15;
        const z = Math.sin(angle) * 15;
        features.push(
          <mesh key={`fire-torch-${i}`} position={[x, 2, z]} castShadow>
            <cylinderGeometry args={[0.1, 0.1, 3]} />
            <meshStandardMaterial 
              color="#ff4444"
              emissive="#ff4444"
              emissiveIntensity={0.5}
            />
          </mesh>
        );
      }
      break;

    case 'water':
      // Water fountains
      features.push(
        <mesh key="water-fountain" position={[0, 1, -10]} castShadow>
          <cylinderGeometry args={[1, 1, 2]} />
          <meshStandardMaterial 
            color="#4466ff"
            transparent
            opacity={0.7}
          />
        </mesh>
      );
      break;

    case 'earth':
      // Stone pillars
      for (let i = 0; i < 6; i++) {
        const angle = (i / 6) * Math.PI * 2;
        const x = Math.cos(angle) * 12;
        const z = Math.sin(angle) * 12;
        features.push(
          <mesh key={`earth-pillar-${i}`} position={[x, 1.5, z]} castShadow>
            <cylinderGeometry args={[0.5, 0.7, 3]} />
            <meshStandardMaterial color="#666666" />
          </mesh>
        );
      }
      break;

    case 'air':
      // Floating crystals
      for (let i = 0; i < 8; i++) {
        const angle = (i / 8) * Math.PI * 2;
        const x = Math.cos(angle) * 10;
        const z = Math.sin(angle) * 10;
        features.push(
          <mesh key={`air-crystal-${i}`} position={[x, 3 + Math.sin(angle) * 2, z]}>
            <octahedronGeometry args={[0.3]} />
            <meshStandardMaterial 
              color="#ffff66"
              transparent
              opacity={0.8}
            />
          </mesh>
        );
      }
      break;

    case 'shadow':
      // Dark obelisks
      for (let i = 0; i < 3; i++) {
        const x = (i - 1) * 8;
        features.push(
          <mesh key={`shadow-obelisk-${i}`} position={[x, 2, -15]} castShadow>
            <coneGeometry args={[0.5, 4, 4]} />
            <meshStandardMaterial 
              color="#333333"
              emissive="#111111"
              emissiveIntensity={0.2}
            />
          </mesh>
        );
      }
      break;

    case 'black':
      // Void portals
      features.push(
        <mesh key="black-portal" position={[0, 1, -20]}>
          <ringGeometry args={[1, 2, 16]} />
          <meshBasicMaterial 
            color="#000000"
            side={THREE.DoubleSide}
          />
        </mesh>
      );
      break;
  }

  return <>{features}</>;
}
