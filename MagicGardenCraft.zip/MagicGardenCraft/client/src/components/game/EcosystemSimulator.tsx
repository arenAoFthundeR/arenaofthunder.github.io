import React, { useState, useRef, useEffect } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import { Text, Sphere, Box, Line } from '@react-three/drei';
import * as THREE from 'three';
import { useScientificData } from '../../lib/stores/useScientificData';

// Animated Pollinator (Bee)
function AnimatedBee({ position, target, onReachTarget }: {
  position: [number, number, number];
  target: [number, number, number];
  onReachTarget: () => void;
}) {
  const meshRef = useRef<THREE.Group>(null);
  const [currentTarget, setCurrentTarget] = useState(new THREE.Vector3(...target));
  const [speed] = useState(0.02 + Math.random() * 0.02);

  useFrame(() => {
    if (meshRef.current) {
      const currentPos = meshRef.current.position;
      const distance = currentPos.distanceTo(currentTarget);
      
      if (distance < 0.1) {
        onReachTarget();
        // Set new random target
        setCurrentTarget(new THREE.Vector3(
          (Math.random() - 0.5) * 10,
          (Math.random() - 0.5) * 8,
          (Math.random() - 0.5) * 10
        ));
      } else {
        // Move towards target
        const direction = currentTarget.clone().sub(currentPos).normalize();
        currentPos.add(direction.multiplyScalar(speed));
        
        // Add wing flutter animation
        meshRef.current.rotation.z = Math.sin(Date.now() * 0.01) * 0.3;
      }
    }
  });

  return (
    <group ref={meshRef} position={position}>
      {/* Bee body */}
      <Box args={[0.3, 0.1, 0.1]}>
        <meshStandardMaterial color="#fbbf24" />
      </Box>
      {/* Bee stripes */}
      <Box args={[0.31, 0.11, 0.05]} position={[0, 0, 0.02]}>
        <meshStandardMaterial color="#000000" />
      </Box>
      {/* Wings */}
      <Box args={[0.15, 0.05, 0.01]} position={[-0.1, 0.08, 0]}>
        <meshStandardMaterial color="#ffffff" transparent opacity={0.7} />
      </Box>
      <Box args={[0.15, 0.05, 0.01]} position={[0.1, 0.08, 0]}>
        <meshStandardMaterial color="#ffffff" transparent opacity={0.7} />
      </Box>
    </group>
  );
}

// Flower with Pollen
function FlowerWithPollen({ position, isBeingVisited }: {
  position: [number, number, number];
  isBeingVisited: boolean;
}) {
  const [pollenCount, setPollenCount] = useState(100);
  
  useEffect(() => {
    if (isBeingVisited && pollenCount > 0) {
      const timer = setTimeout(() => {
        setPollenCount(prev => Math.max(0, prev - 5));
      }, 100);
      return () => clearTimeout(timer);
    }
  }, [isBeingVisited, pollenCount]);

  return (
    <group position={position}>
      {/* Flower petals */}
      {Array.from({ length: 6 }, (_, i) => {
        const angle = (i / 6) * Math.PI * 2;
        return (
          <Box
            key={i}
            args={[0.3, 0.1, 0.02]}
            position={[Math.cos(angle) * 0.4, Math.sin(angle) * 0.4, 0]}
            rotation={[0, 0, angle]}
          >
            <meshStandardMaterial color="#ec4899" />
          </Box>
        );
      })}
      
      {/* Center with pollen */}
      <Sphere args={[0.2]}>
        <meshStandardMaterial color="#fbbf24" />
      </Sphere>
      
      {/* Pollen particles */}
      {Array.from({ length: Math.floor(pollenCount / 10) }, (_, i) => (
        <Sphere
          key={i}
          args={[0.02]}
          position={[
            (Math.random() - 0.5) * 0.5,
            (Math.random() - 0.5) * 0.5,
            0.2 + Math.random() * 0.3
          ]}
        >
          <meshStandardMaterial color="#fbbf24" />
        </Sphere>
      ))}
      
      {/* Pollen count text */}
      <Text
        position={[0, -0.8, 0]}
        fontSize={0.2}
        color="#fbbf24"
        anchorX="center"
        anchorY="middle"
      >
        Pollen: {pollenCount}%
      </Text>
    </group>
  );
}

// Decomposer organisms
function DecomposerColony({ position }: { position: [number, number, number] }) {
  const meshRef = useRef<THREE.Group>(null);
  
  useFrame(() => {
    if (meshRef.current) {
      meshRef.current.rotation.y += 0.005;
    }
  });

  return (
    <group ref={meshRef} position={position}>
      {/* Fungi network */}
      {Array.from({ length: 8 }, (_, i) => {
        const angle = (i / 8) * Math.PI * 2;
        const radius = 1 + Math.sin(Date.now() * 0.001 + i) * 0.2;
        return (
          <Sphere
            key={i}
            args={[0.05]}
            position={[Math.cos(angle) * radius, 0, Math.sin(angle) * radius]}
          >
            <meshStandardMaterial color="#a855f7" />
          </Sphere>
        );
      })}
      
      {/* Central decomposing matter */}
      <Box args={[0.5, 0.2, 0.5]}>
        <meshStandardMaterial color="#92400e" />
      </Box>
      
      <Text
        position={[0, -0.5, 0]}
        fontSize={0.15}
        color="#a855f7"
        anchorX="center"
        anchorY="middle"
      >
        Decomposers
      </Text>
    </group>
  );
}

// Carbon Cycle Visualization
function CarbonCycleFlow() {
  const scientificData = useScientificData();
  
  return (
    <group>
      {/* CO2 molecules in atmosphere */}
      {Array.from({ length: Math.floor(scientificData.co2Level / 50) }, (_, i) => (
        <Sphere
          key={i}
          args={[0.03]}
          position={[
            (Math.random() - 0.5) * 15,
            5 + Math.random() * 3,
            (Math.random() - 0.5) * 15
          ]}
        >
          <meshStandardMaterial color="#ef4444" />
        </Sphere>
      ))}
      
      {/* Oxygen molecules */}
      {Array.from({ length: Math.floor(scientificData.oxygenLevel * 2) }, (_, i) => (
        <Sphere
          key={i}
          args={[0.02]}
          position={[
            (Math.random() - 0.5) * 15,
            2 + Math.random() * 4,
            (Math.random() - 0.5) * 15
          ]}
        >
          <meshStandardMaterial color="#3b82f6" />
        </Sphere>
      ))}
      
      {/* Carbon sequestration visualization */}
      <Text
        position={[0, 8, 0]}
        fontSize={0.5}
        color="#10b981"
        anchorX="center"
        anchorY="middle"
      >
        CO₂: {scientificData.co2Level} ppm
      </Text>
      
      <Text
        position={[0, 7, 0]}
        fontSize={0.3}
        color="#3b82f6"
        anchorX="center"
        anchorY="middle"
      >
        O₂: {scientificData.oxygenLevel}%
      </Text>
    </group>
  );
}

// Main Ecosystem Simulator
export function EcosystemSimulator() {
  const scientificData = useScientificData();
  const [flowers] = useState([
    { id: 1, position: [2, 0, 2] as [number, number, number], visited: false },
    { id: 2, position: [-2, 0, 2] as [number, number, number], visited: false },
    { id: 3, position: [2, 0, -2] as [number, number, number], visited: false },
    { id: 4, position: [-2, 0, -2] as [number, number, number], visited: false }
  ]);
  
  const [beeTargets, setBeeTargets] = useState(
    Array.from({ length: Math.floor(scientificData.pollinatorCount / 5) }, (_, i) => ({
      id: i,
      position: [(Math.random() - 0.5) * 8, (Math.random() - 0.5) * 6, (Math.random() - 0.5) * 8] as [number, number, number],
      target: flowers[i % flowers.length].position
    }))
  );

  const handleBeeReachTarget = (beeId: number) => {
    setBeeTargets(prev => prev.map(bee => 
      bee.id === beeId 
        ? { ...bee, target: flowers[Math.floor(Math.random() * flowers.length)].position }
        : bee
    ));
  };

  return (
    <div className="relative w-full h-96 bg-gradient-to-b from-sky-900 to-green-900 rounded-lg overflow-hidden">
      <Canvas camera={{ position: [0, 5, 10], fov: 60 }}>
        <ambientLight intensity={0.4} />
        <directionalLight position={[10, 10, 5]} intensity={0.8} />
        <pointLight position={[0, 5, 0]} intensity={0.6} color="#fbbf24" />
        
        {/* Ground plane */}
        <Box args={[20, 0.1, 20]} position={[0, -2, 0]}>
          <meshStandardMaterial color="#22c55e" />
        </Box>
        
        {/* Flowers */}
        {flowers.map(flower => (
          <FlowerWithPollen
            key={flower.id}
            position={flower.position}
            isBeingVisited={flower.visited}
          />
        ))}
        
        {/* Bees */}
        {beeTargets.map(bee => (
          <AnimatedBee
            key={bee.id}
            position={bee.position}
            target={bee.target}
            onReachTarget={() => handleBeeReachTarget(bee.id)}
          />
        ))}
        
        {/* Decomposer colonies */}
        <DecomposerColony position={[4, -1.8, 4]} />
        <DecomposerColony position={[-4, -1.8, -4]} />
        
        {/* Carbon cycle visualization */}
        <CarbonCycleFlow />
        
        {/* Ecosystem info */}
        <Text
          position={[0, -4, 0]}
          fontSize={0.4}
          color="#ffffff"
          anchorX="center"
          anchorY="middle"
        >
          Biodiversity Index: {scientificData.biodiversityIndex}
        </Text>
      </Canvas>
      
      {/* Ecosystem metrics overlay */}
      <div className="absolute top-4 left-4 bg-black/80 p-4 rounded-lg text-white max-w-xs">
        <h3 className="text-lg font-bold text-green-400 mb-3">Ecosystem Metrics</h3>
        
        <div className="space-y-2 text-sm">
          <div className="flex justify-between">
            <span className="text-gray-300">Active Pollinators:</span>
            <span className="text-yellow-400">{scientificData.pollinatorCount}</span>
          </div>
          
          <div className="flex justify-between">
            <span className="text-gray-300">Carbon Sequestered:</span>
            <span className="text-green-400">{scientificData.carbonSequestration} kg/day</span>
          </div>
          
          <div className="flex justify-between">
            <span className="text-gray-300">Oxygen Produced:</span>
            <span className="text-blue-400">{scientificData.oxygenProduction} L/day</span>
          </div>
          
          <div className="flex justify-between">
            <span className="text-gray-300">Biodiversity:</span>
            <span className="text-purple-400">{(scientificData.biodiversityIndex * 100).toFixed(0)}%</span>
          </div>
        </div>
        
        <div className="mt-4 text-xs text-gray-400">
          Real-time simulation of pollination networks, nutrient cycling, and 
          carbon sequestration based on current environmental conditions.
        </div>
      </div>
      
      {/* Weather impact indicator */}
      <div className="absolute bottom-4 right-4 bg-black/80 p-3 rounded-lg text-white">
        <div className="text-sm">
          <div className="text-gray-300 mb-1">Weather Impact:</div>
          <div className="text-xs space-y-1">
            {scientificData.temperature < 15 && (
              <div className="text-blue-400">❄️ Cold slows pollinator activity</div>
            )}
            {scientificData.temperature > 30 && (
              <div className="text-red-400">🌡️ Heat stress on ecosystem</div>
            )}
            {scientificData.humidity < 40 && (
              <div className="text-orange-400">💧 Low humidity affects plants</div>
            )}
            {scientificData.humidity > 80 && (
              <div className="text-cyan-400">💧 High humidity favors fungi</div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}