import { useRef } from 'react';
import { useFrame } from '@react-three/fiber';
import { useElements } from '../../lib/stores/useElements';
import { useGarden } from '../../lib/stores/useGarden';
import * as THREE from 'three';

export function ElementalMagic() {
  const { selectedElement, magicPower, spellsKnown } = useElements();
  const { actionTreeData } = useGarden();
  const magicParticlesRef = useRef<THREE.Group>(null);

  // Animate magical effects
  useFrame((state) => {
    if (magicParticlesRef.current && selectedElement) {
      magicParticlesRef.current.rotation.y += 0.01;
      
      // Pulse effect based on magic power
      const scale = 1 + Math.sin(state.clock.elapsedTime * 2) * 0.1 * (magicPower / 100);
      magicParticlesRef.current.scale.setScalar(scale);
    }
  });

  if (!selectedElement) return null;

  const getMagicColor = () => {
    switch (selectedElement) {
      case 'fire': return '#ff4444';
      case 'water': return '#4444ff';
      case 'earth': return '#44ff44';
      case 'air': return '#ffff44';
      case 'shadow': return '#444444';
      case 'black': return '#000000';
      default: return '#ffffff';
    }
  };

  const renderMagicEffect = () => {
    const particles = [];
    const particleCount = Math.min(spellsKnown.length * 2 + 5, 20);

    for (let i = 0; i < particleCount; i++) {
      const angle = (i / particleCount) * Math.PI * 2;
      const radius = 2 + (magicPower / 100) * 3;
      const x = Math.cos(angle) * radius;
      const z = Math.sin(angle) * radius;
      const y = 1 + Math.sin(angle * 3) * 0.5;

      particles.push(
        <mesh key={`magic-particle-${i}`} position={[x, y, z]}>
          <sphereGeometry args={[0.1, 8, 8]} />
          <meshBasicMaterial 
            color={getMagicColor()}
            transparent
            opacity={0.7}
          />
        </mesh>
      );
    }

    return particles;
  };

  return (
    <group ref={magicParticlesRef} position={[0, 0, 0]}>
      {renderMagicEffect()}
      
      {/* Central magic core */}
      <mesh position={[0, 1.5, 0]}>
        <icosahedronGeometry args={[0.3]} />
        <meshBasicMaterial 
          color={getMagicColor()}
          transparent
          opacity={0.8}
        />
      </mesh>

      {/* Magic aura ring */}
      <mesh position={[0, 1.5, 0]} rotation={[Math.PI / 2, 0, 0]}>
        <ringGeometry args={[1, 1.2, 32]} />
        <meshBasicMaterial 
          color={getMagicColor()}
          transparent
          opacity={0.3}
          side={THREE.DoubleSide}
        />
      </mesh>
    </group>
  );
}
