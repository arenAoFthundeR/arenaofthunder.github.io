import React, { useState, useEffect } from 'react';
import { Canvas } from '@react-three/fiber';
import { Text, Box, Sphere } from '@react-three/drei';
import * as THREE from 'three';
import { REAL_PLANT_DATABASE, PlantScience, GeneticProfile } from '../../lib/gameLogic/scientificSystems';
import { useScientificData } from '../../lib/stores/useScientificData';

interface GeneticsLabProps {
  selectedPlant?: string;
  onGeneticModification?: (plantId: string, newTraits: GeneticProfile) => void;
}

// DNA Helix Visualization
function DNAHelix({ genetics }: { genetics: GeneticProfile }) {
  const meshRef = React.useRef<THREE.Group>(null);
  
  useEffect(() => {
    const timer = setInterval(() => {
      if (meshRef.current) {
        meshRef.current.rotation.y += 0.01;
      }
    }, 16);
    return () => clearInterval(timer);
  }, []);

  return (
    <group ref={meshRef} position={[0, 0, 0]}>
      {/* DNA Double Helix Structure */}
      {Array.from({ length: 20 }, (_, i) => {
        const y = (i - 10) * 0.3;
        const angle1 = (i * 0.5) % (Math.PI * 2);
        const angle2 = ((i * 0.5) + Math.PI) % (Math.PI * 2);
        
        return (
          <group key={i}>
            {/* Base pair spheres */}
            <Sphere
              position={[Math.cos(angle1) * 1.5, y, Math.sin(angle1) * 1.5]}
              args={[0.1]}
            >
              <meshStandardMaterial 
                color={genetics.dominantAlleles.length > i ? '#4ade80' : '#ef4444'} 
              />
            </Sphere>
            <Sphere
              position={[Math.cos(angle2) * 1.5, y, Math.sin(angle2) * 1.5]}
              args={[0.1]}
            >
              <meshStandardMaterial 
                color={genetics.recessiveAlleles.length > i ? '#3b82f6' : '#f59e0b'} 
              />
            </Sphere>
            
            {/* Connecting lines between base pairs */}
            <Box
              position={[0, y, 0]}
              args={[3, 0.02, 0.02]}
            >
              <meshStandardMaterial color="#6b7280" />
            </Box>
          </group>
        );
      })}
    </group>
  );
}

// Chromosome Viewer
function ChromosomeViewer({ genetics }: { genetics: GeneticProfile }) {
  return (
    <group>
      {genetics.dominantAlleles.map((allele, index) => (
        <group key={`dominant-${index}`} position={[index * 0.5 - 2, 2, 0]}>
          <Box args={[0.3, 1, 0.1]}>
            <meshStandardMaterial color="#4ade80" />
          </Box>
          <Text
            position={[0, -0.8, 0]}
            fontSize={0.2}
            color="#ffffff"
            anchorX="center"
            anchorY="middle"
          >
            {allele.split('_')[0].toUpperCase()}
          </Text>
        </group>
      ))}
      
      {genetics.recessiveAlleles.map((allele, index) => (
        <group key={`recessive-${index}`} position={[index * 0.5 - 2, -2, 0]}>
          <Box args={[0.3, 1, 0.1]}>
            <meshStandardMaterial color="#3b82f6" />
          </Box>
          <Text
            position={[0, -0.8, 0]}
            fontSize={0.2}
            color="#ffffff"
            anchorX="center"
            anchorY="middle"
          >
            {allele.split('_')[0].toLowerCase()}
          </Text>
        </group>
      ))}
    </group>
  );
}

// Genetic Analysis Panel
function GeneticAnalysisPanel({ plant }: { plant: PlantScience }) {
  const scientificData = useScientificData();
  
  const calculateMutationProbability = () => {
    // Environmental stress increases mutation rate
    const tempStress = Math.abs(scientificData.temperature - 22) / 22;
    const pHStress = Math.abs(scientificData.soilPH - 6.5) / 6.5;
    const environmentalStress = (tempStress + pHStress) / 2;
    
    return plant.geneticTraits.mutationRate * (1 + environmentalStress);
  };

  const calculateHybridSuccess = () => {
    // Better soil conditions improve hybrid viability
    const soilQuality = (scientificData.soilNitrogen / 20 + 
                        scientificData.soilPhosphorus / 15 + 
                        scientificData.soilPotassium / 150) / 3;
    
    return plant.geneticTraits.hybridViability * Math.min(1, soilQuality);
  };

  return (
    <div className="absolute top-4 left-4 bg-black/80 p-4 rounded-lg text-white max-w-xs">
      <h3 className="text-lg font-bold text-green-400 mb-3">Genetic Analysis</h3>
      
      <div className="space-y-2 text-sm">
        <div>
          <span className="text-gray-300">Species:</span>
          <span className="ml-2 font-mono text-green-400">{plant.species}</span>
        </div>
        
        <div>
          <span className="text-gray-300">Dominant Alleles:</span>
          <div className="ml-2 space-y-1">
            {plant.geneticTraits.dominantAlleles.map((allele, i) => (
              <div key={i} className="text-green-400 font-mono text-xs">
                {allele.replace(/_/g, ' ')}
              </div>
            ))}
          </div>
        </div>
        
        <div>
          <span className="text-gray-300">Recessive Alleles:</span>
          <div className="ml-2 space-y-1">
            {plant.geneticTraits.recessiveAlleles.map((allele, i) => (
              <div key={i} className="text-blue-400 font-mono text-xs">
                {allele.replace(/_/g, ' ')}
              </div>
            ))}
          </div>
        </div>
        
        <div className="border-t border-gray-600 pt-2 mt-3">
          <div className="flex justify-between">
            <span className="text-gray-300">Mutation Rate:</span>
            <span className="text-red-400">
              {(calculateMutationProbability() * 100).toFixed(2)}%
            </span>
          </div>
          
          <div className="flex justify-between">
            <span className="text-gray-300">Hybrid Viability:</span>
            <span className="text-yellow-400">
              {(calculateHybridSuccess() * 100).toFixed(1)}%
            </span>
          </div>
          
          <div className="flex justify-between">
            <span className="text-gray-300">Adaptability:</span>
            <span className="text-purple-400">
              {(plant.geneticTraits.adaptabilityScore * 100).toFixed(0)}%
            </span>
          </div>
        </div>
        
        <div className="border-t border-gray-600 pt-2 mt-3">
          <div className="text-xs text-gray-400">
            Environmental conditions affect genetic expression and mutation rates.
            Optimal growing conditions enhance hybrid success rates.
          </div>
        </div>
      </div>
    </div>
  );
}

export function PlantGeneticsSystem({ selectedPlant = 'tomato_lycopersicon' }: GeneticsLabProps) {
  const [viewMode, setViewMode] = useState<'dna' | 'chromosomes'>('dna');
  const plant = REAL_PLANT_DATABASE[selectedPlant];
  
  if (!plant) {
    return (
      <div className="w-full h-96 bg-gray-900 rounded-lg flex items-center justify-center">
        <div className="text-white text-center">
          <h3 className="text-xl font-bold mb-2">Plant Not Found</h3>
          <p className="text-gray-400">Select a valid plant species for genetic analysis</p>
        </div>
      </div>
    );
  }

  return (
    <div className="relative w-full h-96 bg-gray-900 rounded-lg overflow-hidden">
      <Canvas camera={{ position: [0, 0, 8], fov: 60 }}>
        <ambientLight intensity={0.3} />
        <pointLight position={[10, 10, 10]} intensity={0.8} />
        <pointLight position={[-10, -10, -10]} intensity={0.4} color="#4ade80" />
        
        {viewMode === 'dna' && <DNAHelix genetics={plant.geneticTraits} />}
        {viewMode === 'chromosomes' && <ChromosomeViewer genetics={plant.geneticTraits} />}
        
        <Text
          position={[0, -4, 0]}
          fontSize={0.5}
          color="#4ade80"
          anchorX="center"
          anchorY="middle"
        >
          {plant.species}
        </Text>
      </Canvas>
      
      <GeneticAnalysisPanel plant={plant} />
      
      <div className="absolute bottom-4 right-4 space-x-2">
        <button
          onClick={() => setViewMode('dna')}
          className={`px-3 py-1 rounded text-sm ${
            viewMode === 'dna' 
              ? 'bg-green-500 text-white' 
              : 'bg-gray-700 text-gray-300 hover:bg-gray-600'
          }`}
        >
          DNA Helix
        </button>
        <button
          onClick={() => setViewMode('chromosomes')}
          className={`px-3 py-1 rounded text-sm ${
            viewMode === 'chromosomes' 
              ? 'bg-green-500 text-white' 
              : 'bg-gray-700 text-gray-300 hover:bg-gray-600'
          }`}
        >
          Chromosomes
        </button>
      </div>
    </div>
  );
}