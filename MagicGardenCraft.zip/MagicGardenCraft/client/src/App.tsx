import { Canvas } from "@react-three/fiber";
import { Suspense, useEffect, useState } from "react";
import { KeyboardControls } from "@react-three/drei";
import { useAudio } from "./lib/stores/useAudio";
import { useGarden } from "./lib/stores/useGarden";
import { GameWorld } from "./components/game/GameWorld";
import { GameUI } from "./components/ui/GameUI";
import { ElementSelection } from "./components/ui/ElementSelection";
import "@fontsource/inter";
import "./index.css";

// Define control keys for the game
enum Controls {
  forward = 'forward',
  backward = 'backward',
  leftward = 'leftward',
  rightward = 'rightward',
  jump = 'jump',
  interact = 'interact',
  magic = 'magic',
  build = 'build',
  camera = 'camera'
}

const controls = [
  { name: Controls.forward, keys: ["KeyW", "ArrowUp"] },
  { name: Controls.backward, keys: ["KeyS", "ArrowDown"] },
  { name: Controls.leftward, keys: ["KeyA", "ArrowLeft"] },
  { name: Controls.rightward, keys: ["KeyD", "ArrowRight"] },
  { name: Controls.jump, keys: ["Space"] },
  { name: Controls.interact, keys: ["KeyE"] },
  { name: Controls.magic, keys: ["KeyQ"] },
  { name: Controls.build, keys: ["KeyB"] },
  { name: Controls.camera, keys: ["KeyC"] }
];

function App() {
  const { gamePhase, initializeGame } = useGarden();
  const [showCanvas, setShowCanvas] = useState(false);

  // Initialize audio system
  const { setBackgroundMusic, setHitSound, setSuccessSound } = useAudio();

  useEffect(() => {
    // Initialize audio
    const bgMusic = new Audio('/sounds/background.mp3');
    bgMusic.loop = true;
    bgMusic.volume = 0.3;
    setBackgroundMusic(bgMusic);

    const hit = new Audio('/sounds/hit.mp3');
    hit.volume = 0.5;
    setHitSound(hit);

    const success = new Audio('/sounds/success.mp3');
    success.volume = 0.6;
    setSuccessSound(success);

    // Initialize game
    initializeGame();
    setShowCanvas(true);
  }, [setBackgroundMusic, setHitSound, setSuccessSound, initializeGame]);

  if (!showCanvas) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-sky-400 to-green-400 flex items-center justify-center">
        <div className="text-white text-2xl font-bold animate-pulse">
          Loading GARDEN...
        </div>
      </div>
    );
  }

  return (
    <div style={{ width: '100vw', height: '100vh', position: 'relative', overflow: 'hidden' }}>
      <KeyboardControls map={controls}>
        {gamePhase === 'element_selection' && <ElementSelection />}
        
        {gamePhase === 'playing' && (
          <>
            <Canvas
              shadows
              camera={{
                position: [0, 2, 8],
                fov: 45,
                near: 0.1,
                far: 1000
              }}
              gl={{
                antialias: true,
                powerPreference: "default"
              }}
            >
              <color attach="background" args={["#87CEEB"]} />
              
              <Suspense fallback={null}>
                <GameWorld />
              </Suspense>
            </Canvas>
            <GameUI />
          </>
        )}
      </KeyboardControls>
    </div>
  );
}

export default App;
