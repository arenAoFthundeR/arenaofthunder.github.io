# Garden Magic Game - Replit Configuration

## Overview

This is a full-stack web application featuring a 3D magical garden game built with React Three Fiber on the frontend and Express.js on the backend. The game centers around elemental magic systems, XRP economy integration, and progressive skill development through action trees. Players select magical elements, build gardens, cast spells, and develop their abilities in an immersive 3D environment.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

The application follows a modern full-stack architecture with clear separation between client, server, and shared components, designed for seamless website hub integration:

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **3D Graphics**: React Three Fiber with Three.js for immersive 3D gameplay
- **UI Components**: Radix UI primitives with Tailwind CSS for consistent design
- **State Management**: Zustand stores for game state, audio, elements, achievements, and XRP economy
- **Build Tool**: Vite for fast development and optimized builds

### Backend Architecture
- **Runtime**: Node.js with Express.js framework
- **Database**: PostgreSQL with Drizzle ORM for type-safe database operations
- **Database Provider**: Neon Database (serverless PostgreSQL)
- **Development Storage**: In-memory storage class for rapid prototyping
- **Session Management**: Connect-pg-simple for PostgreSQL-backed sessions

### Shared Architecture
- **Schema Definition**: Centralized Drizzle schema with Zod validation
- **Type Safety**: Shared TypeScript types between client and server
- **Path Aliases**: Clean import paths with `@shared/*` aliasing

## Key Components

### Game Systems
1. **Elemental Magic System**: Six elemental affinities (fire, water, earth, air, shadow, black magic) with branching skill trees
2. **Garden Building**: 3D garden plots with elemental plants and growth mechanics
3. **Action Trees**: Progressive skill development across movement, magic, building, and interaction categories
4. **Weather System**: Dynamic weather affecting gameplay and magic effectiveness
5. **Audio System**: Comprehensive sound design with background music, voice acting, and sound effects

### User Interface
1. **3D Game World**: Immersive Three.js environment with player controls and magical effects
2. **Game HUD**: Real-time display of player stats, XRP balance, and weather conditions
3. **Element Selection**: Modal system for choosing magical affinities with rarity mechanics
4. **Achievement System**: Progress tracking and reward mechanisms
5. **XRP Economy**: Real-time market integration affecting in-game prices

### Database Schema
- **Users Table**: Core player data with username/password authentication
- **Extensible Design**: Ready for additional tables (gardens, achievements, transactions)

## Data Flow

1. **Client-Server Communication**: REST API endpoints prefixed with `/api`
2. **Real-time Updates**: Client-side state management with periodic server sync
3. **Game State Persistence**: User progress saved to PostgreSQL database
4. **Audio Management**: Client-side audio system with volume controls and dynamic music
5. **3D Rendering**: React Three Fiber handles WebGL rendering and game physics

## External Dependencies

### Frontend Dependencies
- **@react-three/***: 3D graphics and physics engine integration
- **@radix-ui/react-***: Accessible UI component primitives
- **@tanstack/react-query**: Server state management and caching
- **zustand**: Client-side state management
- **tailwindcss**: Utility-first CSS framework

### Backend Dependencies
- **@neondatabase/serverless**: PostgreSQL database connectivity
- **drizzle-orm**: Type-safe database operations
- **express**: Web application framework
- **connect-pg-simple**: PostgreSQL session storage

### Development Tools
- **tsx**: TypeScript execution for development
- **vite**: Build tool with HMR and optimizations
- **drizzle-kit**: Database migration and schema management

## Deployment Strategy

### Development Environment
- **Hot Module Replacement**: Vite dev server with Express API proxy
- **Database Migrations**: Drizzle Kit for schema updates (`npm run db:push`)
- **Development Server**: Single command startup with `npm run dev`

### Production Build & Hub Integration
- **Client Build**: Vite builds React app to `dist/public` with embedded iframe support
- **Server Build**: esbuild bundles Express server to `dist/index.js` with CORS configured for hub integration
- **Asset Optimization**: Support for 3D models, textures, and audio files with CDN-ready paths
- **Environment Variables**: `DATABASE_URL` required for production deployment
- **Integration APIs**: RESTful endpoints for external website communication
- **Embed Support**: Responsive iframe integration with postMessage communication

### Database Setup
- **Migration System**: Drizzle migrations stored in `./migrations`
- **Schema Validation**: Zod schemas ensure type safety across the stack
- **Connection Pooling**: Neon serverless handles connection management automatically

## Recent Changes

**January 23, 2025 - Website Hub Integration Preparation:**
- **Market Valuation Completed**: Professional market analysis showing $4.2M-$8.5M current value based on educational gaming trends and simulation market growth
- **Deployment Ready**: All systems optimized for website hub integration with comprehensive documentation
- **Integration Points**: Clear API endpoints, scientific dashboard modules, and pet system components ready for external website embedding

**January 23, 2025 - Advanced Scientific & Pet Systems Integration:**
- **Scientific Data Dashboard**: Implemented comprehensive real-time environmental monitoring with atmospheric conditions (CO₂, O₂, temperature, humidity, UV index)
- **Soil Science Analysis**: Added detailed soil composition tracking including pH, NPK nutrients, organic matter, and moisture levels with health status indicators
- **Plant Genetics Laboratory**: Created interactive DNA helix visualization showing genetic traits, allele expressions, and mutation rates affected by environmental conditions
- **Live Ecosystem Simulation**: Developed real-time 3D simulation with animated pollinators, flower interactions, decomposer colonies, and carbon cycle visualization
- **Plant Breeding System**: Full hybrid breeding laboratory with parent selection, compatibility calculations, genetic crossbreeding, and rarity-based offspring generation
- **Plant Pet System**: Complete pet companion system with plant pets that can be worn as magical hats, featuring levels, happiness, feeding, and special abilities
- **Wizard101-Style Camera**: Implemented authentic camera controls matching Wizard101's exact positioning, zoom functionality, and pet showcase modes with orbital viewing
- **Wearable Pet Hats**: Plant pets can be worn as animated hats on player's head with size scaling, magical effects, and rarity-based visual enhancements
- **Realistic Plant Database**: Integrated scientifically accurate plant species data (Solanum lycopersicum) with proper genetic profiles, growth stages, and nutritional requirements
- **Time-Based Ecosystem**: Added seasonal and daily cycles affecting all biological processes with authentic astronomical calculations
- **Biodiversity Metrics**: Implemented Shannon diversity index, carbon sequestration calculations, and oxygen production measurements

**January 22, 2025 - Major Game Enhancement Update:**
- **Enhanced Visual Effects**: Added comprehensive MagicalEffects component with floating particles and elemental auras around players
- **Interactive Environment**: Implemented EnvironmentalObjects with clickable magical trees, floating crystals, and ancient stone circles
- **Advanced UI Systems**: Added MiniMap for spatial navigation, comprehensive SkillTree system with upgradeable abilities, and enhanced GameUI panels
- **Spell Casting System**: Created SpellEffects component with element-specific visual bursts, particle systems, and Q-key casting mechanics
- **Integration with Special Systems**: All new features work seamlessly with Alexander's color switching, Lemonheads economy, XRP monitoring, and $nail AI protection
- **Player Action Triggers**: Every player movement, magic casting, jumping, and building action now triggers Alexander's 1% color switch chance and 25% Lemonheads drop chance

The application now combines magical fantasy elements with scientifically accurate botanical, genetic, and ecological systems, providing both entertainment and educational value through real-time scientific simulations.

The application is designed for easy deployment on platforms supporting Node.js with PostgreSQL database connectivity. The modular architecture allows for independent scaling of client and server components.