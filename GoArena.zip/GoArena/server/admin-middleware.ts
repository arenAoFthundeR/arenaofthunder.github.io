import type { Request, Response, NextFunction } from "express";

const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || "admin123";

declare global {
  namespace Express {
    interface Request {
      isAdmin?: boolean;
    }
  }
}

export function adminAuth(req: Request, res: Response, next: NextFunction) {
  const authHeader = req.headers.authorization;
  
  if (!authHeader || !authHeader.startsWith("Bearer ")) {
    return res.status(401).json({ error: "Unauthorized: Missing credentials" });
  }
  
  const token = authHeader.substring(7);
  
  if (token !== ADMIN_PASSWORD) {
    return res.status(403).json({ error: "Forbidden: Invalid credentials" });
  }
  
  req.isAdmin = true;
  next();
}

export function verifyAdminPassword(password: string): boolean {
  return password === ADMIN_PASSWORD;
}
