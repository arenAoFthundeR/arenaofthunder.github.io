/**
 * Database Storage Implementation - PostgreSQL Backend
 * 
 * This implements the full IStorage interface using PostgreSQL instead of JSON files.
 * Eventually this will replace FileStorage for production use.
 */

import { eq, desc, sql, and, isNull } from "drizzle-orm";
import { db } from "./db.js";
import {
  wallets,
  lore,
  marbles,
  dungeonRuns,
  securityEvents,
  personas,
  tournamentParticipants,
  tournamentRounds,
  j3Credits,
  j3UsageLogs,
  j3Memories,
  j3Conversations,
  j3Messages,
  userActivities,
  type DBWallet,
  type InsertDBWallet,
} from "@shared/schema";
import type {
  WalletMemory,
  LorePiece,
  TournamentData,
  XpData,
  LeaderboardEntry,
  Marble,
  CreateMarble,
  DungeonRun,
  CreateDungeonRun,
  SecurityEvent,
  CreateSecurityEvent,
  Persona,
  CreatePersona,
  J3CreditBalance,
  CreateJ3UsageLog,
  J3UsageLog,
  J3CreditTier,
  J3Memory,
  InsertJ3Memory,
  J3Conversation,
  InsertJ3Conversation,
  J3Message,
  InsertJ3Message,
  UserActivity,
  CreateUserActivity,
} from "@shared/schema";
import type {
  GyroscopeConfig,
  GestureTrigger,
  InsertGestureTrigger,
  UpdateGestureTrigger,
} from "@shared/gyro-schema";
import { IStorage } from "./storage.js";
import { readFileSync, writeFileSync, existsSync } from "fs";
import { join, dirname } from "path";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);
const dataDir = join(__dirname, "data");
const gyroConfigPath = join(dataDir, "gyro-config.json");

export class DatabaseStorage implements IStorage {
  // ============================================================================
  // HELPER METHODS
  // ============================================================================

  private calculateXp(wallet: DBWallet): number {
    const mints = wallet.mintCount || 0;
    const giftsSent = wallet.giftsSent || 0;
    const giftsReceived = wallet.giftsReceived || 0;
    const adminAdjustment = wallet.adminXpAdjustment || 0;
    return mints * 10 + giftsSent * 5 + giftsReceived * 5 + adminAdjustment;
  }

  private getBadges(xp: number): string[] {
    if (xp >= 1000) return ["Storm Titan", "Arena Master"];
    if (xp >= 500) return ["Thunder Adept"];
    if (xp >= 100) return ["Marble Initiate"];
    return [];
  }

  private dbWalletToMemory(dbWallet: DBWallet): WalletMemory {
    return {
      wallet: dbWallet.wallet,
      mintCount: dbWallet.mintCount,
      giftsSent: dbWallet.giftsSent,
      giftsReceived: dbWallet.giftsReceived,
      adminXpAdjustment: dbWallet.adminXpAdjustment,
      seenLoreIds: (dbWallet.seenLoreIds as number[]) || [],
      firstSeen: dbWallet.firstSeen.toISOString(),
      lastSeen: dbWallet.lastSeen.toISOString(),
    };
  }

  // ============================================================================
  // WALLET MEMORY
  // ============================================================================

  async getWalletMemory(wallet: string): Promise<WalletMemory | null> {
    const key = wallet.toLowerCase();
    const [dbWallet] = await db.select().from(wallets).where(eq(wallets.wallet, key));
    
    if (!dbWallet) return null;
    return this.dbWalletToMemory(dbWallet);
  }

  async updateWalletMemory(wallet: string, changes: Partial<WalletMemory>): Promise<WalletMemory> {
    const key = wallet.toLowerCase();
    const now = new Date();

    const [existing] = await db.select().from(wallets).where(eq(wallets.wallet, key));

    if (existing) {
      const updates: Partial<InsertDBWallet> = {
        lastSeen: now,
      };

      if (changes.mintCount !== undefined) updates.mintCount = changes.mintCount;
      if (changes.giftsSent !== undefined) updates.giftsSent = changes.giftsSent;
      if (changes.giftsReceived !== undefined) updates.giftsReceived = changes.giftsReceived;
      if (changes.adminXpAdjustment !== undefined) updates.adminXpAdjustment = changes.adminXpAdjustment;
      if (changes.seenLoreIds !== undefined) updates.seenLoreIds = Array.from(new Set(changes.seenLoreIds));

      const [updated] = await db
        .update(wallets)
        .set(updates)
        .where(eq(wallets.wallet, key))
        .returning();

      return this.dbWalletToMemory(updated);
    } else {
      const [created] = await db
        .insert(wallets)
        .values({
          wallet: key,
          mintCount: changes.mintCount || 0,
          giftsSent: changes.giftsSent || 0,
          giftsReceived: changes.giftsReceived || 0,
          adminXpAdjustment: changes.adminXpAdjustment || 0,
          seenLoreIds: changes.seenLoreIds || [],
          firstSeen: now,
          lastSeen: now,
        })
        .returning();

      return this.dbWalletToMemory(created);
    }
  }

  // ============================================================================
  // XP SYSTEM
  // ============================================================================

  async getXpData(wallet: string): Promise<XpData> {
    const key = wallet.toLowerCase();
    const [dbWallet] = await db.select().from(wallets).where(eq(wallets.wallet, key));
    
    const xp = dbWallet ? this.calculateXp(dbWallet) : 0;
    const level = Math.floor(xp / 100) + 1;

    return {
      wallet,
      xp,
      level,
      badges: this.getBadges(xp),
    };
  }

  private async dbWalletFromMemory(memory: WalletMemory): Promise<DBWallet> {
    const key = memory.wallet.toLowerCase();
    const [dbWallet] = await db.select().from(wallets).where(eq(wallets.wallet, key));
    if (!dbWallet) {
      throw new Error(`Wallet ${key} not found in database`);
    }
    return dbWallet;
  }

  async getLeaderboard(limit = 50): Promise<LeaderboardEntry[]> {
    const allWallets = await db.select().from(wallets);

    const entries = allWallets.map((dbWallet) => {
      const xp = this.calculateXp(dbWallet);
      return {
        wallet: dbWallet.wallet,
        xp,
        level: Math.floor(xp / 100) + 1,
        mints: dbWallet.mintCount,
        giftsSent: dbWallet.giftsSent,
        giftsReceived: dbWallet.giftsReceived,
        lastSeen: dbWallet.lastSeen.toISOString(),
      };
    });

    return entries.sort((a, b) => b.xp - a.xp).slice(0, limit);
  }

  // ============================================================================
  // LORE
  // ============================================================================

  async getLoreForWallet(wallet: string): Promise<LorePiece[]> {
    const allLore = await db.select().from(lore).orderBy(lore.id);
    const memory = await this.getWalletMemory(wallet);
    const seenIds = new Set(memory?.seenLoreIds || []);

    return allLore.map((lorePiece) => ({
      id: lorePiece.id,
      title: lorePiece.title,
      text: lorePiece.text,
      unlocked: seenIds.has(lorePiece.id),
    }));
  }

  async unlockLore(wallet: string, loreId: number): Promise<void> {
    const memory = await this.getWalletMemory(wallet);
    const seenIds = new Set(memory?.seenLoreIds || []);
    seenIds.add(loreId);

    await this.updateWalletMemory(wallet, {
      seenLoreIds: Array.from(seenIds),
    });
  }

  async getAllLore(): Promise<LorePiece[]> {
    const allLore = await db.select().from(lore).orderBy(lore.id);
    return allLore.map((l) => ({
      id: l.id,
      title: l.title,
      text: l.text,
    }));
  }

  async createLore(loreData: Omit<LorePiece, "id">): Promise<LorePiece> {
    const [created] = await db
      .insert(lore)
      .values({
        title: loreData.title,
        text: loreData.text,
      })
      .returning();

    return {
      id: created.id,
      title: created.title,
      text: created.text,
    };
  }

  async updateLore(id: number, updates: Partial<LorePiece>): Promise<void> {
    await db
      .update(lore)
      .set({
        title: updates.title,
        text: updates.text,
      })
      .where(eq(lore.id, id));
  }

  async deleteLore(id: number): Promise<void> {
    await db.delete(lore).where(eq(lore.id, id));
  }

  // ============================================================================
  // TOURNAMENT
  // ============================================================================

  async getTournamentData(): Promise<TournamentData> {
    const participants = await db.select().from(tournamentParticipants);
    const rounds = await db.select().from(tournamentRounds).orderBy(tournamentRounds.completedAt);

    return {
      participants: participants.map((p) => p.wallet),
      rounds: rounds.map((r) => ({
        wallet: r.wallet,
        round: r.round,
        time: r.time,
      })),
    };
  }

  async joinTournament(wallet: string): Promise<void> {
    await db
      .insert(tournamentParticipants)
      .values({ wallet })
      .onConflictDoNothing();
  }

  async advanceTournament(wallet: string): Promise<number> {
    const playerRounds = await db
      .select()
      .from(tournamentRounds)
      .where(eq(tournamentRounds.wallet, wallet));

    const nextRound = playerRounds.length + 1;

    // TODO: Frontend should pass actual elapsed time for the round
    // For now, store 0 as elapsed time since we don't have that data
    // The 'time' field stores elapsed milliseconds, NOT wall-clock timestamp
    await db.insert(tournamentRounds).values({
      wallet,
      round: nextRound,
      time: 0, // Elapsed time in milliseconds (currently unknown)
      completedAt: new Date(), // Wall-clock completion timestamp
    });

    return nextRound;
  }

  async resetTournament(): Promise<void> {
    await db.delete(tournamentRounds);
    await db.delete(tournamentParticipants);
  }

  // ============================================================================
  // MARBLES
  // ============================================================================

  async getMarblesByWallet(walletAddress: string): Promise<Marble[]> {
    const dbMarbles = await db.select().from(marbles).where(eq(marbles.wallet, walletAddress));

    return dbMarbles.map((m) => ({
      id: m.id,
      wallet: m.wallet,
      name: m.name,
      description: m.description,
      rarity: m.rarity as any,
      attack: m.attack,
      defense: m.defense,
      speed: m.speed,
      health: m.health,
      isMinted: m.isMinted,
      tokenId: m.tokenId || undefined,
      txHash: m.txHash || undefined,
      mintedAt: m.mintedAt?.toISOString(),
      createdAt: m.createdAt.toISOString(),
    }));
  }

  async getMarbleById(id: number): Promise<Marble | null> {
    const [marble] = await db.select().from(marbles).where(eq(marbles.id, id));
    if (!marble) return null;

    return {
      id: marble.id,
      wallet: marble.wallet,
      name: marble.name,
      description: marble.description,
      rarity: marble.rarity as any,
      attack: marble.attack,
      defense: marble.defense,
      speed: marble.speed,
      health: marble.health,
      isMinted: marble.isMinted,
      tokenId: marble.tokenId || undefined,
      txHash: marble.txHash || undefined,
      mintedAt: marble.mintedAt?.toISOString(),
      createdAt: marble.createdAt.toISOString(),
    };
  }

  async createMarble(marble: CreateMarble): Promise<Marble> {
    const [created] = await db
      .insert(marbles)
      .values({
        wallet: marble.wallet,
        name: marble.name,
        description: marble.description,
        rarity: marble.rarity,
        attack: marble.attack,
        defense: marble.defense,
        speed: marble.speed,
        health: marble.health,
      })
      .returning();

    return {
      id: created.id,
      wallet: created.wallet,
      name: created.name,
      description: created.description,
      rarity: created.rarity as any,
      attack: created.attack,
      defense: created.defense,
      speed: created.speed,
      health: created.health,
      isMinted: created.isMinted,
      tokenId: created.tokenId || undefined,
      txHash: created.txHash || undefined,
      mintedAt: created.mintedAt?.toISOString(),
      createdAt: created.createdAt.toISOString(),
    };
  }

  async updateMarble(id: number, updates: Partial<Marble>): Promise<void> {
    const updateData: any = {};
    if (updates.isMinted !== undefined) updateData.isMinted = updates.isMinted;
    if (updates.tokenId !== undefined) updateData.tokenId = updates.tokenId;
    if (updates.txHash !== undefined) updateData.txHash = updates.txHash;
    if (updates.mintedAt !== undefined) {
      updateData.mintedAt = typeof updates.mintedAt === 'string' ? new Date(updates.mintedAt) : updates.mintedAt;
    }

    await db.update(marbles).set(updateData).where(eq(marbles.id, id));
  }

  // ============================================================================
  // DUNGEONS
  // ============================================================================

  async getActiveDungeonRun(walletAddress: string): Promise<DungeonRun | null> {
    const [run] = await db
      .select()
      .from(dungeonRuns)
      .where(
        and(
          eq(dungeonRuns.wallet, walletAddress),
          eq(dungeonRuns.isActive, true)
        )
      )
      .orderBy(desc(dungeonRuns.createdAt))
      .limit(1);

    if (!run) return null;

    return {
      id: run.id,
      wallet: run.wallet,
      marbleId: run.marbleId,
      currentFloor: run.currentFloor,
      maxFloorReached: run.maxFloorReached,
      status: run.status as any,
      isActive: run.isActive,
      experienceGained: run.experienceGained,
      currentEnemy: run.currentEnemy || undefined,
      marbleCurrentHealth: run.marbleCurrentHealth,
      createdAt: run.createdAt.toISOString(),
      completedAt: run.completedAt?.toISOString(),
    };
  }

  async getDungeonRunById(id: number): Promise<DungeonRun | null> {
    const [run] = await db.select().from(dungeonRuns).where(eq(dungeonRuns.id, id));
    if (!run) return null;

    return {
      id: run.id,
      wallet: run.wallet,
      marbleId: run.marbleId,
      currentFloor: run.currentFloor,
      maxFloorReached: run.maxFloorReached,
      status: run.status as any,
      isActive: run.isActive,
      experienceGained: run.experienceGained,
      currentEnemy: run.currentEnemy || undefined,
      marbleCurrentHealth: run.marbleCurrentHealth,
      createdAt: run.createdAt.toISOString(),
      completedAt: run.completedAt?.toISOString(),
    };
  }

  async createDungeonRun(data: CreateDungeonRun): Promise<DungeonRun> {
    const marble = await this.getMarbleById(data.marbleId);
    if (!marble) throw new Error(`Marble ${data.marbleId} not found`);

    const [created] = await db
      .insert(dungeonRuns)
      .values({
        wallet: data.wallet,
        marbleId: data.marbleId,
        currentFloor: 1,
        maxFloorReached: 1,
        status: "active",
        isActive: true,
        experienceGained: 0,
        marbleCurrentHealth: marble.health,
      })
      .returning();

    return {
      id: created.id,
      wallet: created.wallet,
      marbleId: created.marbleId,
      currentFloor: created.currentFloor,
      maxFloorReached: created.maxFloorReached,
      status: created.status as any,
      isActive: created.isActive,
      experienceGained: created.experienceGained,
      currentEnemy: created.currentEnemy || undefined,
      marbleCurrentHealth: created.marbleCurrentHealth,
      createdAt: created.createdAt.toISOString(),
      completedAt: created.completedAt?.toISOString(),
    };
  }

  async updateDungeonRun(id: number, updates: Partial<DungeonRun>): Promise<void> {
    const updateData: any = {};
    if (updates.currentFloor !== undefined) updateData.currentFloor = updates.currentFloor;
    if (updates.maxFloorReached !== undefined) updateData.maxFloorReached = updates.maxFloorReached;
    if (updates.status !== undefined) updateData.status = updates.status;
    if (updates.isActive !== undefined) updateData.isActive = updates.isActive;
    if (updates.experienceGained !== undefined) updateData.experienceGained = updates.experienceGained;
    if (updates.currentEnemy !== undefined) updateData.currentEnemy = updates.currentEnemy;
    if (updates.marbleCurrentHealth !== undefined) updateData.marbleCurrentHealth = updates.marbleCurrentHealth;
    if (updates.completedAt !== undefined) {
      updateData.completedAt = typeof updates.completedAt === 'string' ? new Date(updates.completedAt) : updates.completedAt;
    }

    await db.update(dungeonRuns).set(updateData).where(eq(dungeonRuns.id, id));
  }

  async getDungeonHistory(walletAddress: string): Promise<DungeonRun[]> {
    const runs = await db
      .select()
      .from(dungeonRuns)
      .where(eq(dungeonRuns.wallet, walletAddress))
      .orderBy(desc(dungeonRuns.createdAt));

    return runs.map((run) => ({
      id: run.id,
      wallet: run.wallet,
      marbleId: run.marbleId,
      currentFloor: run.currentFloor,
      maxFloorReached: run.maxFloorReached,
      status: run.status as any,
      isActive: run.isActive,
      experienceGained: run.experienceGained,
      currentEnemy: run.currentEnemy || undefined,
      marbleCurrentHealth: run.marbleCurrentHealth,
      createdAt: run.createdAt.toISOString(),
      completedAt: run.completedAt?.toISOString(),
    }));
  }

  // ============================================================================
  // SECURITY EVENTS
  // ============================================================================

  async getSecurityEvents(walletAddress: string): Promise<SecurityEvent[]> {
    const events = await db
      .select()
      .from(securityEvents)
      .where(eq(securityEvents.wallet, walletAddress))
      .orderBy(desc(securityEvents.createdAt));

    return events.map((e) => ({
      id: e.id,
      wallet: e.wallet,
      eventType: e.eventType as any,
      severity: e.severity as any,
      message: e.message,
      details: e.details as Record<string, unknown>,
      createdAt: e.createdAt.toISOString(),
    }));
  }

  async createSecurityEvent(event: CreateSecurityEvent): Promise<SecurityEvent> {
    const [created] = await db
      .insert(securityEvents)
      .values({
        wallet: event.wallet,
        eventType: event.eventType,
        severity: event.severity,
        message: event.message,
        details: event.details || {},
      })
      .returning();

    return {
      id: created.id,
      wallet: created.wallet,
      eventType: created.eventType as any,
      severity: created.severity as any,
      message: created.message,
      details: created.details as Record<string, unknown>,
      createdAt: created.createdAt.toISOString(),
    };
  }

  async clearSecurityEvents(walletAddress: string): Promise<void> {
    await db.delete(securityEvents).where(eq(securityEvents.wallet, walletAddress));
  }

  // ============================================================================
  // ADMIN OPERATIONS
  // ============================================================================

  async getAllWallets(): Promise<WalletMemory[]> {
    const allWallets = await db.select().from(wallets);
    return allWallets.map((w) => this.dbWalletToMemory(w));
  }

  async adminUpdateWalletXp(walletAddress: string, xpAdjustment: number): Promise<WalletMemory> {
    return await this.updateWalletMemory(walletAddress, { adminXpAdjustment: xpAdjustment });
  }

  // ============================================================================
  // GYROSCOPE (Still using JSON for now)
  // ============================================================================

  private readGyroConfig(): GyroscopeConfig {
    try {
      if (!existsSync(gyroConfigPath)) {
        const defaultConfig: GyroscopeConfig = {
          enabled: false,
          triggers: [],
          debugMode: false,
          requirePermission: true,
        };
        writeFileSync(gyroConfigPath, JSON.stringify(defaultConfig, null, 2), "utf8");
        return defaultConfig;
      }
      return JSON.parse(readFileSync(gyroConfigPath, "utf8"));
    } catch {
      return { enabled: false, triggers: [], debugMode: false, requirePermission: true };
    }
  }

  private writeGyroConfig(config: GyroscopeConfig): void {
    writeFileSync(gyroConfigPath, JSON.stringify(config, null, 2), "utf8");
  }

  async getGyroscopeConfig(): Promise<GyroscopeConfig> {
    return this.readGyroConfig();
  }

  async updateGyroscopeConfig(config: Partial<GyroscopeConfig>): Promise<GyroscopeConfig> {
    const current = this.readGyroConfig();
    const updated = { ...current, ...config };
    this.writeGyroConfig(updated);
    return updated;
  }

  async createGestureTrigger(trigger: InsertGestureTrigger): Promise<GestureTrigger> {
    const config = this.readGyroConfig();
    const newTrigger: GestureTrigger = {
      id: crypto.randomUUID(),
      ...trigger,
    };
    config.triggers.push(newTrigger);
    this.writeGyroConfig(config);
    return newTrigger;
  }

  async updateGestureTrigger(id: string, updates: UpdateGestureTrigger): Promise<GestureTrigger> {
    const config = this.readGyroConfig();
    const index = config.triggers.findIndex((t) => t.id === id);
    if (index === -1) throw new Error(`Trigger ${id} not found`);
    
    config.triggers[index] = {
      ...config.triggers[index],
      ...updates,
    };
    this.writeGyroConfig(config);
    return config.triggers[index];
  }

  async deleteGestureTrigger(id: string): Promise<void> {
    const config = this.readGyroConfig();
    config.triggers = config.triggers.filter((t) => t.id !== id);
    this.writeGyroConfig(config);
  }

  async getGestureTriggers(): Promise<GestureTrigger[]> {
    const config = this.readGyroConfig();
    return config.triggers;
  }

  // ============================================================================
  // NFT PERSONA SYSTEM
  // ============================================================================

  async createPersona(data: CreatePersona): Promise<Persona> {
    const [created] = await db
      .insert(personas)
      .values({
        id: crypto.randomUUID(),
        ownerWallet: data.ownerWallet,
        nftTokenId: data.nftTokenId,
        nftContract: data.nftContract,
        aiStylePreset: data.aiStylePreset || "chaotic_neutral",
        customPersonality: data.customPersonality,
        memory: { shortTerm: [], longTerm: [] },
      })
      .returning();

    return {
      id: created.id,
      createdAt: created.createdAt.toISOString(),
      lastActive: created.lastActive.toISOString(),
      ownerWallet: created.ownerWallet || undefined,
      nftTokenId: created.nftTokenId || undefined,
      nftContract: created.nftContract || undefined,
      aiStylePreset: created.aiStylePreset as any,
      customPersonality: created.customPersonality || undefined,
      memory: created.memory as any,
      assets: created.assets as any,
      metadata: created.metadata as Record<string, unknown>,
      totalConversations: created.totalConversations,
      totalMessages: created.totalMessages,
    };
  }

  async getPersona(id: string): Promise<Persona | null> {
    const [persona] = await db.select().from(personas).where(eq(personas.id, id));
    if (!persona) return null;

    return {
      id: persona.id,
      createdAt: persona.createdAt.toISOString(),
      lastActive: persona.lastActive.toISOString(),
      ownerWallet: persona.ownerWallet || undefined,
      nftTokenId: persona.nftTokenId || undefined,
      nftContract: persona.nftContract || undefined,
      aiStylePreset: persona.aiStylePreset as any,
      customPersonality: persona.customPersonality || undefined,
      memory: persona.memory as any,
      assets: persona.assets as any,
      metadata: persona.metadata as Record<string, unknown>,
      totalConversations: persona.totalConversations,
      totalMessages: persona.totalMessages,
    };
  }

  async getAllPersonas(): Promise<Persona[]> {
    const allPersonas = await db.select().from(personas);
    return allPersonas.map((p) => ({
      id: p.id,
      createdAt: p.createdAt.toISOString(),
      lastActive: p.lastActive.toISOString(),
      ownerWallet: p.ownerWallet || undefined,
      nftTokenId: p.nftTokenId || undefined,
      nftContract: p.nftContract || undefined,
      aiStylePreset: p.aiStylePreset as any,
      customPersonality: p.customPersonality || undefined,
      memory: p.memory as any,
      assets: p.assets as any,
      metadata: p.metadata as Record<string, unknown>,
      totalConversations: p.totalConversations,
      totalMessages: p.totalMessages,
    }));
  }

  async updatePersona(id: string, updates: Partial<Persona>): Promise<Persona> {
    const updateData: any = {
      lastActive: new Date(),
    };

    if (updates.aiStylePreset) updateData.aiStylePreset = updates.aiStylePreset;
    if (updates.customPersonality !== undefined) updateData.customPersonality = updates.customPersonality;
    if (updates.memory) updateData.memory = updates.memory;
    if (updates.assets) updateData.assets = updates.assets;
    if (updates.metadata) updateData.metadata = updates.metadata;
    if (updates.totalConversations !== undefined) updateData.totalConversations = updates.totalConversations;
    if (updates.totalMessages !== undefined) updateData.totalMessages = updates.totalMessages;

    const [updated] = await db
      .update(personas)
      .set(updateData)
      .where(eq(personas.id, id))
      .returning();

    return {
      id: updated.id,
      createdAt: updated.createdAt.toISOString(),
      lastActive: updated.lastActive.toISOString(),
      ownerWallet: updated.ownerWallet || undefined,
      nftTokenId: updated.nftTokenId || undefined,
      nftContract: updated.nftContract || undefined,
      aiStylePreset: updated.aiStylePreset as any,
      customPersonality: updated.customPersonality || undefined,
      memory: updated.memory as any,
      assets: updated.assets as any,
      metadata: updated.metadata as Record<string, unknown>,
      totalConversations: updated.totalConversations,
      totalMessages: updated.totalMessages,
    };
  }

  async deletePersona(id: string): Promise<void> {
    await db.delete(personas).where(eq(personas.id, id));
  }

  async getPersonasByWallet(walletAddress: string): Promise<Persona[]> {
    const walletPersonas = await db
      .select()
      .from(personas)
      .where(eq(personas.ownerWallet, walletAddress));

    return walletPersonas.map((p) => ({
      id: p.id,
      createdAt: p.createdAt.toISOString(),
      lastActive: p.lastActive.toISOString(),
      ownerWallet: p.ownerWallet || undefined,
      nftTokenId: p.nftTokenId || undefined,
      nftContract: p.nftContract || undefined,
      aiStylePreset: p.aiStylePreset as any,
      customPersonality: p.customPersonality || undefined,
      memory: p.memory as any,
      assets: p.assets as any,
      metadata: p.metadata as Record<string, unknown>,
      totalConversations: p.totalConversations,
      totalMessages: p.totalMessages,
    }));
  }

  // ============================================================================
  // J3SSICA3 CREDIT SYSTEM
  // ============================================================================

  private calculateJ3Tier(totalEarned: number): J3CreditTier {
    if (totalEarned >= 5000) return "Legend";
    if (totalEarned >= 1000) return "Master";
    if (totalEarned >= 500) return "Adept";
    if (totalEarned >= 100) return "Apprentice";
    return "Novice";
  }

  async getJ3Credits(walletAddress: string): Promise<J3CreditBalance> {
    const [credits] = await db.select().from(j3Credits).where(eq(j3Credits.wallet, walletAddress));

    if (!credits) {
      const newCredits = await db
        .insert(j3Credits)
        .values({
          wallet: walletAddress,
          balance: 100,
          tier: "Apprentice",
          totalEarned: 100,
        })
        .returning();

      return {
        wallet: newCredits[0].wallet,
        balance: newCredits[0].balance,
        tier: newCredits[0].tier as J3CreditTier,
        lastRegenerated: newCredits[0].lastRegenerated.toISOString(),
        totalEarned: newCredits[0].totalEarned,
        totalSpent: newCredits[0].totalSpent,
        gracePeriodMessages: newCredits[0].gracePeriodMessages,
        firstSeen: newCredits[0].firstSeen.toISOString(),
        lastUpdated: newCredits[0].lastUpdated.toISOString(),
      };
    }

    return {
      wallet: credits.wallet,
      balance: credits.balance,
      tier: credits.tier as J3CreditTier,
      lastRegenerated: credits.lastRegenerated.toISOString(),
      totalEarned: credits.totalEarned,
      totalSpent: credits.totalSpent,
      gracePeriodMessages: credits.gracePeriodMessages,
      firstSeen: credits.firstSeen.toISOString(),
      lastUpdated: credits.lastUpdated.toISOString(),
    };
  }

  async updateJ3Credits(
    walletAddress: string,
    creditsChange: number,
    action: CreateJ3UsageLog["action"],
    metadata?: Record<string, unknown>
  ): Promise<J3CreditBalance> {
    const current = await this.getJ3Credits(walletAddress);

    const newBalance = current.balance + creditsChange;
    const newTotalEarned = creditsChange > 0 ? current.totalEarned + creditsChange : current.totalEarned;
    const newTotalSpent = creditsChange < 0 ? current.totalSpent + Math.abs(creditsChange) : current.totalSpent;
    const newTier = this.calculateJ3Tier(newTotalEarned);

    const [updated] = await db
      .update(j3Credits)
      .set({
        balance: newBalance,
        totalEarned: newTotalEarned,
        totalSpent: newTotalSpent,
        tier: newTier,
        lastUpdated: new Date(),
      })
      .where(eq(j3Credits.wallet, walletAddress))
      .returning();

    await this.logJ3Usage({
      wallet: walletAddress,
      action,
      creditsChange,
      balanceAfter: newBalance,
      metadata: metadata || {},
    });

    return {
      wallet: updated.wallet,
      balance: updated.balance,
      tier: updated.tier as J3CreditTier,
      lastRegenerated: updated.lastRegenerated.toISOString(),
      totalEarned: updated.totalEarned,
      totalSpent: updated.totalSpent,
      gracePeriodMessages: updated.gracePeriodMessages,
      firstSeen: updated.firstSeen.toISOString(),
      lastUpdated: updated.lastUpdated.toISOString(),
    };
  }

  async deductJ3Credits(walletAddress: string, amount: number): Promise<J3CreditBalance> {
    const current = await this.getJ3Credits(walletAddress);

    if (current.gracePeriodMessages > 0) {
      const [updated] = await db
        .update(j3Credits)
        .set({
          gracePeriodMessages: current.gracePeriodMessages - 1,
          lastUpdated: new Date(),
        })
        .where(eq(j3Credits.wallet, walletAddress))
        .returning();

      await this.logJ3Usage({
        wallet: walletAddress,
        action: "grace_period",
        creditsChange: 0,
        balanceAfter: current.balance,
        metadata: { gracePeriodMessagesRemaining: updated.gracePeriodMessages },
      });

      return {
        wallet: updated.wallet,
        balance: updated.balance,
        tier: updated.tier as J3CreditTier,
        lastRegenerated: updated.lastRegenerated.toISOString(),
        totalEarned: updated.totalEarned,
        totalSpent: updated.totalSpent,
        gracePeriodMessages: updated.gracePeriodMessages,
        firstSeen: updated.firstSeen.toISOString(),
        lastUpdated: updated.lastUpdated.toISOString(),
      };
    }

    if (current.balance < amount) {
      throw new Error("Insufficient J3 credits");
    }

    return await this.updateJ3Credits(walletAddress, -amount, "chat_message");
  }

  async regenerateDailyCredits(walletAddress: string): Promise<J3CreditBalance | null> {
    const current = await this.getJ3Credits(walletAddress);
    const now = new Date();
    const lastRegen = new Date(current.lastRegenerated);
    const hoursSinceRegen = (now.getTime() - lastRegen.getTime()) / (1000 * 60 * 60);

    if (hoursSinceRegen < 24) {
      return null;
    }

    const [updated] = await db
      .update(j3Credits)
      .set({
        balance: current.balance + 10,
        totalEarned: current.totalEarned + 10,
        lastRegenerated: now,
        lastUpdated: now,
      })
      .where(eq(j3Credits.wallet, walletAddress))
      .returning();

    await this.logJ3Usage({
      wallet: walletAddress,
      action: "daily_regen",
      creditsChange: 10,
      balanceAfter: updated.balance,
      metadata: {},
    });

    return {
      wallet: updated.wallet,
      balance: updated.balance,
      tier: updated.tier as J3CreditTier,
      lastRegenerated: updated.lastRegenerated.toISOString(),
      totalEarned: updated.totalEarned,
      totalSpent: updated.totalSpent,
      gracePeriodMessages: updated.gracePeriodMessages,
      firstSeen: updated.firstSeen.toISOString(),
      lastUpdated: updated.lastUpdated.toISOString(),
    };
  }

  async logJ3Usage(log: CreateJ3UsageLog): Promise<J3UsageLog> {
    const [created] = await db
      .insert(j3UsageLogs)
      .values({
        wallet: log.wallet,
        action: log.action,
        creditsChange: log.creditsChange,
        balanceAfter: log.balanceAfter,
        metadata: log.metadata || {},
      })
      .returning();

    return {
      id: created.id,
      wallet: created.wallet,
      action: created.action as any,
      creditsChange: created.creditsChange,
      balanceAfter: created.balanceAfter,
      timestamp: created.timestamp.toISOString(),
      metadata: created.metadata as Record<string, unknown>,
    };
  }

  async getJ3UsageHistory(walletAddress: string, limit = 50): Promise<J3UsageLog[]> {
    const logs = await db
      .select()
      .from(j3UsageLogs)
      .where(eq(j3UsageLogs.wallet, walletAddress))
      .orderBy(desc(j3UsageLogs.timestamp))
      .limit(limit);

    return logs.map((log) => ({
      id: log.id,
      wallet: log.wallet,
      action: log.action as any,
      creditsChange: log.creditsChange,
      balanceAfter: log.balanceAfter,
      timestamp: log.timestamp.toISOString(),
      metadata: log.metadata as Record<string, unknown>,
    }));
  }

  async getAllJ3Credits(): Promise<J3CreditBalance[]> {
    const allCredits = await db.select().from(j3Credits);
    return allCredits.map((c) => ({
      wallet: c.wallet,
      balance: c.balance,
      tier: c.tier as J3CreditTier,
      lastRegenerated: c.lastRegenerated.toISOString(),
      totalEarned: c.totalEarned,
      totalSpent: c.totalSpent,
      gracePeriodMessages: c.gracePeriodMessages,
      firstSeen: c.firstSeen.toISOString(),
      lastUpdated: c.lastUpdated.toISOString(),
    }));
  }

  async adminGrantJ3Credits(walletAddress: string, amount: number): Promise<J3CreditBalance> {
    return await this.updateJ3Credits(walletAddress, amount, "admin_grant", {
      grantAmount: amount,
      grantedAt: new Date().toISOString(),
    });
  }

  // ============================================================================
  // J3 LONG-TERM MEMORY
  // ============================================================================

  async getJ3Memories(wallet: string, personaId?: string | null): Promise<J3Memory[]> {
    const memories = await db
      .select()
      .from(j3Memories)
      .where(this.buildPersonaCondition(wallet, personaId))
      .orderBy(desc(j3Memories.lastUpdated));

    return memories.map((m) => ({
      id: m.id,
      wallet: m.wallet,
      personaId: m.personaId,
      conversationSummary: m.conversationSummary,
      learnedFacts: m.learnedFacts,
      preferences: m.preferences,
      metadata: m.metadata,
      interactionCount: m.interactionCount,
      createdAt: m.createdAt.toISOString(),
      lastUpdated: m.lastUpdated.toISOString(),
    }));
  }

  async getLatestJ3Memory(wallet: string, personaId?: string | null): Promise<J3Memory | null> {
    const [memory] = await db
      .select()
      .from(j3Memories)
      .where(this.buildPersonaCondition(wallet, personaId))
      .orderBy(desc(j3Memories.lastUpdated))
      .limit(1);

    if (!memory) return null;

    return {
      id: memory.id,
      wallet: memory.wallet,
      personaId: memory.personaId,
      conversationSummary: memory.conversationSummary,
      learnedFacts: memory.learnedFacts,
      preferences: memory.preferences,
      metadata: memory.metadata,
      interactionCount: memory.interactionCount,
      createdAt: memory.createdAt.toISOString(),
      lastUpdated: memory.lastUpdated.toISOString(),
    };
  }

  async createJ3Memory(memory: InsertJ3Memory): Promise<J3Memory> {
    const [created] = await db.insert(j3Memories).values({
      wallet: memory.wallet.toLowerCase(),
      personaId: memory.personaId || null,
      conversationSummary: memory.conversationSummary,
      learnedFacts: memory.learnedFacts,
      preferences: memory.preferences,
      metadata: memory.metadata,
      interactionCount: memory.interactionCount,
    }).returning();

    return {
      id: created.id,
      wallet: created.wallet,
      personaId: created.personaId,
      conversationSummary: created.conversationSummary,
      learnedFacts: created.learnedFacts,
      preferences: created.preferences,
      metadata: created.metadata,
      interactionCount: created.interactionCount,
      createdAt: created.createdAt.toISOString(),
      lastUpdated: created.lastUpdated.toISOString(),
    };
  }

  async updateJ3Memory(id: number, updates: Partial<InsertJ3Memory>): Promise<J3Memory> {
    const updateData: any = { lastUpdated: new Date() };
    
    if (updates.conversationSummary !== undefined) updateData.conversationSummary = updates.conversationSummary;
    if (updates.learnedFacts !== undefined) updateData.learnedFacts = updates.learnedFacts;
    if (updates.preferences !== undefined) updateData.preferences = updates.preferences;
    if (updates.metadata !== undefined) updateData.metadata = updates.metadata;
    if (updates.interactionCount !== undefined) updateData.interactionCount = updates.interactionCount;

    const [updated] = await db
      .update(j3Memories)
      .set(updateData)
      .where(eq(j3Memories.id, id))
      .returning();

    return {
      id: updated.id,
      wallet: updated.wallet,
      personaId: updated.personaId,
      conversationSummary: updated.conversationSummary,
      learnedFacts: updated.learnedFacts,
      preferences: updated.preferences,
      metadata: updated.metadata,
      interactionCount: updated.interactionCount,
      createdAt: updated.createdAt.toISOString(),
      lastUpdated: updated.lastUpdated.toISOString(),
    };
  }

  async appendLearnedFact(wallet: string, personaId: string | null, fact: string): Promise<void> {
    const key = wallet.toLowerCase();
    
    const existing = await this.getLatestJ3Memory(key, personaId);
    
    if (existing) {
      const newFacts = [...existing.learnedFacts, fact];
      await this.updateJ3Memory(existing.id, {
        learnedFacts: newFacts,
        interactionCount: existing.interactionCount + 1,
      });
    } else {
      await this.createJ3Memory({
        wallet: key,
        personaId: personaId,
        conversationSummary: `User shared: ${fact}`,
        learnedFacts: [fact],
        preferences: {},
        metadata: {},
        interactionCount: 1,
      });
    }
  }

  /**
   * Helper: Build persona-aware WHERE condition for j3_memories/j3_conversations queries.
   * Correctly handles NULL persona_id using isNull() instead of eq().
   * 
   * @param wallet - Wallet address (required)
   * @param personaId - Persona ID (optional: undefined = all personas, null = default persona, string = specific persona)
   * @param table - Which table to query (j3Memories or j3Conversations)
   * @returns Drizzle WHERE condition
   */
  private buildPersonaCondition(wallet: string, personaId?: string | null, table: typeof j3Memories | typeof j3Conversations = j3Memories) {
    const key = wallet.toLowerCase();
    
    if (personaId === undefined) {
      // No persona filter - return all for wallet
      return eq(table.wallet, key);
    }
    
    // Filter by specific persona or default (null) persona
    return and(
      eq(table.wallet, key),
      personaId === null ? isNull(table.personaId) : eq(table.personaId, personaId)
    );
  }

  // ============================================================================
  // J3SSICA3 CONVERSATION HISTORY
  // ============================================================================

  async getConversations(wallet: string, personaId?: string | null): Promise<J3Conversation[]> {
    const conversations = await db
      .select()
      .from(j3Conversations)
      .where(this.buildPersonaCondition(wallet, personaId, j3Conversations))
      .orderBy(desc(j3Conversations.lastMessageAt));

    return conversations.map((c) => ({
      id: c.id,
      wallet: c.wallet,
      personaId: c.personaId,
      title: c.title,
      messageCount: c.messageCount,
      totalCreditsSpent: c.totalCreditsSpent,
      createdAt: c.createdAt.toISOString(),
      lastMessageAt: c.lastMessageAt.toISOString(),
    }));
  }

  async getConversationById(id: number): Promise<J3Conversation | null> {
    const [conversation] = await db
      .select()
      .from(j3Conversations)
      .where(eq(j3Conversations.id, id))
      .limit(1);

    if (!conversation) return null;

    return {
      id: conversation.id,
      wallet: conversation.wallet,
      personaId: conversation.personaId,
      title: conversation.title,
      messageCount: conversation.messageCount,
      totalCreditsSpent: conversation.totalCreditsSpent,
      createdAt: conversation.createdAt.toISOString(),
      lastMessageAt: conversation.lastMessageAt.toISOString(),
    };
  }

  async createConversation(conversation: InsertJ3Conversation): Promise<J3Conversation> {
    const [created] = await db.insert(j3Conversations).values({
      wallet: conversation.wallet.toLowerCase(),
      personaId: conversation.personaId || null,
      title: conversation.title,
      messageCount: 0,
      totalCreditsSpent: 0,
    }).returning();

    return {
      id: created.id,
      wallet: created.wallet,
      personaId: created.personaId,
      title: created.title,
      messageCount: created.messageCount,
      totalCreditsSpent: created.totalCreditsSpent,
      createdAt: created.createdAt.toISOString(),
      lastMessageAt: created.lastMessageAt.toISOString(),
    };
  }

  async getMessages(conversationId: number): Promise<J3Message[]> {
    const messages = await db
      .select()
      .from(j3Messages)
      .where(eq(j3Messages.conversationId, conversationId))
      .orderBy(j3Messages.timestamp);

    return messages.map((m) => ({
      id: m.id,
      conversationId: m.conversationId,
      role: m.role as "user" | "assistant",
      content: m.content,
      creditsSpent: m.creditsSpent,
      timestamp: m.timestamp.toISOString(),
    }));
  }

  async addMessage(message: InsertJ3Message): Promise<J3Message> {
    const [created] = await db.insert(j3Messages).values({
      conversationId: message.conversationId,
      role: message.role,
      content: message.content,
      creditsSpent: message.creditsSpent,
    }).returning();

    return {
      id: created.id,
      conversationId: created.conversationId,
      role: created.role as "user" | "assistant",
      content: created.content,
      creditsSpent: created.creditsSpent,
      timestamp: created.timestamp.toISOString(),
    };
  }

  async updateConversationStats(conversationId: number, creditsSpent: number): Promise<void> {
    await db
      .update(j3Conversations)
      .set({
        messageCount: sql`${j3Conversations.messageCount} + 1`,
        totalCreditsSpent: sql`${j3Conversations.totalCreditsSpent} + ${creditsSpent}`,
        lastMessageAt: new Date(),
      })
      .where(eq(j3Conversations.id, conversationId));
  }

  // ============================================================================
  // USER ACTIVITY TIMELINE
  // ============================================================================

  async getUserActivities(wallet: string, eventType?: string | null, limit: number = 100): Promise<UserActivity[]> {
    const conditions = [eq(userActivities.wallet, wallet)];
    
    if (eventType) {
      conditions.push(eq(userActivities.eventType, eventType));
    }

    const activities = await db
      .select()
      .from(userActivities)
      .where(and(...conditions))
      .orderBy(desc(userActivities.createdAt))
      .limit(limit);

    return activities.map(this.mapDBActivityToUserActivity);
  }

  async createActivity(activity: CreateUserActivity): Promise<UserActivity> {
    const [created] = await db
      .insert(userActivities)
      .values({
        wallet: activity.wallet,
        eventType: activity.eventType,
        description: activity.description,
        metadata: activity.metadata || {},
      })
      .returning();

    return this.mapDBActivityToUserActivity(created);
  }

  async getActivityStats(wallet: string): Promise<{ totalActivities: number; eventCounts: Record<string, number> }> {
    const activities = await db
      .select()
      .from(userActivities)
      .where(eq(userActivities.wallet, wallet));

    const eventCounts: Record<string, number> = {};
    activities.forEach(activity => {
      const type = activity.eventType;
      eventCounts[type] = (eventCounts[type] || 0) + 1;
    });

    return {
      totalActivities: activities.length,
      eventCounts,
    };
  }

  private mapDBActivityToUserActivity(dbActivity: typeof userActivities.$inferSelect): UserActivity {
    return {
      id: dbActivity.id,
      wallet: dbActivity.wallet,
      eventType: dbActivity.eventType as UserActivity['eventType'],
      description: dbActivity.description,
      metadata: dbActivity.metadata as Record<string, unknown>,
      createdAt: dbActivity.createdAt.toISOString(),
    };
  }
}
