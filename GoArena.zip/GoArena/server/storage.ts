import { readFileSync, writeFileSync, existsSync, mkdirSync } from "fs";
import { join, dirname } from "path";
import { fileURLToPath } from "url";
import type {
  WalletMemory,
  LorePiece,
  TournamentData,
  XpData,
  LeaderboardEntry,
  Marble,
  CreateMarble,
  DungeonRun,
  CreateDungeonRun,
  DungeonAction,
  SecurityEvent,
  CreateSecurityEvent,
  Persona,
  CreatePersona,
  J3CreditBalance,
  CreateJ3CreditBalance,
  J3UsageLog,
  CreateJ3UsageLog,
  J3Memory,
  InsertJ3Memory,
  J3Conversation,
  InsertJ3Conversation,
  J3Message,
  InsertJ3Message,
  UserActivity,
  CreateUserActivity,
} from "@shared/schema";
import type {
  GyroscopeConfig,
  GestureTrigger,
  InsertGestureTrigger,
  UpdateGestureTrigger,
} from "@shared/gyro-schema";

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);
const dataDir = join(__dirname, "data");

// Ensure data directory exists
if (!existsSync(dataDir)) {
  mkdirSync(dataDir, { recursive: true });
}

const memoryPath = join(dataDir, "memory.json");
const lorePath = join(dataDir, "lore.json");
const tournamentPath = join(dataDir, "tournament.json");
const marblesPath = join(dataDir, "marbles.json");
const dungeonsPath = join(dataDir, "dungeons.json");
const securityPath = join(dataDir, "security.json");
const gyroConfigPath = join(dataDir, "gyro-config.json");
const personasPath = join(dataDir, "personas.json");
const j3CreditsPath = join(dataDir, "j3-credits.json");
const j3UsagePath = join(dataDir, "j3-usage.json");

interface MemoryStore {
  wallets: Record<string, WalletMemory>;
}

export interface IStorage {
  // Wallet Memory
  getWalletMemory(wallet: string): Promise<WalletMemory | null>;
  updateWalletMemory(wallet: string, changes: Partial<WalletMemory>): Promise<WalletMemory>;
  
  // XP System
  getXpData(wallet: string): Promise<XpData>;
  
  // Leaderboard
  getLeaderboard(limit?: number): Promise<LeaderboardEntry[]>;
  
  // Lore
  getLoreForWallet(wallet: string): Promise<LorePiece[]>;
  unlockLore(wallet: string, loreId: number): Promise<void>;
  
  // Tournament
  getTournamentData(): Promise<TournamentData>;
  joinTournament(wallet: string): Promise<void>;
  advanceTournament(wallet: string): Promise<number>;
  
  // Marbles
  getMarblesByWallet(wallet: string): Promise<Marble[]>;
  getMarbleById(id: number): Promise<Marble | null>;
  createMarble(marble: CreateMarble): Promise<Marble>;
  updateMarble(id: number, updates: Partial<Marble>): Promise<void>;
  
  // Dungeons
  getActiveDungeonRun(wallet: string): Promise<DungeonRun | null>;
  getDungeonRunById(id: number): Promise<DungeonRun | null>;
  createDungeonRun(data: CreateDungeonRun): Promise<DungeonRun>;
  updateDungeonRun(id: number, updates: Partial<DungeonRun>): Promise<void>;
  getDungeonHistory(wallet: string): Promise<DungeonRun[]>;
  
  // Security Events
  getSecurityEvents(wallet: string): Promise<SecurityEvent[]>;
  createSecurityEvent(event: CreateSecurityEvent): Promise<SecurityEvent>;
  clearSecurityEvents(wallet: string): Promise<void>;
  
  // Admin Operations
  getAllWallets(): Promise<WalletMemory[]>;
  getAllLore(): Promise<LorePiece[]>;
  createLore(lore: Omit<LorePiece, "id">): Promise<LorePiece>;
  updateLore(id: number, updates: Partial<LorePiece>): Promise<void>;
  deleteLore(id: number): Promise<void>;
  resetTournament(): Promise<void>;
  adminUpdateWalletXp(wallet: string, xpAdjustment: number): Promise<WalletMemory>;
  
  // Gyroscope Code Injection
  getGyroscopeConfig(): Promise<GyroscopeConfig>;
  updateGyroscopeConfig(config: Partial<GyroscopeConfig>): Promise<GyroscopeConfig>;
  createGestureTrigger(trigger: InsertGestureTrigger): Promise<GestureTrigger>;
  updateGestureTrigger(id: string, updates: UpdateGestureTrigger): Promise<GestureTrigger>;
  deleteGestureTrigger(id: string): Promise<void>;
  getGestureTriggers(): Promise<GestureTrigger[]>;
  
  // NFT Persona System (J3SSICA3-managed)
  createPersona(data: CreatePersona): Promise<Persona>;
  getPersona(id: string): Promise<Persona | null>;
  getAllPersonas(): Promise<Persona[]>;
  updatePersona(id: string, updates: Partial<Persona>): Promise<Persona>;
  deletePersona(id: string): Promise<void>;
  getPersonasByWallet(wallet: string): Promise<Persona[]>;
  
  // J3SSICA3 Credit System
  getJ3Credits(wallet: string): Promise<J3CreditBalance>;
  updateJ3Credits(wallet: string, creditsChange: number, action: CreateJ3UsageLog['action'], metadata?: Record<string, unknown>): Promise<J3CreditBalance>;
  deductJ3Credits(wallet: string, amount: number): Promise<J3CreditBalance>;
  regenerateDailyCredits(wallet: string): Promise<J3CreditBalance | null>;
  logJ3Usage(log: CreateJ3UsageLog): Promise<J3UsageLog>;
  getJ3UsageHistory(wallet: string, limit?: number): Promise<J3UsageLog[]>;
  getAllJ3Credits(): Promise<J3CreditBalance[]>;
  adminGrantJ3Credits(wallet: string, amount: number): Promise<J3CreditBalance>;

  // J3SSICA3 Long-term Memory
  getJ3Memories(wallet: string, personaId?: string | null): Promise<J3Memory[]>;
  getLatestJ3Memory(wallet: string, personaId?: string | null): Promise<J3Memory | null>;
  createJ3Memory(memory: InsertJ3Memory): Promise<J3Memory>;
  updateJ3Memory(id: number, updates: Partial<InsertJ3Memory>): Promise<J3Memory>;
  appendLearnedFact(wallet: string, personaId: string | null, fact: string): Promise<void>;

  // J3SSICA3 Conversation History
  getConversations(wallet: string, personaId?: string | null): Promise<J3Conversation[]>;
  getConversationById(id: number): Promise<J3Conversation | null>;
  createConversation(conversation: InsertJ3Conversation): Promise<J3Conversation>;
  getMessages(conversationId: number): Promise<J3Message[]>;
  addMessage(message: InsertJ3Message): Promise<J3Message>;
  updateConversationStats(conversationId: number, creditsSpent: number): Promise<void>;

  // User Activity Timeline
  getUserActivities(wallet: string, eventType?: string | null, limit?: number): Promise<UserActivity[]>;
  createActivity(activity: CreateUserActivity): Promise<UserActivity>;
  getActivityStats(wallet: string): Promise<{ totalActivities: number; eventCounts: Record<string, number> }>;
}

export class FileStorage implements IStorage {
  private readMemory(): MemoryStore {
    try {
      if (!existsSync(memoryPath)) {
        return { wallets: {} };
      }
      const data = readFileSync(memoryPath, "utf8");
      return JSON.parse(data || '{"wallets":{}}');
    } catch {
      return { wallets: {} };
    }
  }

  private writeMemory(store: MemoryStore): void {
    writeFileSync(memoryPath, JSON.stringify(store, null, 2), "utf8");
  }

  private readLore(): LorePiece[] {
    try {
      if (!existsSync(lorePath)) {
        const defaultLore: LorePiece[] = [
          {
            id: 1,
            title: "Genesis of the Storm",
            text: "When the first marble shattered in the ancient arena, thunder was born. The fragments scattered across the realm, each carrying a spark of the primordial storm.",
          },
          {
            id: 2,
            title: "The Seven Titans",
            text: "Within the thunder lived seven original marbles, each representing a fundamental force: Fury, Grace, Wisdom, Chaos, Harmony, Destruction, and Creation.",
          },
          {
            id: 3,
            title: "The Eternal Contest",
            text: "The arena exists outside of time, where champions from all eras gather to prove their worth. Victory grants not just glory, but fragments of understanding.",
          },
          {
            id: 4,
            title: "Storm's Blessing",
            text: "Those who earn 500 XP receive the Storm's Blessing, allowing them to hear whispers of ancient battles and glimpse the patterns in the chaos.",
          },
          {
            id: 5,
            title: "The Thunder Throne",
            text: "At 1000 XP, a champion may approach the Thunder Throne, where the greatest warriors are immortalized in lightning. Only the Storm Titans have claimed this honor.",
          },
        ];
        writeFileSync(lorePath, JSON.stringify(defaultLore, null, 2), "utf8");
        return defaultLore;
      }
      return JSON.parse(readFileSync(lorePath, "utf8"));
    } catch {
      return [];
    }
  }

  private readTournament(): TournamentData {
    try {
      if (!existsSync(tournamentPath)) {
        const defaultData: TournamentData = {
          participants: [],
          rounds: [],
        };
        writeFileSync(tournamentPath, JSON.stringify(defaultData, null, 2), "utf8");
        return defaultData;
      }
      return JSON.parse(readFileSync(tournamentPath, "utf8"));
    } catch {
      return { participants: [], rounds: [] };
    }
  }

  private writeTournament(data: TournamentData): void {
    writeFileSync(tournamentPath, JSON.stringify(data, null, 2), "utf8");
  }

  private calculateXp(memory: WalletMemory): number {
    const mints = memory.mintCount || 0;
    const giftsSent = memory.giftsSent || 0;
    const giftsReceived = memory.giftsReceived || 0;
    const adminAdjustment = memory.adminXpAdjustment || 0;
    // +10 XP per mint, +5 XP per gift sent, +5 XP per gift received, + admin adjustment
    return mints * 10 + giftsSent * 5 + giftsReceived * 5 + adminAdjustment;
  }

  private getBadges(xp: number): string[] {
    if (xp >= 1000) return ["Storm Titan", "Arena Master"];
    if (xp >= 500) return ["Thunder Adept"];
    if (xp >= 100) return ["Marble Initiate"];
    return [];
  }

  async getWalletMemory(wallet: string): Promise<WalletMemory | null> {
    const store = this.readMemory();
    const key = wallet.toLowerCase();
    return store.wallets[key] || null;
  }

  async updateWalletMemory(wallet: string, changes: Partial<WalletMemory>): Promise<WalletMemory> {
    const store = this.readMemory();
    const key = wallet.toLowerCase();
    const now = new Date().toISOString();

    const current = store.wallets[key] || {
      wallet,
      mintCount: 0,
      giftsSent: 0,
      giftsReceived: 0,
      adminXpAdjustment: 0,
      seenLoreIds: [],
      firstSeen: now,
      lastSeen: now,
    };

    Object.entries(changes).forEach(([field, value]) => {
      if (Array.isArray(value)) {
        (current as any)[field] = Array.from(new Set(value));
      } else {
        (current as any)[field] = value;
      }
    });

    current.lastSeen = now;
    store.wallets[key] = current;
    this.writeMemory(store);
    return current;
  }

  async getXpData(wallet: string): Promise<XpData> {
    const memory = await this.getWalletMemory(wallet);
    const xp = memory ? this.calculateXp(memory) : 0;
    const level = Math.floor(xp / 100) + 1;
    
    return {
      wallet,
      xp,
      level,
      badges: this.getBadges(xp),
    };
  }

  async getLeaderboard(limit = 50): Promise<LeaderboardEntry[]> {
    const store = this.readMemory();
    const entries = Object.values(store.wallets).map((memory) => {
      const xp = this.calculateXp(memory);
      return {
        wallet: memory.wallet,
        xp,
        level: Math.floor(xp / 100) + 1,
        mints: memory.mintCount,
        giftsSent: memory.giftsSent,
        giftsReceived: memory.giftsReceived,
        lastSeen: memory.lastSeen,
      };
    });

    return entries
      .sort((a, b) => b.xp - a.xp)
      .slice(0, limit);
  }

  async getLoreForWallet(wallet: string): Promise<LorePiece[]> {
    const allLore = this.readLore();
    const memory = await this.getWalletMemory(wallet);
    const seenIds = new Set(memory?.seenLoreIds || []);

    return allLore.map((lore) => ({
      ...lore,
      unlocked: seenIds.has(lore.id),
    }));
  }

  async unlockLore(wallet: string, loreId: number): Promise<void> {
    const memory = await this.getWalletMemory(wallet);
    const seenIds = new Set(memory?.seenLoreIds || []);
    seenIds.add(loreId);

    await this.updateWalletMemory(wallet, {
      seenLoreIds: Array.from(seenIds),
    });
  }

  async getTournamentData(): Promise<TournamentData> {
    return this.readTournament();
  }

  async joinTournament(wallet: string): Promise<void> {
    const data = this.readTournament();
    if (!data.participants.includes(wallet)) {
      data.participants.push(wallet);
      this.writeTournament(data);
    }
  }

  async advanceTournament(wallet: string): Promise<number> {
    const data = this.readTournament();
    const playerRounds = data.rounds.filter((r) => r.wallet === wallet);
    const nextRound = playerRounds.length + 1;

    data.rounds.push({
      wallet,
      round: nextRound,
      time: Date.now(),
    });

    this.writeTournament(data);
    return nextRound;
  }

  async getAllWallets(): Promise<WalletMemory[]> {
    const store = this.readMemory();
    return Object.values(store.wallets);
  }

  async getAllLore(): Promise<LorePiece[]> {
    return this.readLore();
  }

  async createLore(lore: Omit<LorePiece, "id">): Promise<LorePiece> {
    const allLore = this.readLore();
    const maxId = allLore.length > 0 ? Math.max(...allLore.map((l) => l.id)) : 0;
    const newLore: LorePiece = {
      ...lore,
      id: maxId + 1,
    };
    allLore.push(newLore);
    writeFileSync(lorePath, JSON.stringify(allLore, null, 2), "utf8");
    return newLore;
  }

  async updateLore(id: number, updates: Partial<LorePiece>): Promise<void> {
    const allLore = this.readLore();
    const index = allLore.findIndex((l) => l.id === id);
    if (index === -1) {
      throw new Error("Lore not found");
    }
    allLore[index] = { ...allLore[index], ...updates, id };
    writeFileSync(lorePath, JSON.stringify(allLore, null, 2), "utf8");
  }

  async deleteLore(id: number): Promise<void> {
    const allLore = this.readLore();
    const filtered = allLore.filter((l) => l.id !== id);
    writeFileSync(lorePath, JSON.stringify(filtered, null, 2), "utf8");
  }

  async resetTournament(): Promise<void> {
    const emptyData: TournamentData = {
      participants: [],
      rounds: [],
    };
    this.writeTournament(emptyData);
  }

  async adminUpdateWalletXp(wallet: string, xpAdjustment: number): Promise<WalletMemory> {
    const memory = await this.getWalletMemory(wallet);
    const currentAdminAdjustment = memory?.adminXpAdjustment || 0;
    
    // Add the new adjustment to any existing admin adjustment
    // This allows admins to make incremental adjustments
    const newAdminAdjustment = currentAdminAdjustment + xpAdjustment;
    
    // Update only the adminXpAdjustment field, preserving all gameplay counters
    return await this.updateWalletMemory(wallet, {
      adminXpAdjustment: newAdminAdjustment,
    });
  }

  // Marble Methods
  private readMarbles(): Marble[] {
    try {
      if (!existsSync(marblesPath)) {
        return [];
      }
      return JSON.parse(readFileSync(marblesPath, "utf8"));
    } catch {
      return [];
    }
  }

  private writeMarbles(marbles: Marble[]): void {
    writeFileSync(marblesPath, JSON.stringify(marbles, null, 2), "utf8");
  }

  async getMarblesByWallet(wallet: string): Promise<Marble[]> {
    const allMarbles = this.readMarbles();
    return allMarbles.filter((m) => m.wallet.toLowerCase() === wallet.toLowerCase());
  }

  async getMarbleById(id: number): Promise<Marble | null> {
    const allMarbles = this.readMarbles();
    return allMarbles.find((m) => m.id === id) || null;
  }

  async createMarble(marble: CreateMarble): Promise<Marble> {
    const allMarbles = this.readMarbles();
    const maxId = allMarbles.length > 0 ? Math.max(...allMarbles.map((m) => m.id)) : 0;
    const newMarble: Marble = {
      ...marble,
      id: maxId + 1,
      isMinted: false,
      createdAt: new Date().toISOString(),
    };
    allMarbles.push(newMarble);
    this.writeMarbles(allMarbles);
    return newMarble;
  }

  async updateMarble(id: number, updates: Partial<Marble>): Promise<void> {
    const allMarbles = this.readMarbles();
    const index = allMarbles.findIndex((m) => m.id === id);
    if (index === -1) {
      throw new Error("Marble not found");
    }
    allMarbles[index] = { ...allMarbles[index], ...updates, id };
    this.writeMarbles(allMarbles);
  }

  // Dungeon Methods
  private readDungeons(): DungeonRun[] {
    try {
      if (!existsSync(dungeonsPath)) {
        return [];
      }
      return JSON.parse(readFileSync(dungeonsPath, "utf8"));
    } catch {
      return [];
    }
  }

  private writeDungeons(dungeons: DungeonRun[]): void {
    writeFileSync(dungeonsPath, JSON.stringify(dungeons, null, 2), "utf8");
  }

  async getActiveDungeonRun(wallet: string): Promise<DungeonRun | null> {
    const allRuns = this.readDungeons();
    return allRuns.find(
      (r) => r.wallet.toLowerCase() === wallet.toLowerCase() && r.isActive
    ) || null;
  }

  async getDungeonRunById(id: number): Promise<DungeonRun | null> {
    const allRuns = this.readDungeons();
    return allRuns.find((r) => r.id === id) || null;
  }

  async createDungeonRun(data: CreateDungeonRun): Promise<DungeonRun> {
    const allRuns = this.readDungeons();
    const marble = await this.getMarbleById(data.marbleId);
    if (!marble) {
      throw new Error("Marble not found");
    }

    const maxId = allRuns.length > 0 ? Math.max(...allRuns.map((r) => r.id)) : 0;
    const newRun: DungeonRun = {
      id: maxId + 1,
      wallet: data.wallet,
      marbleId: data.marbleId,
      currentFloor: 1,
      maxFloorReached: 1,
      status: "active",
      isActive: true,
      experienceGained: 0,
      marbleCurrentHealth: marble.health,
      createdAt: new Date().toISOString(),
    };
    allRuns.push(newRun);
    this.writeDungeons(allRuns);
    return newRun;
  }

  async updateDungeonRun(id: number, updates: Partial<DungeonRun>): Promise<void> {
    const allRuns = this.readDungeons();
    const index = allRuns.findIndex((r) => r.id === id);
    if (index === -1) {
      throw new Error("Dungeon run not found");
    }
    allRuns[index] = { ...allRuns[index], ...updates, id };
    this.writeDungeons(allRuns);
  }

  async getDungeonHistory(wallet: string): Promise<DungeonRun[]> {
    const allRuns = this.readDungeons();
    return allRuns
      .filter((r) => r.wallet.toLowerCase() === wallet.toLowerCase())
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }

  // Security Event Methods
  private readSecurityEvents(): SecurityEvent[] {
    try {
      if (!existsSync(securityPath)) {
        return [];
      }
      return JSON.parse(readFileSync(securityPath, "utf8"));
    } catch {
      return [];
    }
  }

  private writeSecurityEvents(events: SecurityEvent[]): void {
    writeFileSync(securityPath, JSON.stringify(events, null, 2), "utf8");
  }

  async getSecurityEvents(wallet: string): Promise<SecurityEvent[]> {
    const allEvents = this.readSecurityEvents();
    return allEvents
      .filter((e) => e.wallet.toLowerCase() === wallet.toLowerCase())
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }

  async createSecurityEvent(event: CreateSecurityEvent): Promise<SecurityEvent> {
    const allEvents = this.readSecurityEvents();
    const maxId = allEvents.length > 0 ? Math.max(...allEvents.map((e) => e.id)) : 0;
    const newEvent: SecurityEvent = {
      ...event,
      id: maxId + 1,
      createdAt: new Date().toISOString(),
    };
    allEvents.push(newEvent);
    this.writeSecurityEvents(allEvents);
    return newEvent;
  }

  async clearSecurityEvents(wallet: string): Promise<void> {
    const allEvents = this.readSecurityEvents();
    const filtered = allEvents.filter(
      (e) => e.wallet.toLowerCase() !== wallet.toLowerCase()
    );
    this.writeSecurityEvents(filtered);
  }

  // Gyroscope Config Methods
  private readGyroConfig(): GyroscopeConfig {
    try {
      if (!existsSync(gyroConfigPath)) {
        const defaultConfig: GyroscopeConfig = {
          enabled: false,
          triggers: [],
          debugMode: false,
          requirePermission: true,
        };
        return defaultConfig;
      }
      return JSON.parse(readFileSync(gyroConfigPath, "utf8"));
    } catch {
      return {
        enabled: false,
        triggers: [],
        debugMode: false,
        requirePermission: true,
      };
    }
  }

  private writeGyroConfig(config: GyroscopeConfig): void {
    writeFileSync(gyroConfigPath, JSON.stringify(config, null, 2), "utf8");
  }

  async getGyroscopeConfig(): Promise<GyroscopeConfig> {
    return this.readGyroConfig();
  }

  async updateGyroscopeConfig(updates: Partial<GyroscopeConfig>): Promise<GyroscopeConfig> {
    const current = this.readGyroConfig();
    const updated = { ...current, ...updates };
    this.writeGyroConfig(updated);
    return updated;
  }

  async createGestureTrigger(trigger: InsertGestureTrigger): Promise<GestureTrigger> {
    const config = this.readGyroConfig();
    const id = `trigger_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    const newTrigger: GestureTrigger = {
      ...trigger,
      id,
    };
    config.triggers.push(newTrigger);
    this.writeGyroConfig(config);
    return newTrigger;
  }

  async updateGestureTrigger(id: string, updates: UpdateGestureTrigger): Promise<GestureTrigger> {
    const config = this.readGyroConfig();
    const index = config.triggers.findIndex((t) => t.id === id);
    if (index === -1) {
      throw new Error("Trigger not found");
    }
    config.triggers[index] = { ...config.triggers[index], ...updates, id };
    this.writeGyroConfig(config);
    return config.triggers[index];
  }

  async deleteGestureTrigger(id: string): Promise<void> {
    const config = this.readGyroConfig();
    config.triggers = config.triggers.filter((t) => t.id !== id);
    this.writeGyroConfig(config);
  }

  async getGestureTriggers(): Promise<GestureTrigger[]> {
    const config = this.readGyroConfig();
    return config.triggers;
  }

  // NFT Persona System (J3SSICA3-managed infinite storage)
  private readPersonas(): Record<string, Persona> {
    try {
      if (!existsSync(personasPath)) {
        return {};
      }
      const data = readFileSync(personasPath, "utf8");
      return JSON.parse(data || '{}');
    } catch {
      return {};
    }
  }

  private writePersonas(personas: Record<string, Persona>): void {
    writeFileSync(personasPath, JSON.stringify(personas, null, 2), "utf8");
  }

  async createPersona(data: CreatePersona): Promise<Persona> {
    const personas = this.readPersonas();
    const id = `persona_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    const now = new Date().toISOString();
    
    const newPersona: Persona = {
      id,
      createdAt: now,
      lastActive: now,
      ownerWallet: data.ownerWallet,
      nftTokenId: data.nftTokenId,
      nftContract: data.nftContract,
      aiStylePreset: data.aiStylePreset || "chaotic_neutral",
      customPersonality: data.customPersonality,
      memory: {
        shortTerm: [],
        longTerm: [],
      },
      assets: {
        marbles: [],
        titles: [],
        achievements: [],
      },
      metadata: {},
      totalConversations: 0,
      totalMessages: 0,
    };

    personas[id] = newPersona;
    this.writePersonas(personas);
    return newPersona;
  }

  async getPersona(id: string): Promise<Persona | null> {
    const personas = this.readPersonas();
    return personas[id] || null;
  }

  async getAllPersonas(): Promise<Persona[]> {
    const personas = this.readPersonas();
    return Object.values(personas);
  }

  async updatePersona(id: string, updates: Partial<Persona>): Promise<Persona> {
    const personas = this.readPersonas();
    if (!personas[id]) {
      throw new Error("Persona not found");
    }
    
    personas[id] = {
      ...personas[id],
      ...updates,
      id, // Ensure ID doesn't change
      lastActive: new Date().toISOString(),
    };
    
    this.writePersonas(personas);
    return personas[id];
  }

  async deletePersona(id: string): Promise<void> {
    const personas = this.readPersonas();
    delete personas[id];
    this.writePersonas(personas);
  }

  async getPersonasByWallet(wallet: string): Promise<Persona[]> {
    const personas = this.readPersonas();
    return Object.values(personas).filter(p => p.ownerWallet === wallet);
  }

  // J3SSICA3 Credit System Implementation
  private readJ3Credits(): Record<string, J3CreditBalance> {
    try {
      if (!existsSync(j3CreditsPath)) {
        return {};
      }
      const data = readFileSync(j3CreditsPath, "utf8");
      return JSON.parse(data || '{}');
    } catch {
      return {};
    }
  }

  private writeJ3Credits(credits: Record<string, J3CreditBalance>): void {
    writeFileSync(j3CreditsPath, JSON.stringify(credits, null, 2), "utf8");
  }

  private readJ3Usage(): J3UsageLog[] {
    try {
      if (!existsSync(j3UsagePath)) {
        return [];
      }
      const data = readFileSync(j3UsagePath, "utf8");
      return JSON.parse(data || '[]');
    } catch {
      return [];
    }
  }

  private writeJ3Usage(logs: J3UsageLog[]): void {
    writeFileSync(j3UsagePath, JSON.stringify(logs, null, 2), "utf8");
  }

  private calculateTier(balance: number): J3CreditBalance['tier'] {
    if (balance >= 5000) return "Legend";
    if (balance >= 1000) return "Master";
    if (balance >= 500) return "Adept";
    if (balance >= 100) return "Apprentice";
    return "Novice";
  }

  async getJ3Credits(wallet: string): Promise<J3CreditBalance> {
    const credits = this.readJ3Credits();
    
    if (!credits[wallet]) {
      // Create new credit balance for first-time user
      const now = new Date().toISOString();
      const newBalance: J3CreditBalance = {
        wallet,
        balance: 100, // New users start with 100 J3C
        tier: "Apprentice",
        lastRegenerated: now,
        totalEarned: 100,
        totalSpent: 0,
        gracePeriodMessages: 3, // 3 free messages for new users
        firstSeen: now,
        lastUpdated: now,
      };
      credits[wallet] = newBalance;
      this.writeJ3Credits(credits);
      return newBalance;
    }

    return credits[wallet];
  }

  async updateJ3Credits(
    wallet: string,
    creditsChange: number,
    action: CreateJ3UsageLog['action'],
    metadata?: Record<string, unknown>
  ): Promise<J3CreditBalance> {
    const credits = this.readJ3Credits();
    const current = await this.getJ3Credits(wallet);
    
    const newBalance = Math.max(0, current.balance + creditsChange);
    const updated: J3CreditBalance = {
      ...current,
      balance: newBalance,
      tier: this.calculateTier(newBalance),
      totalEarned: creditsChange > 0 ? current.totalEarned + creditsChange : current.totalEarned,
      totalSpent: creditsChange < 0 ? current.totalSpent + Math.abs(creditsChange) : current.totalSpent,
      lastUpdated: new Date().toISOString(),
    };

    credits[wallet] = updated;
    this.writeJ3Credits(credits);

    // Log the usage
    await this.logJ3Usage({
      wallet,
      action,
      creditsChange,
      balanceAfter: newBalance,
      metadata: metadata || {},
    });

    return updated;
  }

  async deductJ3Credits(wallet: string, amount: number): Promise<J3CreditBalance> {
    const current = await this.getJ3Credits(wallet);
    
    // Check if user has grace period messages
    if (current.gracePeriodMessages > 0) {
      const credits = this.readJ3Credits();
      credits[wallet] = {
        ...current,
        gracePeriodMessages: current.gracePeriodMessages - 1,
        lastUpdated: new Date().toISOString(),
      };
      this.writeJ3Credits(credits);

      // Log grace period usage
      await this.logJ3Usage({
        wallet,
        action: "grace_period",
        creditsChange: 0,
        balanceAfter: current.balance,
        metadata: { gracePeriodMessagesRemaining: credits[wallet].gracePeriodMessages },
      });

      return credits[wallet];
    }

    // Check if user has enough credits
    if (current.balance < amount) {
      throw new Error(`Insufficient credits. Required: ${amount} J3C, Available: ${current.balance} J3C`);
    }

    return this.updateJ3Credits(wallet, -amount, "chat_message");
  }

  async regenerateDailyCredits(wallet: string): Promise<J3CreditBalance | null> {
    const current = await this.getJ3Credits(wallet);
    const now = new Date();
    const lastRegen = new Date(current.lastRegenerated);
    
    // Check if 24 hours have passed since last regeneration
    const hoursSinceRegen = (now.getTime() - lastRegen.getTime()) / (1000 * 60 * 60);
    
    if (hoursSinceRegen < 24) {
      return null; // Not eligible for regen yet
    }

    const credits = this.readJ3Credits();
    const regenerated = await this.updateJ3Credits(wallet, 10, "daily_regen", {
      hoursSinceLastRegen: hoursSinceRegen.toFixed(2),
    });

    // Update last regenerated time
    credits[wallet] = {
      ...regenerated,
      lastRegenerated: now.toISOString(),
    };
    this.writeJ3Credits(credits);

    return credits[wallet];
  }

  async logJ3Usage(log: CreateJ3UsageLog): Promise<J3UsageLog> {
    const logs = this.readJ3Usage();
    const newLog: J3UsageLog = {
      ...log,
      id: logs.length + 1,
      timestamp: new Date().toISOString(),
    };
    logs.push(newLog);
    this.writeJ3Usage(logs);
    return newLog;
  }

  async getJ3UsageHistory(wallet: string, limit: number = 100): Promise<J3UsageLog[]> {
    const logs = this.readJ3Usage();
    return logs
      .filter(log => log.wallet === wallet)
      .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime())
      .slice(0, limit);
  }

  async getAllJ3Credits(): Promise<J3CreditBalance[]> {
    const credits = this.readJ3Credits();
    return Object.values(credits);
  }

  async adminGrantJ3Credits(wallet: string, amount: number): Promise<J3CreditBalance> {
    return this.updateJ3Credits(wallet, amount, "admin_grant", {
      grantedBy: "admin",
      amount,
    });
  }

  // J3 Long-term Memory (stub - will be replaced by DatabaseStorage)
  async getJ3Memories(_wallet: string, _personaId?: string | null): Promise<J3Memory[]> {
    return [];
  }

  async getLatestJ3Memory(_wallet: string, _personaId?: string | null): Promise<J3Memory | null> {
    return null;
  }

  async createJ3Memory(memory: InsertJ3Memory): Promise<J3Memory> {
    return {
      id: 1,
      ...memory,
      personaId: memory.personaId || null,
      createdAt: new Date().toISOString(),
      lastUpdated: new Date().toISOString(),
    };
  }

  async updateJ3Memory(_id: number, _updates: Partial<InsertJ3Memory>): Promise<J3Memory> {
    throw new Error("J3 memory updates not supported in FileStorage");
  }

  async appendLearnedFact(_wallet: string, _personaId: string | null, _fact: string): Promise<void> {
    // No-op in FileStorage
  }

  // J3 Conversation History (stub - will be replaced by DatabaseStorage)
  async getConversations(_wallet: string, _personaId?: string | null): Promise<J3Conversation[]> {
    return [];
  }

  async getConversationById(_id: number): Promise<J3Conversation | null> {
    return null;
  }

  async createConversation(conversation: InsertJ3Conversation): Promise<J3Conversation> {
    return {
      id: 1,
      ...conversation,
      personaId: conversation.personaId || null,
      messageCount: 0,
      totalCreditsSpent: 0,
      createdAt: new Date().toISOString(),
      lastMessageAt: new Date().toISOString(),
    };
  }

  async getMessages(_conversationId: number): Promise<J3Message[]> {
    return [];
  }

  async addMessage(message: InsertJ3Message): Promise<J3Message> {
    return {
      id: 1,
      ...message,
      timestamp: new Date().toISOString(),
    };
  }

  async updateConversationStats(_conversationId: number, _creditsSpent: number): Promise<void> {
    // No-op in FileStorage
  }

  async getUserActivities(_wallet: string, _eventType?: string | null, _limit?: number): Promise<UserActivity[]> {
    return [];
  }

  async createActivity(_activity: CreateUserActivity): Promise<UserActivity> {
    throw new Error("Activity tracking not supported in FileStorage");
  }

  async getActivityStats(_wallet: string): Promise<{ totalActivities: number; eventCounts: Record<string, number> }> {
    return { totalActivities: 0, eventCounts: {} };
  }
}

export const storage = new FileStorage();
