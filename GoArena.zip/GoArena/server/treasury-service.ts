import { ethers } from 'ethers';

const TREASURY_ADDRESS = '0xd39c27709D46654c203B3c3013eb2Aac8E34a657';

interface TreasuryTransaction {
  hash: string;
  from: string;
  to: string;
  value: string;
  timestamp: number;
  type: 'donation' | 'reward';
}

export class TreasuryService {
  private wallet: ethers.Wallet | null = null;
  private provider: ethers.JsonRpcProvider;

  constructor() {
    this.provider = new ethers.JsonRpcProvider('https://eth.llamarpc.com');
    
    const privateKey = process.env.TREASURY_PRIVATE_KEY;
    if (privateKey) {
      this.wallet = new ethers.Wallet(privateKey, this.provider);
    }
  }

  getAddress(): string {
    return TREASURY_ADDRESS;
  }

  async getBalance(): Promise<string> {
    try {
      const balance = await this.provider.getBalance(TREASURY_ADDRESS);
      return ethers.formatEther(balance);
    } catch (error) {
      console.error('Error fetching treasury balance:', error);
      return '0.0';
    }
  }

  async getBalanceInWei(): Promise<bigint> {
    try {
      const balance = await this.provider.getBalance(TREASURY_ADDRESS);
      return balance;
    } catch (error) {
      console.error('Error fetching treasury balance:', error);
      return BigInt(0);
    }
  }

  async sendReward(recipientAddress: string, amountEth: string): Promise<{ success: boolean; txHash?: string; error?: string }> {
    if (!this.wallet) {
      return { success: false, error: 'Treasury wallet not configured' };
    }

    try {
      if (!ethers.isAddress(recipientAddress)) {
        return { success: false, error: 'Invalid recipient address' };
      }

      const amount = ethers.parseEther(amountEth);
      const balance = await this.getBalanceInWei();

      if (balance < amount) {
        return { success: false, error: 'Insufficient treasury balance' };
      }

      const tx = await this.wallet.sendTransaction({
        to: recipientAddress,
        value: amount,
      });

      await tx.wait();

      return { success: true, txHash: tx.hash };
    } catch (error: any) {
      console.error('Error sending reward:', error);
      return { success: false, error: error.message || 'Transaction failed' };
    }
  }

  async getRecentTransactions(limit: number = 10): Promise<TreasuryTransaction[]> {
    // Transaction history requires Etherscan API or archive node
    // For MVP, return empty array - balance and send functions are priority
    // Users can view transactions on Etherscan directly
    return [];
  }

  async estimateGasCost(recipientAddress: string, amountEth: string): Promise<string> {
    if (!this.wallet) {
      return '0.0';
    }

    try {
      const amount = ethers.parseEther(amountEth);
      const gasPrice = (await this.provider.getFeeData()).gasPrice || BigInt(0);
      const gasLimit = await this.wallet.estimateGas({
        to: recipientAddress,
        value: amount,
      });

      const gasCost = gasPrice * gasLimit;
      return ethers.formatEther(gasCost);
    } catch (error) {
      console.error('Error estimating gas:', error);
      return '0.0';
    }
  }
}

export const treasuryService = new TreasuryService();
