import OpenAI from "openai";
import type { MarbleRarity, DungeonEnemy } from "@shared/schema";

const openai = new OpenAI({
  apiKey: process.env.AI_INTEGRATIONS_OPENAI_API_KEY,
  baseURL: process.env.AI_INTEGRATIONS_OPENAI_BASE_URL,
});

// Stat ranges based on rarity
const RARITY_STAT_RANGES: Record<
  MarbleRarity,
  { min: number; max: number }
> = {
  common: { min: 5, max: 15 },
  uncommon: { min: 10, max: 25 },
  rare: { min: 20, max: 40 },
  epic: { min: 35, max: 60 },
  legendary: { min: 50, max: 80 },
  mythic: { min: 70, max: 100 },
};

function randomStatInRange(rarity: MarbleRarity): number {
  const range = RARITY_STAT_RANGES[rarity];
  return Math.floor(Math.random() * (range.max - range.min + 1)) + range.min;
}

export interface GeneratedMarbleData {
  name: string;
  description: string;
  attack: number;
  defense: number;
  speed: number;
  health: number;
}

export async function generateMarble(
  rarity: MarbleRarity
): Promise<GeneratedMarbleData> {
  const attack = randomStatInRange(rarity);
  const defense = randomStatInRange(rarity);
  const speed = randomStatInRange(rarity);
  const health = randomStatInRange(rarity) * 2; // Health is 2x other stats

  try {
    const completion = await openai.chat.completions.create({
      model: "gpt-4o-mini",
      messages: [
        {
          role: "system",
          content: `You are a creative AI generating unique marble names and descriptions for the Arena of Thunder - a storm-themed marble battle game. Generate a ${rarity} marble with electric storm aesthetics.

The marble has these stats:
- Attack: ${attack}
- Defense: ${defense}
- Speed: ${speed}
- Health: ${health}

Generate a name and description that reflects the rarity and stats. Higher rarity marbles should have more epic, legendary names.

Respond ONLY with valid JSON in this exact format:
{
  "name": "Marble Name Here",
  "description": "A brief, exciting description of this marble's appearance and power."
}`,
        },
      ],
      temperature: 0.9,
      max_tokens: 150,
    });

    const response = completion.choices[0]?.message?.content;
    if (!response) {
      throw new Error("No response from AI");
    }

    const parsed = JSON.parse(response);

    return {
      name: parsed.name,
      description: parsed.description,
      attack,
      defense,
      speed,
      health,
    };
  } catch (error) {
    console.error("Error generating marble:", error);

    // Fallback with deterministic names
    const fallbackNames: Record<MarbleRarity, string[]> = {
      common: ["Storm Pebble", "Thunder Spark", "Lightning Shard"],
      uncommon: ["Volt Orb", "Plasma Core", "Electric Echo"],
      rare: ["Tempest Sphere", "Ionized Heart", "Thunder Crystal"],
      epic: ["Storm Titan Orb", "Electro Nexus", "Cyclone Core"],
      legendary: ["Wrath of Zeus", "Heaven's Thunder", "Stormborn Relic"],
      mythic: ["Primordial Storm", "Eternal Lightning", "Celestial Tempest"],
    };

    const names = fallbackNames[rarity];
    const randomName = names[Math.floor(Math.random() * names.length)];

    return {
      name: randomName,
      description: `A ${rarity} marble crackling with electric energy from the Arena of Thunder.`,
      attack,
      defense,
      speed,
      health,
    };
  }
}

export async function generateDungeonEnemy(
  floor: number
): Promise<DungeonEnemy> {
  // Scale enemy stats with floor level
  const baseStats = 10 + floor * 5;
  const variance = floor * 2;

  const attack = baseStats + Math.floor(Math.random() * variance);
  const defense = baseStats + Math.floor(Math.random() * variance);
  const speed = baseStats + Math.floor(Math.random() * variance);
  const health = (baseStats + Math.floor(Math.random() * variance)) * 2;

  try {
    const completion = await openai.chat.completions.create({
      model: "gpt-4o-mini",
      messages: [
        {
          role: "system",
          content: `You are creating a dungeon enemy for floor ${floor} of the Arena of Thunder dungeons - a storm-themed roguelike battle system.

The enemy has these stats:
- Attack: ${attack}
- Defense: ${defense}  
- Speed: ${speed}
- Health: ${health}

Generate an enemy that fits the storm/electric theme and is appropriate for floor ${floor}. Lower floors have weaker enemies, higher floors have more dangerous ones.

Respond ONLY with valid JSON in this exact format:
{
  "name": "Enemy Name Here",
  "description": "A brief, atmospheric description of this enemy and its threat level."
}`,
        },
      ],
      temperature: 0.8,
      max_tokens: 120,
    });

    const response = completion.choices[0]?.message?.content;
    if (!response) {
      throw new Error("No response from AI");
    }

    const parsed = JSON.parse(response);

    return {
      name: parsed.name,
      description: parsed.description,
      attack,
      defense,
      speed,
      health,
      currentHealth: health,
    };
  } catch (error) {
    console.error("Error generating enemy:", error);

    // Fallback enemies based on floor
    const enemyTemplates = [
      { name: "Static Wraith", desc: "A ghostly figure crackling with electricity" },
      { name: "Thunder Beast", desc: "A feral creature born from storm clouds" },
      { name: "Volt Sentinel", desc: "A guardian charged with pure lightning" },
      { name: "Storm Phantom", desc: "An ethereal being of condensed thunder" },
      { name: "Electro Golem", desc: "A massive construct powered by lightning" },
    ];

    const template = enemyTemplates[floor % enemyTemplates.length];

    return {
      name: `${template.name} Lv.${floor}`,
      description: template.desc,
      attack,
      defense,
      speed,
      health,
      currentHealth: health,
    };
  }
}

// Battle logic
export interface BattleResult {
  playerDamage: number;
  enemyDamage: number;
  playerNewHealth: number;
  enemyNewHealth: number;
  playerDefeated: boolean;
  enemyDefeated: boolean;
  combatLog: string[];
}

export function processBattleTurn(
  action: "attack" | "defend",
  playerAttack: number,
  playerDefense: number,
  playerSpeed: number,
  playerHealth: number,
  enemyAttack: number,
  enemyDefense: number,
  enemySpeed: number,
  enemyHealth: number
): BattleResult {
  const log: string[] = [];

  // Determine who attacks first based on speed
  const playerGoesFirst = playerSpeed >= enemySpeed;

  let pHealth = playerHealth;
  let eHealth = enemyHealth;
  let playerDamage = 0;
  let enemyDamage = 0;

  // Calculate damage
  if (action === "attack") {
    // Player attacks
    const pDmg = Math.max(1, playerAttack - Math.floor(enemyDefense * 0.5));
    playerDamage = pDmg;
    log.push(`You attack for ${pDmg} damage!`);

    // Enemy retaliates
    const eDmg = Math.max(1, enemyAttack - Math.floor(playerDefense * 0.5));
    enemyDamage = eDmg;
    log.push(`Enemy retaliates for ${eDmg} damage!`);

    if (playerGoesFirst) {
      eHealth -= pDmg;
      if (eHealth > 0) pHealth -= eDmg;
    } else {
      pHealth -= eDmg;
      if (pHealth > 0) eHealth -= pDmg;
    }
  } else {
    // Player defends (reduces damage by 75%)
    const eDmg = Math.max(1, Math.floor((enemyAttack - playerDefense) * 0.25));
    enemyDamage = eDmg;
    log.push(`You defend! Enemy attacks for reduced ${eDmg} damage!`);
    pHealth -= eDmg;
  }

  return {
    playerDamage,
    enemyDamage,
    playerNewHealth: Math.max(0, pHealth),
    enemyNewHealth: Math.max(0, eHealth),
    playerDefeated: pHealth <= 0,
    enemyDefeated: eHealth <= 0,
    combatLog: log,
  };
}

// Weighted random rarity for marble spawning
export function randomRarity(): MarbleRarity {
  const rand = Math.random();
  if (rand < 0.50) return "common";       // 50%
  if (rand < 0.75) return "uncommon";     // 25%
  if (rand < 0.90) return "rare";         // 15%
  if (rand < 0.97) return "epic";         // 7%
  if (rand < 0.995) return "legendary";   // 2.5%
  return "mythic";                        // 0.5%
}
