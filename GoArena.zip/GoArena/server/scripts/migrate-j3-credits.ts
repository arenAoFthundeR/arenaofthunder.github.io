import { storage } from "../storage";
import { readFileSync, existsSync } from "fs";
import { join, dirname } from "path";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);
const dataDir = join(__dirname, "../data");
const memoryPath = join(dataDir, "memory.json");

/**
 * J3 Credit Migration Script
 * 
 * Grants 100 J3 Credits to all existing wallets in memory.json
 * Run this once to migrate existing users to the J3 Allowance System
 * 
 * Usage: tsx server/scripts/migrate-j3-credits.ts
 */
async function migrateJ3Credits() {
  console.log("[J3 Migration] Starting credit migration for existing users...");

  try {
    // Read existing wallet data
    if (!existsSync(memoryPath)) {
      console.log("[J3 Migration] No existing wallets found. Migration complete.");
      return;
    }

    const data = readFileSync(memoryPath, "utf8");
    const memoryStore = JSON.parse(data || '{"wallets":{}}');
    const wallets = Object.keys(memoryStore.wallets || {});

    console.log(`[J3 Migration] Found ${wallets.length} existing wallets`);

    let migrated = 0;
    let skipped = 0;

    for (const wallet of wallets) {
      try {
        // Check if wallet already has credits
        const existingCredits = await storage.getJ3Credits(wallet);
        
        // If wallet already has credits (totalEarned >= initial 100), skip
        // Note: getJ3Credits auto-seeds with 100 J3C, so >= prevents double-granting
        if (existingCredits.totalEarned >= 100) {
          console.log(`[J3 Migration] Skipping ${wallet.slice(0, 8)}... (already has credits)`);
          skipped++;
          continue;
        }

        // Grant initial 100 J3C to existing users (only if totalEarned < 100)
        await storage.adminGrantJ3Credits(wallet, 100);
        migrated++;
        console.log(`[J3 Migration] Granted 100 J3C to ${wallet.slice(0, 8)}...`);
      } catch (error) {
        console.error(`[J3 Migration] Error migrating ${wallet}:`, error);
      }
    }

    console.log(`\n[J3 Migration] Complete!`);
    console.log(`  - Migrated: ${migrated} wallets`);
    console.log(`  - Skipped: ${skipped} wallets`);
    console.log(`  - Total: ${wallets.length} wallets\n`);
  } catch (error) {
    console.error("[J3 Migration] Fatal error:", error);
    process.exit(1);
  }
}

// Run migration
migrateJ3Credits().then(() => {
  console.log("[J3 Migration] Done.");
  process.exit(0);
}).catch((error) => {
  console.error("[J3 Migration] Unhandled error:", error);
  process.exit(1);
});
