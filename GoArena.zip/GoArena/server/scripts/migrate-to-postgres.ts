/**
 * Migration Script: JSON Files → PostgreSQL
 * 
 * Imports all existing JSON data into the PostgreSQL database.
 * Handles:
 * - Wallets (memory.json)
 * - Lore (lore.json)
 * - Tournaments (tournament.json)
 * - Marbles (marbles.json)
 * - Dungeon Runs (dungeons.json)
 * - Security Events (security.json)
 * - Personas (personas.json)
 * - J3 Credits (j3-credits.json)
 * - J3 Usage Logs (j3-usage.json)
 * 
 * Usage: npm run migrate:json-to-db
 */

import { readFileSync, existsSync } from "fs";
import { join, dirname } from "path";
import { fileURLToPath } from "url";
import { db } from "../db.js";
import { pool } from "../db.js";
import { 
  wallets, 
  lore, 
  marbles, 
  dungeonRuns, 
  securityEvents, 
  personas,
  tournamentParticipants,
  tournamentRounds,
  j3Credits,
  j3UsageLogs
} from "@shared/schema";
import type {
  WalletMemory,
  LorePiece,
  TournamentData,
  Marble,
  DungeonRun,
  SecurityEvent,
  Persona,
  J3CreditBalance,
  J3UsageLog,
} from "@shared/schema";

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);
const dataDir = join(__dirname, "../data");

interface MemoryStore {
  wallets: Record<string, WalletMemory>;
}

async function loadJsonFile<T>(filename: string): Promise<T | null> {
  const path = join(dataDir, filename);
  if (!existsSync(path)) {
    console.log(`⚠️  ${filename} not found, skipping...`);
    return null;
  }
  
  try {
    const content = readFileSync(path, "utf-8");
    return JSON.parse(content);
  } catch (error) {
    console.error(`❌ Error reading ${filename}:`, error);
    return null;
  }
}

async function migrateWallets() {
  console.log("\n📦 Migrating wallets...");
  const data = await loadJsonFile<MemoryStore>("memory.json");
  if (!data || !data.wallets) {
    console.log("   No wallet data found");
    return;
  }

  const walletList = Object.values(data.wallets);
  let imported = 0;
  
  for (const wallet of walletList) {
    try {
      await db.insert(wallets).values({
        wallet: wallet.wallet,
        mintCount: wallet.mintCount || 0,
        giftsSent: wallet.giftsSent || 0,
        giftsReceived: wallet.giftsReceived || 0,
        adminXpAdjustment: wallet.adminXpAdjustment || 0,
        seenLoreIds: wallet.seenLoreIds || [],
        firstSeen: new Date(wallet.firstSeen || Date.now()),
        lastSeen: new Date(wallet.lastSeen || Date.now()),
      }).onConflictDoNothing();
      imported++;
    } catch (error) {
      console.error(`   Error importing wallet ${wallet.wallet}:`, error);
    }
  }
  
  console.log(`   ✅ Imported ${imported} wallets`);
}

async function migrateLore() {
  console.log("\n📜 Migrating lore...");
  const data = await loadJsonFile<LorePiece[]>("lore.json");
  if (!data || !Array.isArray(data)) {
    console.log("   No lore data found");
    return;
  }

  let imported = 0;
  
  for (const piece of data) {
    try {
      await db.insert(lore).values({
        id: piece.id,
        title: piece.title,
        text: piece.text,
        createdAt: new Date(),
      }).onConflictDoNothing();
      imported++;
    } catch (error) {
      console.error(`   Error importing lore ${piece.id}:`, error);
    }
  }
  
  console.log(`   ✅ Imported ${imported} lore pieces`);
}

async function migrateTournament() {
  console.log("\n🏆 Migrating tournament data...");
  const data = await loadJsonFile<TournamentData>("tournament.json");
  if (!data) {
    console.log("   No tournament data found");
    return;
  }

  let participantsImported = 0;
  let roundsImported = 0;

  // Import participants - participants is an array of wallet strings
  if (data.participants && Array.isArray(data.participants)) {
    for (const walletAddress of data.participants) {
      try {
        await db.insert(tournamentParticipants).values({
          wallet: walletAddress,
          joinedAt: new Date(),
        }).onConflictDoNothing();
        participantsImported++;
      } catch (error) {
        console.error(`   Error importing participant ${walletAddress}:`, error);
      }
    }
  }

  // Import rounds - rounds is an array of {wallet, round, time}
  // NOTE: 'time' in JSON is elapsed milliseconds, not a wall-clock timestamp
  if (data.rounds && Array.isArray(data.rounds)) {
    for (const round of data.rounds) {
      try {
        // Use current time as completedAt since we don't have the actual completion timestamp
        await db.insert(tournamentRounds).values({
          wallet: round.wallet,
          round: round.round,
          time: round.time, // Preserve original elapsed time value
          completedAt: new Date(), // Set to current time as best approximation
        }).onConflictDoNothing();
        roundsImported++;
      } catch (error) {
        console.error(`   Error importing round for ${round.wallet}:`, error);
      }
    }
  }
  
  console.log(`   ✅ Imported ${participantsImported} participants and ${roundsImported} rounds`);
}

async function migrateMarbles() {
  console.log("\n⚔️  Migrating marbles...");
  const data = await loadJsonFile<Marble[]>("marbles.json");
  if (!data || !Array.isArray(data)) {
    console.log("   No marbles data found");
    return;
  }

  let imported = 0;
  
  for (const marble of data) {
    try {
      await db.insert(marbles).values({
        id: marble.id,
        wallet: marble.wallet,
        name: marble.name,
        description: marble.description,
        rarity: marble.rarity,
        attack: marble.attack,
        defense: marble.defense,
        speed: marble.speed,
        health: marble.health,
        isMinted: marble.isMinted || false,
        tokenId: marble.tokenId,
        txHash: marble.txHash,
        mintedAt: marble.mintedAt ? new Date(marble.mintedAt) : null,
        createdAt: new Date(marble.createdAt || Date.now()),
      }).onConflictDoNothing();
      imported++;
    } catch (error) {
      console.error(`   Error importing marble ${marble.id}:`, error);
    }
  }
  
  console.log(`   ✅ Imported ${imported} marbles`);
}

async function migrateDungeons() {
  console.log("\n🗡️  Migrating dungeon runs...");
  const data = await loadJsonFile<DungeonRun[]>("dungeons.json");
  if (!data || !Array.isArray(data)) {
    console.log("   No dungeon data found");
    return;
  }

  let imported = 0;
  
  for (const run of data) {
    try {
      await db.insert(dungeonRuns).values({
        id: run.id,
        wallet: run.wallet,
        marbleId: run.marbleId,
        currentFloor: run.currentFloor,
        maxFloorReached: run.maxFloorReached,
        status: run.status,
        isActive: run.isActive,
        experienceGained: run.experienceGained,
        currentEnemy: run.currentEnemy || null,
        marbleCurrentHealth: run.marbleCurrentHealth,
        createdAt: new Date(run.createdAt),
        completedAt: run.completedAt ? new Date(run.completedAt) : null,
      }).onConflictDoNothing();
      imported++;
    } catch (error) {
      console.error(`   Error importing dungeon run ${run.id}:`, error);
    }
  }
  
  console.log(`   ✅ Imported ${imported} dungeon runs`);
}

async function migrateSecurityEvents() {
  console.log("\n🔒 Migrating security events...");
  const data = await loadJsonFile<SecurityEvent[]>("security.json");
  if (!data || !Array.isArray(data)) {
    console.log("   No security data found");
    return;
  }

  let imported = 0;
  
  for (const event of data) {
    try {
      await db.insert(securityEvents).values({
        id: event.id,
        wallet: event.wallet,
        eventType: event.eventType,
        severity: event.severity,
        message: event.message,
        details: event.details || {},
        createdAt: new Date(event.createdAt),
      }).onConflictDoNothing();
      imported++;
    } catch (error) {
      console.error(`   Error importing security event ${event.id}:`, error);
    }
  }
  
  console.log(`   ✅ Imported ${imported} security events`);
}

async function migratePersonas() {
  console.log("\n🤖 Migrating personas...");
  const data = await loadJsonFile<Persona[]>("personas.json");
  if (!data || !Array.isArray(data)) {
    console.log("   No personas data found");
    return;
  }

  let imported = 0;
  
  for (const persona of data) {
    try {
      await db.insert(personas).values({
        id: persona.id,
        createdAt: new Date(persona.createdAt),
        lastActive: new Date(persona.lastActive),
        ownerWallet: persona.ownerWallet,
        nftTokenId: persona.nftTokenId,
        nftContract: persona.nftContract,
        aiStylePreset: persona.aiStylePreset,
        customPersonality: persona.customPersonality,
        memory: persona.memory,
        assets: persona.assets || { marbles: [], titles: [], achievements: [] },
        metadata: persona.metadata || {},
        totalConversations: persona.totalConversations || 0,
        totalMessages: persona.totalMessages || 0,
      }).onConflictDoNothing();
      imported++;
    } catch (error) {
      console.error(`   Error importing persona ${persona.id}:`, error);
    }
  }
  
  console.log(`   ✅ Imported ${imported} personas`);
}

async function migrateJ3Credits() {
  console.log("\n💎 Migrating J3 credits...");
  const data = await loadJsonFile<J3CreditBalance[]>("j3-credits.json");
  if (!data || !Array.isArray(data)) {
    console.log("   No J3 credits data found");
    return;
  }

  let imported = 0;
  
  for (const credit of data) {
    try {
      await db.insert(j3Credits).values({
        wallet: credit.wallet,
        balance: credit.balance,
        tier: credit.tier,
        lastRegenerated: new Date(credit.lastRegenerated),
        totalEarned: credit.totalEarned || 0,
        totalSpent: credit.totalSpent || 0,
        gracePeriodMessages: credit.gracePeriodMessages || 0,
        firstSeen: new Date(credit.firstSeen),
        lastUpdated: new Date(credit.lastUpdated),
      }).onConflictDoNothing();
      imported++;
    } catch (error) {
      console.error(`   Error importing J3 credit for ${credit.wallet}:`, error);
    }
  }
  
  console.log(`   ✅ Imported ${imported} J3 credit balances`);
}

async function migrateJ3Usage() {
  console.log("\n📊 Migrating J3 usage logs...");
  const data = await loadJsonFile<J3UsageLog[]>("j3-usage.json");
  if (!data || !Array.isArray(data)) {
    console.log("   No J3 usage data found");
    return;
  }

  let imported = 0;
  
  for (const log of data) {
    try {
      await db.insert(j3UsageLogs).values({
        id: log.id,
        wallet: log.wallet,
        action: log.action,
        creditsChange: log.creditsChange,
        balanceAfter: log.balanceAfter,
        timestamp: new Date(log.timestamp),
        metadata: log.metadata || {},
      }).onConflictDoNothing();
      imported++;
    } catch (error) {
      console.error(`   Error importing J3 usage log ${log.id}:`, error);
    }
  }
  
  console.log(`   ✅ Imported ${imported} J3 usage logs`);
}

async function main() {
  console.log("🚀 Starting JSON → PostgreSQL Migration");
  console.log("=========================================");
  
  const client = await pool.connect();
  
  try {
    // Start transaction for atomic migration
    await client.query('BEGIN');
    console.log("\n📝 Transaction started for atomic migration");

    await migrateWallets();
    await migrateLore();
    await migrateTournament();
    await migrateMarbles();
    await migrateDungeons();
    await migrateSecurityEvents();
    await migratePersonas();
    await migrateJ3Credits();
    await migrateJ3Usage();
    
    // Commit transaction
    await client.query('COMMIT');
    console.log("\n✅ Transaction committed successfully");
    console.log("\n✨ Migration Complete!");
    console.log("=========================================");
  } catch (error) {
    // Rollback on error
    await client.query('ROLLBACK');
    console.error("\n❌ Migration failed - transaction rolled back:", error);
    process.exit(1);
  } finally {
    client.release();
  }
}

main();
