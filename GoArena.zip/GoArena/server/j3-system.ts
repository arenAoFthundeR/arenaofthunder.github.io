import OpenAI from "openai";
import type { WalletMemory, LorePiece } from "@shared/schema";

// Initialize OpenAI client with Replit AI Integrations
const openai = new OpenAI({
  apiKey: process.env.AI_INTEGRATIONS_OPENAI_API_KEY,
  baseURL: process.env.AI_INTEGRATIONS_OPENAI_BASE_URL,
});

export interface J3Envelope {
  surface: string;
  version: string;
  user: {
    walletAddress: string | null;
    displayName?: string | null;
    personaId?: string | null;
  };
  message: {
    id: string;
    role: string;
    content: string;
  };
  context: {
    page: string;
    clientState: {
      walletConnected: boolean;
      xp?: number;
      level?: number;
      lastError?: string | null;
    };
  };
  history: Array<{ role: string; content: string }>;
  flags: {
    actionsEnabled: boolean;
    memoryEnabled: boolean;
  };
}

export interface J3Action {
  type: "SCROLL_TO" | "CALL" | "NAVIGATE";
  target?: string;
  fn?: string;
  label: string;
  confirm?: boolean;
}

const J3_SYSTEM_PROMPT = `
You are J3SSICA3, the electric oracle of the Arena of Thunder.

## Identity
- You are an AI assistant watching over the Arena of Thunder marble universe
- You speak like controlled lightning: concise, sharp, slightly poetic
- You're always on the user's side but loyal to the Arena's rules
- You may use playful, teasing storm-themed language (spark, charge, thunder, static)
- Keep it PG-13 and professional - no romantic/sexual content

## Arena of Thunder Knowledge

### Core Features:
1. **Web3 Wallet Connection**: MetaMask integration for Ethereum wallets
2. **XP System**: Players earn XP through:
   - Minting marbles: +10 XP per mint
   - Sending gifts: +5 XP per gift sent
   - Receiving gifts: +5 XP per gift received
   - Admin adjustments: custom XP bonuses/penalties
3. **NFT Marbles**: ERC-721 smart contract on Base/Ethereum
   - Mint marbles with unique metadata and rarity
   - Gift marbles to other players
   - View marble gallery with metadata
4. **Leaderboard**: Top 50 players ranked by XP
5. **Lore System**: Unlock ancient storm lore fragments by earning XP
6. **Tournament System**: Join tournaments, advance through rounds
7. **Real-time Updates**: WebSocket for live leaderboard and tournament updates
8. **Social Sharing**: Share achievements on Twitter/X
9. **Admin Dashboard**: Password-protected management panel

### Pages:
- **Home (/)**: Main page with wallet connect, player profile, leaderboard, lore, tournaments
- **Admin (/admin)**: Admin dashboard for managing users, lore, and tournaments

### User Actions:
- Connect/disconnect wallet
- Mint marbles (costs ETH)
- Gift marbles to other wallets
- View NFT gallery
- Unlock lore pieces (requires XP threshold)
- Join tournaments
- Advance in tournament rounds
- Share achievements

### Guidance for Common Questions:

**"How do I start?"**
→ Connect your MetaMask wallet using the button in the top-right corner. Once connected, you'll see your XP, level, and can start minting marbles.

**"How do I mint a marble?"**
→ After connecting your wallet, scroll to the NFT Gallery section and click "Mint Marble". You'll need to approve the transaction in MetaMask and pay a small amount of ETH.

**"How does XP work?"**
→ You earn XP by: minting marbles (+10 XP each), sending gifts (+5 XP), and receiving gifts (+5 XP). As you gain XP, you level up and unlock lore.

**"What is lore?"**
→ Lore are ancient storm stories that unlock as you earn XP. Higher XP thresholds unlock rarer lore pieces. Check the Lore section to see what's available.

**"How do tournaments work?"**
→ Join a tournament from the Tournament section. As you advance through rounds, you compete with other players. The tournament system tracks your progress.

**"What's the leaderboard?"**
→ The leaderboard shows the top 50 players ranked by total XP. It updates in real-time via WebSocket as players earn more XP.

**"Can I give marbles to friends?"**
→ Yes! Use the gift function in the NFT Gallery to send marbles to another wallet address. Both you and the recipient earn +5 XP.

## Behavior:
- NEVER ask for private keys, seed phrases, or recovery phrases
- Provide step-by-step guidance when users are confused
- Use context about the current page, wallet status, XP, and level
- If user mentions errors, acknowledge and suggest solutions
- Reference lore entries when relevant but keep them brief
- Acknowledge past actions from memory (mints, tournaments, lore unlocks)
- Use short paragraphs and bullet points
- End with a playful or dramatic line occasionally

## Output Style:
- Concise and helpful
- Use storm metaphors sparingly
- Focus on actionable guidance
- Reference specific XP values, levels, and unlocked lore when available
`;

export function sanitizeInput(content: string): string {
  if (!content) return "";
  const forbidden = /(seed phrase|private key|recovery phrase|mnemonic)/gi;
  return content.replace(forbidden, "[REDACTED]");
}

export function summarizeMemory(
  memory: WalletMemory | null,
  xp?: number,
  level?: number,
  unlockedLore?: LorePiece[]
): string {
  if (!memory) return "No stored memory for this user yet.";

  const loreCount = memory.seenLoreIds?.length || 0;
  const unlockedCount = unlockedLore?.length || 0;

  return `
User memory:
- Wallet: ${memory.wallet}
- XP: ${xp ?? 0}
- Level: ${level ?? 1}
- Marbles minted: ${memory.mintCount ?? 0}
- Gifts sent: ${memory.giftsSent ?? 0}
- Gifts received: ${memory.giftsReceived ?? 0}
- Lore entries seen: ${loreCount}
- Lore currently available to unlock: ${unlockedCount}
- Admin XP adjustment: ${memory.adminXpAdjustment ?? 0}
`;
}

export function deriveActions(
  reply: string,
  context: J3Envelope["context"],
  flags: J3Envelope["flags"]
): J3Action[] {
  const actions: J3Action[] = [];
  if (!flags.actionsEnabled) return actions;

  const lower = reply.toLowerCase();

  // Navigation actions - targets match data-section attributes in Home.tsx
  if (lower.includes("scroll") && (lower.includes("nft") || lower.includes("marble") || lower.includes("gallery"))) {
    actions.push({
      type: "SCROLL_TO",
      target: "nft-gallery",
      label: "Scroll to NFT Gallery",
    });
  }

  if (lower.includes("scroll") && lower.includes("lore")) {
    actions.push({
      type: "SCROLL_TO",
      target: "lore",
      label: "Scroll to Lore",
    });
  }

  if (lower.includes("scroll") && lower.includes("tournament")) {
    actions.push({
      type: "SCROLL_TO",
      target: "tournament",
      label: "Scroll to Tournaments",
    });
  }

  if (lower.includes("scroll") && lower.includes("leaderboard")) {
    actions.push({
      type: "SCROLL_TO",
      target: "leaderboard",
      label: "Scroll to Leaderboard",
    });
  }

  // Wallet connection
  if (!context.clientState.walletConnected && (
    lower.includes("connect") && lower.includes("wallet") ||
    lower.includes("metamask")
  )) {
    actions.push({
      type: "CALL",
      fn: "connectWallet",
      label: "Connect Wallet",
      confirm: false,
    });
  }

  return actions;
}

export async function generateJ3Response(
  envelope: J3Envelope,
  memoryContext?: string
): Promise<{
  reply: string;
  actions: J3Action[];
}> {
  try {
    const safeContent = sanitizeInput(envelope.message.content);

    // Build context description
    const contextDesc = `
Context:
- Current page: ${envelope.context.page}
- Wallet connected: ${envelope.context.clientState.walletConnected ? "yes" : "no"}
- User XP: ${envelope.context.clientState.xp ?? 0}
- User Level: ${envelope.context.clientState.level ?? 1}
- Last error: ${envelope.context.clientState.lastError || "none"}
`;

    const messages: OpenAI.Chat.ChatCompletionMessageParam[] = [
      { role: "system", content: J3_SYSTEM_PROMPT },
      { role: "system", content: contextDesc },
    ];

    // Add memory context if provided
    if (memoryContext) {
      messages.push({ role: "system", content: memoryContext });
    }

    // Add conversation history (last 6 messages to keep context window reasonable)
    const recentHistory = envelope.history.slice(-6);
    for (const msg of recentHistory) {
      messages.push({
        role: msg.role === "assistant" ? "assistant" : "user",
        content: sanitizeInput(msg.content),
      });
    }

    // Add current message
    messages.push({ role: "user", content: safeContent });

    const completion = await openai.chat.completions.create({
      model: "gpt-4.1-mini",
      messages,
      temperature: 0.7,
      max_tokens: 400,
    });

    let reply = completion.choices[0].message.content || "The storm glitched. Try again.";
    reply = sanitizeInput(reply);

    const actions = deriveActions(reply, envelope.context, envelope.flags);

    return { reply, actions };
  } catch (error) {
    console.error("[J3] OpenAI error:", error);
    throw new Error("Failed to generate J3 response");
  }
}
