import { WebSocketServer, WebSocket } from "ws";
import { type Server } from "http";
import { log } from "./vite";

export interface WSMessage {
  type: "leaderboard_update" | "tournament_join" | "tournament_advance" | "xp_update" | "tournament_reset";
  data: any;
}

let wss: WebSocketServer | null = null;
const clients: Set<WebSocket> = new Set();

export function setupWebSocket(server: Server): WebSocketServer {
  wss = new WebSocketServer({ server, path: "/ws" });

  wss.on("connection", (ws: WebSocket) => {
    clients.add(ws);
    log(`WebSocket client connected. Total clients: ${clients.size}`, "websocket");

    ws.on("close", () => {
      clients.delete(ws);
      log(`WebSocket client disconnected. Total clients: ${clients.size}`, "websocket");
    });

    ws.on("error", (error) => {
      log(`WebSocket error: ${error.message}`, "websocket");
      clients.delete(ws);
    });

    ws.send(JSON.stringify({
      type: "connection_established",
      data: { message: "Connected to Arena of Thunder WebSocket" }
    }));
  });

  wss.on("error", (error) => {
    log(`WebSocket server error: ${error.message}`, "websocket");
  });

  return wss;
}

export function broadcast(message: WSMessage) {
  if (!wss || clients.size === 0) {
    return;
  }

  const payload = JSON.stringify(message);
  let successCount = 0;
  let failCount = 0;

  clients.forEach((client) => {
    if (client.readyState === WebSocket.OPEN) {
      try {
        client.send(payload);
        successCount++;
      } catch (error) {
        failCount++;
        log(`Failed to send message to client: ${error}`, "websocket");
      }
    } else {
      clients.delete(client);
    }
  });

  if (successCount > 0) {
    log(`Broadcast ${message.type} to ${successCount} clients`, "websocket");
  }
  if (failCount > 0) {
    log(`Failed to broadcast to ${failCount} clients`, "websocket");
  }
}

export function getClientCount(): number {
  return clients.size;
}
