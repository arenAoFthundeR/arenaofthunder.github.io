import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { walletRequestSchema, loreUnlockRequestSchema, memoryUpdateSchema } from "@shared/schema";
import { z } from "zod";
import { broadcast } from "./websocket";
import { adminAuth, verifyAdminPassword } from "./admin-middleware";
import { generateJ3Response, summarizeMemory, type J3Envelope } from "./j3-system";
import { gyroscopeConfigSchema, insertGestureTriggerSchema } from "@shared/gyro-schema";
import { createPersonaSchema, personaChatRequestSchema } from "@shared/schema";
import DOMPurify from "isomorphic-dompurify";
import { 
  generateMarble, 
  generateDungeonEnemy, 
  processBattleTurn, 
  randomRarity 
} from "./marble-dungeon-service";
import { 
  createMarbleSchema, 
  createDungeonRunSchema, 
  dungeonActionSchema,
  createSecurityEventSchema 
} from "@shared/schema";
import { treasuryService } from "./treasury-service";
import type { ActivityEventType } from "@shared/schema";

// Activity tracking helper - async, non-blocking
async function trackActivity(
  wallet: string,
  eventType: ActivityEventType,
  description: string,
  metadata: Record<string, unknown> = {}
): Promise<void> {
  try {
    await storage.createActivity({
      wallet,
      eventType,
      description,
      metadata,
    });
  } catch (error) {
    // Log error but don't throw - activity tracking should never break user actions
    console.error(`[Activity] Failed to track ${eventType} for ${wallet}:`, error);
  }
}

export async function registerRoutes(app: Express): Promise<Server> {
  // Simple in-memory rate limiter for J3 endpoints (scoped to route registration)
  interface RateLimitEntry {
    count: number;
    resetTime: number;
  }

  const rateLimitMap = new Map<string, RateLimitEntry>();

  // Rate limit: 10 requests per minute per wallet for J3 chat
  const J3_RATE_LIMIT = 10;
  const J3_WINDOW_MS = 60 * 1000; // 1 minute

  function j3RateLimiter(wallet: string): boolean {
    const now = Date.now();
    const entry = rateLimitMap.get(wallet);

    if (!entry || now > entry.resetTime) {
      // Create new window
      rateLimitMap.set(wallet, {
        count: 1,
        resetTime: now + J3_WINDOW_MS,
      });
      return true;
    }

    if (entry.count >= J3_RATE_LIMIT) {
      return false; // Rate limit exceeded
    }

    entry.count++;
    return true;
  }

  // Cleanup old entries every 5 minutes
  const cleanupInterval = setInterval(() => {
    const now = Date.now();
    for (const [wallet, entry] of rateLimitMap.entries()) {
      if (now > entry.resetTime) {
        rateLimitMap.delete(wallet);
      }
    }
  }, 5 * 60 * 1000);
  // XP System
  app.post("/api/xp/get", async (req, res) => {
    try {
      const { wallet } = walletRequestSchema.parse(req.body);
      const xpData = await storage.getXpData(wallet);
      res.json(xpData);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: "Invalid wallet address" });
      }
      console.error("[XP] Error:", error);
      res.status(500).json({ error: "Failed to fetch XP data" });
    }
  });

  // Leaderboard
  app.get("/api/leaderboard", async (_req, res) => {
    try {
      const leaderboard = await storage.getLeaderboard(50);
      res.json(leaderboard);
    } catch (error) {
      console.error("[Leaderboard] Error:", error);
      res.status(500).json({ error: "Failed to fetch leaderboard" });
    }
  });

  // Lore System
  app.post("/api/lore/list", async (req, res) => {
    try {
      const { wallet } = walletRequestSchema.parse(req.body);
      const lore = await storage.getLoreForWallet(wallet);
      res.json(lore);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: "Invalid wallet address" });
      }
      console.error("[Lore] Error:", error);
      res.status(500).json({ error: "Failed to fetch lore" });
    }
  });

  app.post("/api/lore/unlock", async (req, res) => {
    try {
      const { wallet, id } = loreUnlockRequestSchema.parse(req.body);
      await storage.unlockLore(wallet, id);
      
      // Award J3 Credits for unlocking lore (+15 J3C)
      await storage.updateJ3Credits(wallet, 15, "unlock_lore", {
        loreId: id,
      });
      
      const updatedLore = await storage.getLoreForWallet(wallet);
      const unlockedPiece = updatedLore.find((l) => l.id === id);
      
      // Track lore unlock activity
      if (unlockedPiece) {
        trackActivity(wallet, "lore_unlocked", `Unlocked lore: ${unlockedPiece.title}`, { loreId: id, title: unlockedPiece.title }).catch(() => {});
      }
      
      res.json({
        success: true,
        lore: unlockedPiece,
      });
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: "Invalid request data" });
      }
      console.error("[Lore Unlock] Error:", error);
      res.status(500).json({ error: "Failed to unlock lore" });
    }
  });

  // Tournament System
  app.get("/api/tournament/status", async (_req, res) => {
    try {
      const tournament = await storage.getTournamentData();
      res.json(tournament);
    } catch (error) {
      console.error("[Tournament Status] Error:", error);
      res.status(500).json({ error: "Failed to fetch tournament status" });
    }
  });

  app.post("/api/tournament/join", async (req, res) => {
    try {
      const { wallet } = walletRequestSchema.parse(req.body);
      await storage.joinTournament(wallet);
      
      // Award J3 Credits for joining tournament (+20 J3C)
      await storage.updateJ3Credits(wallet, 20, "join_tournament");
      
      const tournament = await storage.getTournamentData();
      
      // Track tournament join activity
      trackActivity(wallet, "tournament_joined", "Joined the Arena Tournament", { participantCount: tournament.participants.length }).catch(() => {});
      
      // Broadcast tournament update to all connected clients
      broadcast({
        type: "tournament_join",
        data: {
          wallet,
          participants: tournament.participants,
          totalParticipants: tournament.participants.length,
        },
      });
      
      res.json({
        success: true,
        participants: tournament.participants,
      });
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: "Invalid wallet address" });
      }
      console.error("[Tournament Join] Error:", error);
      res.status(500).json({ error: "Failed to join tournament" });
    }
  });

  app.post("/api/tournament/advance", async (req, res) => {
    try {
      const { wallet } = walletRequestSchema.parse(req.body);
      const currentRound = await storage.advanceTournament(wallet);
      
      // Award J3 Credits for advancing in tournament (+25 J3C)
      await storage.updateJ3Credits(wallet, 25, "advance_round", {
        round: currentRound,
      });
      
      // Track tournament round completion activity
      trackActivity(wallet, "tournament_round_completed", `Completed tournament round ${currentRound}`, { round: currentRound }).catch(() => {});
      
      // Broadcast tournament advancement to all connected clients
      broadcast({
        type: "tournament_advance",
        data: {
          wallet,
          currentRound,
        },
      });
      
      res.json({
        success: true,
        currentRound,
      });
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: "Invalid wallet address" });
      }
      console.error("[Tournament Advance] Error:", error);
      res.status(500).json({ error: "Failed to advance round" });
    }
  });

  // Memory System
  app.post("/api/memory/get", async (req, res) => {
    try {
      const { wallet } = walletRequestSchema.parse(req.body);
      const memory = await storage.getWalletMemory(wallet);
      res.json(memory || {});
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: "Invalid wallet address" });
      }
      console.error("[Memory Get] Error:", error);
      res.status(500).json({ error: "Failed to fetch memory" });
    }
  });

  app.post("/api/memory/set", async (req, res) => {
    try {
      const { wallet, changes } = memoryUpdateSchema.parse(req.body);
      const updated = await storage.updateWalletMemory(wallet, changes);
      res.json(updated);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: "Invalid request data" });
      }
      console.error("[Memory Set] Error:", error);
      res.status(500).json({ error: "Failed to update memory" });
    }
  });

  // Blockchain Actions
  app.post("/api/blockchain/mint", async (req, res) => {
    try {
      const { wallet } = walletRequestSchema.parse(req.body);
      const memory = await storage.getWalletMemory(wallet);
      const newMintCount = (memory?.mintCount || 0) + 1;
      
      // Update mint count - XP is calculated automatically via calculateXp(mintCount * 10 + giftCount * 5)
      await storage.updateWalletMemory(wallet, {
        mintCount: newMintCount,
      });
      
      // Award J3 Credits for minting (+10 J3C)
      await storage.updateJ3Credits(wallet, 10, "mint_marble", {
        marbleCount: newMintCount,
      });
      
      // Fetch updated XP data with new calculations
      const xpData = await storage.getXpData(wallet);
      
      // Broadcast XP update to all clients (affects leaderboard)
      broadcast({
        type: "xp_update",
        data: {
          wallet,
          xp: xpData.xp,
          level: xpData.level,
        },
      });
      
      res.json({
        success: true,
        mintCount: newMintCount,
        xpData,
      });
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: "Invalid wallet address" });
      }
      console.error("[Mint] Error:", error);
      res.status(500).json({ error: "Failed to record mint" });
    }
  });

  app.post("/api/blockchain/gift", async (req, res) => {
    try {
      const schema = z.object({
        from: z.string().regex(/^0x[a-fA-F0-9]{40}$/, "Invalid sender address"),
        to: z.string().regex(/^0x[a-fA-F0-9]{40}$/, "Invalid recipient address"),
      });
      const { from, to } = schema.parse(req.body);
      
      // Update sender's gifts sent count (+5 XP via calculateXp)
      const fromMemory = await storage.getWalletMemory(from);
      await storage.updateWalletMemory(from, {
        giftsSent: (fromMemory?.giftsSent || 0) + 1,
      });
      
      // Award J3 Credits to sender (+5 J3C)
      await storage.updateJ3Credits(from, 5, "send_gift", {
        recipientWallet: to,
      });
      
      // Update recipient's gifts received count (+5 XP via calculateXp)
      // updateWalletMemory handles initialization if wallet is new
      const toMemory = await storage.getWalletMemory(to);
      await storage.updateWalletMemory(to, {
        giftsReceived: (toMemory?.giftsReceived || 0) + 1,
      });
      
      // Award J3 Credits to recipient (+5 J3C)
      await storage.updateJ3Credits(to, 5, "receive_gift", {
        senderWallet: from,
      });
      
      const fromXpData = await storage.getXpData(from);
      const toXpData = await storage.getXpData(to);
      
      // Track gift activities for both sender and receiver
      trackActivity(from, "marble_gifted_sent", `Sent a marble gift to ${to.substring(0, 6)}...${to.substring(38)}`, { recipientWallet: to }).catch(() => {});
      trackActivity(to, "marble_gifted_received", `Received a marble gift from ${from.substring(0, 6)}...${from.substring(38)}`, { senderWallet: from }).catch(() => {});
      
      // Broadcast XP updates for both sender and recipient
      broadcast({
        type: "xp_update",
        data: {
          wallet: from,
          xp: fromXpData.xp,
          level: fromXpData.level,
        },
      });
      broadcast({
        type: "xp_update",
        data: {
          wallet: to,
          xp: toXpData.xp,
          level: toXpData.level,
        },
      });
      
      res.json({
        success: true,
        from: fromXpData,
        to: toXpData,
      });
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: "Invalid request data" });
      }
      console.error("[Gift] Error:", error);
      res.status(500).json({ error: "Failed to record gift" });
    }
  });

  // Admin Authentication
  app.post("/api/admin/auth", async (req, res) => {
    try {
      const schema = z.object({
        password: z.string(),
      });
      const { password } = schema.parse(req.body);
      
      if (verifyAdminPassword(password)) {
        res.json({
          success: true,
          token: password,
        });
      } else {
        res.status(401).json({ error: "Invalid admin password" });
      }
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: "Invalid request" });
      }
      res.status(500).json({ error: "Authentication failed" });
    }
  });

  // Admin - User Management
  app.get("/api/admin/wallets", adminAuth, async (_req, res) => {
    try {
      const wallets = await storage.getAllWallets();
      res.json(wallets);
    } catch (error) {
      console.error("[Admin - Get Wallets] Error:", error);
      res.status(500).json({ error: "Failed to fetch wallets" });
    }
  });

  app.post("/api/admin/wallet/xp", adminAuth, async (req, res) => {
    try {
      const schema = z.object({
        wallet: z.string().regex(/^0x[a-fA-F0-9]{40}$/),
        adjustment: z.number(),
      });
      const { wallet, adjustment } = schema.parse(req.body);
      
      const updated = await storage.adminUpdateWalletXp(wallet, adjustment);
      const xpData = await storage.getXpData(wallet);
      
      broadcast({
        type: "xp_update",
        data: {
          wallet,
          xp: xpData.xp,
          level: xpData.level,
        },
      });
      
      res.json({ success: true, wallet: updated, xpData });
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: "Invalid request data" });
      }
      console.error("[Admin - Update XP] Error:", error);
      res.status(500).json({ error: "Failed to update wallet XP" });
    }
  });

  // Admin - Lore Management
  app.get("/api/admin/lore", adminAuth, async (_req, res) => {
    try {
      const lore = await storage.getAllLore();
      res.json(lore);
    } catch (error) {
      console.error("[Admin - Get Lore] Error:", error);
      res.status(500).json({ error: "Failed to fetch lore" });
    }
  });

  app.post("/api/admin/lore", adminAuth, async (req, res) => {
    try {
      const schema = z.object({
        title: z.string(),
        text: z.string(),
      });
      const { title, text } = schema.parse(req.body);
      
      const newLore = await storage.createLore({ title, text });
      res.json({ success: true, lore: newLore });
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: "Invalid request data" });
      }
      console.error("[Admin - Create Lore] Error:", error);
      res.status(500).json({ error: "Failed to create lore" });
    }
  });

  app.put("/api/admin/lore/:id", adminAuth, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const schema = z.object({
        title: z.string().optional(),
        text: z.string().optional(),
      });
      const updates = schema.parse(req.body);
      
      await storage.updateLore(id, updates);
      res.json({ success: true });
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: "Invalid request data" });
      }
      console.error("[Admin - Update Lore] Error:", error);
      res.status(500).json({ error: "Failed to update lore" });
    }
  });

  app.delete("/api/admin/lore/:id", adminAuth, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      await storage.deleteLore(id);
      res.json({ success: true });
    } catch (error) {
      console.error("[Admin - Delete Lore] Error:", error);
      res.status(500).json({ error: "Failed to delete lore" });
    }
  });

  // Admin - Tournament Management
  app.post("/api/admin/tournament/reset", adminAuth, async (_req, res) => {
    try {
      await storage.resetTournament();
      
      broadcast({
        type: "tournament_reset",
        data: {},
      });
      
      res.json({ success: true });
    } catch (error) {
      console.error("[Admin - Reset Tournament] Error:", error);
      res.status(500).json({ error: "Failed to reset tournament" });
    }
  });

  // Admin - J3 Credit Management
  app.get("/api/admin/j3/credits", adminAuth, async (_req, res) => {
    try {
      const credits = await storage.getAllJ3Credits();
      res.json(credits);
    } catch (error) {
      console.error("[Admin - Get J3 Credits] Error:", error);
      res.status(500).json({ error: "Failed to fetch credit balances" });
    }
  });

  app.post("/api/admin/j3/grant", adminAuth, async (req, res) => {
    try {
      const schema = z.object({
        wallet: z.string().regex(/^0x[a-fA-F0-9]{40}$/),
        amount: z.number(),
      });
      const { wallet, amount } = schema.parse(req.body);
      
      const updatedCredits = await storage.adminGrantJ3Credits(wallet, amount);
      res.json(updatedCredits);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: "Invalid request data" });
      }
      console.error("[Admin - Grant J3 Credits] Error:", error);
      res.status(500).json({ error: "Failed to grant credits" });
    }
  });

  app.get("/api/admin/j3/usage", adminAuth, async (req, res) => {
    try {
      const wallet = req.query.wallet as string | undefined;
      const limit = parseInt(req.query.limit as string) || 100;
      
      if (wallet) {
        const usage = await storage.getJ3UsageHistory(wallet, limit);
        res.json(usage);
      } else {
        // Return all usage logs (not wallet-specific)
        const usage = await storage.getJ3UsageHistory("", 1000);
        res.json(usage);
      }
    } catch (error) {
      console.error("[Admin - Get J3 Usage] Error:", error);
      res.status(500).json({ error: "Failed to fetch usage logs" });
    }
  });

  // Treasury Routes
  app.get("/api/treasury/info", async (_req, res) => {
    try {
      const address = treasuryService.getAddress();
      const balance = await treasuryService.getBalance();
      res.json({ address, balance });
    } catch (error) {
      console.error("[Treasury - Info] Error:", error);
      res.status(500).json({ error: "Failed to fetch treasury info" });
    }
  });

  app.post("/api/treasury/send", adminAuth, async (req, res) => {
    try {
      const { ethers } = await import('ethers');
      const MAX_TRANSFER_WEI = ethers.parseEther("10"); // 10 ETH in wei
      
      const schema = z.object({
        recipient: z.string()
          .min(42, "Invalid Ethereum address")
          .max(42, "Invalid Ethereum address")
          .regex(/^0x[a-fA-F0-9]{40}$/, "Invalid Ethereum address format"),
        amount: z.string()
          .min(1, "Amount required")
          .regex(/^\d+(\.\d{1,18})?$/, "Amount must have at most 18 decimal places")
          .refine((val) => {
            try {
              const parsed = ethers.parseEther(val);
              return parsed > BigInt(0) && parsed <= MAX_TRANSFER_WEI;
            } catch {
              return false;
            }
          }, "Amount must be greater than 0 and not exceed 10 ETH per transaction"),
      });
      const { recipient, amount } = schema.parse(req.body);

      const result = await treasuryService.sendReward(recipient, amount);
      
      if (!result.success) {
        return res.status(400).json({ error: result.error });
      }

      res.json({ 
        success: true, 
        txHash: result.txHash,
        message: `Sent ${amount} ETH to ${recipient}` 
      });
    } catch (error) {
      if (error instanceof z.ZodError) {
        const firstError = error.errors[0];
        return res.status(400).json({ error: firstError.message || "Invalid request data" });
      }
      console.error("[Treasury - Send] Error:", error);
      res.status(500).json({ error: "Failed to send funds" });
    }
  });

  app.post("/api/treasury/estimate-gas", adminAuth, async (req, res) => {
    try {
      const { ethers } = await import('ethers');
      const MAX_TRANSFER_WEI = ethers.parseEther("10"); // 10 ETH in wei
      
      const schema = z.object({
        recipient: z.string()
          .min(42, "Invalid Ethereum address")
          .max(42, "Invalid Ethereum address")
          .regex(/^0x[a-fA-F0-9]{40}$/, "Invalid Ethereum address format"),
        amount: z.string()
          .min(1, "Amount required")
          .regex(/^\d+(\.\d{1,18})?$/, "Amount must have at most 18 decimal places")
          .refine((val) => {
            try {
              const parsed = ethers.parseEther(val);
              return parsed > BigInt(0) && parsed <= MAX_TRANSFER_WEI;
            } catch {
              return false;
            }
          }, "Amount must be greater than 0 and not exceed 10 ETH per transaction"),
      });
      const { recipient, amount } = schema.parse(req.body);

      const gasCost = await treasuryService.estimateGasCost(recipient, amount);
      res.json({ gasCost });
    } catch (error) {
      if (error instanceof z.ZodError) {
        const firstError = error.errors[0];
        return res.status(400).json({ error: firstError.message || "Invalid request data" });
      }
      console.error("[Treasury - Estimate Gas] Error:", error);
      res.status(500).json({ error: "Failed to estimate gas" });
    }
  });

  // Marble Routes
  app.post("/api/marbles/list", async (req, res) => {
    try {
      const { wallet } = walletRequestSchema.parse(req.body);
      const marbles = await storage.getMarblesByWallet(wallet);
      res.json(marbles);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: "Invalid wallet address" });
      }
      console.error("[Marbles - List] Error:", error);
      res.status(500).json({ error: "Failed to fetch marbles" });
    }
  });

  app.post("/api/marbles/create", async (req, res) => {
    try {
      const { wallet } = walletRequestSchema.parse(req.body);
      
      // Generate random rarity and AI-generated marble
      const rarity = randomRarity();
      const marbleData = await generateMarble(rarity);
      
      const marble = await storage.createMarble({
        wallet,
        rarity,
        ...marbleData,
      });
      
      res.json(marble);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: "Invalid wallet address" });
      }
      console.error("[Marbles - Create] Error:", error);
      res.status(500).json({ error: "Failed to create marble" });
    }
  });

  app.post("/api/marbles/update-mint", async (req, res) => {
    try {
      const schema = z.object({
        marbleId: z.number(),
        tokenId: z.number(),
        txHash: z.string(),
      });
      const { marbleId, tokenId, txHash } = schema.parse(req.body);
      
      await storage.updateMarble(marbleId, {
        isMinted: true,
        tokenId,
        txHash,
        mintedAt: new Date().toISOString(),
      });
      
      const marble = await storage.getMarbleById(marbleId);
      
      // Track marble minting activity
      if (marble) {
        trackActivity(
          marble.wallet,
          "marble_minted",
          `Minted ${marble.rarity} marble: ${marble.name}`,
          { marbleId, tokenId, txHash, rarity: marble.rarity }
        ).catch(() => {}); // Non-blocking
      }
      
      res.json(marble);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: "Invalid request data" });
      }
      console.error("[Marbles - Update Mint] Error:", error);
      res.status(500).json({ error: "Failed to update marble mint status" });
    }
  });

  // Dungeon Routes
  app.post("/api/dungeons/active", async (req, res) => {
    try {
      const { wallet } = walletRequestSchema.parse(req.body);
      const activeRun = await storage.getActiveDungeonRun(wallet);
      res.json(activeRun || null);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: "Invalid wallet address" });
      }
      console.error("[Dungeons - Active] Error:", error);
      res.status(500).json({ error: "Failed to fetch active dungeon run" });
    }
  });

  app.post("/api/dungeons/start", async (req, res) => {
    try {
      const { wallet, marbleId } = createDungeonRunSchema.parse(req.body);
      
      // Check for existing active run
      const existingRun = await storage.getActiveDungeonRun(wallet);
      if (existingRun) {
        return res.status(400).json({ error: "You already have an active dungeon run" });
      }
      
      // Create new dungeon run
      const run = await storage.createDungeonRun({ wallet, marbleId });
      
      // Generate first enemy
      const enemy = await generateDungeonEnemy(1);
      await storage.updateDungeonRun(run.id, { currentEnemy: enemy });
      
      const updatedRun = await storage.getDungeonRunById(run.id);
      
      // Track dungeon start activity
      const marble = await storage.getMarbleById(marbleId);
      if (marble) {
        trackActivity(wallet, "dungeon_started", `Started dungeon run with ${marble.name}`, { runId: run.id, marbleId, marbleName: marble.name }).catch(() => {});
      }
      
      res.json(updatedRun);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: "Invalid request data" });
      }
      console.error("[Dungeons - Start] Error:", error);
      res.status(500).json({ error: "Failed to start dungeon run" });
    }
  });

  app.post("/api/dungeons/action", async (req, res) => {
    try {
      const schema = z.object({
        wallet: z.string(),
        runId: z.number(),
        action: z.enum(["attack", "defend", "retreat"]),
      });
      const { wallet, runId, action } = schema.parse(req.body);
      
      const run = await storage.getDungeonRunById(runId);
      if (!run || !run.isActive) {
        return res.status(400).json({ error: "No active dungeon run found" });
      }
      
      // SECURITY: Verify run belongs to this wallet
      if (run.wallet.toLowerCase() !== wallet.toLowerCase()) {
        return res.status(403).json({ error: "Unauthorized: This dungeon run belongs to another player" });
      }
      
      // Handle retreat
      if (action === "retreat") {
        await storage.updateDungeonRun(runId, {
          status: "retreat",
          isActive: false,
          completedAt: new Date().toISOString(),
        });
        
        const updatedRun = await storage.getDungeonRunById(runId);
        return res.json({
          run: updatedRun,
          result: "retreat",
          message: "You retreated from the dungeon safely.",
        });
      }
      
      // Get marble and enemy data
      const marble = await storage.getMarbleById(run.marbleId);
      if (!marble || !run.currentEnemy) {
        return res.status(400).json({ error: "Invalid dungeon state" });
      }
      
      // SECURITY: Verify marble belongs to this wallet
      if (marble.wallet.toLowerCase() !== wallet.toLowerCase()) {
        return res.status(403).json({ error: "Unauthorized: This marble belongs to another player" });
      }
      
      // Process battle turn
      const battleResult = processBattleTurn(
        action,
        marble.attack,
        marble.defense,
        marble.speed,
        run.marbleCurrentHealth,
        run.currentEnemy.attack,
        run.currentEnemy.defense,
        run.currentEnemy.speed,
        run.currentEnemy.currentHealth
      );
      
      // Update enemy health
      const updatedEnemy = {
        ...run.currentEnemy,
        currentHealth: battleResult.enemyNewHealth,
      };
      
      let result: string;
      let updates: Partial<typeof run> = {
        marbleCurrentHealth: battleResult.playerNewHealth,
        currentEnemy: updatedEnemy,
      };
      
      // Check for player defeat
      if (battleResult.playerDefeated) {
        result = "defeat";
        updates = {
          ...updates,
          status: "defeat",
          isActive: false,
          completedAt: new Date().toISOString(),
        };
      }
      // Check for enemy defeat
      else if (battleResult.enemyDefeated) {
        const xpGain = 10 + run.currentFloor * 5;
        const nextFloor = run.currentFloor + 1;
        
        updates = {
          ...updates,
          experienceGained: run.experienceGained + xpGain,
          currentFloor: nextFloor,
          maxFloorReached: Math.max(run.maxFloorReached, nextFloor),
        };
        
        // Generate next enemy
        const nextEnemy = await generateDungeonEnemy(nextFloor);
        updates.currentEnemy = nextEnemy;
        
        // Reset marble health for next floor
        updates.marbleCurrentHealth = marble.health;
        
        result = "victory";
      } else {
        result = "continue";
      }
      
      await storage.updateDungeonRun(runId, updates);
      const updatedRun = await storage.getDungeonRunById(runId);
      
      res.json({
        run: updatedRun,
        result,
        battleResult,
      });
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: "Invalid request data" });
      }
      console.error("[Dungeons - Action] Error:", error);
      res.status(500).json({ error: "Failed to process dungeon action" });
    }
  });

  app.post("/api/dungeons/history", async (req, res) => {
    try {
      const { wallet } = walletRequestSchema.parse(req.body);
      const history = await storage.getDungeonHistory(wallet);
      res.json(history);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: "Invalid wallet address" });
      }
      console.error("[Dungeons - History] Error:", error);
      res.status(500).json({ error: "Failed to fetch dungeon history" });
    }
  });

  // Security Console Routes
  app.post("/api/security/events", async (req, res) => {
    try {
      const { wallet } = walletRequestSchema.parse(req.body);
      const events = await storage.getSecurityEvents(wallet);
      res.json(events);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: "Invalid wallet address" });
      }
      console.error("[Security - Events] Error:", error);
      res.status(500).json({ error: "Failed to fetch security events" });
    }
  });

  app.post("/api/security/create", async (req, res) => {
    try {
      const eventData = createSecurityEventSchema.parse(req.body);
      
      // SECURITY: Verify wallet has at least one minted marble (NFT holder check)
      const marbles = await storage.getMarblesByWallet(eventData.wallet);
      const hasMintedMarbles = marbles.some((m) => m.isMinted);
      
      if (!hasMintedMarbles) {
        return res.status(403).json({ error: "Access denied: Security Console requires NFT ownership" });
      }
      
      const event = await storage.createSecurityEvent(eventData);
      res.json(event);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: "Invalid event data" });
      }
      console.error("[Security - Create Event] Error:", error);
      res.status(500).json({ error: "Failed to create security event" });
    }
  });

  app.post("/api/security/clear", async (req, res) => {
    try {
      const { wallet } = walletRequestSchema.parse(req.body);
      
      // SECURITY: Verify wallet has at least one minted marble (NFT holder check)
      const marbles = await storage.getMarblesByWallet(wallet);
      const hasMintedMarbles = marbles.some((m) => m.isMinted);
      
      if (!hasMintedMarbles) {
        return res.status(403).json({ error: "Access denied: Security Console requires NFT ownership" });
      }
      
      await storage.clearSecurityEvents(wallet);
      res.json({ success: true });
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: "Invalid wallet address" });
      }
      console.error("[Security - Clear] Error:", error);
      res.status(500).json({ error: "Failed to clear security events" });
    }
  });

  // J3SSICA3 AI Assistant Routes
  app.get("/api/j3/ping", (_req, res) => {
    res.json({ status: "ok", ts: Date.now() });
  });

  app.post("/api/j3/chat", async (req, res) => {
    try {
      const envelope = req.body as J3Envelope;
      const wallet = envelope.user.walletAddress;

      // Require wallet for credit system
      if (!wallet) {
        return res.status(400).json({
          reply: "Connect your wallet to chat with J3SSICA3. The storm needs to know who you are.",
          actions: [],
          error: "wallet_required"
        });
      }

      // Check rate limiting
      if (!j3RateLimiter(wallet)) {
        return res.status(429).json({
          reply: "Whoa there, thunderstruck one. You're sending too many messages too fast. Take a breath—I'll be here when the storm settles.",
          actions: [],
          error: "rate_limit_exceeded"
        });
      }

      // Try to regenerate daily credits if eligible
      await storage.regenerateDailyCredits(wallet);

      // Get credit balance and deduct credits (handles grace period automatically)
      let creditBalance;
      try {
        creditBalance = await storage.deductJ3Credits(wallet, 5); // 5 J3C per message
      } catch (error) {
        const credits = await storage.getJ3Credits(wallet);
        return res.status(402).json({
          reply: `You're out of J3 Credits, friend. You need ${5 - credits.balance} more J3C to chat. Earn more by minting marbles, joining tournaments, or unlocking lore!`,
          actions: [{
            type: "earn_credits",
            label: "How to Earn J3C"
          }],
          error: "insufficient_credits",
          balance: credits.balance,
          tier: credits.tier
        });
      }
      
      // Get user context if wallet is provided
      let memoryContext: string | undefined;
      if (envelope.flags.memoryEnabled && wallet) {
        const memory = await storage.getWalletMemory(wallet);
        const xpData = await storage.getXpData(wallet);
        const lore = await storage.getLoreForWallet(wallet);
        const unlockedLore = lore.filter(l => !l.unlocked);
        
        memoryContext = summarizeMemory(memory, xpData.xp, xpData.level, unlockedLore);
        
        // Fetch J3 long-term memory (persona-specific if personaId provided)
        const personaId = envelope.user.personaId || null;
        const j3Memory = await storage.getLatestJ3Memory(wallet, personaId);
        
        // Enhance memory context with long-term learning + credit awareness
        if (j3Memory) {
          const factsSummary = j3Memory.learnedFacts.length > 0 
            ? `\n\nLearned facts about user:\n${j3Memory.learnedFacts.slice(-5).map(f => `- ${f}`).join('\n')}`
            : '';
          const prefsSummary = Object.keys(j3Memory.preferences).length > 0
            ? `\n\nUser preferences: ${JSON.stringify(j3Memory.preferences)}`
            : '';
          const convSummary = j3Memory.conversationSummary 
            ? `\n\nConversation history: ${j3Memory.conversationSummary}`
            : '';
          
          memoryContext += factsSummary + prefsSummary + convSummary;
        }
        
        // Add credit-aware guidance
        const tierName = creditBalance.tier.replace('_', ' ').toLowerCase();
        memoryContext += `\n\nJ3C Status: ${creditBalance.balance} credits | Tier: ${tierName} | Grace: ${creditBalance.gracePeriodMessages} msgs remaining`;
        memoryContext += `\n[If user seems low on credits or asks how to earn, suggest: mint marbles (+10), unlock lore (+15), tournaments (+20/25), daily regen (+10 after 24h)]`;
      }

      // Generate AI response with memory context
      const result = await generateJ3Response(envelope, memoryContext);

      // Asynchronously save conversation to history + update long-term memory
      if (wallet && envelope.flags.memoryEnabled) {
        const personaId = envelope.user.personaId || null;
        const userMsg = envelope.message.content;
        const assistantReply = result.reply;
        
        // Save to conversation history
        try {
          // Get or create ongoing conversation for this wallet/persona
          const existingConvos = await storage.getConversations(wallet, personaId);
          let conversation;
          
          if (existingConvos.length === 0) {
            // Create first conversation with title from first message
            const title = userMsg.slice(0, 60) + (userMsg.length > 60 ? '...' : '');
            conversation = await storage.createConversation({
              wallet,
              personaId: personaId,
              title: title || "Conversation with J3SSICA3",
            });
          } else {
            // Use most recent conversation
            conversation = existingConvos[0];
          }
          
          // Save user message
          await storage.addMessage({
            conversationId: conversation.id,
            role: "user",
            content: userMsg,
            creditsSpent: 0,
          });
          
          // Save assistant message
          const creditsDeducted = creditBalance.gracePeriodMessages > 0 ? 0 : 5;
          await storage.addMessage({
            conversationId: conversation.id,
            role: "assistant",
            content: assistantReply,
            creditsSpent: creditsDeducted,
          });
          
          // Update conversation stats
          await storage.updateConversationStats(conversation.id, creditsDeducted);
        } catch (convError) {
          console.error("[J3] Error saving conversation history:", convError);
          // Don't fail the request if conversation saving fails
        }
        
        // Simple conversation summary for long-term memory
        const interactionSummary = `User: "${userMsg.slice(0, 100)}${userMsg.length > 100 ? '...' : ''}" → J3: "${assistantReply.slice(0, 100)}${assistantReply.length > 100 ? '...' : ''}"`;
        
        const existingMemory = await storage.getLatestJ3Memory(wallet, personaId);
        if (existingMemory) {
          // Update existing memory
          const newSummary = `${existingMemory.conversationSummary}\n${interactionSummary}`.slice(-1000); // Keep last 1000 chars
          await storage.updateJ3Memory(existingMemory.id, {
            conversationSummary: newSummary,
            interactionCount: existingMemory.interactionCount + 1,
          });
        } else {
          // Create new memory entry
          await storage.createJ3Memory({
            wallet,
            personaId: personaId,
            conversationSummary: interactionSummary,
            learnedFacts: [],
            preferences: {},
            metadata: { firstInteraction: new Date().toISOString() },
            interactionCount: 1,
          });
        }
      }

      // Add credit info to response
      res.json({
        ...result,
        credits: {
          balance: creditBalance.balance,
          tier: creditBalance.tier,
          deducted: creditBalance.gracePeriodMessages > 0 ? 0 : 5,
          gracePeriodRemaining: creditBalance.gracePeriodMessages
        }
      });
    } catch (error) {
      console.error("[J3] Chat error:", error);
      res.status(500).json({
        reply: "The storm glitched on my side. Try again in a moment—or refresh and call me back.",
        actions: [],
      });
    }
  });

  // J3 Credit System Endpoints
  app.get("/api/j3/credits/:wallet", async (req, res) => {
    try {
      const { wallet } = req.params;
      
      if (!wallet) {
        return res.status(400).json({ error: "Wallet address required" });
      }

      // Try to regenerate daily credits first
      await storage.regenerateDailyCredits(wallet);
      
      const credits = await storage.getJ3Credits(wallet);
      res.json(credits);
    } catch (error) {
      console.error("[J3 Credits] Error fetching credits:", error);
      res.status(500).json({ error: "Failed to fetch credit balance" });
    }
  });

  app.post("/api/j3/credits/earn", async (req, res) => {
    try {
      const { wallet, action, metadata } = req.body;
      
      if (!wallet || !action) {
        return res.status(400).json({ error: "Wallet and action required" });
      }

      // Define credit rewards for different actions
      const creditRewards: Record<string, number> = {
        wallet_connect: 50,   // One-time bonus
        mint_marble: 10,
        send_gift: 5,
        receive_gift: 5,
        unlock_lore: 15,
        join_tournament: 20,
        advance_round: 25,
      };

      const creditsToAward = creditRewards[action];
      if (!creditsToAward) {
        return res.status(400).json({ error: "Invalid action type" });
      }

      // For wallet_connect, check if this is first time (prevent farming)
      if (action === "wallet_connect") {
        const currentCredits = await storage.getJ3Credits(wallet);
        const usageHistory = await storage.getJ3UsageHistory(wallet, 1000);
        const hasConnectedBefore = usageHistory.some(log => log.action === "wallet_connect");
        
        if (hasConnectedBefore) {
          return res.status(400).json({ 
            error: "Wallet connect bonus already claimed",
            credits: currentCredits
          });
        }
      }

      const updatedCredits = await storage.updateJ3Credits(
        wallet,
        creditsToAward,
        action as any,
        metadata
      );

      res.json({
        success: true,
        credited: creditsToAward,
        balance: updatedCredits.balance,
        tier: updatedCredits.tier,
        action,
      });
    } catch (error) {
      console.error("[J3 Credits] Error earning credits:", error);
      res.status(500).json({ error: "Failed to award credits" });
    }
  });

  app.get("/api/j3/usage/:wallet", async (req, res) => {
    try {
      const { wallet } = req.params;
      const limit = parseInt(req.query.limit as string) || 100;
      
      if (!wallet) {
        return res.status(400).json({ error: "Wallet address required" });
      }

      const usageHistory = await storage.getJ3UsageHistory(wallet, limit);
      res.json(usageHistory);
    } catch (error) {
      console.error("[J3 Credits] Error fetching usage history:", error);
      res.status(500).json({ error: "Failed to fetch usage history" });
    }
  });

  // J3 Conversation History
  app.get("/api/j3/conversations/:wallet", async (req, res) => {
    try {
      const { wallet } = req.params;
      const personaId = req.query.personaId as string | undefined;
      
      if (!wallet) {
        return res.status(400).json({ error: "Wallet address required" });
      }

      const conversations = await storage.getConversations(
        wallet,
        personaId === undefined ? undefined : personaId || null
      );
      res.json(conversations);
    } catch (error) {
      console.error("[J3 Conversations] Error fetching conversations:", error);
      res.status(500).json({ error: "Failed to fetch conversations" });
    }
  });

  app.get("/api/j3/conversations/:id/messages", async (req, res) => {
    try {
      const conversationId = parseInt(req.params.id);
      
      if (isNaN(conversationId)) {
        return res.status(400).json({ error: "Invalid conversation ID" });
      }

      const messages = await storage.getMessages(conversationId);
      res.json(messages);
    } catch (error) {
      console.error("[J3 Conversations] Error fetching messages:", error);
      res.status(500).json({ error: "Failed to fetch messages" });
    }
  });

  // User Activity Timeline API
  app.post("/api/activities/list", async (req, res) => {
    try {
      const schema = z.object({
        wallet: z.string(),
        eventType: z.string().optional(),
        limit: z.number().optional(),
      });
      const { wallet, eventType, limit } = schema.parse(req.body);

      const activities = await storage.getUserActivities(wallet, eventType || null, limit || 100);
      res.json(activities);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: "Invalid request data" });
      }
      console.error("[Activities] Error fetching activities:", error);
      res.status(500).json({ error: "Failed to fetch activities" });
    }
  });

  app.post("/api/activities/stats", async (req, res) => {
    try {
      const { wallet } = walletRequestSchema.parse(req.body);

      const stats = await storage.getActivityStats(wallet);
      res.json(stats);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: "Invalid wallet address" });
      }
      console.error("[Activities] Error fetching stats:", error);
      res.status(500).json({ error: "Failed to fetch activity stats" });
    }
  });

  // Gyroscope Code Injection System
  app.get("/api/gyro/config", async (_req, res) => {
    try {
      const config = await storage.getGyroscopeConfig();
      res.json(config);
    } catch (error) {
      console.error("[Gyro] Error fetching config:", error);
      res.status(500).json({ error: "Failed to fetch gyroscope config" });
    }
  });

  app.patch("/api/gyro/config", adminAuth, async (req, res) => {
    try {
      const updates = req.body;
      const config = await storage.updateGyroscopeConfig(updates);
      res.json(config);
    } catch (error) {
      console.error("[Gyro] Error updating config:", error);
      res.status(500).json({ error: "Failed to update gyroscope config" });
    }
  });

  app.get("/api/gyro/triggers", async (_req, res) => {
    try {
      const triggers = await storage.getGestureTriggers();
      res.json(triggers);
    } catch (error) {
      console.error("[Gyro] Error fetching triggers:", error);
      res.status(500).json({ error: "Failed to fetch gesture triggers" });
    }
  });

  app.post("/api/gyro/triggers", adminAuth, async (req, res) => {
    try {
      const trigger = insertGestureTriggerSchema.parse(req.body);
      const created = await storage.createGestureTrigger(trigger);
      res.json(created);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: "Invalid trigger data" });
      }
      console.error("[Gyro] Error creating trigger:", error);
      res.status(500).json({ error: "Failed to create gesture trigger" });
    }
  });

  app.patch("/api/gyro/triggers/:id", adminAuth, async (req, res) => {
    try {
      const { id } = req.params;
      const updates = req.body;
      const updated = await storage.updateGestureTrigger(id, updates);
      res.json(updated);
    } catch (error) {
      console.error("[Gyro] Error updating trigger:", error);
      res.status(500).json({ error: "Failed to update gesture trigger" });
    }
  });

  app.delete("/api/gyro/triggers/:id", adminAuth, async (req, res) => {
    try {
      const { id } = req.params;
      await storage.deleteGestureTrigger(id);
      res.json({ success: true });
    } catch (error) {
      console.error("[Gyro] Error deleting trigger:", error);
      res.status(500).json({ error: "Failed to delete gesture trigger" });
    }
  });

  // Planning Documents (admin-protected)
  const planningDocs = new Map([
    ["J3SSICA3_ALLOWANCE_PLAN.md", "J3SSICA3_ALLOWANCE_PLAN.md"],
    ["ARTICLE_NOTES.md", "ARTICLE_NOTES.md"],
    ["ARENA_ROADMAP.md", "ARENA_ROADMAP.md"],
    ["PLANNING_SUMMARY.md", "PLANNING_SUMMARY.md"],
  ]);

  app.get("/api/planning/:filename", adminAuth, async (req, res) => {
    try {
      const { filename } = req.params;
      
      // Strict allow-list validation - prevent path traversal
      if (!planningDocs.has(filename)) {
        return res.status(404).json({ error: "Document not found" });
      }

      const fs = await import("fs/promises");
      const path = await import("path");
      const filePath = path.resolve(process.cwd(), planningDocs.get(filename)!);
      
      // Additional security: ensure resolved path is in project root
      const projectRoot = process.cwd();
      if (!filePath.startsWith(projectRoot)) {
        return res.status(403).json({ error: "Access denied" });
      }

      const content = await fs.readFile(filePath, "utf-8");
      
      // Note: Content is raw markdown (plain text), not HTML
      // Client will parse markdown to HTML and sanitize
      // No server-side HTML sanitization needed for plain markdown files
      
      res.setHeader("Content-Type", "application/json");
      res.setHeader("Cache-Control", "private, max-age=300");
      res.json({ content });
    } catch (error) {
      console.error("[Planning] Error reading document:", error);
      res.status(500).json({ error: "Failed to read document" });
    }
  });

  // ========================================
  // NFT Persona System (J3SSICA3-managed infinite storage)
  // Separate microservice within this codebase
  // ========================================

  // Create new persona (with Zod validation)
  app.post("/api/persona/create", async (req, res) => {
    try {
      // Validate input with Zod schema
      const validatedData = createPersonaSchema.parse(req.body);
      
      const persona = await storage.createPersona(validatedData);

      console.log(`[Persona] Created new persona: ${persona.id}`);
      res.json(persona);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: "Invalid input", details: error.errors });
      }
      console.error("[Persona] Create error:", error);
      res.status(500).json({ error: "Failed to create persona" });
    }
  });

  // Get persona by ID
  app.get("/api/persona/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const persona = await storage.getPersona(id);
      
      if (!persona) {
        return res.status(404).json({ error: "Persona not found" });
      }

      res.json(persona);
    } catch (error) {
      console.error("[Persona] Get error:", error);
      res.status(500).json({ error: "Failed to retrieve persona" });
    }
  });

  // Chat with persona (J3SSICA3 integration with validation)
  app.post("/api/persona/:id/chat", async (req, res) => {
    try {
      const { id } = req.params;
      
      // Validate chat request with Zod schema
      const { message, context } = personaChatRequestSchema.parse({
        personaId: id,
        message: req.body.message,
        context: req.body.context,
      });

      const persona = await storage.getPersona(id);
      if (!persona) {
        return res.status(404).json({ error: "Persona not found" });
      }

      // Build conversation context for J3SSICA3
      const conversationHistory = persona.memory.shortTerm.slice(-10); // Last 10 messages
      const systemPrompt = `You are J3SSICA3, an AI managing NFT personas in the Arena of Thunder universe.

Current Persona Details:
- Persona ID: ${persona.id}
- AI Style: ${persona.aiStylePreset}
${persona.customPersonality ? `- Custom Personality: ${persona.customPersonality}` : ''}
${persona.memory.longTerm.length > 0 ? `- Important Memories: ${persona.memory.longTerm.map(m => m.summary).join('; ')}` : ''}

Respond in character based on this persona's unique style and personality. Maintain continuity with the conversation history and persona's established traits.`;

      // Call OpenAI directly for persona management using proper SDK types
      const OpenAILib = await import("openai");
      const openai = new OpenAILib.default({ apiKey: process.env.OPENAI_API_KEY });
      
      // Build messages array using OpenAI SDK types
      const messages: Array<{
        role: "system" | "user" | "assistant";
        content: string;
      }> = [];
      
      // System prompt
      messages.push({ role: "system", content: systemPrompt });
      
      // Add conversation history
      for (const m of conversationHistory) {
        messages.push({
          role: m.role === "assistant" ? "assistant" : "user",
          content: m.content,
        });
      }
      
      // Add current user message
      messages.push({ role: "user", content: message });

      const completion = await openai.chat.completions.create({
        model: "gpt-4.1-mini",
        messages: messages as any, // TypeScript workaround - types are correct at runtime
        temperature: 0.8, // Higher creativity for unique personas
        max_tokens: 500,
      });

      const reply = completion.choices[0].message.content || "Connection lost to the persona. Try again.";
      const timestamp = new Date().toISOString();

      // Update persona memory (CRITICAL: This persists the conversation)
      const updatedShortTerm = [
        ...persona.memory.shortTerm,
        { role: "user" as const, content: message, timestamp },
        { role: "assistant" as const, content: reply, timestamp },
      ];

      // Keep only last 50 messages in short-term memory
      if (updatedShortTerm.length > 50) {
        updatedShortTerm.splice(0, updatedShortTerm.length - 50);
      }

      // Create long-term memory summary every 10 messages
      const updatedLongTerm = [...persona.memory.longTerm];
      if ((persona.totalMessages + 1) % 10 === 0) {
        updatedLongTerm.push({
          summary: `After ${persona.totalMessages + 1} messages, key topics: ${reply.slice(0, 100)}...`,
          importance: 5,
          createdAt: timestamp,
        });
      }

      // **CRITICAL FIX**: Actually persist the updated memory to storage
      const updatedPersona = await storage.updatePersona(id, {
        memory: {
          shortTerm: updatedShortTerm,
          longTerm: updatedLongTerm,
        },
        totalMessages: persona.totalMessages + 1,
        totalConversations: persona.totalConversations + (persona.totalMessages === 0 ? 1 : 0),
      });

      console.log(`[Persona] Chat processed for ${id}, total messages: ${updatedPersona.totalMessages}`);

      res.json({
        reply,
        personaId: id,
        timestamp,
        memoryUpdated: true,
      });
    } catch (error) {
      console.error("[Persona] Chat error:", error);
      res.status(500).json({ error: "Failed to process chat" });
    }
  });

  // Get personas by wallet
  app.get("/api/persona/wallet/:wallet", async (req, res) => {
    try {
      const { wallet } = req.params;
      const personas = await storage.getPersonasByWallet(wallet);
      res.json(personas);
    } catch (error) {
      console.error("[Persona] Get by wallet error:", error);
      res.status(500).json({ error: "Failed to retrieve personas" });
    }
  });

  // Admin: Get all personas (admin auth required)
  app.get("/api/persona/admin/all", adminAuth, async (req, res) => {
    try {
      const personas = await storage.getAllPersonas();
      res.json(personas);
    } catch (error) {
      console.error("[Persona] Admin get all error:", error);
      res.status(500).json({ error: "Failed to retrieve all personas" });
    }
  });

  // Admin: Delete persona (admin auth required)
  app.delete("/api/persona/admin/:id", adminAuth, async (req, res) => {
    try {
      const { id } = req.params;
      await storage.deletePersona(id);
      res.json({ success: true, message: "Persona deleted" });
    } catch (error) {
      console.error("[Persona] Admin delete error:", error);
      res.status(500).json({ error: "Failed to delete persona" });
    }
  });

  // Health check
  app.get("/api/health", (_req, res) => {
    res.json({
      status: "ok",
      service: "arena-of-thunder",
      timestamp: new Date().toISOString(),
    });
  });

  const httpServer = createServer(app);
  return httpServer;
}
