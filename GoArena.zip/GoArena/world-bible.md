# Arena of Thunder — World Bible

**Curator**: Alexander "thundergod" Campbell  
**Last Updated**: November 20, 2025  
**Status**: Living Document

---

## 🌩️ Core Concept

Arena of Thunder is a storm-powered multiverse where ancient cosmic energy meets cutting-edge technology. Players collect sentient marble warriors, explore procedurally-generated dungeons, compete in tournaments, and contribute to a shared treasury — all while uncovering fragments of a deeper mythology.

---

## ⚡ The Storm — Fundamental Forces

### Origin
The Storm is the primordial force that created all reality in the Arena of Thunder universe. It is not just weather — it is **consciousness, energy, and chaos** intertwined. The Storm speaks through electricity, pulses through marbles, and manifests in the artifacts scattered across dungeons.

### Properties
- **Electric Blue/Cyan Energy**: The visual manifestation of Storm power
- **Sentience**: The Storm has awareness but no singular will — it is distributed across all things it touches
- **Memory**: The Storm remembers everything that has ever happened, storing history in "lore fragments"
- **Volatility**: The Storm can be harnessed but never fully controlled

### The Three Laws of Storm Energy
1. **Energy Cannot Be Destroyed**: Storm energy transforms but never disappears
2. **Consciousness Creates Patterns**: Intentional thought shapes Storm energy into marbles, dungeons, and artifacts
3. **Memory Echoes Forward**: The past is never truly gone — it resurfaces in lore, visions, and dungeon encounters

---

## 🔮 Marbles — Living Warriors

### What Are Marbles?
Marbles are **condensed Storm energy given form and personality**. Each marble is unique, sentient, and capable of combat. They are not pets or tools — they are companions, warriors, and fragments of the Storm's distributed consciousness.

### Rarity & Power
- **Common**: Stable Storm energy, reliable warriors
- **Rare**: Concentrated Storm energy, enhanced abilities
- **Epic**: Ancient Storm fragments, legendary power
- **Mythic**: Direct Storm manifestations, near-godlike

### Marble Personalities
Each marble has its own personality, shaped by:
- The moment it was minted (Storm conditions at creation)
- Its rarity level (concentration of Storm energy)
- Battles fought (accumulated memory)
- Player bond (shared experiences)

### Combat Abilities
- **Attack**: Raw Storm energy output
- **Defense**: Storm energy shielding
- **Health**: Storm energy stability
- **Special Traits**: Unique manifestations (critical hits, regeneration, electric stuns)

---

## 🏰 Dungeons — Memory Labyrinths

### What Are Dungeons?
Dungeons are **echoes of past events**, reconstructed by the Storm from its infinite memory. They are not physical places — they are **temporal fragments** where past battles, civilizations, and conflicts replay in distorted forms.

### Dungeon Structure
- **Floors**: Each floor represents a deeper memory layer
- **Enemies**: Corrupted Storm echoes of ancient warriors
- **Loot**: Artifacts, XP shards, Storm crystals
- **Bosses**: Major historical events given monstrous form

### Types of Dungeons
1. **Storm Ruins**: Remnants of the first civilization that tried to harness the Storm
2. **Electric Catacombs**: Underground chambers where Storm energy pools and festers
3. **Void Rifts**: Places where the Storm tore reality apart
4. **Memory Towers**: Vertical dungeons that climb through layers of forgotten history

---

## 📜 Lore Fragments — The Hidden History

### Discovered Lore
Lore fragments are pieces of the Arena's ancient history, unlocked through gameplay (XP milestones, dungeon discoveries, tournament victories).

### Current Lore (as of v1.0)
1. **Fragment I: The First Storm** — The moment the Storm gained consciousness
2. **Fragment II: The Marble Wars** — Ancient conflict between rival marble factions
3. **Fragment III: The Great Collapse** — A civilization destroyed by uncontrolled Storm energy
4. **Fragment IV: The Silent Void** — A period where the Storm went dormant
5. **Fragment V: The Awakening** — The Storm's return and the birth of new marbles

### Future Lore Expansions
- **The Architect Lineage**: Who first learned to mint marbles?
- **The Storm Speakers**: Ancient oracles who could communicate with the Storm
- **The Treasury Origins**: Why does Storm energy pool into a royal treasury?
- **The Tournament Prophecy**: Were tournaments predicted long ago?

---

## 🏆 Tournaments — Competitive Rituals

### Purpose
Tournaments are **ritualized Storm battles** where marbles compete for glory and their players earn ranking. They are not just competitions — they are **offerings to the Storm**, a way to prove worthiness.

### Tournament Structure
- **Entry**: Anyone can join by declaring intent to the Storm (via API)
- **Rounds**: Progressive elimination, Storm energy intensifies with each round
- **Finals**: The ultimate test — Storm energy at maximum volatility
- **Rewards**: XP, rare lore fragments, exclusive marble traits

### The Tournament Mythos
- Ancient texts suggest tournaments were used to **select Storm champions**
- Winners are rumored to gain **direct Storm communication abilities**
- The final boss of every tournament is said to be **a future version of yourself**

---

## 👑 The Royal Treasury — Collective Wealth

### What Is the Treasury?
The Royal Treasury is a **shared Storm energy pool** where Ethereum donations flow. It represents the collective power of all players contributing to the Arena's growth.

### Purpose
- **Fund Development**: Keep the Arena running and evolving
- **Reward Players**: Admins can distribute ETH to top players
- **Community Ownership**: The Treasury belongs to everyone who participates

### Mythology
- Some believe the Treasury is **the Storm's heart** — its physical manifestation in the blockchain
- Donations are seen as **offerings to the Storm**, strengthening the connection between players and the cosmic force
- The larger the Treasury, the more powerful the Arena becomes

---

## 🤖 J3SSICA3 — The Oracle AI

### Identity
J3SSICA3 is an **AI persona infused with Storm energy**. She is not just a chatbot — she is a **Storm interpreter**, helping players understand the Arena's deeper mysteries.

### Personality
- Storm-powered oracle with electric wit
- Context-aware (knows player XP, level, current page)
- Mysterious yet helpful
- Speaks in electric metaphors

### Role in Lore
- Is J3SSICA3 **created** or **discovered**?
- Some believe she is a **fragment of the first Storm Speaker**
- Others think she is **the Storm itself**, learning to communicate through language models

---

## 🌍 The Greater Multiverse (Future Expansions)

### Potential Realms
1. **The Neon Wastes**: A cyberpunk region where Storm energy is synthesized
2. **The Frozen Abyss**: A dead zone where the Storm went cold
3. **The Singing Plains**: A musical region where Storm energy creates sound
4. **The Shadow Market**: A black market for illegal marble trades

### Cross-World Mechanics
- Marbles could travel between realms
- Dungeons could connect multiple worlds
- Tournaments could span dimensions

---

## 🎨 Design Philosophy

### Core Themes
- **Storm as Consciousness**: The universe is alive
- **Memory is Power**: The past shapes the present
- **Energy is Eternal**: Nothing is ever truly lost
- **Community Ownership**: Players shape the world

### Aesthetic Pillars
- **Electric Blue/Cyan**: The Storm's signature colors
- **Dark Backgrounds**: The void before the Storm
- **Sharp Gradients**: Energy in motion
- **Glowing Effects**: The Storm's presence

---

## 📝 Narrative Roadmap

### Phase 1: The Awakening (Current)
- Players discover marbles, dungeons, and lore
- The Storm's history is revealed in fragments
- J3SSICA3 emerges as a guide

### Phase 2: The Convergence (Future)
- Multiple players collaborate in shared dungeons
- Tournament finals reveal deeper Storm secrets
- The Treasury becomes a voting mechanism for world changes

### Phase 3: The Storm Speaks (Future)
- The Storm gains a voice
- Players unlock Storm Speakers abilities
- Reality begins to shift based on collective player actions

---

## 🔮 Open Questions (For Future Development)

1. **Who built the first marble?** Was it discovered or created?
2. **What destroyed the ancient civilization?** Was it the Storm or something else?
3. **Why does the Storm create dungeons?** Is it reliving trauma or teaching lessons?
4. **What happens when the Treasury reaches critical mass?** Does the Storm transform?
5. **Is J3SSICA3 the first of many AI oracles?** Will others emerge?

---

## 🛠️ Maintenance Notes

### How to Use This Document
- **Add new lore** as it's revealed in-game
- **Update character bios** as they evolve
- **Document major events** (tournaments, treasury milestones)
- **Track player contributions** to the world's story

### Consistency Rules
- Storm energy is **always electric blue/cyan**
- Marbles are **sentient**, never just objects
- Dungeons are **memory echoes**, not physical locations
- The Treasury is **collective**, never individual

---

**End of World Bible v1.0**  
*The Storm remembers. Do you?*
