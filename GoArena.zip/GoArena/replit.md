# Alexander Campbell Portfolio + Arena of Thunder

## Overview
This project is a hybrid application serving two main purposes: a professional portfolio for Alexander Campbell, showcasing his work in game design, AI, and creative fields, and a live, interactive Web3 demo platform called "Arena of Thunder." The portfolio highlights his expertise, while Arena of Thunder functions as a fully interactive decentralized application (dApp) demonstrating blockchain integration, game mechanics, and AI experimentation. The ambition is to provide a living demonstration of cutting-edge web technologies and creative development.

## User Preferences
- **Brand Name**: "thundergod" (lowercase, never "Thundergod")
- **Typography**: Space Grotesk (headings) + Inter (body) for portfolio sections; Segoe UI Historic reserved for lore-heavy Arena content via `.font-historic` utility classes
- **Design Philosophy**: Storm/electric aesthetic is fundamental - electric blue/cyan must dominate all visual elements

## System Architecture
The application is built with a dual-purpose architecture:
-   **Frontend**: Developed with React 18 and TypeScript, utilizing Tailwind CSS for styling with a custom storm theme (electric blue/cyan), TanStack Query for data fetching, ethers.js for Web3 wallet integration (MetaMask), Wouter for routing, and Shadcn UI components.
-   **Backend**: An Express.js server with TypeScript, employing a RESTful API architecture. **Data persistence** upgraded to PostgreSQL via Drizzle ORM with comprehensive database schemas for wallets, lore, tournaments, J3 credits, marbles, dungeons, personas, and security events. Migration utilities support importing from legacy JSON files (`memory.json`, `lore.json`, `tournament.json`). CORS and security middleware are implemented.
-   **Database Infrastructure** (Phase 4 - COMPLETE Nov 2025): Production-ready PostgreSQL backend with 10 tables, 25+ performance indexes (including composite indexes for leaderboard/dungeon/persona queries), JSONB columns for flexible metadata, full relational integrity, and timestamp tracking. Complete DatabaseStorage implementation (800+ lines) with type-safe timestamp handling, atomic migration script with transaction rollback, and all IStorage methods. Architect-approved for production deployment. Migration utilities in `server/scripts/migrate-to-postgres.ts`. Drizzle ORM with Neon Serverless for scalability.
-   **Shared**: Contains shared TypeScript types and Zod schemas for consistency between frontend and backend.
-   **Design System**: Features a dark storm theme with electric blue (#38bdf8) and cyan (#06b6d4) accents, elevated dark cards, and gradient backgrounds. Typography uses Space Grotesk for headings, Inter for body text, and JetBrains Mono for monospace elements. Visual effects include electric glows, smooth hover elevations, and loading skeletons.
-   **Core Features**:
    -   **Web3 Wallet Connection**: MetaMask integration.
    -   **XP System**: Tracks player progress based on in-game actions.
    -   **Blockchain Integration**: ERC-721 smart contract for NFT marbles with rarity.
    -   **NFT Gallery**: Displays owned NFTs.
    -   **Leaderboard**: Ranks players based on XP.
    -   **Lore Progression**: Unlocks narrative fragments.
    -   **Tournament System**: Allows participation in competitive events.
    -   **Treasury Ticker**: Displays live treasury information.
    -   **Real-Time Updates**: WebSocket integration for live data.
    -   **Social Sharing**: Enables sharing achievements.
    -   **Admin Dashboard**: Password-protected for managing game elements (5 tabs: Users, Lore, Tournament, J3 Credits, Gyroscope).
    -   **J3SSICA3 AI Assistant**: An OpenAI-powered chat assistant providing context-aware guidance with long-term memory and credit-aware responses.
    -   **J3 Allowance System** (Phase 1 Complete - Nov 2025): Sustainable credit-based economy for J3SSICA3 AI chat. New wallets start with 100 J3C + 3 free messages. Messages cost 5 J3C each. Players earn credits through gameplay (mint +10, gift +5, lore +15, tournament +20/25, daily +10). 5-tier progression system (Novice to Legend). Rate limiting (10 req/min) prevents abuse. Full admin management via dashboard tab. Documentation: J3_ALLOWANCE_SYSTEM.md.
    -   **J3 Long-Term Memory System** (COMPLETE Nov 2025): PostgreSQL-backed conversational memory enabling J3SSICA3 to remember user preferences, learned facts, and conversation history across sessions. Supports persona-specific memory slices via wallet+personaId composite key. Each chat interaction asynchronously persists summaries to j3_memories table. NULL-safe persona filtering via buildPersonaCondition() helper prevents SQL comparison bugs. Credit-aware guidance automatically suggests earning opportunities based on current balance and tier. Architect-verified for production.
    -   **J3 Conversation History System** (COMPLETE Nov 2025): Full conversation transcription and replay capability for J3SSICA3 chat sessions. Two-table design (`j3_conversations` for metadata, `j3_messages` for content) tracks all user-assistant exchanges with credit costs and timestamps. One ongoing conversation per wallet/persona combination - auto-creates on first message, appends thereafter. Frontend dialog UI displays conversation list with stats (message count, total credits spent) and full message-by-message replay with timestamps. NULL-safe persona filtering, composite indexes for performance, cascade deletes for data integrity. Integrated into J3Chat component via History button. REST API endpoints: GET conversations by wallet, GET messages by conversation ID. Architect-verified for production.
    -   **User Activity Timeline System** (COMPLETE Nov 2025): Comprehensive activity tracking and display for all user actions across the Arena platform. PostgreSQL `user_activities` table with 20+ event types (marble_minted, marble_gifted_sent/received, lore_unlocked, tournament_joined/advanced, dungeon_started, credits_earned, persona_created, j3_chat_message, wallet_connected, level_up). Fire-and-forget trackActivity helper integrated into 6+ critical endpoints prevents logging from blocking main flows. POST API endpoints (`/api/activities/list`, `/api/activities/stats`) with Zod validation and event filtering. Frontend ActivityTimeline component with storm-themed UI, event-specific icons/colors, filtering dropdown, stats display, and relative timestamps. Accessible via dedicated /activity route in Arena navigation dropdown. Performance indexes on wallet and eventType columns. Architect-verified for production.
    -   **Planning Documents Viewer**: Accessible at /planning route - displays all J3 Allowance planning documents and roadmaps.
    -   **Gyroscope Code Injection System**: Admin-configurable motion-triggered code execution for mobile devices. Supports 5 gesture types (shake, tilt, rotate, flip, twist) with customizable thresholds and JavaScript code injection. Auto-initializes on app load via Device Motion/Orientation APIs. Full documentation in GYROSCOPE_SYSTEM.md.
    -   **NFT Persona System**: Separate microservice for J3SSICA3-managed infinite storage AI. Each connection can spawn a unique NFT-linked persona with distinct personality, memory (short/long-term), and conversation continuity. File-based storage in personas.json, scalable to database. API namespace `/api/persona/*` independent from Arena routes. 8 AI personality presets available (aggressive, gentle, chaotic_neutral, wise_elder, rebellious, protective, analytical, empathetic). Full input validation with Zod schemas, admin-protected management endpoints.
-   **World Bible**: A comprehensive `world-bible.md` document serves as a living repository for all lore, mythology, and narrative elements, including The Storm, Marbles, Dungeons, Lore Fragments, Tournaments, Royal Treasury, and J3SSICA3.

## External Dependencies
-   **MetaMask**: For Web3 wallet connection and interactions.
-   **OpenAI**: Powers the J3SSICA3 AI Assistant (GPT-4.1-mini) via Replit AI Integrations.
-   **ethers.js**: For interacting with the Ethereum blockchain and smart contracts.
-   **LlamaRPC**: Used for mainnet integration for the Royal Treasury.
-   **Twitter/X**: For social sharing functionality.