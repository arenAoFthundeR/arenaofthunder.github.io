# Arena Thunder Marbles Smart Contract

## Overview

ERC-721 NFT contract for Arena of Thunder marble minting and gifting.

## Features

- **Minting**: Create new marble NFTs with metadata and rarity
- **Gifting**: Transfer marbles to other players
- **Rarity System**: 4 rarity levels (Common, Rare, Epic, Legendary)
- **Metadata**: IPFS-compatible token URI storage

## Important Notes

- **OpenZeppelin Version**: This contract requires OpenZeppelin Contracts v5.0+
- **Minting Access**: Anyone can mint marbles (no access control). This is intentional for player self-minting. Consider adding access control if needed.
- **Deployment**: Ensure the deployer account has enough testnet ETH for gas fees

## Deployment

### Using Remix IDE

1. Go to [Remix IDE](https://remix.ethereum.org/)
2. Create new file `ArenaMarbles.sol`
3. Copy the contract code
4. Install OpenZeppelin dependencies:
   - Go to Plugin Manager → Activate "OpenZeppelin Contracts"
5. Compile with Solidity 0.8.20+
6. Deploy to testnet (Sepolia recommended)

### Using Hardhat

```bash
npm install --save-dev hardhat @openzeppelin/contracts
npx hardhat compile
npx hardhat run scripts/deploy.js --network sepolia
```

## After Deployment

1. Copy the deployed contract address
2. Add to `.env` file:
   ```
   VITE_CONTRACT_ADDRESS=0x...
   ```
3. Verify contract on Etherscan for better UX

## Contract Interface

- `mint(address to, string tokenURI, uint8 rarity)` - Mint new marble
- `gift(address to, uint256 tokenId)` - Gift marble to another player
- `totalSupply()` - Get total minted marbles
- `tokensOfOwner(address owner)` - Get all token IDs for an owner

## Testnet Faucets

- Sepolia ETH: https://sepoliafaucet.com/
- Mumbai MATIC: https://faucet.polygon.technology/
