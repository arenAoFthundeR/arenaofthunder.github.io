# Thundergod Portfolio - Design Guidelines

## Design Approach
**Storm-Powered Portfolio** inspired by Epic Games' dramatic presentation, Discord's community feel, and Rainbow Wallet's Web3 aesthetics. This is Alexander "Thundergod" Campbell's electric domain - maximum storm energy with lightning-charged sections, electric glows, and thunder-powered typography.

---

## Typography System

**Font Families:**
- Display: `'Space Grotesk', 'Inter', sans-serif` (headings, dramatic statements) - BOLD usage (700-800)
- Body: `'Inter', system-ui, sans-serif` (readable content for portfolio sections)
- Historic/Lore: `'Segoe UI Historic', 'Segoe UI', serif` (selective use for Arena lore, dungeon narratives, treasury decrees)
- Code/Tech: `'JetBrains Mono', monospace` (wallet addresses, technical details)

**NOTE:** Modern portfolio sections use Space Grotesk + Inter for clean readability. Segoe UI Historic is reserved for lore-heavy Arena sections (dungeons, treasury proclamations, lore fragments) via `.font-historic`, `.historic-prose`, and `.historic-heading` utility classes.

**Type Scale:**
- Hero Display: text-6xl to text-8xl, font-extrabold (800), tracking-tight with electric glow
- Section Headers: text-4xl to text-5xl, font-bold (700), uppercase for impact
- Project Titles: text-2xl to text-3xl, font-semibold (600)
- Body: text-base to text-lg, font-normal (400)
- Labels: text-sm, font-medium (500), uppercase, tracking-wide

---

## Layout System

**Spacing Primitives:** Tailwind units **4, 6, 8, 12, 16, 24**
- Hero padding: py-24 to py-32
- Section spacing: py-16 to py-24
- Card padding: p-6 to p-8
- Element gaps: gap-4 to gap-8

**Container Strategy:**
- Portfolio sections: max-w-7xl mx-auto
- Hero: full-width with inner max-w-6xl
- Project grids: 3-column on desktop (grid-cols-1 md:grid-cols-2 lg:grid-cols-3)

---

## Component Library

### Navigation Header
Sticky header with heavy backdrop blur (backdrop-blur-lg bg-slate-950/90):
- Logo/name "THUNDERGOD" in Space Grotesk bold with electric cyan glow
- Navigation links: Home, Projects, Arena of Thunder (dropdown: Marbles, Dungeons, Treasury), About, Contact
- Wallet connect button (top-right) with electric gradient (blue-600 to cyan-500)
- Active nav items highlighted with electric underline (border-b-2 border-cyan-400)

### Hero Section - Electric Storm Entry
**Image:** Full-viewport (min-h-screen) dramatic storm photograph - dark churning clouds with multiple lightning strikes, electric blue illumination from below. Apply gradient overlay (bg-gradient-to-t from-slate-950 via-slate-950/60 to-transparent).

Hero Content (centered, z-10):
- Pretitle: "GAME DESIGNER • AI TINKERER • CREATIVE" (text-sm, tracking-widest, cyan glow)
- Main headline: "ALEXANDER CAMPBELL" (text-7xl, font-extrabold, white with strong electric glow)
- Subtitle: "THUNDERGOD" (text-5xl, font-bold, electric blue gradient text)
- Tagline: One-liner about storm-powered creativity (text-xl, text-slate-300)
- Dual CTAs: "View Projects" (electric gradient, blurred bg-slate-900/60) + "Arena of Thunder" (electric border, blurred bg-slate-900/40)
- Scroll indicator: Animated lightning bolt pointing down

### About Section
Two-column split (md:grid-cols-2):
- Left: Dramatic portrait or workspace photo with electric border glow
- Right: Bio text with electric blue accent quotes, skill tags as electric pills (rounded-full, bg-blue-500/20, border-blue-400/50)
- Background: Subtle animated storm clouds texture

### Projects Showcase Grid
Three-column responsive grid with project cards:
- **Card Structure:** 
  - Project thumbnail image (16:9) with dark overlay
  - Electric gradient border on hover (border-2 border-cyan-400)
  - Title in Space Grotesk bold (text-2xl)
  - Tech stack pills below (flex-wrap gap-2)
  - "View Project" link with arrow, electric cyan color
  - Live demo badge for active projects (pulsing electric glow)
- **Featured Project (Arena of Thunder):** Larger card spanning 2 columns with tabbed sections for Marbles/Dungeons/Treasury demos

### Arena of Thunder Live Demo Section
Full-width dramatic section with storm video background:
- Section header: "LIVE: ARENA OF THUNDER" (text-5xl, electric glow)
- Three demo cards in grid (Marbles, Dungeons, Treasury)
- Each card: Screenshot preview, title, description, "Launch Demo" button with lightning icon
- Cards have deeper shadows (shadow-2xl shadow-cyan-900/40) and stronger electric borders

### Skills/Tech Stack Section
Masonry-style grid or flexible wrap:
- Category headers: "Game Design", "AI/ML", "Web3", "Creative Tools"
- Tech items as electric badges with icons
- Hover effect: Lightning strike animation, brightness increase

### Contact Section
Split layout:
- Left: Contact form with electric-bordered inputs (focus:border-cyan-400, focus:ring-cyan-500/50)
- Right: Alternative contact methods (email, Discord, GitHub) with electric icons
- Background: Dark storm gradient with subtle lightning particle effects
- Submit button: Primary electric gradient with lightning bolt icon

### Footer
Dark background (bg-slate-950) with electric top border:
- Three columns: About snippet | Quick links | Social icons
- Copyright with electric accent
- "Powered by Thunder" tagline with small lightning bolt

---

## Visual Treatments

**Electric Glow System:**
- Text glow: `text-shadow: 0 0 20px rgba(6, 182, 212, 0.8), 0 0 40px rgba(6, 182, 212, 0.4)`
- Card glow: `box-shadow: 0 0 30px rgba(6, 182, 212, 0.3), 0 10px 50px rgba(0, 0, 0, 0.5)`
- Intense glow (hover): `0 0 40px rgba(6, 182, 212, 0.6), 0 0 80px rgba(6, 182, 212, 0.3)`

**Storm Gradients:**
- Hero overlay: `bg-gradient-to-t from-slate-950 via-slate-950/60 to-transparent`
- Section backgrounds: `bg-gradient-to-br from-slate-900 via-slate-950 to-blue-950/20`
- Electric accent gradient: `bg-gradient-to-r from-blue-600 via-cyan-500 to-blue-600`

**Borders & Depth:**
- Electric borders: border-2 border-cyan-400/60 with glow
- Card elevation: shadow-xl shadow-blue-900/30
- Deep shadows: shadow-2xl shadow-cyan-900/40

---

## Images

**Required Images:**
1. **Hero Background:** Full-width storm photography (2400x1400px) - dark storm clouds with multiple lightning strikes, electric blue/purple sky illumination. Must feel immersive and powerful.

2. **Project Thumbnails:** 16:9 screenshots or mockups (800x450px) for each project - apply subtle dark overlay for text legibility.

3. **Arena of Thunder Demos:** Dramatic in-game screenshots showing marble arena, dungeon environments, treasury interface - each with storm/lightning elements visible.

4. **About Section Photo:** Professional/creative portrait or workspace shot (600x800px) with moody lighting, optional lightning accents.

5. **Background Textures:** Subtle storm cloud patterns, electric particle effects (low opacity) for section backgrounds.

---

## Animations

**Critical Animations:**
- Hero lightning bolts: Occasional flash/glow pulse (every 4-5s)
- Card hover: Scale-105 with glow intensity increase
- Electric border pulse on active elements
- Smooth counting animations for stats/metrics
- All transitions: transition-all duration-300 ease-out

**Particle Effects:**
- Floating electric particles in hero section (subtle, slow movement)
- Lightning strike effect on CTA clicks (brief flash)

---

## Storm Energy Checklist
- Electric glows on ALL headings and key elements
- Dark storm backgrounds (slate-900 to slate-950) throughout
- Bold, powerful typography - no timid font weights
- Lightning/thunder iconography in UI elements
- Electric blue/cyan dominance in accents and CTAs
- Every section should feel charged with energy
- Text remains highly readable despite dramatic theming

This portfolio transforms professional presentation into a storm-powered showcase worthy of the Thundergod name.