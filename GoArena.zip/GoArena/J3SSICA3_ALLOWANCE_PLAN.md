# J3SSICA3 ALLOWANCE SYSTEM - IMPLEMENTATION PLAN

**Project:** Arena of Thunder + thundergod Portfolio  
**Date:** November 20, 2025  
**Status:** PLANNING PHASE - NO CODE CHANGES YET  

---

## EXECUTIVE SUMMARY

This document outlines a comprehensive **J3SSICA3 ALLOWANCE** system to manage AI chat resources, prevent abuse, and create a sustainable token economy within the Arena of Thunder ecosystem. The system will integrate seamlessly with existing wallet-based authentication and XP mechanics.

**Core Concept:** Users earn "J3 Credits" through gameplay and can spend them to interact with J3SSICA3, creating a natural rate-limiting mechanism tied to Arena participation.

---

## 1. CURRENT STATE ANALYSIS

### What We Have ✓
- **J3SSICA3 AI Assistant**: Fully operational GPT-4.1-mini integration
- **Wallet Authentication**: MetaMask-based identity system
- **XP System**: Players earn XP through mints, gifts, tournament participation
- **Memory System**: Per-wallet memory tracking (mints, gifts, lore unlocked)
- **WebSocket**: Real-time updates for leaderboard/tournaments
- **File Storage**: JSON-based persistence in `server/data/`

### Current Limitations ⚠️
1. **No rate limiting** on `/api/j3/chat` endpoint
2. **Unlimited AI calls** - anyone can spam expensive GPT requests
3. **No cost tracking** - no visibility into AI usage per user
4. **No resource allocation** - J3 available equally to all users
5. **No incentive economy** - gameplay doesn't unlock AI access

---

## 2. J3SSICA3 ALLOWANCE SYSTEM DESIGN

### 2.1 Core Concepts

**J3 Credits (J3C)** - In-game currency for AI interactions
- Earned through Arena gameplay
- Spent when chatting with J3SSICA3
- Regenerates over time for active players
- Can be boosted through achievements

**Allowance Tiers**
```
GUEST (No Wallet)     →  5 messages/day, basic responses
INITIATE (Connected)  → 20 messages/day, full context
WARRIOR (100+ XP)     → 50 messages/day, priority processing
CHAMPION (500+ XP)    → 100 messages/day, extended memory
LEGEND (1000+ XP)     → Unlimited, premium features
```

### 2.2 Credit Economy

#### Earning J3 Credits
| Action | J3C Earned | Notes |
|--------|-----------|-------|
| Connect Wallet | +50 J3C | One-time welcome bonus |
| Mint Marble | +10 J3C | Per marble minted |
| Send Gift | +5 J3C | Per gift sent |
| Receive Gift | +5 J3C | Per gift received |
| Unlock Lore | +15 J3C | Per lore fragment |
| Join Tournament | +20 J3C | Per tournament entry |
| Advance Round | +25 J3C | Per round won |
| Daily Login | +10 J3C | 24-hour cooldown |
| Admin Bonus | Variable | Admin-granted rewards |

#### Spending J3 Credits
| Action | J3C Cost | Notes |
|--------|---------|-------|
| Standard Message | -2 J3C | Normal chat interaction |
| Complex Query | -5 J3C | Requires context lookup |
| Action Request | -3 J3C | Scroll, navigate, call functions |
| History Recall | -10 J3C | Load long-term memory |
| Lore Generation | -15 J3C | Generate custom lore |

#### Regeneration
- **Base Regen**: +1 J3C per hour (passive)
- **Active Regen**: +2 J3C per hour (wallet connected, active session)
- **Max Cap**: 200 J3C (can earn above cap, but regen stops)
- **Rollover**: Unused credits persist indefinitely

---

## 3. TECHNICAL ARCHITECTURE

### 3.1 Data Schema Extension

**New Storage Interface Methods** (to add to `server/storage.ts`):
```typescript
interface IStorage {
  // ... existing methods ...
  
  // J3 Allowance
  getJ3Credits(wallet: string): Promise<J3Credits>;
  modifyJ3Credits(wallet: string, amount: number, reason: string): Promise<J3Credits>;
  getJ3UsageHistory(wallet: string, limit?: number): Promise<J3Usage[]>;
  checkJ3RateLimit(wallet: string): Promise<RateLimitStatus>;
  recordJ3Interaction(wallet: string, cost: number, type: string): Promise<void>;
}

interface J3Credits {
  wallet: string;
  balance: number;
  lifetime_earned: number;
  lifetime_spent: number;
  tier: "guest" | "initiate" | "warrior" | "champion" | "legend";
  daily_limit: number;
  messages_today: number;
  last_message_at: number;
  last_regen_at: number;
}

interface J3Usage {
  timestamp: number;
  wallet: string;
  cost: number;
  type: "message" | "action" | "context" | "lore";
  message_length: number;
  response_length: number;
  tokens_used?: number;
}

interface RateLimitStatus {
  allowed: boolean;
  current_balance: number;
  required_balance: number;
  messages_remaining_today: number;
  reset_at: number;
  reason?: string;
}
```

### 3.2 New API Endpoints

**Credit Management**
```
GET  /api/j3/credits              → Get current J3C balance
POST /api/j3/credits/earn         → Manually award credits (admin)
GET  /api/j3/credits/history      → Get usage history
GET  /api/j3/credits/leaderboard  → Top earners/spenders
```

**Enhanced Chat Endpoint**
```
POST /api/j3/chat (MODIFIED)
  - Check rate limit before processing
  - Deduct credits based on message complexity
  - Track usage in history
  - Return updated balance in response
```

### 3.3 Storage Files

**New File**: `server/data/j3-credits.json`
```json
{
  "wallets": {
    "0xABC...": {
      "balance": 127,
      "lifetime_earned": 450,
      "lifetime_spent": 323,
      "tier": "warrior",
      "daily_limit": 50,
      "messages_today": 12,
      "last_message_at": 1763604856000,
      "last_regen_at": 1763604800000
    }
  }
}
```

**New File**: `server/data/j3-usage.json`
```json
{
  "usage": [
    {
      "timestamp": 1763604856000,
      "wallet": "0xABC...",
      "cost": 2,
      "type": "message",
      "message_length": 45,
      "response_length": 234,
      "tokens_used": 156
    }
  ]
}
```

---

## 4. RATE LIMITING STRATEGY

### 4.1 Multi-Layer Protection

**Layer 1: Credit Balance Check**
- User must have sufficient J3C to send message
- Deduct credits BEFORE making OpenAI API call
- Refund if API call fails

**Layer 2: Daily Message Cap**
- Hard limit per tier (5/20/50/100/unlimited)
- Resets at midnight UTC
- Prevents credit hoarding abuse

**Layer 3: Request Cooldown**
- 2-second minimum between messages (all users)
- Prevents rapid-fire spam
- Implemented in frontend + backend validation

**Layer 4: IP-Based Fallback**
- If wallet not connected, limit by IP address
- 10 requests per day per IP
- Stored in memory (not persisted)

### 4.2 Grace Period & Soft Limits

**Grace Messages**: First-time users get 3 free messages
- Deducted from balance after grace period
- Encourages wallet connection
- Prevents immediate paywall frustration

**Overdraft Protection**: Allow -10 J3C maximum
- User can finish conversation even if balance hits zero
- Must earn back to positive before next session
- Prevents mid-conversation cutoffs

---

## 5. FRONTEND UX INTEGRATION

### 5.1 J3 Chat Component Updates

**Balance Display**
```
┌─────────────────────────────────┐
│ J3SSICA3 ⚡ [Online]            │
│ Arena AI Oracle                 │
│ ─────────────────────────────── │
│ Credits: 127 J3C ⚡              │
│ Tier: Warrior 🗡️                │
│ Daily: 12/50 messages           │
└─────────────────────────────────┘
```

**Warning States**
- **Low Balance** (<10 J3C): Yellow warning banner
- **Depleted** (0 J3C): Red notice with earn instructions
- **Rate Limited**: Cooldown timer display
- **Overdraft**: "In debt" indicator with recovery tips

**Earn Prompts**
```
"Out of J3 Credits? Try:
 • Mint a marble (+10 J3C)
 • Join a tournament (+20 J3C)
 • Unlock lore (+15 J3C)
 • Come back tomorrow (+10 J3C daily bonus)"
```

### 5.2 Message Cost Transparency

Show cost BEFORE sending complex queries:
```
User types: "Tell me all the lore about the Seven Titans"
System: "This complex query will cost 5 J3C. Continue?"
  [Send (5 J3C)] [Cancel]
```

### 5.3 Credits in Profile Display

Enhance wallet profile section to show:
- Current J3C balance (prominent)
- Lifetime earned/spent
- Current tier badge
- Progress to next tier
- Recent J3 activity log

---

## 6. ADMIN DASHBOARD ENHANCEMENTS

### New Admin Features

**Credit Management Panel**
```
┌─ J3SSICA3 Allowance Manager ────────────┐
│                                          │
│ Total Credits Issued:    45,234 J3C     │
│ Total Credits Spent:     32,891 J3C     │
│ Active Users (7d):       127 wallets    │
│ Avg Messages/User:       23.4           │
│                                          │
│ [Grant Credits] [Adjust Rates]          │
│ [View Top Earners] [Ban Abusers]        │
└──────────────────────────────────────────┘
```

**Abuse Detection**
- Flag users with >100 messages/day
- Detect rapid-fire patterns
- Monitor credit farming attempts
- Admin can temporarily ban or reduce limits

**Economy Tuning**
- Adjust earn rates globally
- Modify tier thresholds
- Set promotional bonuses
- Export analytics

---

## 7. MIGRATION STRATEGY

### Phase 1: Add Infrastructure (No Breaking Changes)
1. Add new storage methods to `IStorage`
2. Create `j3-credits.json` and `j3-usage.json` files
3. Implement credit tracking (passive mode)
4. Add admin dashboard for monitoring

**Status**: Backend-only, users see no changes

### Phase 2: Soft Launch (Optional Credits)
1. Display J3C balance in UI
2. Show earnings notifications
3. Allow users to earn credits
4. Do NOT enforce spending yet

**Status**: Users see system, can opt-in

### Phase 3: Enforce Allowances (Full Launch)
1. Require credits for J3 interactions
2. Apply rate limits by tier
3. Show cost transparency
4. Enable all earn mechanisms

**Status**: Full system active

### Phase 4: Optimize & Expand
1. Add leaderboard for J3C earners
2. Introduce credit trading (wallet-to-wallet)
3. Premium features unlock at high tiers
4. Integration with NFT marbles (marbles grant J3C bonuses)

---

## 8. SECURITY CONSIDERATIONS

### Exploit Prevention

**Credit Duplication**
- Atomic transactions for credit changes
- Log all modifications with reason codes
- Admin audit trail
- Rollback capability

**Sybil Attacks**
- Link credits to wallet, not sessions
- Require minimum XP for credit transfers
- Monitor new wallet patterns
- Admin approval for bulk grants

**API Abuse**
- Server-side validation of all credit operations
- Timestamp verification (prevent replay attacks)
- Rate limit on credit endpoints themselves
- Monitor for automation patterns

### Data Integrity

**Backups**
- Automatic backup of `j3-credits.json` every hour
- Retain 7 days of history
- Admin restore capability

**Reconciliation**
- Daily audit: earned - spent = balance
- Flag discrepancies for manual review
- Automated correction for minor drift

---

## 9. ANALYTICS & MONITORING

### Key Metrics to Track

**Engagement**
- Messages per user per day
- J3C earned vs. spent ratios
- Tier distribution
- Credit conversion rate (XP → J3C → Messages)

**Economy Health**
- Inflation rate (credits issued vs. consumed)
- User retention by tier
- Overdraft frequency
- Grace period conversion rate

**Performance**
- Average response time by tier
- OpenAI token usage per user
- Cost per message (in $)
- ROI on credit system

### Dashboard Widgets
```
┌─ J3 Economy Dashboard ──────────────────┐
│                                          │
│ 📊 7-Day Activity                        │
│   Messages Sent:     1,234               │
│   Credits Earned:    5,678 J3C          │
│   Credits Spent:     4,321 J3C          │
│   Net Surplus:       +1,357 J3C         │
│                                          │
│ 🎯 Tier Breakdown                        │
│   Guest:     45%  (127 users)           │
│   Initiate:  30%  (85 users)            │
│   Warrior:   15%  (42 users)            │
│   Champion:   8%  (23 users)            │
│   Legend:     2%  (6 users)             │
│                                          │
│ ⚠️  Alerts                               │
│   - 3 users hit daily limit             │
│   - 1 user in overdraft >24h            │
│                                          │
└──────────────────────────────────────────┘
```

---

## 10. FUTURE ENHANCEMENTS

### V2 Features (Post-Launch)

**1. J3C Marketplace**
- Users trade J3C for marbles
- Auction system for premium lore
- J3C staking for passive regen boost

**2. Subscription Tiers**
- "Lightning Pass" - $5/month = unlimited J3C
- "Storm Patron" - $20/month = legend tier + perks
- Proceeds fund OpenAI costs + development

**3. NFT Integration**
- Marbles grant J3C production bonuses
- Rare marbles = higher chat priority
- Limited edition J3SSICA3 avatar NFTs

**4. Social Features**
- Gift J3C to other wallets
- Leaderboard for J3 interactions
- Achievements unlock credit multipliers

**5. Advanced AI Features**
- **Voice Mode** (50 J3C/min): Talk to J3 with text-to-speech
- **Image Generation** (100 J3C): J3 creates custom marble art
- **Code Execution** (75 J3C): J3 runs simple on-chain queries

**6. Cross-Platform Credits**
- J3C works across all thundergod projects
- Unified identity system
- Credit portability

---

## 11. COST ANALYSIS

### Current Costs (No Allowance)
- GPT-4.1-mini: ~$0.15 per 1M input tokens, ~$0.60 per 1M output tokens
- Average message: ~500 tokens total
- Cost per message: ~$0.0004 (less than a penny)
- 10,000 messages/month = ~$4.00

**Problem**: No limits = potential runaway costs

### With Allowance System
- Limit to 50 avg messages/user/day
- 100 active users = 5,000 messages/day = 150k/month
- Monthly cost: ~$60
- Predictable, capped, sustainable

### Revenue Opportunities
- Premium subscriptions: $5-20/month
- J3C purchases: $1 per 100 J3C
- NFT sales fund credit pool
- Ads in free tier (optional)

**Break-even**: 12 subscribers at $5/month covers 150k messages

---

## 12. IMPLEMENTATION CHECKLIST

### Backend Tasks
- [ ] Extend `IStorage` interface with J3 credit methods
- [ ] Create `FileStorage` implementations for new methods
- [ ] Add `j3-credits.json` storage file
- [ ] Add `j3-usage.json` logging file
- [ ] Implement rate limiting middleware
- [ ] Modify `/api/j3/chat` to check/deduct credits
- [ ] Create `/api/j3/credits/*` endpoints
- [ ] Add credit earning triggers (mint, gift, tournament, etc.)
- [ ] Implement automatic regeneration (cron or on-request)
- [ ] Add admin dashboard credit management UI
- [ ] Create migration script for existing users

### Frontend Tasks
- [ ] Update `J3Chat.tsx` to display balance
- [ ] Add credit warnings/notifications
- [ ] Show message cost before sending
- [ ] Display tier badge and progress
- [ ] Create "Earn J3C" help panel
- [ ] Add usage history viewer
- [ ] Implement grace period UI flow
- [ ] Show daily limit progress
- [ ] Add overdraft warning states
- [ ] Update profile to show J3 stats

### Testing
- [ ] Test credit earn/spend flows
- [ ] Verify rate limiting works
- [ ] Test tier transitions
- [ ] Validate regeneration logic
- [ ] Test overdraft scenarios
- [ ] Check grace period handling
- [ ] Load test with 100+ concurrent users
- [ ] Security audit credit operations
- [ ] Test migration with existing users

### Documentation
- [ ] User guide: "How J3 Credits Work"
- [ ] API documentation for credit endpoints
- [ ] Admin manual for economy tuning
- [ ] FAQ for common questions
- [ ] Changelog for allowance system launch

---

## 13. ROLLOUT TIMELINE

**Week 1: Foundation**
- Implement backend storage and methods
- Add basic credit tracking (passive)
- No user-facing changes

**Week 2: Soft Launch**
- Display credits in UI
- Show earn notifications
- Allow earning, not enforcing spending

**Week 3: Testing & Tuning**
- Internal testing with select users
- Adjust earn/spend rates based on feedback
- Fix bugs and edge cases

**Week 4: Full Launch**
- Enable credit enforcement
- Activate all rate limits
- Monitor closely for issues
- Quick fixes as needed

**Week 5+: Optimization**
- Analyze analytics
- Tune economy parameters
- Add features based on usage patterns
- Plan V2 enhancements

---

## 14. SUCCESS CRITERIA

### Metrics for Success
1. **Sustainability**: AI costs stay under $100/month
2. **Engagement**: 70%+ users earn credits weekly
3. **Fairness**: <5% of users hit rate limits
4. **Conversion**: 20%+ guests upgrade to initiate tier
5. **Quality**: User satisfaction remains >4/5 stars

### Red Flags
- Users complaining system is "too restrictive"
- Significant drop in J3 usage
- Credit farming exploits discovered
- Cost per message increases >50%
- Mass exodus to competitor without limits

---

## CONCLUSION

The J3SSICA3 ALLOWANCE system transforms an unlimited resource into a **strategic game mechanic** that:
- Prevents abuse and controls costs
- Rewards engaged players
- Creates sustainable AI integration
- Opens revenue opportunities
- Enhances the Arena experience

**This system turns J3SSICA3 from a cost center into a core game feature.**

Next steps: Begin Phase 1 implementation with backend infrastructure.

---

**Document Version**: 1.0  
**Last Updated**: November 20, 2025  
**Author**: Replit Agent  
**Status**: APPROVED FOR PLANNING - AWAITING IMPLEMENTATION
