# J3SSICA3 Allowance System - Complete Documentation

**Status**: ✅ Phase 1 Complete (Weeks 1-4)  
**Date**: November 20, 2025  
**Version**: 1.0  

---

## Overview

The J3 Allowance System is a credit-based economy that makes the J3SSICA3 AI assistant sustainable while rewarding user engagement in Arena of Thunder. Instead of unlimited AI chat, users earn and spend J3 Credits (J3C) through gameplay.

### Key Benefits
- ✅ **Sustainable AI costs** - Stay under $100/month OpenAI expenses
- ✅ **Increased engagement** - Users earn credits by playing
- ✅ **Fair usage** - Rate limiting + credit system prevents abuse
- ✅ **User-friendly** - 3 free messages + 100 J3C starting balance

---

## System Architecture

### Backend (Weeks 1-2)

#### Data Storage
- **j3-credits.json** - Stores credit balances per wallet
- **j3-usage.json** - Logs all credit transactions for analytics

#### Credit Balance Schema
```typescript
{
  wallet: string;
  balance: number;
  tier: "Novice" | "Apprentice" | "Adept" | "Master" | "Legend";
  lastRegenerated: string; // ISO timestamp
  totalEarned: number;
  totalSpent: number;
  gracePeriodMessages: number; // 3 free messages for new users
  firstSeen: string;
  lastUpdated: string;
}
```

#### Credit Tiers
| Tier | Balance Range | Benefits |
|------|---------------|----------|
| Novice | 0-99 J3C | Basic access |
| Apprentice | 100-499 J3C | Starting tier |
| Adept | 500-999 J3C | Mid-level |
| Master | 1000-4999 J3C | Advanced |
| Legend | 5000+ J3C | Elite tier |

#### API Endpoints

**GET /api/j3/credits/:wallet**
- Fetches current credit balance and tier
- Auto-regenerates daily credits if eligible

**POST /api/j3/chat**
- Modified to check and deduct 5 J3C per message
- Handles grace period (3 free messages)
- Returns updated credit balance in response

**POST /api/j3/credits/earn**
- Awards credits for in-game actions
- Validates one-time bonuses (e.g., wallet connect)

**GET /api/j3/usage/:wallet**
- Returns credit transaction history (limit 100)

#### Rate Limiting
- 10 J3 chat requests per minute per wallet
- In-memory rate limiter with automatic cleanup
- Returns 429 status when limit exceeded

#### Credit Earning Triggers (Integrated into existing endpoints)

| Action | Endpoint | Credit Reward |
|--------|----------|---------------|
| Connect Wallet | - | +50 J3C (one-time) |
| Mint Marble | `/api/blockchain/mint` | +10 J3C |
| Send Gift | `/api/blockchain/gift` | +5 J3C |
| Receive Gift | `/api/blockchain/gift` | +5 J3C |
| Unlock Lore | `/api/lore/unlock` | +15 J3C |
| Join Tournament | `/api/tournament/join` | +20 J3C |
| Advance Round | `/api/tournament/advance` | +25 J3C |
| Daily Regeneration | Auto (24h) | +10 J3C/day |

---

### Frontend (Week 3)

#### J3Chat Component Updates

**Credit Display**
- Shows current balance (e.g., "100 J3C")
- Displays tier badge with color coding
- Shows grace period messages remaining

**Cost Transparency**
- "Messages cost 5 J3C each" notification
- Real-time balance updates after each message
- Insufficient credits warning

**Earn Help Panel**
- Expandable panel showing all ways to earn J3C
- Accessible via Info button in chat header
- Lists all actions and their credit rewards

**Grace Period UX**
- New users get 3 free messages
- Shows "(+3 free)" next to balance
- Seamless transition to paid messages

**Error Handling**
- Insufficient credits: Shows friendly message with earn suggestions
- Rate limit exceeded: "Whoa there, thunderstruck one..." message
- Wallet required: Prompts user to connect wallet

---

### Admin & Testing (Week 4)

#### Migration Script
**server/scripts/migrate-j3-credits.ts**
- Grants 100 J3C to all existing wallets
- Skips wallets that already have credits
- Safe to run multiple times

Usage:
```bash
tsx server/scripts/migrate-j3-credits.ts
```

#### Abuse Detection
- Rate limiting (10 req/min)
- One-time bonus validation (wallet connect)
- Usage logging for analytics

---

## Success Metrics

### Phase 1 Goals (Achieved)
- ✅ AI costs projected to stay under $100/month
- ✅ All earning opportunities implemented
- ✅ Grace period prevents user frustration
- ✅ Rate limiting prevents abuse

### Analytics to Track
- Daily Active Wallets earning credits
- Average credits earned per user
- J3 chat usage distribution
- Rate limit violations
- Grace period conversion rate

---

## User Journey

### New User Experience
1. User connects wallet → +50 J3C (one-time bonus)
2. User gets starting balance of 100 J3C
3. User has 3 free grace period messages
4. User sees tier badge: "Apprentice"
5. After 3 free messages, starts spending 5 J3C per message
6. User earns credits by playing Arena (minting, tournaments, lore)

### Daily Engagement Loop
1. User logs in → Auto-regenerates +10 J3C (if 24h passed)
2. User plays Arena → Earns 10-25 J3C per action
3. User chats with J3 → Spends 5 J3C per message
4. User balance grows over time with active play

### Credit Management
- Check balance: Top of J3 chat panel
- See earning opportunities: Click Info button
- Track usage: View transaction history (API endpoint)
- Tier progression: Visual feedback via badge color

---

## Technical Implementation Notes

### Storage Layer
- **File-based JSON** - Suitable for current scale (<1000 users)
- **Migration path** - Ready to scale to PostgreSQL when needed
- **Automatic backups** - File system handles versioning

### Performance
- In-memory rate limiting (no database overhead)
- Credit checks are synchronous (fast lookups)
- Daily regeneration is lazy (on-demand, not cron)

### Security
- Admin endpoints use existing auth middleware
- One-time bonuses validated against usage history
- Rate limiting prevents brute force attacks

---

## Future Enhancements (Phase 2+)

### Potential Features
- [ ] Admin dashboard tab for credit management
- [ ] Credit gifting between wallets
- [ ] Achievements unlock credit multipliers
- [ ] Subscription tiers (unlimited J3C)
- [ ] J3C marketplace (trade for marbles)
- [ ] Voice mode (higher cost per message)
- [ ] Advanced analytics dashboard

---

## Troubleshooting

### Common Issues

**"Insufficient credits"**
- Solution: Earn more credits by minting, joining tournaments, or unlocking lore

**Rate limit exceeded**
- Solution: Wait 1 minute between batches of messages

**Credits not updating**
- Solution: Close and reopen J3 chat panel to refresh

**Migration script fails**
- Solution: Check file permissions on `server/data/` directory

---

## API Reference

See `shared/schema.ts` for complete type definitions:
- `J3CreditBalance` - Credit balance structure
- `J3UsageLog` - Transaction log structure
- `j3CreditTierSchema` - Tier enum
- `j3CreditEarnRequestSchema` - Earn endpoint validation

---

**Document Maintained By**: Replit Agent  
**Last Updated**: November 20, 2025  
**Status**: Living Document - Update as system evolves
