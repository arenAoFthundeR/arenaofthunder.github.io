# ARTICLE ANALYSIS & ARCHITECTURAL NOTES

**Project:** Arena of Thunder Infrastructure Planning  
**Date:** November 20, 2025  
**Source Material:** Two attached technical discussion articles  

---

## ARTICLE 1: "LOCAL SERVER FACE INFRASTRUCTURE"

### Summary
Guide for building a minimal local web server using Windows-native tools (no npm/node installs), centered around serving a "face image" as the core identity/gateway to other services.

### Key Concepts Extracted

#### 1. **Minimal Infrastructure Philosophy**
- **Core Idea**: Build with absolute minimal dependencies
- **Windows-native**: Use File Explorer, Notepad, built-in server
- **Old-school web**: HTML, CSS, vanilla JS (no frameworks)
- **Progressive enhancement**: Add complexity only when needed

**Application to Arena of Thunder:**
- Our current stack (React, TypeScript, Express) is already more advanced
- BUT: The principle of "add complexity only when justified" is valuable
- Consider: Could we offer a "lite" version of Arena for low-bandwidth users?

#### 2. **Project Structure Pattern**
```
root/
  ├─ index.html          (entry point)
  ├─ /img                (assets)
  │   └─ face.png
  ├─ /css                (styles)
  │   └─ style.css
  └─ /js                 (behavior)
      └─ main.js
```

**Comparison to Arena Structure:**
```
arena-of-thunder/
  ├─ client/src/         (React frontend)
  ├─ server/             (Express backend)
  ├─ shared/             (Types/schemas)
  └─ attached_assets/    (Images, etc.)
```

**Insight**: Article's structure is **flat and discoverable**. Our structure is **modular and scalable**. Both valid for different use cases.

#### 3. **"Face as Gateway" Metaphor**
- User's face image = authentication/identity
- Visual metaphor: "Face in the wire"
- Every connection "looks through" the face
- Personality-driven navigation

**Application to J3SSICA3:**
- J3's avatar/persona could be the "face" of Arena
- Every interaction "goes through" J3SSICA3
- Visual: J3's face/logo appears during loading, auth, transitions
- Lore integration: "J3SSICA3 is the gatekeeper of the Arena"

#### 4. **Staged Rollout Roadmap**
Article suggests:
1. **Phase 1**: Static HTML with face image
2. **Phase 2**: Add simple JS interactions (button clicks)
3. **Phase 3**: More pages, hyperlinks
4. **Phase 4**: Log system (fake at first)
5. **Phase 5**: Backend integration (when ready)

**What Arena Already Has:**
- ✅ Full stack (we're at "Phase 5+")
- ✅ Multiple pages with routing
- ✅ Backend API with persistence
- ✅ Real-time WebSocket
- ✅ Database (file-based JSON)

**What We Could Learn:**
- Could we create a "Phase 1" landing page?
- Simple, fast-loading entry point before full app loads
- Just hero image + "Connect Wallet" button
- Progressive enhancement: load React app after connection

#### 5. **"Fantasy Verification" Concept**
Article mentions:
> "Face verification fantasy - frontend animation that pretends the server is 'authorizing' anything that connects through your face"

**Application Ideas:**
- When connecting wallet → J3SSICA3 "scans" your address
- Loading animation: "Verifying storm signature..."
- Visual: Electric particles analyze the wallet address
- Lore text: "J3SSICA3 authenticates your presence in the Arena"
- Even though it's instant, make it **feel** ceremonial

---

## ARTICLE 2: "GOOGLE DRIVE LIMITS & PERSONA ARCHITECTURE"

### Summary
Technical deep-dive into Google Drive storage quotas, item limits, and architectural patterns for a "persona-per-connection" system where each user/NFT gets their own cloud storage account.

### Key Technical Limits Identified

#### 1. **Google Drive Quotas**
- **Storage**: 15 GB per free account (shared: Drive + Gmail + Photos)
- **Items**: ~5 million items per personal Drive
- **Daily Upload**: 750 GB/day per user
- **Workspace**: Hundreds of millions of items (enterprise)
- **Per-folder**: 500k items max

**Implications for Arena:**
- If we stored per-wallet data in separate Google accounts → unsustainable
- Current approach (JSON files) → much more reasonable
- Each `memory.json` entry is bytes, not a full account
- Can scale to thousands of wallets in single file

#### 2. **Auto-Account Creation Reality Check**
Article warns:
> "Automating large-scale creation of Google accounts is **against Google's Terms of Service** and will trigger anti-abuse systems."

**Translation for Our Use Case:**
- Don't create a Google account per wallet
- Don't create a database per NFT
- DO use single storage backend with wallet-indexed records
- DO use our current `FileStorage` approach or upgrade to Postgres

**We're already doing this right** ✅

#### 3. **"Persona" Data Schema**
Article proposes:
```json
{
  "personaId": "0xNFTIDorUUID",
  "createdAt": "timestamp",
  "ownerWallet": "0x...",
  "aiStylePreset": "aggressive / gentle / chaotic-neutral",
  "memory": {
    "shortTerm": [ ... ],
    "longTerm": [ ... ]
  },
  "assets": {
    "marbles": [ ... ],
    "titles": [ ... ]
  }
}
```

**Our Current Schema** (from `WalletMemory`):
```typescript
{
  wallet: string;
  mintCount: number;
  giftsSent: number;
  giftsReceived: number;
  seenLoreIds: number[];
  adminXpAdjustment: number;
}
```

**Gap Analysis:**
- ❌ We don't have `personaId` (but wallet serves this purpose)
- ❌ We don't have `aiStylePreset` (J3 treats everyone the same)
- ❌ We don't track `shortTerm` vs. `longTerm` memory explicitly
- ✅ We do track assets (marbles, dungeons, tournaments)
- ✅ We do track creation time (`createdAt` in various records)

**Opportunity:** Add `aiStylePreset` to WalletMemory
- Let users customize J3's personality toward them
- Options: "Playful", "Serious", "Cryptic", "Aggressive"
- Stored per wallet
- J3 system prompt includes: "User prefers {preset} tone"

#### 4. **Persona Manager Architecture**
Article proposes API structure:
```
POST /persona/create        → Mint NFT, create persona JSON, return ID
GET  /persona/:id           → Load persona data
POST /persona/:id/chat      → Send message, get reply, update memory
```

**Our Current Structure:**
```
POST /api/j3/chat           → Send message, get reply (context from wallet)
GET  /api/memory/get        → Get wallet memory
POST /api/memory/set        → Update wallet memory
```

**Differences:**
- Article uses **persona-centric** routing (`:id` in URL)
- We use **wallet-centric** routing (wallet in request body)
- Both valid, ours is simpler for Web3 (wallet = identity)

**Could We Add Persona Layer?**
- Yes, if we wanted multiple "personas" per wallet
- Example: User has 3 NFT marbles, each is a separate persona
- Each marble talks to J3 differently
- Marble #1 = aggressive, Marble #2 = wise, Marble #3 = chaotic
- Would require: `POST /api/j3/chat/:marbleId` endpoint

---

### 5. **Memory Architecture Insights**

Article distinguishes:
- **Short-term memory**: Recent conversation (last N messages)
- **Long-term memory**: Important facts user has shared

**Our Current Approach:**
- Conversation history stored in frontend state (lost on refresh)
- Long-term memory = XP, mints, lore unlocked, tournament progress
- No persistent "facts user told J3"

**Enhancement Opportunity: Persistent Conversation Memory**

**Example:**
```json
{
  "wallet": "0xABC...",
  "j3_memory": {
    "facts": [
      "User's favorite marble is 'Stormbringer'",
      "User wants to focus on tournament strategy",
      "User asked about lore #7 three times"
    ],
    "preferences": {
      "tone": "playful",
      "topics_of_interest": ["tournaments", "lore", "trading"],
      "avoid_topics": ["technical_jargon"]
    },
    "last_conversations": [
      {
        "timestamp": 1763604856000,
        "summary": "User asked how to mint marbles, J3 explained process",
        "messages": [ ... ]
      }
    ]
  }
}
```

**Storage:** Add to `WalletMemory` or create new `j3-memory.json`

**When to use:**
- J3 can reference: "Last time we talked, you were working on tournament strategy..."
- J3 avoids repeating explanations
- J3 personalizes responses based on known interests

---

## ARCHITECTURAL PATTERNS COMPARISON

### Pattern 1: Article's "Persona-Per-NFT" Model
```
NFT #1 → Persona A → Google Drive Account A → Memory A
NFT #2 → Persona B → Google Drive Account B → Memory B
NFT #3 → Persona C → Google Drive Account C → Memory C
```

**Pros:**
- Each NFT has isolated storage
- True "soul per marble" lore immersion
- No data mixing between NFTs

**Cons:**
- Unsustainable at scale (Google TOS violation)
- Complex account management
- Expensive (need paid storage per NFT)
- Hard to query across personas

---

### Pattern 2: Our Current "Wallet-Centric" Model
```
Wallet 0xABC → {
  marbles: [NFT1, NFT2, NFT3],
  memory: WalletMemory,
  j3_interactions: [...],
  xp: 450
}
```

**Pros:**
- Simple, scalable
- Single auth (wallet signature)
- Easy to query and aggregate
- Cost-effective (single storage backend)

**Cons:**
- No per-marble differentiation
- J3 treats all user's marbles the same
- Less immersive "each marble is alive" fantasy

---

### Pattern 3: Hybrid "Marble-As-Persona" Model (PROPOSED)
```
Wallet 0xABC → {
  marbles: [
    {
      id: 1,
      personaId: "marble_1_abc",
      aiPreset: "aggressive",
      memory: {...}
    },
    {
      id: 2,
      personaId: "marble_2_def",
      aiPreset: "wise",
      memory: {...}
    }
  ],
  wallet_memory: {...},
  j3_credits: 127
}
```

**Implementation:**
- Each marble NFT gets a `personaId`
- User selects which marble to "speak through" in J3 chat
- J3's tone/knowledge adapts to marble's personality
- Marble-specific memory stored in marble record
- Wallet-level data (XP, credits) shared across all marbles

**Example UX:**
```
J3 Chat UI:
┌────────────────────────────────────┐
│ Speaking as: [Marble #7: Stormbringer ▼] │
│ Personality: Aggressive ⚔️          │
├────────────────────────────────────┤
│ J3: What do you seek, warrior?     │
│ You: Tell me about tournaments     │
└────────────────────────────────────┘

[Switch to Marble #2: Lumina]
┌────────────────────────────────────┐
│ Speaking as: [Marble #2: Lumina ▼] │
│ Personality: Wise 📿                │
├────────────────────────────────────┤
│ J3: Ah, seeker of knowledge...     │
│ You: Tell me about tournaments     │
│ J3: Patience. First, understand... │
└────────────────────────────────────┘
```

**Benefits:**
- Maintains scalability (no Google accounts per marble)
- Adds immersive marble personalities
- Users collect marbles for gameplay AND for different J3 interactions
- Rare marbles = unique personalities
- Lore integration: "Each marble holds a fragment of consciousness"

---

## STORAGE SCALABILITY ANALYSIS

### Current State: File-Based JSON

**Files:**
- `memory.json` (~10KB per 100 wallets)
- `lore.json` (~5KB)
- `tournament.json` (~20KB)
- `marbles.json` (~50KB per 1000 marbles)
- `dungeons.json` (~30KB per 500 runs)
- `security.json` (~10KB)

**Total at 1,000 active users:** ~500KB - 1MB

**Pros:**
- Simple, no database setup
- Easy to backup (copy files)
- Human-readable for debugging
- Works perfectly at current scale

**Cons:**
- Slow at 10,000+ users (full file read/write)
- No concurrent write safety (race conditions possible)
- No indexing (must iterate to find records)
- Memory usage grows with data size

---

### Migration Path: PostgreSQL

**When to migrate:**
- 1,000+ active wallets
- 100+ concurrent users
- Need complex queries (leaderboards, analytics)
- J3 allowance system needs high-frequency updates

**Schema Design:**
```sql
-- Wallets table
CREATE TABLE wallets (
  address VARCHAR(42) PRIMARY KEY,
  xp INTEGER DEFAULT 0,
  level INTEGER DEFAULT 1,
  mint_count INTEGER DEFAULT 0,
  gifts_sent INTEGER DEFAULT 0,
  gifts_received INTEGER DEFAULT 0,
  admin_xp_adjustment INTEGER DEFAULT 0,
  created_at TIMESTAMP DEFAULT NOW(),
  last_seen TIMESTAMP DEFAULT NOW()
);

-- J3 Credits table
CREATE TABLE j3_credits (
  wallet VARCHAR(42) PRIMARY KEY REFERENCES wallets(address),
  balance INTEGER DEFAULT 0,
  lifetime_earned INTEGER DEFAULT 0,
  lifetime_spent INTEGER DEFAULT 0,
  tier VARCHAR(20) DEFAULT 'guest',
  daily_limit INTEGER DEFAULT 20,
  messages_today INTEGER DEFAULT 0,
  last_message_at TIMESTAMP,
  last_regen_at TIMESTAMP,
  CONSTRAINT positive_balance CHECK (balance >= -10)
);

-- J3 Usage log
CREATE TABLE j3_usage (
  id SERIAL PRIMARY KEY,
  wallet VARCHAR(42) REFERENCES wallets(address),
  timestamp TIMESTAMP DEFAULT NOW(),
  cost INTEGER NOT NULL,
  type VARCHAR(20) NOT NULL,
  message_length INTEGER,
  response_length INTEGER,
  tokens_used INTEGER
);

-- Indexes for performance
CREATE INDEX idx_j3_usage_wallet ON j3_usage(wallet);
CREATE INDEX idx_j3_usage_timestamp ON j3_usage(timestamp DESC);
CREATE INDEX idx_wallets_xp ON wallets(xp DESC);
```

**Migration Strategy:**
1. Keep file-based storage active
2. Add PostgreSQL connection (optional)
3. Write to both systems during transition
4. Validate data consistency
5. Switch reads to PostgreSQL
6. Deprecate file writes
7. Archive old JSON files

---

## INFRASTRUCTURE INSIGHTS FOR ARENA

### 1. **Identity Model: Wallet-First**
- Article explores persona-per-NFT
- Arena should stay wallet-first (simpler, Web3-native)
- Optional: Add marble-level personas as enhancement

### 2. **Storage Philosophy: Start Simple, Scale Smart**
- Article warns against over-engineering (1 Google account per user)
- Arena's JSON files are perfect for current scale
- Postgres migration only when hitting 1,000+ active users

### 3. **Memory Architecture: Layered Approach**
- **Session memory**: Frontend state (conversation history)
- **Short-term memory**: Last 7 days of interactions (could add)
- **Long-term memory**: XP, achievements, unlocked lore (we have this)
- **Persistent facts**: User preferences, J3 learned insights (opportunity)

### 4. **Rate Limiting: Multi-Layer Defense**
Article doesn't mention rate limiting, but our J3 ALLOWANCE plan covers:
- Credit-based (gameplay earns access)
- Tier-based (XP unlocks higher limits)
- Time-based (daily resets)
- IP-based (fallback for guests)

### 5. **Cost Control: Quota Systems**
Google Drive analogy:
- 15GB limit prevents runaway storage
- 5M item cap prevents spam

J3 Credits analogy:
- 200 J3C max balance prevents hoarding
- Daily message caps prevent abuse
- Cost-per-message prevents unlimited API calls

---

## KEY TAKEAWAYS FOR THUNDERGOD BRAND

### From Article 1: "Face in the Wire"
1. **Visual Identity**: J3SSICA3's face/avatar should be prominent gateway
2. **Progressive Enhancement**: Start simple, add complexity when justified
3. **Ceremonial UX**: Make technical processes feel meaningful (auth animation)
4. **Local-First**: Consider offline/local capabilities (not cloud-dependent)

### From Article 2: "Persona Storage Architecture"
1. **Scalable Identity**: Wallet = identity, don't overcomplicate
2. **Storage Realism**: File-based is fine now, plan Postgres migration
3. **Memory Layers**: Distinguish short-term (chat) from long-term (achievements)
4. **Quota Philosophy**: Limits create sustainability and strategy

---

## PROPOSED ENHANCEMENTS INSPIRED BY ARTICLES

### 1. **J3SSICA3 "Face Scan" Animation**
When connecting wallet:
```
[J3's face appears, eyes glow]
"Scanning storm signature..."
[Particles analyze wallet address]
"0xABC...DEF verified ✓"
"Welcome back, Initiate."
```

### 2. **Marble Personas**
Each marble NFT has:
- Personality type (aggressive, wise, playful, mysterious)
- J3 adapts tone when user "speaks through" that marble
- Marble-specific memory/preferences

### 3. **Persistent J3 Memory**
Add to WalletMemory:
```typescript
{
  j3_learned_facts: string[];
  j3_conversation_summaries: ConversationSummary[];
  j3_tone_preference: "playful" | "serious" | "cryptic";
}
```

### 4. **Local Storage Fallback**
Article emphasizes local-first approach:
- Store J3 conversation in browser localStorage
- Sync to backend when online
- Works offline for cached data

### 5. **"Relay Channels" Lore Integration**
Article mentions: "Relay channels aligned"
- Use in Arena lore: "J3SSICA3 communicates through storm relay channels"
- When J3 is "thinking", show: "Aligning relay channels..."
- Failure states: "Storm interference detected. Retry..."

---

## ARCHITECTURAL DECISION MATRIX

| Feature | Article 1 Approach | Article 2 Approach | Arena Current | Recommended |
|---------|-------------------|-------------------|---------------|-------------|
| **Identity** | Face image file | PersonaId per NFT | Wallet address | ✅ Keep wallet-first |
| **Storage** | Local files | Google Drive accounts | JSON files | ✅ Keep JSON, plan Postgres |
| **AI Memory** | Not mentioned | Short/long-term split | Conversation history | ➕ Add persistent memory |
| **Personas** | Single face | One per NFT | One per wallet | ➕ Add marble personas |
| **Scaling** | Keep it simple | Cloud accounts | File-based | ➕ Plan Postgres at 1K users |
| **UX Loading** | Progressive | Not mentioned | Full React load | ➕ Add loading animations |

**Legend:**
- ✅ Keep current approach
- ➕ Enhancement opportunity
- ⚠️ Needs attention

---

## CONCLUSION

**Article 1** teaches us: **Simplicity and ceremony matter**. Make technical processes feel meaningful through UX, not just function.

**Article 2** teaches us: **Scaling architecture requires pragmatism**. Don't over-engineer for fantasy when simpler solutions work.

**Arena of Thunder** already implements many best practices:
- Wallet-centric identity (simpler than personas)
- File-based storage (appropriate for scale)
- AI integration with context awareness

**Next steps** informed by articles:
1. Add J3SSICA3 "face scan" visual during wallet connection
2. Implement J3 Credits allowance system (quota management)
3. Consider marble-level personas (optional enhancement)
4. Add persistent J3 memory layer
5. Plan Postgres migration for 1,000+ user milestone

---

**Document Version**: 1.0  
**Last Updated**: November 20, 2025  
**Author**: Replit Agent  
**Purpose**: Extract architectural insights from external articles for Arena planning
