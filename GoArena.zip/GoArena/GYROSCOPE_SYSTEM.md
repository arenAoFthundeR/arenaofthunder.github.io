# Gyroscope Code Injection System

## Overview
The Gyroscope Code Injection System enables admins to inject custom JavaScript code snippets that execute when specific device motion gestures are detected on mobile devices. This creates dynamic, motion-responsive web experiences without requiring app-level code changes.

## Architecture

### Core Components

1. **Motion Detection Engine** (`client/src/lib/gyroscope.ts`)
   - Interfaces with Device Motion and Orientation APIs
   - Detects 5 gesture types: shake, tilt, rotate, flip, twist
   - Handles permission requests for iOS 13+ devices
   - Manages cooldowns and debouncing
   - Supports debug logging

2. **Schema Layer** (`shared/gyro-schema.ts`)
   - TypeScript types and Zod schemas
   - Gesture trigger configuration
   - System configuration
   - Type-safe data structures

3. **Storage Layer** (`server/storage.ts`)
   - Persists configuration to `gyroscope.json`
   - CRUD operations for gesture triggers
   - Atomic file operations

4. **API Routes** (`server/routes.ts`)
   - `/api/gyro/config` - Get/update system configuration
   - `/api/gyro/triggers` - Manage gesture triggers
   - Admin-protected mutation endpoints

5. **Admin Interface** (`client/src/components/GyroscopeManager.tsx`)
   - Visual trigger configuration
   - Code editor for JavaScript injection
   - Real-time status monitoring
   - System toggles (enabled, debug, permissions)

6. **React Hook** (`client/src/hooks/useGyroscope.ts`)
   - Auto-initializes system on app load
   - Manages lifecycle (start/stop)
   - Permission handling
   - Status tracking

## Gesture Types

### 1. Shake
Detects rapid back-and-forth device motion
```typescript
{
  type: "shake",
  threshold: { acceleration: 20 }, // m/s²
  cooldown: 1000 // ms between triggers
}
```

### 2. Tilt
Detects device orientation changes
```typescript
{
  type: "tilt",
  threshold: {
    direction: "left" | "right" | "forward" | "back",
    angle: 30 // degrees
  }
}
```

### 3. Rotate
Detects rotation around specific axes
```typescript
{
  type: "rotate",
  threshold: {
    axis: "pitch" | "roll" | "yaw",
    degrees: 45
  }
}
```

### 4. Flip
Detects complete 180° device flips
```typescript
{
  type: "flip",
  threshold: {
    axis: "horizontal" | "vertical"
  }
}
```

### 5. Twist
Detects rapid rotation motion
```typescript
{
  type: "twist",
  threshold: {
    rotationRate: 200 // degrees/second
  }
}
```

## Usage Flow

### 1. Admin Configuration
1. Navigate to Admin Dashboard → Gyroscope tab
2. Enable the system with the main toggle
3. Create gesture triggers:
   - Name and describe the trigger
   - Select gesture type
   - Configure thresholds
   - Write JavaScript code to inject
   - Set cooldown period

### 2. Automatic Initialization
The system auto-initializes on app load via the `useGyroscope` hook in `Layout.tsx`:
```typescript
export function Layout({ children }: LayoutProps) {
  useGyroscope(); // Auto-starts monitoring
  // ...
}
```

### 3. Runtime Execution
When a user performs a configured gesture:
1. Motion event fires
2. Gesture detection algorithm evaluates event data
3. If threshold met and cooldown expired:
   - Trigger identified
   - Custom code executed in isolated scope
   - Cooldown timer starts
4. Debug logs (if enabled)

## Code Injection Safety

### Execution Context
Injected code runs in a sandboxed function scope with access to:
- `window` - Global window object
- `document` - DOM access
- React Query `queryClient` - Cache invalidation
- All standard browser APIs

### Example Injections

**Refresh Data on Shake**
```javascript
// Invalidate all queries to refresh data
import { queryClient } from '@/lib/queryClient';
queryClient.invalidateQueries();
console.log('🔄 Data refreshed!');
```

**Navigate on Tilt**
```javascript
// Navigate to a different page
window.location.href = '/arena';
```

**Toggle Theme on Twist**
```javascript
// Toggle dark mode
document.documentElement.classList.toggle('dark');
```

**Show Toast on Flip**
```javascript
// Display notification
import { toast } from '@/hooks/use-toast';
toast({
  title: "Device Flipped!",
  description: "You just flipped your phone"
});
```

## Permission Handling

### iOS 13+ Requirements
iOS requires explicit user permission for motion sensors:

```typescript
if (typeof DeviceMotionEvent?.requestPermission === 'function') {
  const permission = await DeviceMotionEvent.requestPermission();
  if (permission === 'granted') {
    // Start monitoring
  }
}
```

The system automatically requests permission when `requirePermission` is enabled in config.

### Android/Other Browsers
No permission required - sensors are always available.

## Configuration Options

### System Configuration
```typescript
{
  enabled: boolean;          // Master toggle
  debugMode: boolean;        // Console logging
  requirePermission: boolean; // Force permission request
  triggers: GestureTrigger[]; // Active triggers
}
```

### Gesture Trigger
```typescript
{
  id: string;
  name: string;
  description: string;
  enabled: boolean;
  type: "shake" | "tilt" | "rotate" | "flip" | "twist";
  threshold: object;         // Type-specific thresholds
  cooldown?: number;         // ms between executions
  duration?: number;         // Max execution time
  codeToInject: string;      // JavaScript code
}
```

## File Structure

```
Arena of Thunder
├── client/src/
│   ├── lib/
│   │   └── gyroscope.ts          # Motion detection engine
│   ├── hooks/
│   │   └── useGyroscope.ts       # React integration
│   ├── components/
│   │   ├── Layout.tsx            # System initialization
│   │   └── GyroscopeManager.tsx  # Admin interface
│   └── pages/
│       └── AdminDashboard.tsx    # Gyroscope tab
├── server/
│   ├── storage.ts                # Data persistence
│   └── routes.ts                 # API endpoints
├── shared/
│   └── gyro-schema.ts            # Type definitions
└── gyroscope.json                # Runtime configuration
```

## API Reference

### GET `/api/gyro/config`
Returns current system configuration and all triggers.

**Response:**
```json
{
  "enabled": true,
  "debugMode": false,
  "requirePermission": true,
  "triggers": [...]
}
```

### PATCH `/api/gyro/config` (Admin)
Update system configuration.

**Request:**
```json
{
  "enabled": true,
  "debugMode": true
}
```

### POST `/api/gyro/triggers` (Admin)
Create new gesture trigger.

**Request:**
```json
{
  "name": "Shake to Refresh",
  "description": "Refresh all data",
  "type": "shake",
  "threshold": { "acceleration": 20 },
  "cooldown": 1000,
  "codeToInject": "queryClient.invalidateQueries();"
}
```

### PATCH `/api/gyro/triggers/:id` (Admin)
Update existing trigger.

### DELETE `/api/gyro/triggers/:id` (Admin)
Delete trigger.

## Testing

### Browser DevTools
1. Open browser console
2. Enable debug mode in admin panel
3. Trigger gestures manually or use device
4. Observe detailed logging:
   ```
   [Gyro] Motion event: {acceleration: {x: 2.1, y: 1.3, z: 9.8}}
   [Gyro] Shake detected! Threshold: 20, Actual: 23.4
   [Gyro] Executing trigger: "Shake to Refresh"
   ```

### Mobile Testing
1. Access app on mobile device
2. Grant motion permissions if prompted
3. Perform physical gestures
4. Verify code execution (check logs or side effects)

### Desktop Simulation
Desktop browsers don't have motion sensors. For testing:
1. Use mobile device
2. Use browser DevTools device emulation (limited)
3. Use WebSocket/remote debugging
4. Trigger code manually via console

## Future Enhancements

- [ ] Gesture sequence triggers (shake then tilt)
- [ ] Gesture recording/playback for testing
- [ ] Visual feedback overlays
- [ ] Analytics dashboard for gesture usage
- [ ] User-facing gesture customization
- [ ] Haptic feedback integration
- [ ] Machine learning gesture recognition
- [ ] Multi-gesture combos

## Security Considerations

⚠️ **Admin Only**: Only admins can create/modify triggers
⚠️ **Code Review**: Injected code has full DOM access - review carefully
⚠️ **XSS Prevention**: Validate admin inputs, sanitize where possible
⚠️ **Performance**: Set appropriate cooldowns to prevent spam
⚠️ **Privacy**: Respect user motion data, don't log sensitive info

## Troubleshooting

### "Permission denied" on iOS
- Ensure `requirePermission` is enabled
- User must grant permission on first interaction
- Permission persists across sessions

### Gestures not detected
- Check system is enabled
- Verify trigger thresholds aren't too high
- Enable debug mode to see raw sensor data
- Confirm device has motion sensors

### Code not executing
- Check browser console for errors
- Verify syntax in injected code
- Check cooldown hasn't blocked execution
- Ensure trigger is enabled

### High battery drain
- Reduce number of active triggers
- Increase cooldown periods
- Disable when not needed
- Use `stopGyroscope()` to pause monitoring

---

**Built for Arena of Thunder** • Electric-themed Web3 gaming platform
