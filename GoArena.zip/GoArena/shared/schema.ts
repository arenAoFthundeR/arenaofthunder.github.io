import { z } from "zod";
import { 
  pgTable, 
  serial, 
  text, 
  integer, 
  boolean, 
  timestamp, 
  jsonb, 
  varchar,
  bigint,
  index 
} from "drizzle-orm/pg-core";
import { relations } from "drizzle-orm";

// Player/Wallet Data Schema
export const walletMemorySchema = z.object({
  wallet: z.string(),
  mintCount: z.number().default(0),
  giftsSent: z.number().default(0),
  giftsReceived: z.number().default(0),
  adminXpAdjustment: z.number().default(0),
  seenLoreIds: z.array(z.number()).default([]),
  firstSeen: z.string(),
  lastSeen: z.string(),
});

export type WalletMemory = z.infer<typeof walletMemorySchema>;

export const insertWalletMemorySchema = walletMemorySchema.partial({
  firstSeen: true,
  lastSeen: true,
});

export type InsertWalletMemory = z.infer<typeof insertWalletMemorySchema>;

// XP & Level Data
export const xpDataSchema = z.object({
  wallet: z.string(),
  xp: z.number(),
  level: z.number(),
  badges: z.array(z.string()),
});

export type XpData = z.infer<typeof xpDataSchema>;

// Leaderboard Entry
export const leaderboardEntrySchema = z.object({
  wallet: z.string(),
  xp: z.number(),
  level: z.number(),
  mints: z.number(),
  giftsSent: z.number(),
  giftsReceived: z.number(),
  lastSeen: z.string().optional(),
});

export type LeaderboardEntry = z.infer<typeof leaderboardEntrySchema>;

// Lore Piece
export const lorePieceSchema = z.object({
  id: z.number(),
  title: z.string(),
  text: z.string(),
  unlocked: z.boolean().optional(),
});

export type LorePiece = z.infer<typeof lorePieceSchema>;

export const loreUnlockRequestSchema = z.object({
  wallet: z.string(),
  id: z.number(),
});

export type LoreUnlockRequest = z.infer<typeof loreUnlockRequestSchema>;

// Tournament Data
export const tournamentRoundSchema = z.object({
  wallet: z.string(),
  round: z.number(),
  time: z.number(),
});

export type TournamentRound = z.infer<typeof tournamentRoundSchema>;

export const tournamentDataSchema = z.object({
  participants: z.array(z.string()),
  rounds: z.array(tournamentRoundSchema),
});

export type TournamentData = z.infer<typeof tournamentDataSchema>;

export const tournamentJoinRequestSchema = z.object({
  wallet: z.string(),
});

export type TournamentJoinRequest = z.infer<typeof tournamentJoinRequestSchema>;

// API Request/Response Schemas
export const walletRequestSchema = z.object({
  wallet: z.string().min(1, "Wallet address required"),
});

export type WalletRequest = z.infer<typeof walletRequestSchema>;

export const memoryUpdateSchema = z.object({
  wallet: z.string(),
  changes: z.record(z.unknown()),
});

export type MemoryUpdate = z.infer<typeof memoryUpdateSchema>;

// Marble Combat System
export const marbleRaritySchema = z.enum(["common", "uncommon", "rare", "epic", "legendary", "mythic"]);
export type MarbleRarity = z.infer<typeof marbleRaritySchema>;

export const marbleSchema = z.object({
  id: z.number(),
  wallet: z.string(),
  name: z.string(),
  description: z.string(),
  rarity: marbleRaritySchema,
  attack: z.number(),
  defense: z.number(),
  speed: z.number(),
  health: z.number(),
  isMinted: z.boolean().default(false),
  tokenId: z.number().optional(),
  txHash: z.string().optional(),
  mintedAt: z.string().optional(),
  createdAt: z.string(),
});

export type Marble = z.infer<typeof marbleSchema>;

export const createMarbleSchema = marbleSchema.omit({ 
  id: true, 
  createdAt: true,
  isMinted: true,
  tokenId: true,
  txHash: true,
  mintedAt: true,
});

export type CreateMarble = z.infer<typeof createMarbleSchema>;

// Dungeon System
export const dungeonStatusSchema = z.enum(["active", "victory", "defeat", "retreat"]);
export type DungeonStatus = z.infer<typeof dungeonStatusSchema>;

export const dungeonEnemySchema = z.object({
  name: z.string(),
  description: z.string(),
  attack: z.number(),
  defense: z.number(),
  speed: z.number(),
  health: z.number(),
  currentHealth: z.number(),
});

export type DungeonEnemy = z.infer<typeof dungeonEnemySchema>;

export const dungeonRunSchema = z.object({
  id: z.number(),
  wallet: z.string(),
  marbleId: z.number(),
  currentFloor: z.number(),
  maxFloorReached: z.number(),
  status: dungeonStatusSchema,
  isActive: z.boolean(),
  experienceGained: z.number(),
  currentEnemy: dungeonEnemySchema.optional(),
  marbleCurrentHealth: z.number(),
  createdAt: z.string(),
  completedAt: z.string().optional(),
});

export type DungeonRun = z.infer<typeof dungeonRunSchema>;

export const createDungeonRunSchema = z.object({
  wallet: z.string(),
  marbleId: z.number(),
});

export type CreateDungeonRun = z.infer<typeof createDungeonRunSchema>;

export const dungeonActionSchema = z.object({
  runId: z.number(),
  action: z.enum(["attack", "defend", "retreat"]),
});

export type DungeonAction = z.infer<typeof dungeonActionSchema>;

// Security Console
export const securityEventTypeSchema = z.enum([
  "bluetooth_scan",
  "usb_detection", 
  "network_monitor",
  "firmware_check",
  "anomaly_detected",
  "manual_audit"
]);

export type SecurityEventType = z.infer<typeof securityEventTypeSchema>;

export const securitySeveritySchema = z.enum(["info", "warning", "critical"]);
export type SecuritySeverity = z.infer<typeof securitySeveritySchema>;

export const securityEventSchema = z.object({
  id: z.number(),
  wallet: z.string(),
  eventType: securityEventTypeSchema,
  severity: securitySeveritySchema,
  message: z.string(),
  details: z.record(z.unknown()),
  createdAt: z.string(),
});

export type SecurityEvent = z.infer<typeof securityEventSchema>;

export const createSecurityEventSchema = z.object({
  wallet: z.string(),
  eventType: securityEventTypeSchema,
  severity: securitySeveritySchema,
  message: z.string(),
  details: z.record(z.unknown()).default({}),
});

export type CreateSecurityEvent = z.infer<typeof createSecurityEventSchema>;

// NFT Persona System (J3SSICA3-managed infinite storage AI)
export const aiStylePresetSchema = z.enum([
  "aggressive",
  "gentle",
  "chaotic_neutral",
  "wise_elder",
  "rebellious",
  "protective",
  "analytical",
  "empathetic"
]);

export type AIStylePreset = z.infer<typeof aiStylePresetSchema>;

export const personaMemorySchema = z.object({
  shortTerm: z.array(z.object({
    role: z.enum(["user", "assistant"]),
    content: z.string(),
    timestamp: z.string(),
  })),
  longTerm: z.array(z.object({
    summary: z.string(),
    importance: z.number(),
    createdAt: z.string(),
  })),
});

export type PersonaMemory = z.infer<typeof personaMemorySchema>;

export const personaSchema = z.object({
  id: z.string(), // UUID or NFT token ID
  createdAt: z.string(),
  lastActive: z.string(),
  ownerWallet: z.string().optional(),
  nftTokenId: z.string().optional(),
  nftContract: z.string().optional(),
  aiStylePreset: aiStylePresetSchema,
  customPersonality: z.string().optional(),
  memory: personaMemorySchema,
  assets: z.object({
    marbles: z.array(z.number()).default([]),
    titles: z.array(z.string()).default([]),
    achievements: z.array(z.string()).default([]),
  }).default({ marbles: [], titles: [], achievements: [] }),
  metadata: z.record(z.unknown()).default({}),
  totalConversations: z.number().default(0),
  totalMessages: z.number().default(0),
});

export type Persona = z.infer<typeof personaSchema>;

export const createPersonaSchema = z.object({
  ownerWallet: z.string().optional(),
  nftTokenId: z.string().optional(),
  nftContract: z.string().optional(),
  aiStylePreset: aiStylePresetSchema.default("chaotic_neutral"),
  customPersonality: z.string().optional(),
});

export type CreatePersona = z.infer<typeof createPersonaSchema>;

export const personaChatRequestSchema = z.object({
  personaId: z.string(),
  message: z.string().min(1),
  context: z.record(z.unknown()).optional(),
});

export type PersonaChatRequest = z.infer<typeof personaChatRequestSchema>;

export const personaChatResponseSchema = z.object({
  reply: z.string(),
  personaId: z.string(),
  timestamp: z.string(),
  memoryUpdated: z.boolean(),
});

export type PersonaChatResponse = z.infer<typeof personaChatResponseSchema>;

// J3SSICA3 Allowance System (Credit Economy)
export const j3CreditTierSchema = z.enum([
  "Novice",      // 0-99 J3C
  "Apprentice",  // 100-499 J3C
  "Adept",       // 500-999 J3C
  "Master",      // 1000-4999 J3C
  "Legend"       // 5000+ J3C
]);

export type J3CreditTier = z.infer<typeof j3CreditTierSchema>;

export const j3CreditBalanceSchema = z.object({
  wallet: z.string(),
  balance: z.number(),
  tier: j3CreditTierSchema,
  lastRegenerated: z.string(), // ISO timestamp of last daily regen
  totalEarned: z.number().default(0),
  totalSpent: z.number().default(0),
  gracePeriodMessages: z.number().default(3), // Free messages for new users
  firstSeen: z.string(),
  lastUpdated: z.string(),
});

export type J3CreditBalance = z.infer<typeof j3CreditBalanceSchema>;

export const createJ3CreditBalanceSchema = z.object({
  wallet: z.string(),
  balance: z.number().default(100), // New users start with 100 J3C
  gracePeriodMessages: z.number().default(3),
});

export type CreateJ3CreditBalance = z.infer<typeof createJ3CreditBalanceSchema>;

export const j3UsageLogSchema = z.object({
  id: z.number(),
  wallet: z.string(),
  action: z.enum([
    "chat_message",    // -5 J3C
    "wallet_connect",  // +50 J3C (one-time)
    "mint_marble",     // +10 J3C
    "send_gift",       // +5 J3C
    "receive_gift",    // +5 J3C
    "unlock_lore",     // +15 J3C
    "join_tournament", // +20 J3C
    "advance_round",   // +25 J3C
    "daily_regen",     // +10 J3C
    "admin_grant",     // Variable (admin action)
    "grace_period",    // 0 J3C (free message)
  ]),
  creditsChange: z.number(), // Positive for earnings, negative for spending
  balanceAfter: z.number(),
  timestamp: z.string(),
  metadata: z.record(z.unknown()).default({}),
});

export type J3UsageLog = z.infer<typeof j3UsageLogSchema>;

export const createJ3UsageLogSchema = j3UsageLogSchema.omit({
  id: true,
  timestamp: true,
});

export type CreateJ3UsageLog = z.infer<typeof createJ3UsageLogSchema>;

export const j3CreditEarnRequestSchema = z.object({
  wallet: z.string(),
  action: z.enum([
    "wallet_connect",
    "mint_marble",
    "send_gift",
    "receive_gift",
    "unlock_lore",
    "join_tournament",
    "advance_round",
  ]),
  metadata: z.record(z.unknown()).optional(),
});

export type J3CreditEarnRequest = z.infer<typeof j3CreditEarnRequestSchema>;

// ============================================================================
// DRIZZLE DATABASE SCHEMAS - PostgreSQL Physical Storage
// ============================================================================

// Wallets Table - Core player data
export const wallets = pgTable("wallets", {
  id: serial("id").primaryKey(),
  wallet: varchar("wallet", { length: 42 }).notNull().unique(),
  mintCount: integer("mint_count").notNull().default(0),
  giftsSent: integer("gifts_sent").notNull().default(0),
  giftsReceived: integer("gifts_received").notNull().default(0),
  adminXpAdjustment: integer("admin_xp_adjustment").notNull().default(0),
  seenLoreIds: jsonb("seen_lore_ids").$type<number[]>().notNull().default([]),
  firstSeen: timestamp("first_seen").notNull().defaultNow(),
  lastSeen: timestamp("last_seen").notNull().defaultNow(),
}, (table) => ({
  walletIdx: index("wallet_idx").on(table.wallet),
  lastSeenIdx: index("last_seen_idx").on(table.lastSeen),
  // Composite index for leaderboard queries (ordering by XP components)
  leaderboardIdx: index("leaderboard_idx").on(
    table.mintCount, 
    table.giftsSent, 
    table.giftsReceived, 
    table.adminXpAdjustment
  ),
}));

export type DBWallet = typeof wallets.$inferSelect;
export type InsertDBWallet = typeof wallets.$inferInsert;

// Lore Pieces Table - Narrative fragments
export const lore = pgTable("lore", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  text: text("text").notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export type DBLore = typeof lore.$inferSelect;
export type InsertDBLore = typeof lore.$inferInsert;

// J3 Credit Balances Table - Credit economy
export const j3Credits = pgTable("j3_credits", {
  id: serial("id").primaryKey(),
  wallet: varchar("wallet", { length: 42 }).notNull().unique(),
  balance: integer("balance").notNull().default(100),
  tier: varchar("tier", { length: 20 }).notNull().default("Apprentice"),
  lastRegenerated: timestamp("last_regenerated").notNull().defaultNow(),
  totalEarned: integer("total_earned").notNull().default(100),
  totalSpent: integer("total_spent").notNull().default(0),
  gracePeriodMessages: integer("grace_period_messages").notNull().default(3),
  firstSeen: timestamp("first_seen").notNull().defaultNow(),
  lastUpdated: timestamp("last_updated").notNull().defaultNow(),
}, (table) => ({
  walletIdx: index("j3_wallet_idx").on(table.wallet),
  tierIdx: index("j3_tier_idx").on(table.tier),
  balanceIdx: index("j3_balance_idx").on(table.balance),
}));

export type DBJ3Credit = typeof j3Credits.$inferSelect;
export type InsertDBJ3Credit = typeof j3Credits.$inferInsert;

// J3 Usage Logs Table - Transaction history
export const j3UsageLogs = pgTable("j3_usage_logs", {
  id: serial("id").primaryKey(),
  wallet: varchar("wallet", { length: 42 }).notNull(),
  action: varchar("action", { length: 50 }).notNull(),
  creditsChange: integer("credits_change").notNull(),
  balanceAfter: integer("balance_after").notNull(),
  timestamp: timestamp("timestamp").notNull().defaultNow(),
  metadata: jsonb("metadata").$type<Record<string, unknown>>().notNull().default({}),
}, (table) => ({
  walletIdx: index("j3_usage_wallet_idx").on(table.wallet),
  timestampIdx: index("j3_usage_timestamp_idx").on(table.timestamp),
  actionIdx: index("j3_usage_action_idx").on(table.action),
}));

export type DBJ3UsageLog = typeof j3UsageLogs.$inferSelect;
export type InsertDBJ3UsageLog = typeof j3UsageLogs.$inferInsert;

// Marbles Table - NFT combat units
export const marbles = pgTable("marbles", {
  id: serial("id").primaryKey(),
  wallet: varchar("wallet", { length: 42 }).notNull(),
  name: text("name").notNull(),
  description: text("description").notNull(),
  rarity: varchar("rarity", { length: 20 }).notNull(),
  attack: integer("attack").notNull(),
  defense: integer("defense").notNull(),
  speed: integer("speed").notNull(),
  health: integer("health").notNull(),
  isMinted: boolean("is_minted").notNull().default(false),
  tokenId: integer("token_id"),
  txHash: text("tx_hash"),
  mintedAt: timestamp("minted_at"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
}, (table) => ({
  walletIdx: index("marbles_wallet_idx").on(table.wallet),
  rarityIdx: index("marbles_rarity_idx").on(table.rarity),
  isMintedIdx: index("marbles_is_minted_idx").on(table.isMinted),
}));

export type DBMarble = typeof marbles.$inferSelect;
export type InsertDBMarble = typeof marbles.$inferInsert;

// Dungeon Runs Table - Combat sessions
export const dungeonRuns = pgTable("dungeon_runs", {
  id: serial("id").primaryKey(),
  wallet: varchar("wallet", { length: 42 }).notNull(),
  marbleId: integer("marble_id").notNull(),
  currentFloor: integer("current_floor").notNull().default(1),
  maxFloorReached: integer("max_floor_reached").notNull().default(1),
  status: varchar("status", { length: 20 }).notNull(),
  isActive: boolean("is_active").notNull().default(true),
  experienceGained: integer("experience_gained").notNull().default(0),
  currentEnemy: jsonb("current_enemy").$type<DungeonEnemy | null>(),
  marbleCurrentHealth: integer("marble_current_health").notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  completedAt: timestamp("completed_at"),
}, (table) => ({
  walletIdx: index("dungeon_wallet_idx").on(table.wallet),
  marbleIdIdx: index("dungeon_marble_idx").on(table.marbleId),
  isActiveIdx: index("dungeon_active_idx").on(table.isActive),
  // Composite index for dungeon history queries (wallet + timestamp ordering)
  historyIdx: index("dungeon_history_idx").on(table.wallet, table.createdAt),
}));

export type DBDungeonRun = typeof dungeonRuns.$inferSelect;
export type InsertDBDungeonRun = typeof dungeonRuns.$inferInsert;

// Personas Table - AI personality storage
export const personas = pgTable("personas", {
  id: varchar("id", { length: 100 }).primaryKey(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  lastActive: timestamp("last_active").notNull().defaultNow(),
  ownerWallet: varchar("owner_wallet", { length: 42 }),
  nftTokenId: varchar("nft_token_id", { length: 100 }),
  nftContract: varchar("nft_contract", { length: 42 }),
  aiStylePreset: varchar("ai_style_preset", { length: 30 }).notNull(),
  customPersonality: text("custom_personality"),
  memory: jsonb("memory").$type<PersonaMemory>().notNull(),
  assets: jsonb("assets").$type<{ marbles: number[]; titles: string[]; achievements: string[] }>().notNull().default({ marbles: [], titles: [], achievements: [] }),
  metadata: jsonb("metadata").$type<Record<string, unknown>>().notNull().default({}),
  totalConversations: integer("total_conversations").notNull().default(0),
  totalMessages: integer("total_messages").notNull().default(0),
}, (table) => ({
  ownerIdx: index("persona_owner_idx").on(table.ownerWallet),
  nftTokenIdx: index("persona_nft_token_idx").on(table.nftTokenId),
  lastActiveIdx: index("persona_last_active_idx").on(table.lastActive),
  // Composite index for wallet-based persona queries
  walletPersonasIdx: index("persona_wallet_personas_idx").on(table.ownerWallet, table.lastActive),
}));

export type DBPersona = typeof personas.$inferSelect;
export type InsertDBPersona = typeof personas.$inferInsert;

// J3 Memories Table - Long-term conversational memory
export const j3Memories = pgTable("j3_memories", {
  id: serial("id").primaryKey(),
  wallet: varchar("wallet", { length: 42 }).notNull(),
  personaId: varchar("persona_id", { length: 100 }),
  conversationSummary: text("conversation_summary").notNull(),
  learnedFacts: jsonb("learned_facts").$type<string[]>().notNull().default([]),
  preferences: jsonb("preferences").$type<{
    tone?: string;
    topics?: string[];
    avoid?: string[];
  }>().notNull().default({}),
  metadata: jsonb("metadata").$type<Record<string, unknown>>().notNull().default({}),
  interactionCount: integer("interaction_count").notNull().default(1),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  lastUpdated: timestamp("last_updated").notNull().defaultNow(),
}, (table) => ({
  walletIdx: index("j3_mem_wallet_idx").on(table.wallet),
  personaIdx: index("j3_mem_persona_idx").on(table.personaId),
  walletPersonaIdx: index("j3_mem_wallet_persona_idx").on(table.wallet, table.personaId),
  lastUpdatedIdx: index("j3_mem_updated_idx").on(table.lastUpdated),
}));

export type DBJ3Memory = typeof j3Memories.$inferSelect;
export type InsertDBJ3Memory = typeof j3Memories.$inferInsert;

// J3 Memory API Types
export const j3MemorySchema = z.object({
  id: z.number(),
  wallet: z.string(),
  personaId: z.string().nullable(),
  conversationSummary: z.string(),
  learnedFacts: z.array(z.string()),
  preferences: z.object({
    tone: z.string().optional(),
    topics: z.array(z.string()).optional(),
    avoid: z.array(z.string()).optional(),
  }),
  metadata: z.record(z.unknown()),
  interactionCount: z.number(),
  createdAt: z.string(),
  lastUpdated: z.string(),
});

export const insertJ3MemorySchema = j3MemorySchema.omit({ id: true, createdAt: true, lastUpdated: true });
export const updateJ3MemorySchema = j3MemorySchema.partial().required({ id: true });

export type J3Memory = z.infer<typeof j3MemorySchema>;
export type InsertJ3Memory = z.infer<typeof insertJ3MemorySchema>;
export type UpdateJ3Memory = z.infer<typeof updateJ3MemorySchema>;

// J3 Conversations Table - Conversation thread tracking
export const j3Conversations = pgTable("j3_conversations", {
  id: serial("id").primaryKey(),
  wallet: varchar("wallet", { length: 42 }).notNull(),
  personaId: varchar("persona_id", { length: 100 }),
  title: text("title").notNull(),
  messageCount: integer("message_count").notNull().default(0),
  totalCreditsSpent: integer("total_credits_spent").notNull().default(0),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  lastMessageAt: timestamp("last_message_at").notNull().defaultNow(),
}, (table) => ({
  walletIdx: index("j3_conv_wallet_idx").on(table.wallet),
  personaIdx: index("j3_conv_persona_idx").on(table.personaId),
  walletPersonaIdx: index("j3_conv_wallet_persona_idx").on(table.wallet, table.personaId),
  lastMessageIdx: index("j3_conv_last_msg_idx").on(table.lastMessageAt),
}));

export type DBJ3Conversation = typeof j3Conversations.$inferSelect;
export type InsertDBJ3Conversation = typeof j3Conversations.$inferInsert;

// J3 Messages Table - Individual messages in conversations
export const j3Messages = pgTable("j3_messages", {
  id: serial("id").primaryKey(),
  conversationId: integer("conversation_id").notNull().references(() => j3Conversations.id, { onDelete: "cascade" }),
  role: varchar("role", { length: 20 }).notNull(), // 'user' or 'assistant'
  content: text("content").notNull(),
  creditsSpent: integer("credits_spent").notNull().default(0),
  timestamp: timestamp("timestamp").notNull().defaultNow(),
}, (table) => ({
  conversationIdx: index("j3_msg_conv_idx").on(table.conversationId),
  timestampIdx: index("j3_msg_timestamp_idx").on(table.timestamp),
}));

export type DBJ3Message = typeof j3Messages.$inferSelect;
export type InsertDBJ3Message = typeof j3Messages.$inferInsert;

// J3 Conversation API Types
export const j3ConversationSchema = z.object({
  id: z.number(),
  wallet: z.string(),
  personaId: z.string().nullable(),
  title: z.string(),
  messageCount: z.number(),
  totalCreditsSpent: z.number(),
  createdAt: z.string(),
  lastMessageAt: z.string(),
});

export const j3MessageSchema = z.object({
  id: z.number(),
  conversationId: z.number(),
  role: z.enum(["user", "assistant"]),
  content: z.string(),
  creditsSpent: z.number(),
  timestamp: z.string(),
});

export const insertJ3ConversationSchema = j3ConversationSchema.omit({ 
  id: true, 
  messageCount: true,
  totalCreditsSpent: true,
  createdAt: true, 
  lastMessageAt: true 
});

export const insertJ3MessageSchema = j3MessageSchema.omit({ 
  id: true, 
  timestamp: true 
});

export type J3Conversation = z.infer<typeof j3ConversationSchema>;
export type J3Message = z.infer<typeof j3MessageSchema>;
export type InsertJ3Conversation = z.infer<typeof insertJ3ConversationSchema>;
export type InsertJ3Message = z.infer<typeof insertJ3MessageSchema>;

// Tournament Participants Table
export const tournamentParticipants = pgTable("tournament_participants", {
  id: serial("id").primaryKey(),
  wallet: varchar("wallet", { length: 42 }).notNull(),
  joinedAt: timestamp("joined_at").notNull().defaultNow(),
}, (table) => ({
  walletIdx: index("tournament_part_wallet_idx").on(table.wallet),
}));

export type DBTournamentParticipant = typeof tournamentParticipants.$inferSelect;
export type InsertDBTournamentParticipant = typeof tournamentParticipants.$inferInsert;

// Tournament Rounds Table
export const tournamentRounds = pgTable("tournament_rounds", {
  id: serial("id").primaryKey(),
  wallet: varchar("wallet", { length: 42 }).notNull(),
  round: integer("round").notNull(),
  time: bigint("time", { mode: "number" }).notNull(),
  completedAt: timestamp("completed_at").notNull(),
}, (table) => ({
  walletIdx: index("tournament_round_wallet_idx").on(table.wallet),
  roundIdx: index("tournament_round_idx").on(table.round),
}));

export type DBTournamentRound = typeof tournamentRounds.$inferSelect;
export type InsertDBTournamentRound = typeof tournamentRounds.$inferInsert;

// Security Events Table
export const securityEvents = pgTable("security_events", {
  id: serial("id").primaryKey(),
  wallet: varchar("wallet", { length: 42 }).notNull(),
  eventType: varchar("event_type", { length: 50 }).notNull(),
  severity: varchar("severity", { length: 20 }).notNull(),
  message: text("message").notNull(),
  details: jsonb("details").$type<Record<string, unknown>>().notNull().default({}),
  createdAt: timestamp("created_at").notNull().defaultNow(),
}, (table) => ({
  walletIdx: index("security_wallet_idx").on(table.wallet),
  severityIdx: index("security_severity_idx").on(table.severity),
  eventTypeIdx: index("security_event_type_idx").on(table.eventType),
}));

export type DBSecurityEvent = typeof securityEvents.$inferSelect;
export type InsertDBSecurityEvent = typeof securityEvents.$inferInsert;

// User Activity Timeline System
export const activityEventTypeSchema = z.enum([
  // Marble Events
  "marble_minted",
  "marble_gifted_sent",
  "marble_gifted_received",
  
  // Lore Events
  "lore_unlocked",
  
  // Tournament Events
  "tournament_joined",
  "tournament_round_completed",
  "tournament_won",
  
  // J3 Credit Events
  "credits_earned",
  "credits_spent",
  "credits_daily_regen",
  
  // J3 AI Events
  "j3_chat_message",
  "j3_conversation_started",
  
  // Dungeon Events
  "dungeon_started",
  "dungeon_completed",
  "dungeon_failed",
  
  // Persona Events
  "persona_created",
  
  // XP Events
  "xp_gained",
  "level_up",
  
  // Account Events
  "wallet_first_seen",
  "admin_xp_adjustment"
]);

export type ActivityEventType = z.infer<typeof activityEventTypeSchema>;

export const userActivities = pgTable("user_activities", {
  id: serial("id").primaryKey(),
  wallet: varchar("wallet", { length: 42 }).notNull(),
  eventType: varchar("event_type", { length: 50 }).notNull(),
  description: text("description").notNull(),
  metadata: jsonb("metadata").$type<Record<string, unknown>>().notNull().default({}),
  createdAt: timestamp("created_at").notNull().defaultNow(),
}, (table) => ({
  walletIdx: index("activity_wallet_idx").on(table.wallet),
  eventTypeIdx: index("activity_event_type_idx").on(table.eventType),
  createdAtIdx: index("activity_created_at_idx").on(table.createdAt),
  walletEventIdx: index("activity_wallet_event_idx").on(table.wallet, table.eventType),
  walletTimeIdx: index("activity_wallet_time_idx").on(table.wallet, table.createdAt),
}));

export const userActivitySchema = z.object({
  id: z.number(),
  wallet: z.string(),
  eventType: activityEventTypeSchema,
  description: z.string(),
  metadata: z.record(z.unknown()),
  createdAt: z.string(),
});

export type UserActivity = z.infer<typeof userActivitySchema>;

export const createUserActivitySchema = z.object({
  wallet: z.string(),
  eventType: activityEventTypeSchema,
  description: z.string(),
  metadata: z.record(z.unknown()).default({}),
});

export type CreateUserActivity = z.infer<typeof createUserActivitySchema>;

export type DBUserActivity = typeof userActivities.$inferSelect;
export type InsertDBUserActivity = typeof userActivities.$inferInsert;

// Relations for better query joins
export const walletsRelations = relations(wallets, ({ many }) => ({
  marbles: many(marbles),
  dungeonRuns: many(dungeonRuns),
  j3Credits: many(j3Credits),
  j3UsageLogs: many(j3UsageLogs),
  tournamentParticipants: many(tournamentParticipants),
  tournamentRounds: many(tournamentRounds),
  securityEvents: many(securityEvents),
  userActivities: many(userActivities),
}));

export const marblesRelations = relations(marbles, ({ one }) => ({
  wallet: one(wallets, {
    fields: [marbles.wallet],
    references: [wallets.wallet],
  }),
}));

export const j3CreditsRelations = relations(j3Credits, ({ one }) => ({
  wallet: one(wallets, {
    fields: [j3Credits.wallet],
    references: [wallets.wallet],
  }),
}));
