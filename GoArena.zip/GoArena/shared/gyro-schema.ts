import { z } from "zod";

/**
 * Shared schemas for gyroscope code injection system
 */

export const gestureTriggerSchema = z.object({
  id: z.string(),
  name: z.string().min(1).max(100),
  description: z.string().max(500),
  enabled: z.boolean().default(true),
  type: z.enum(['orientation', 'motion', 'shake', 'tilt', 'rotation']),
  threshold: z.object({
    alpha: z.object({
      min: z.number().min(0).max(360).optional(),
      max: z.number().min(0).max(360).optional(),
    }).optional(),
    beta: z.object({
      min: z.number().min(-180).max(180).optional(),
      max: z.number().min(-180).max(180).optional(),
    }).optional(),
    gamma: z.object({
      min: z.number().min(-90).max(90).optional(),
      max: z.number().min(-90).max(90).optional(),
    }).optional(),
    acceleration: z.number().min(0).optional(),
    rotationRate: z.number().min(0).optional(),
  }),
  duration: z.number().min(0).optional(),
  cooldown: z.number().min(0).optional(),
  codeToInject: z.string().min(1).max(10000),
  lastTriggered: z.number().optional(),
});

export const gyroscopeConfigSchema = z.object({
  enabled: z.boolean(),
  triggers: z.array(gestureTriggerSchema),
  debugMode: z.boolean().default(false),
  requirePermission: z.boolean().default(true),
});

export const insertGestureTriggerSchema = gestureTriggerSchema.omit({ id: true, lastTriggered: true });
export const updateGestureTriggerSchema = gestureTriggerSchema.partial().required({ id: true });

export type GestureTrigger = z.infer<typeof gestureTriggerSchema>;
export type GyroscopeConfig = z.infer<typeof gyroscopeConfigSchema>;
export type InsertGestureTrigger = z.infer<typeof insertGestureTriggerSchema>;
export type UpdateGestureTrigger = z.infer<typeof updateGestureTriggerSchema>;
