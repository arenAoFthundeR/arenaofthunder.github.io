import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Wallet, Power, Copy, Check } from "lucide-react";
import { connectWallet, getConnectedAccount, truncateAddress, setupWalletListeners } from "@/lib/web3";
import { useToast } from "@/hooks/use-toast";

interface WalletConnectProps {
  onConnect: (address: string) => void;
  onDisconnect: () => void;
}

export function WalletConnect({ onConnect, onDisconnect }: WalletConnectProps) {
  const [address, setAddress] = useState<string | null>(null);
  const [isConnecting, setIsConnecting] = useState(false);
  const [copied, setCopied] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    const checkConnection = async () => {
      const account = await getConnectedAccount();
      if (account) {
        setAddress(account);
        onConnect(account);
      }
    };
    checkConnection();

    const cleanup = setupWalletListeners(
      (accounts) => {
        if (accounts.length === 0) {
          setAddress(null);
          onDisconnect();
        } else if (accounts[0] !== address) {
          setAddress(accounts[0]);
          onConnect(accounts[0]);
        }
      },
      () => {
        window.location.reload();
      }
    );

    return cleanup;
  }, []);

  const handleConnect = async () => {
    setIsConnecting(true);
    try {
      const account = await connectWallet();
      setAddress(account);
      onConnect(account);
      toast({
        title: "Wallet Connected",
        description: `Connected to ${truncateAddress(account)}`,
      });
    } catch (error: any) {
      toast({
        title: "Connection Failed",
        description: error.message || "Failed to connect wallet",
        variant: "destructive",
      });
    } finally {
      setIsConnecting(false);
    }
  };

  const handleDisconnect = () => {
    setAddress(null);
    onDisconnect();
    toast({
      title: "Wallet Disconnected",
      description: "Your wallet has been disconnected",
    });
  };

  const handleCopy = async () => {
    if (address) {
      await navigator.clipboard.writeText(address);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
      toast({
        title: "Address Copied",
        description: "Wallet address copied to clipboard",
      });
    }
  };

  if (!address) {
    return (
      <Button
        onClick={handleConnect}
        disabled={isConnecting}
        className="bg-gradient-to-r from-primary to-accent hover:opacity-90 transition-opacity"
        data-testid="button-connect-wallet"
      >
        <Wallet className="w-4 h-4 mr-2" />
        {isConnecting ? "Connecting..." : "Connect Wallet"}
      </Button>
    );
  }

  return (
    <div className="flex items-center gap-2">
      <div className="flex items-center gap-2 px-4 py-2 rounded-lg bg-card border border-card-border">
        <Wallet className="w-4 h-4 text-primary" />
        <span className="font-mono text-sm" data-testid="text-wallet-address">
          {truncateAddress(address)}
        </span>
        <Button
          size="icon"
          variant="ghost"
          onClick={handleCopy}
          className="h-7 w-7"
          data-testid="button-copy-address"
        >
          {copied ? <Check className="w-3 h-3" /> : <Copy className="w-3 h-3" />}
        </Button>
      </div>
      <Button
        size="icon"
        variant="ghost"
        onClick={handleDisconnect}
        className="h-9 w-9"
        data-testid="button-disconnect-wallet"
      >
        <Power className="w-4 h-4" />
      </Button>
    </div>
  );
}
