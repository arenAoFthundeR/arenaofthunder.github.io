import { useState, useEffect } from "react";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Sparkles, ImageOff } from "lucide-react";
import { arenaContract, type MarbleMetadata } from "@/lib/contract";
import { useToast } from "@/hooks/use-toast";

interface NFTGalleryProps {
  wallet: string | null;
}

const RARITY_COLORS = {
  Common: "bg-muted text-muted-foreground",
  Rare: "bg-primary/20 text-primary border-primary/50",
  Epic: "bg-accent/20 text-accent border-accent/50",
  Legendary: "bg-gradient-to-r from-chart-5 to-destructive text-background",
};

export function NFTGallery({ wallet }: NFTGalleryProps) {
  const [marbles, setMarbles] = useState<MarbleMetadata[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const { toast } = useToast();

  useEffect(() => {
    async function loadMarbles() {
      if (!wallet) {
        // Clear marbles and reset state when wallet disconnects
        setMarbles([]);
        setError(null);
        setIsLoading(false);
        return;
      }

      try {
        setIsLoading(true);
        setError(null);
        const ownedMarbles = await arenaContract.getOwnedMarbles(wallet);
        setMarbles(ownedMarbles);
      } catch (err: any) {
        console.error("Failed to load marbles:", err);
        
        if (err.message?.includes("Contract address not configured")) {
          setError("Smart contract not deployed. Configure VITE_CONTRACT_ADDRESS.");
        } else {
          setError("Failed to load your marble collection");
          toast({
            title: "Error Loading NFTs",
            description: "Could not fetch your marble collection from the blockchain",
            variant: "destructive",
          });
        }
      } finally {
        setIsLoading(false);
      }
    }

    loadMarbles();
  }, [wallet, toast]);

  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-primary" />
            My Marble Collection
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
            {Array.from({ length: 4 }).map((_, i) => (
              <Skeleton key={i} className="h-48 w-full" />
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  if (error) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-primary" />
            My Marble Collection
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center py-12">
            <ImageOff className="w-12 h-12 text-muted-foreground mx-auto mb-4 opacity-50" />
            <p className="text-muted-foreground">{error}</p>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between space-y-0">
        <CardTitle className="flex items-center gap-2">
          <Sparkles className="w-5 h-5 text-primary" />
          My Marble Collection
        </CardTitle>
        <Badge variant="outline" className="bg-primary/10 border-primary/50">
          {marbles.length} {marbles.length === 1 ? "Marble" : "Marbles"}
        </Badge>
      </CardHeader>
      <CardContent>
        {marbles.length === 0 ? (
          <div className="text-center py-12">
            <Sparkles className="w-12 h-12 text-muted-foreground mx-auto mb-4 opacity-50" />
            <p className="text-lg font-medium mb-2">No Marbles Yet</p>
            <p className="text-sm text-muted-foreground">
              Mint your first Thunder Marble to start your collection!
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
            {marbles.map((marble) => (
              <div
                key={marble.tokenId}
                className="electric-glow hover-elevate transition-all duration-300 rounded-lg border border-border bg-card overflow-hidden"
                data-testid={`nft-card-${marble.tokenId}`}
              >
                <div className="p-4 space-y-2 pb-3">
                  <div className="flex items-center justify-between gap-2">
                    <Badge variant="outline" className="text-xs">
                      #{marble.tokenId}
                    </Badge>
                    <Badge
                      className={
                        RARITY_COLORS[marble.rarityName as keyof typeof RARITY_COLORS] ||
                        RARITY_COLORS.Common
                      }
                    >
                      {marble.rarityName}
                    </Badge>
                  </div>
                </div>
                <div className="px-4 pb-4 space-y-3">
                  <div className="aspect-square bg-gradient-to-br from-primary/20 via-accent/20 to-chart-3/20 rounded-lg flex items-center justify-center overflow-hidden relative">
                    <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_50%,rgba(56,189,248,0.3),transparent_50%)]"></div>
                    <Sparkles className="w-12 h-12 text-primary/50 relative z-10" />
                  </div>
                  <div className="text-center">
                    <p className="font-semibold text-sm" data-testid={`nft-name-${marble.tokenId}`}>
                      Thunder Marble
                    </p>
                    <p className="text-xs text-muted-foreground font-mono truncate">
                      {marble.tokenURI.slice(0, 30)}...
                    </p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
