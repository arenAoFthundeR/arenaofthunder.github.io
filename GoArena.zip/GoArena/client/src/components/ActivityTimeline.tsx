import { useQuery } from "@tanstack/react-query";
import { useState } from "react";
import { apiRequest } from "@/lib/queryClient";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import { Clock, Zap, Trophy, Gift, BookOpen, Swords, Coins, Scroll, User } from "lucide-react";
import { formatDistanceToNow } from "date-fns";

interface UserActivity {
  id: number;
  wallet: string;
  eventType: string;
  description: string;
  metadata: Record<string, unknown> | null;
  createdAt: string;
}

interface ActivityStats {
  totalActivities: number;
  eventCounts: Record<string, number>;
}

interface ActivityTimelineProps {
  wallet: string | null;
}

const eventTypeIcons: Record<string, React.ComponentType<{ className?: string }>> = {
  marble_minted: Zap,
  marble_gifted_sent: Gift,
  marble_gifted_received: Gift,
  lore_unlocked: BookOpen,
  tournament_joined: Trophy,
  tournament_round_completed: Trophy,
  dungeon_started: Swords,
  dungeon_completed: Swords,
  dungeon_failed: Swords,
  credits_earned: Coins,
  credits_spent: Coins,
  persona_created: User,
  j3_chat_message: Scroll,
  wallet_connected: User,
  level_up: Zap,
};

const eventTypeColors: Record<string, string> = {
  marble_minted: "bg-primary/10 text-primary border-primary/20",
  marble_gifted_sent: "bg-purple-500/10 text-purple-400 border-purple-500/20",
  marble_gifted_received: "bg-green-500/10 text-green-400 border-green-500/20",
  lore_unlocked: "bg-blue-500/10 text-blue-400 border-blue-500/20",
  tournament_joined: "bg-yellow-500/10 text-yellow-400 border-yellow-500/20",
  tournament_round_completed: "bg-yellow-500/10 text-yellow-400 border-yellow-500/20",
  dungeon_started: "bg-red-500/10 text-red-400 border-red-500/20",
  dungeon_completed: "bg-emerald-500/10 text-emerald-400 border-emerald-500/20",
  dungeon_failed: "bg-orange-500/10 text-orange-400 border-orange-500/20",
  credits_earned: "bg-cyan-500/10 text-cyan-400 border-cyan-500/20",
  credits_spent: "bg-pink-500/10 text-pink-400 border-pink-500/20",
  persona_created: "bg-indigo-500/10 text-indigo-400 border-indigo-500/20",
  j3_chat_message: "bg-violet-500/10 text-violet-400 border-violet-500/20",
  wallet_connected: "bg-slate-500/10 text-slate-400 border-slate-500/20",
  level_up: "bg-primary/10 text-primary border-primary/20",
};

export default function ActivityTimeline({ wallet }: ActivityTimelineProps) {
  const [filter, setFilter] = useState<string>("all");

  const { data: activities, isLoading } = useQuery<UserActivity[]>({
    queryKey: ["/api/activities/list", wallet, filter],
    queryFn: async () => {
      const res = await apiRequest("POST", "/api/activities/list", {
        wallet,
        eventType: filter !== "all" ? filter : undefined,
      });
      return res.json();
    },
    enabled: !!wallet,
  });

  const { data: stats } = useQuery<ActivityStats>({
    queryKey: ["/api/activities/stats", wallet],
    queryFn: async () => {
      const res = await apiRequest("POST", "/api/activities/stats", { wallet });
      return res.json();
    },
    enabled: !!wallet,
  });

  if (!wallet) {
    return (
      <Card data-testid="card-activity-timeline">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Clock className="w-5 h-5" />
            Activity Timeline
          </CardTitle>
          <CardDescription>Connect your wallet to view your activity history</CardDescription>
        </CardHeader>
      </Card>
    );
  }

  const eventTypes = [
    { value: "all", label: "All Events" },
    { value: "marble_minted", label: "Marble Minted" },
    { value: "marble_gifted_sent", label: "Gifts Sent" },
    { value: "marble_gifted_received", label: "Gifts Received" },
    { value: "lore_unlocked", label: "Lore Unlocked" },
    { value: "tournament_joined", label: "Tournaments" },
    { value: "dungeon_started", label: "Dungeons" },
    { value: "credits_earned", label: "Credits Earned" },
    { value: "persona_created", label: "Personas" },
    { value: "j3_chat_message", label: "J3 Chats" },
  ];

  return (
    <Card data-testid="card-activity-timeline" className="w-full">
      <CardHeader>
        <div className="flex items-center justify-between gap-2 flex-wrap">
          <div>
            <CardTitle className="flex items-center gap-2">
              <Clock className="w-5 h-5" />
              Activity Timeline
            </CardTitle>
            <CardDescription>
              {stats ? `${stats.totalActivities || 0} total activities` : "Your recent activity history"}
            </CardDescription>
          </div>
          <Select value={filter} onValueChange={setFilter}>
            <SelectTrigger className="w-48" data-testid="select-activity-filter">
              <SelectValue placeholder="Filter events" />
            </SelectTrigger>
            <SelectContent>
              {eventTypes.map((type) => (
                <SelectItem key={type.value} value={type.value} data-testid={`option-filter-${type.value}`}>
                  {type.label}
                  {stats && stats.eventCounts[type.value] ? ` (${stats.eventCounts[type.value]})` : ""}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </CardHeader>
      <CardContent>
        {isLoading ? (
          <div className="space-y-3">
            {[...Array(5)].map((_, i) => (
              <div key={i} className="flex items-start gap-3">
                <Skeleton className="h-10 w-10 rounded-full" />
                <div className="flex-1 space-y-2">
                  <Skeleton className="h-4 w-3/4" />
                  <Skeleton className="h-3 w-1/2" />
                </div>
              </div>
            ))}
          </div>
        ) : !activities || activities.length === 0 ? (
          <div className="text-center py-8 text-muted-foreground" data-testid="text-no-activities">
            <Clock className="w-12 h-12 mx-auto mb-3 opacity-50" />
            <p>No activities yet</p>
            <p className="text-sm mt-1">Start minting, battling, and exploring to build your history!</p>
          </div>
        ) : (
          <div className="space-y-3">
            {activities.map((activity) => {
              const Icon = eventTypeIcons[activity.eventType] || Clock;
              const colorClass = eventTypeColors[activity.eventType] || "bg-muted text-muted-foreground";
              
              return (
                <div
                  key={activity.id}
                  className="flex items-start gap-3 p-3 rounded-lg hover-elevate active-elevate-2 transition-all"
                  data-testid={`activity-${activity.id}`}
                >
                  <div className={`p-2 rounded-full ${colorClass}`}>
                    <Icon className="w-5 h-5" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium" data-testid={`text-activity-description-${activity.id}`}>
                      {activity.description}
                    </p>
                    <div className="flex items-center gap-2 mt-1 flex-wrap">
                      <Badge variant="secondary" className="text-xs" data-testid={`badge-event-type-${activity.id}`}>
                        {activity.eventType.replace(/_/g, " ")}
                      </Badge>
                      <span className="text-xs text-muted-foreground" data-testid={`text-time-${activity.id}`}>
                        {formatDistanceToNow(new Date(activity.createdAt), { addSuffix: true })}
                      </span>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
