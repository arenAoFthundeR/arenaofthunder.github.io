import { Link, useLocation } from "wouter";
import { WalletConnect } from "@/components/WalletConnect";
import { AdminLogin } from "@/components/AdminLogin";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Zap, WifiOff, Wifi, Sparkles, Sword, Shield, Crown, ChevronDown, FileText, Clock } from "lucide-react";
import { useWS } from "@/components/WebSocketProvider";

interface SharedHeaderProps {
  onWalletConnect: (address: string) => void;
  onWalletDisconnect: () => void;
}

export function SharedHeader({ onWalletConnect, onWalletDisconnect }: SharedHeaderProps) {
  const { isConnected } = useWS();
  const [location] = useLocation();

  const isActive = (path: string) => location === path;
  const isArenaActive = ['/marbles', '/dungeons', '/treasury', '/activity', '/security'].includes(location);
  const isPlanningActive = location === '/planning';

  return (
    <header className="sticky top-0 z-50 backdrop-blur-lg bg-slate-950/90 border-b border-cyan-500/20">
      <div className="max-w-7xl mx-auto px-6 py-4">
        <div className="flex items-center justify-between gap-4">
          <div className="flex items-center gap-8">
            <Link href="/" data-testid="link-home">
              <div className="flex items-center gap-3 hover-elevate rounded-md p-2 -ml-2 cursor-pointer">
                <div className="electric-glow-strong rounded-full p-2 bg-primary/20">
                  <Zap className="w-6 h-6 text-primary" />
                </div>
                <div>
                  <h1 className="text-lg font-display font-bold tracking-tight text-white">
                    thundergod
                  </h1>
                </div>
              </div>
            </Link>
            
            <nav className="hidden lg:flex items-center gap-1">
              <a href="/">
                <Button 
                  variant="ghost" 
                  size="sm" 
                  className={isActive('/') ? 'border-b-2 border-cyan-400 rounded-b-none' : ''}
                  data-testid="nav-home"
                >
                  Home
                </Button>
              </a>
              <a href="#projects">
                <Button variant="ghost" size="sm" data-testid="nav-projects">
                  Projects
                </Button>
              </a>
              
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button 
                    variant="ghost" 
                    size="sm"
                    className={isArenaActive ? 'border-b-2 border-cyan-400 rounded-b-none' : ''}
                    data-testid="nav-arena-dropdown"
                  >
                    Arena of Thunder
                    <ChevronDown className="w-3 h-3 ml-1" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="start" className="w-48 bg-slate-900 border-cyan-500/30">
                  <Link href="/marbles">
                    <DropdownMenuItem className="cursor-pointer" data-testid="dropdown-marbles">
                      <Sparkles className="w-4 h-4 mr-2" />
                      Marbles
                    </DropdownMenuItem>
                  </Link>
                  <Link href="/dungeons">
                    <DropdownMenuItem className="cursor-pointer" data-testid="dropdown-dungeons">
                      <Sword className="w-4 h-4 mr-2" />
                      Dungeons
                    </DropdownMenuItem>
                  </Link>
                  <Link href="/treasury">
                    <DropdownMenuItem className="cursor-pointer" data-testid="dropdown-treasury">
                      <Crown className="w-4 h-4 mr-2" />
                      Treasury
                    </DropdownMenuItem>
                  </Link>
                  <Link href="/activity">
                    <DropdownMenuItem className="cursor-pointer" data-testid="dropdown-activity">
                      <Clock className="w-4 h-4 mr-2" />
                      Activity
                    </DropdownMenuItem>
                  </Link>
                  <Link href="/security">
                    <DropdownMenuItem className="cursor-pointer" data-testid="dropdown-security">
                      <Shield className="w-4 h-4 mr-2" />
                      Security
                    </DropdownMenuItem>
                  </Link>
                </DropdownMenuContent>
              </DropdownMenu>

              <Link href="/planning">
                <Button 
                  variant="ghost" 
                  size="sm"
                  className={isPlanningActive ? 'border-b-2 border-cyan-400 rounded-b-none' : ''}
                  data-testid="nav-planning"
                >
                  <FileText className="w-3 h-3 mr-1.5" />
                  Planning
                </Button>
              </Link>

              <a href="#about">
                <Button variant="ghost" size="sm" data-testid="nav-about">
                  About
                </Button>
              </a>
              <a href="#contact">
                <Button variant="ghost" size="sm" data-testid="nav-contact">
                  Contact
                </Button>
              </a>
            </nav>
          </div>
          <div className="flex items-center gap-3">
            <Badge
              variant={isConnected ? "default" : "secondary"}
              className="gap-1.5 hidden md:flex"
              data-testid="ws-status-badge"
            >
              {isConnected ? (
                <>
                  <Wifi className="w-3 h-3" />
                  Live
                </>
              ) : (
                <>
                  <WifiOff className="w-3 h-3" />
                  Offline
                </>
              )}
            </Badge>
            <AdminLogin />
            <WalletConnect onConnect={onWalletConnect} onDisconnect={onWalletDisconnect} />
          </div>
        </div>
      </div>
    </header>
  );
}
