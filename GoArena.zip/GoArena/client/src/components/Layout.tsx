import { ReactNode } from "react";
import { SharedHeader } from "@/components/SharedHeader";
import { J3Chat } from "@/components/J3Chat";
import { useWallet } from "@/lib/walletContext";
import { useGyroscope } from "@/hooks/useGyroscope";

interface LayoutProps {
  children: ReactNode;
}

export function Layout({ children }: LayoutProps) {
  const { wallet, handleConnect, handleDisconnect } = useWallet();
  useGyroscope(); // Initialize gyroscope system

  return (
    <div className="min-h-screen bg-gradient-to-b from-background via-background to-card">
      <SharedHeader 
        onWalletConnect={handleConnect} 
        onWalletDisconnect={handleDisconnect} 
      />
      <main>{children}</main>
      <J3Chat wallet={wallet} />
    </div>
  );
}
