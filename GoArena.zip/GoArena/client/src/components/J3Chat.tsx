import { useState, useEffect, useRef } from "react";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { X, Zap, Send, Coins, Info, History, MessageSquare } from "lucide-react";
import { cn } from "@/lib/utils";

interface J3Message {
  role: "user" | "assistant";
  content: string;
}

interface J3Action {
  type: "SCROLL_TO" | "CALL" | "NAVIGATE" | "earn_credits";
  target?: string;
  fn?: string;
  label: string;
  confirm?: boolean;
}

interface J3Credits {
  balance: number;
  tier: string;
  deducted: number;
  gracePeriodRemaining: number;
}

interface J3Conversation {
  id: number;
  wallet: string;
  personaId: string | null;
  title: string;
  messageCount: number;
  totalCreditsSpent: number;
  createdAt: string;
  lastMessageAt: string;
}

interface J3HistoryMessage {
  id: number;
  conversationId: number;
  role: "user" | "assistant";
  content: string;
  creditsSpent: number;
  timestamp: string;
}

interface J3ChatProps {
  wallet: string | null;
  xp?: number;
  level?: number;
  onConnect?: () => void;
}

const J3_API_URL = "/api/j3/chat";
const J3_PING_URL = "/api/j3/ping";
const J3_CREDITS_URL = "/api/j3/credits";

export function J3Chat({ wallet, xp = 0, level = 1, onConnect }: J3ChatProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<J3Message[]>([]);
  const [input, setInput] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [isOnline, setIsOnline] = useState(true);
  const [credits, setCredits] = useState<J3Credits | null>(null);
  const [showEarnHelp, setShowEarnHelp] = useState(false);
  const [showHistory, setShowHistory] = useState(false);
  const [selectedConversation, setSelectedConversation] = useState<number | null>(null);
  const chatLogRef = useRef<HTMLDivElement>(null);

  // Fetch conversation history
  const { data: conversations = [] } = useQuery<J3Conversation[]>({
    queryKey: [`/api/j3/conversations/${wallet}`],
    enabled: !!wallet && showHistory,
  });

  // Fetch messages for selected conversation
  const { data: historyMessages = [] } = useQuery<J3HistoryMessage[]>({
    queryKey: [`/api/j3/conversations/${selectedConversation}/messages`],
    enabled: !!selectedConversation,
  });

  // Detect current page context
  const detectPageContext = (): string => {
    const inView = (selector: string) => {
      const el = document.querySelector(selector);
      if (!el) return false;
      const rect = el.getBoundingClientRect();
      return rect.top < window.innerHeight && rect.bottom > 0;
    };

    if (inView('[data-section="nft-gallery"]')) return "nft-gallery";
    if (inView('[data-section="lore"]')) return "lore";
    if (inView('[data-section="tournament"]')) return "tournament";
    if (inView('[data-section="leaderboard"]')) return "leaderboard";
    return "home";
  };

  // Ping server to check if J3 is online
  useEffect(() => {
    const ping = async () => {
      try {
        await fetch(J3_PING_URL);
        setIsOnline(true);
      } catch {
        setIsOnline(false);
      }
    };
    ping();
    const interval = setInterval(ping, 30000);
    return () => clearInterval(interval);
  }, []);

  // Fetch credits when wallet changes or chat opens
  useEffect(() => {
    if (wallet && isOpen) {
      fetch(`${J3_CREDITS_URL}/${wallet}`)
        .then((res) => res.json())
        .then((data) => {
          setCredits({
            balance: data.balance,
            tier: data.tier,
            deducted: 0,
            gracePeriodRemaining: data.gracePeriodMessages,
          });
        })
        .catch(() => {
          // Silently fail - credits will just not display
        });
    }
  }, [wallet, isOpen]);

  // Welcome message on first open
  useEffect(() => {
    if (isOpen && messages.length === 0) {
      setMessages([
        {
          role: "assistant",
          content: wallet
            ? `J3SSICA3 online. Your storm signature detected at ${wallet.slice(0, 6)}...${wallet.slice(-4)}. Ask me about minting, lore, or the Arena.`
            : "J3SSICA3 online. You walked into my storm. Ask me about minting, the Arena, or lore. Connect your wallet to unlock my full memory.",
        },
      ]);
    }
  }, [isOpen, wallet, messages.length]);

  // Auto-scroll chat log
  useEffect(() => {
    if (chatLogRef.current) {
      chatLogRef.current.scrollTop = chatLogRef.current.scrollHeight;
    }
  }, [messages]);

  const handleSend = async (text: string) => {
    if (!text.trim() || isLoading) return;

    const userMessage: J3Message = { role: "user", content: text };
    setMessages((prev) => [...prev, userMessage]);
    setInput("");
    setIsLoading(true);

    try {
      const envelope = {
        surface: "web",
        version: "j3-core-v1",
        user: {
          walletAddress: wallet,
          displayName: null,
        },
        message: {
          id: String(Date.now()),
          role: "user",
          content: text,
        },
        context: {
          page: detectPageContext(),
          clientState: {
            walletConnected: !!wallet,
            xp,
            level,
            lastError: null,
          },
        },
        history: messages,
        flags: {
          actionsEnabled: true,
          memoryEnabled: true,
        },
      };

      const res = await fetch(J3_API_URL, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(envelope),
      });

      const data = await res.json();

      // Handle insufficient credits
      if (!res.ok && data.error === "insufficient_credits") {
        setMessages((prev) => [
          ...prev,
          {
            role: "assistant",
            content: data.reply,
          },
        ]);
        setShowEarnHelp(true);
        return;
      }

      if (!res.ok) throw new Error("J3 request failed");

      const assistantMessage: J3Message = {
        role: "assistant",
        content: data.reply,
      };

      setMessages((prev) => [...prev, assistantMessage]);

      // Update credits from response
      if (data.credits) {
        setCredits(data.credits);
      }

      // Handle actions
      if (data.actions && data.actions.length > 0) {
        data.actions.forEach((action: J3Action) => {
          executeAction(action);
        });
      }
    } catch (error) {
      console.error("[J3] Error:", error);
      setMessages((prev) => [
        ...prev,
        {
          role: "assistant",
          content: "My signal crackled. Check your connection and try again.",
        },
      ]);
    } finally {
      setIsLoading(false);
    }
  };

  const executeAction = (action: J3Action) => {
    if (action.type === "SCROLL_TO" && action.target) {
      const selector = `[data-section="${action.target}"]`;
      const element = document.querySelector(selector);
      element?.scrollIntoView({ behavior: "smooth", block: "start" });
    }

    if (action.type === "CALL") {
      if (action.fn === "connectWallet" && onConnect) {
        onConnect();
      }
    }

    if (action.type === "earn_credits") {
      setShowEarnHelp(true);
    }
  };

  const getTierColor = (tier: string): string => {
    const colors: Record<string, string> = {
      Novice: "bg-gray-500",
      Apprentice: "bg-blue-500",
      Adept: "bg-purple-500",
      Master: "bg-amber-500",
      Legend: "bg-red-500",
    };
    return colors[tier] || "bg-gray-500";
  };

  const quickActions = [
    { label: "How do I start?", query: "Where do I start on this site?" },
    { label: "Mint a marble", query: "How do I mint a marble?" },
    { label: "Show leaderboard", query: "Scroll to the leaderboard" },
    { label: "Tell me lore", query: "Tell me some Arena lore" },
  ];

  return (
    <>
      {/* Floating J3 Bubble */}
      <Button
        size="icon"
        onClick={() => setIsOpen(true)}
        className={cn(
          "fixed bottom-6 right-6 w-14 h-14 rounded-full shadow-2xl z-50",
          "bg-gradient-to-br from-purple-900 via-purple-700 to-orange-600",
          "hover:scale-110 transition-transform duration-200",
          "animate-pulse"
        )}
        data-testid="button-j3-launcher"
      >
        <Zap className="w-6 h-6" />
      </Button>

      {/* Chat Panel */}
      {isOpen && (
        <Card
          className={cn(
            "fixed bottom-24 right-6 w-96 h-[600px]",
            "flex flex-col shadow-2xl z-50",
            "bg-background border-primary/20"
          )}
          data-testid="panel-j3-chat"
        >
          {/* Header */}
          <div className="border-b border-primary/20 bg-gradient-to-r from-primary/10 to-transparent">
            <div className="flex items-center justify-between p-3">
              <div>
                <div className="font-bold text-sm tracking-wider uppercase flex items-center gap-2">
                  <Zap className="w-4 h-4 text-primary" />
                  J3SSICA3
                  <span
                    className={cn(
                      "w-2 h-2 rounded-full",
                      isOnline ? "bg-green-500" : "bg-red-500"
                    )}
                    title={isOnline ? "Online" : "Offline"}
                  />
                </div>
                <div className="text-xs text-muted-foreground">Arena AI Oracle</div>
              </div>
              <div className="flex items-center gap-2">
                {wallet && (
                  <Button
                    size="icon"
                    variant="ghost"
                    onClick={() => setShowHistory(true)}
                    title="Conversation History"
                    data-testid="button-conversation-history"
                  >
                    <History className="w-4 h-4" />
                  </Button>
                )}
                {credits && wallet && (
                  <Button
                    size="icon"
                    variant="ghost"
                    onClick={() => setShowEarnHelp(!showEarnHelp)}
                    title="How to earn J3C"
                    data-testid="button-earn-help"
                  >
                    <Info className="w-4 h-4" />
                  </Button>
                )}
                <Button
                  size="icon"
                  variant="ghost"
                  onClick={() => setIsOpen(false)}
                  data-testid="button-j3-close"
                >
                  <X className="w-4 h-4" />
                </Button>
              </div>
            </div>
            
            {/* Credits Display */}
            {credits && wallet && (
              <div className="px-3 pb-2 flex items-center justify-between text-xs">
                <div className="flex items-center gap-2">
                  <Coins className="w-3 h-3 text-cyan-400" />
                  <span className="font-mono font-bold text-cyan-400">{credits.balance} J3C</span>
                  {credits.gracePeriodRemaining > 0 && (
                    <span className="text-muted-foreground">
                      (+{credits.gracePeriodRemaining} free)
                    </span>
                  )}
                </div>
                <Badge className={cn("text-xs", getTierColor(credits.tier))}>
                  {credits.tier}
                </Badge>
              </div>
            )}
          </div>

          {/* Earn Help Panel */}
          {showEarnHelp && wallet && (
            <div className="p-3 border-b border-primary/20 bg-amber-500/10 space-y-2">
              <div className="flex items-center justify-between">
                <div className="font-bold text-sm flex items-center gap-2">
                  <Coins className="w-4 h-4" />
                  How to Earn J3 Credits
                </div>
                <Button
                  size="icon"
                  variant="ghost"
                  onClick={() => setShowEarnHelp(false)}
                  className="h-6 w-6"
                >
                  <X className="w-3 h-3" />
                </Button>
              </div>
              <div className="text-xs space-y-1 text-muted-foreground">
                <div>• Mint a Marble: +10 J3C</div>
                <div>• Send/Receive Gift: +5 J3C each</div>
                <div>• Unlock Lore: +15 J3C</div>
                <div>• Join Tournament: +20 J3C</div>
                <div>• Advance Round: +25 J3C</div>
                <div>• Daily Regeneration: +10 J3C/day</div>
                <div className="pt-1 text-xs italic">Messages cost 5 J3C each</div>
              </div>
            </div>
          )}

          {/* Quick Actions */}
          <div className="flex flex-wrap gap-1.5 p-2 border-b border-primary/10 bg-muted/30">
            {quickActions.map((action, i) => (
              <Button
                key={i}
                size="sm"
                variant="outline"
                onClick={() => handleSend(action.query)}
                className="text-xs h-7"
                data-testid={`button-quick-${i}`}
              >
                {action.label}
              </Button>
            ))}
          </div>

          {/* Messages */}
          <div
            ref={chatLogRef}
            className="flex-1 overflow-y-auto p-3 space-y-3 bg-gradient-to-b from-background to-primary/5"
            data-testid="div-j3-messages"
          >
            {messages.map((msg, i) => (
              <div
                key={i}
                className={cn(
                  "max-w-[85%] p-2.5 rounded-lg text-sm",
                  msg.role === "user"
                    ? "ml-auto bg-primary/20 text-foreground"
                    : "mr-auto bg-muted border border-primary/10"
                )}
                data-testid={`message-${msg.role}-${i}`}
              >
                {msg.content}
              </div>
            ))}
            {isLoading && (
              <div className="mr-auto max-w-[85%] p-2.5 rounded-lg text-sm bg-muted border border-primary/10">
                <span className="inline-flex gap-1">
                  <span className="animate-bounce">⚡</span>
                  <span className="animate-bounce delay-100">⚡</span>
                  <span className="animate-bounce delay-200">⚡</span>
                </span>
              </div>
            )}
          </div>

          {/* Input */}
          <form
            onSubmit={(e) => {
              e.preventDefault();
              handleSend(input);
            }}
            className="flex gap-2 p-3 border-t border-primary/20 bg-muted/30"
          >
            <Input
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="Ask J3SSICA3 anything..."
              disabled={isLoading}
              className="flex-1"
              data-testid="input-j3-message"
            />
            <Button
              type="submit"
              size="icon"
              disabled={isLoading || !input.trim()}
              data-testid="button-j3-send"
            >
              <Send className="w-4 h-4" />
            </Button>
          </form>
        </Card>
      )}

      {/* Conversation History Dialog */}
      <Dialog 
        open={showHistory} 
        onOpenChange={(open) => {
          setShowHistory(open);
          if (!open) setSelectedConversation(null); // Reset selection on close
        }}
      >
        <DialogContent className="max-w-2xl max-h-[80vh] flex flex-col">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <History className="w-5 h-5 text-primary" />
              {selectedConversation ? "Conversation Details" : "Conversation History"}
            </DialogTitle>
          </DialogHeader>

          {selectedConversation ? (
            <div className="flex-1 overflow-y-auto space-y-3 pr-2">
              <Button
                variant="outline"
                size="sm"
                onClick={() => setSelectedConversation(null)}
                className="mb-2"
                data-testid="button-back-to-list"
              >
                ← Back to List
              </Button>
              
              {historyMessages.map((msg, i) => (
                <div
                  key={i}
                  className={cn(
                    "max-w-[85%] p-3 rounded-lg text-sm",
                    msg.role === "user"
                      ? "ml-auto bg-primary/20 text-foreground"
                      : "mr-auto bg-muted border border-primary/10"
                  )}
                  data-testid={`history-message-${msg.role}-${i}`}
                >
                  <div className="mb-1">{msg.content}</div>
                  <div className="text-xs text-muted-foreground flex items-center justify-between">
                    <span>{new Date(msg.timestamp).toLocaleString()}</span>
                    {msg.creditsSpent > 0 && (
                      <Badge variant="outline" className="text-xs">
                        {msg.creditsSpent} J3C
                      </Badge>
                    )}
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="flex-1 overflow-y-auto">
              {conversations.length === 0 ? (
                <div className="text-center py-12 text-muted-foreground">
                  <MessageSquare className="w-12 h-12 mx-auto mb-4 opacity-50" />
                  <p>No conversation history yet.</p>
                  <p className="text-sm">Start chatting with J3SSICA3 to build your history!</p>
                </div>
              ) : (
                <div className="space-y-2">
                  {conversations.map((conv) => (
                    <Card
                      key={conv.id}
                      className="p-3 cursor-pointer hover-elevate active-elevate-2 transition-all"
                      onClick={() => setSelectedConversation(conv.id)}
                      data-testid={`conversation-${conv.id}`}
                    >
                      <div className="flex items-start justify-between gap-2">
                        <div className="flex-1 min-w-0">
                          <h4 className="font-semibold text-sm truncate mb-1">
                            {conv.title}
                          </h4>
                          <div className="flex items-center gap-3 text-xs text-muted-foreground">
                            <span className="flex items-center gap-1">
                              <MessageSquare className="w-3 h-3" />
                              {conv.messageCount} messages
                            </span>
                            <span className="flex items-center gap-1">
                              <Coins className="w-3 h-3" />
                              {conv.totalCreditsSpent} J3C
                            </span>
                          </div>
                        </div>
                        <div className="text-xs text-muted-foreground text-right shrink-0">
                          {new Date(conv.lastMessageAt).toLocaleDateString()}
                        </div>
                      </div>
                    </Card>
                  ))}
                </div>
              )}
            </div>
          )}
        </DialogContent>
      </Dialog>
    </>
  );
}
