import { createContext, useContext } from "react";
import { useWebSocket, type WSMessageType } from "@/hooks/use-websocket";

type MessageHandler = (data: any) => void;

interface WebSocketContextValue {
  isConnected: boolean;
  subscribe: (type: WSMessageType, handler: MessageHandler) => () => void;
  reconnectAttempts: number;
}

const WebSocketContext = createContext<WebSocketContextValue | null>(null);

export function WebSocketProvider({ children }: { children: React.ReactNode }) {
  const ws = useWebSocket();

  return (
    <WebSocketContext.Provider value={ws}>
      {children}
    </WebSocketContext.Provider>
  );
}

export function useWS() {
  const context = useContext(WebSocketContext);
  if (!context) {
    throw new Error("useWS must be used within WebSocketProvider");
  }
  return context;
}
