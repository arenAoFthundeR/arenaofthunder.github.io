import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Trophy, Medal, Award } from "lucide-react";
import type { LeaderboardEntry } from "@shared/schema";

interface LeaderboardProps {
  entries: LeaderboardEntry[];
  currentWallet?: string;
  isLoading?: boolean;
}

export function Leaderboard({ entries, currentWallet, isLoading = false }: LeaderboardProps) {
  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="text-2xl font-display flex items-center gap-2">
            <Trophy className="w-6 h-6 text-chart-5" />
            Leaderboard
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-2">
          {Array.from({ length: 5 }).map((_, i) => (
            <Skeleton key={i} className="h-16 w-full" />
          ))}
        </CardContent>
      </Card>
    );
  }

  const getRankIcon = (rank: number) => {
    if (rank === 1) return <Trophy className="w-5 h-5 text-chart-5" />;
    if (rank === 2) return <Medal className="w-5 h-5 text-muted-foreground" />;
    if (rank === 3) return <Award className="w-5 h-5 text-destructive" />;
    return null;
  };

  const getRankBadgeColor = (rank: number) => {
    if (rank === 1) return "bg-chart-5 text-background";
    if (rank === 2) return "bg-muted-foreground text-background";
    if (rank === 3) return "bg-destructive text-background";
    return "bg-muted text-muted-foreground";
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-2xl font-display flex items-center gap-2">
          <Trophy className="w-6 h-6 text-chart-5" />
          Leaderboard
        </CardTitle>
      </CardHeader>
      <CardContent>
        {entries.length === 0 ? (
          <div className="text-center py-12">
            <Trophy className="w-12 h-12 text-muted-foreground mx-auto mb-4 opacity-50" />
            <p className="text-muted-foreground">No players yet. Be the first to join!</p>
          </div>
        ) : (
          <div className="space-y-2">
            {entries.map((entry, index) => {
              const rank = index + 1;
              const isCurrentUser = currentWallet && entry.wallet.toLowerCase() === currentWallet.toLowerCase();

              return (
                <div
                  key={entry.wallet}
                  className={`flex items-center gap-4 p-4 rounded-lg transition-all ${
                    isCurrentUser
                      ? "bg-primary/10 border border-primary/50 electric-glow"
                      : "bg-card hover-elevate"
                  }`}
                  data-testid={`leaderboard-entry-${rank}`}
                >
                  <div className="flex items-center gap-3 min-w-[60px]">
                    {getRankIcon(rank)}
                    <Badge className={getRankBadgeColor(rank)}>#{rank}</Badge>
                  </div>

                  <div className="flex-1 min-w-0">
                    <div className="font-mono text-sm truncate" data-testid={`text-wallet-${rank}`}>
                      {entry.wallet}
                    </div>
                    <div className="flex gap-2 mt-1 text-xs text-muted-foreground">
                      <span>{entry.mints} mints</span>
                      <span>•</span>
                      <span>{entry.giftsSent} sent</span>
                      <span>•</span>
                      <span>{entry.giftsReceived} received</span>
                    </div>
                  </div>

                  <div className="text-right">
                    <div className="font-semibold text-lg" data-testid={`text-xp-${rank}`}>
                      {entry.xp.toLocaleString()}
                    </div>
                    <div className="text-xs text-muted-foreground">
                      Level {entry.level}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
