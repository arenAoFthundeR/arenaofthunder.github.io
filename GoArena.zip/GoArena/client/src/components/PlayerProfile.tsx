import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Trophy, Sparkles, Scroll, Swords, User } from "lucide-react";
import { MintGiftDialog } from "./MintGiftDialog";
import { ShareButton } from "./ShareButton";
import type { XpData, LorePiece, TournamentData } from "@shared/schema";

interface PlayerProfileProps {
  wallet: string;
  xpData?: XpData;
  lore?: LorePiece[];
  tournament?: TournamentData;
  rank?: number;
  totalPlayers?: number;
  isLoading?: boolean;
}

export function PlayerProfile({
  wallet,
  xpData,
  lore,
  tournament,
  rank,
  totalPlayers,
  isLoading = false,
}: PlayerProfileProps) {
  const unlockedLore = lore?.filter((l) => l.unlocked) || [];
  const isJoined = tournament?.participants?.includes(wallet) || false;
  const playerRounds = tournament?.rounds?.filter((r) => r.wallet === wallet) || [];

  if (isLoading) {
    return (
      <div className="space-y-6">
        <Card className="electric-glow">
          <CardHeader className="space-y-4">
            <div className="flex justify-between items-start gap-4 flex-wrap">
              <div className="space-y-2">
                <Skeleton className="h-4 w-20" />
                <Skeleton className="h-6 w-80" />
              </div>
              <div className="flex gap-2 flex-wrap">
                <Skeleton className="h-8 w-24" />
                <Skeleton className="h-8 w-24" />
                <Skeleton className="h-8 w-24" />
              </div>
            </div>
          </CardHeader>
        </Card>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          <Skeleton className="h-40" />
          <Skeleton className="h-40" />
          <Skeleton className="h-40" />
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <Card className="electric-glow border-primary/30">
        <CardHeader className="space-y-4">
          <div className="flex justify-between items-start gap-4 flex-wrap">
            <div>
              <div className="text-xs uppercase tracking-wider text-muted-foreground mb-1 flex items-center gap-2">
                <User className="w-3 h-3" />
                Wallet
              </div>
              <div className="font-mono text-sm break-all" data-testid="text-profile-wallet">
                {wallet}
              </div>
            </div>
            <div className="flex gap-2 flex-wrap">
              <Badge
                variant="outline"
                className="bg-primary/10 border-primary/50"
                data-testid="text-level"
              >
                Level {xpData?.level || 1}
              </Badge>
              <Badge
                variant="outline"
                className="bg-accent/10 border-accent/50"
                data-testid="text-xp"
              >
                {xpData?.xp || 0} XP
              </Badge>
              <Badge
                variant="outline"
                className="bg-chart-3/10 border-chart-3/50"
                data-testid="text-rank"
              >
                {rank ? `#${rank}` : "Unranked"}
                {totalPlayers && ` of ${totalPlayers}`}
              </Badge>
            </div>
          </div>
          <div className="pt-2 border-t border-border/50 flex items-center gap-2">
            <MintGiftDialog wallet={wallet} />
            <ShareButton
              title="Arena of Thunder - My Achievement"
              text={`I just reached Level ${xpData?.level || 1} with ${xpData?.xp || 0} XP in Arena of Thunder! ${
                rank ? `Rank #${rank} out of ${totalPlayers} players!` : "Join me in the storm!"
              }`}
              hashtags={["ArenaOfThunder", "Web3Gaming", "NFT"]}
            />
          </div>
        </CardHeader>
      </Card>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        <Card className="hover-elevate transition-all duration-300">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-base font-medium flex items-center gap-2">
              <Trophy className="w-4 h-4 text-chart-5" />
              Badges
            </CardTitle>
          </CardHeader>
          <CardContent>
            {xpData?.badges && xpData.badges.length > 0 ? (
              <div className="flex flex-wrap gap-2" data-testid="badge-row">
                {xpData.badges.map((badge) => (
                  <Badge
                    key={badge}
                    className="bg-gradient-to-r from-chart-5 to-destructive text-background font-semibold"
                  >
                    <Sparkles className="w-3 h-3 mr-1" />
                    {badge}
                  </Badge>
                ))}
              </div>
            ) : (
              <p className="text-sm text-muted-foreground">
                No badges earned yet. Gain XP to unlock badges!
              </p>
            )}
          </CardContent>
        </Card>

        <Card className="hover-elevate transition-all duration-300">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-base font-medium flex items-center gap-2">
              <Scroll className="w-4 h-4 text-chart-3" />
              Lore Progress
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <p className="font-semibold" data-testid="text-lore-progress">
                {unlockedLore.length} / {lore?.length || 0} lore unlocked
              </p>
              {unlockedLore.length > 0 ? (
                <div className="space-y-2">
                  {unlockedLore.slice(0, 2).map((piece) => (
                    <div key={piece.id} className="text-sm">
                      <p className="font-medium text-foreground">{piece.title}</p>
                      <p className="text-xs text-muted-foreground line-clamp-2">
                        {piece.text}
                      </p>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-sm text-muted-foreground">
                  No lore unlocked yet. Mint or play to reveal the first fragment.
                </p>
              )}
            </div>
          </CardContent>
        </Card>

        <Card className="hover-elevate transition-all duration-300">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-base font-medium flex items-center gap-2">
              <Swords className="w-4 h-4 text-destructive" />
              Tournament Status
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <p className="font-semibold" data-testid="text-tournament-status">
                {isJoined ? "Joined" : "Not joined"}
              </p>
              {playerRounds.length > 0 ? (
                <div className="space-y-1 text-sm">
                  {playerRounds.slice(0, 3).map((round, idx) => (
                    <div key={idx} className="text-muted-foreground">
                      Round {round.round} – {new Date(round.time).toLocaleDateString()}
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-sm text-muted-foreground">
                  {isJoined ? "No rounds played yet." : "Join a tournament to compete!"}
                </p>
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
