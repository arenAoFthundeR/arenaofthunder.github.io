import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Swords, Users, TrendingUp } from "lucide-react";
import type { TournamentData } from "@shared/schema";

interface TournamentSectionProps {
  tournament?: TournamentData;
  wallet?: string;
  onJoin: () => void;
  onAdvance: () => void;
  isJoining?: boolean;
  isAdvancing?: boolean;
  isLoading?: boolean;
}

export function TournamentSection({
  tournament,
  wallet,
  onJoin,
  onAdvance,
  isJoining = false,
  isAdvancing = false,
  isLoading = false,
}: TournamentSectionProps) {
  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="text-2xl font-display flex items-center gap-2">
            <Swords className="w-6 h-6 text-destructive" />
            Tournament Arena
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <Skeleton className="h-32 w-full" />
          <Skeleton className="h-12 w-full" />
        </CardContent>
      </Card>
    );
  }

  const isJoined = wallet && tournament?.participants?.includes(wallet);
  const playerRounds = tournament?.rounds?.filter((r) => r.wallet === wallet) || [];
  const totalRounds = tournament?.rounds?.length || 0;

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between flex-wrap gap-4">
          <CardTitle className="text-2xl font-display flex items-center gap-2">
            <Swords className="w-6 h-6 text-destructive" />
            Tournament Arena
          </CardTitle>
          <div className="flex gap-2">
            <Badge variant="outline" className="bg-primary/10 border-primary/50">
              <Users className="w-3 h-3 mr-1" />
              {tournament?.participants?.length || 0} Participants
            </Badge>
            <Badge variant="outline" className="bg-destructive/10 border-destructive/50">
              <TrendingUp className="w-3 h-3 mr-1" />
              {totalRounds} Total Rounds
            </Badge>
          </div>
        </div>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="p-6 rounded-lg bg-card border border-card-border">
          <div className="flex items-center justify-between flex-wrap gap-4">
            <div>
              <p className="text-sm text-muted-foreground mb-1">Tournament Status</p>
              <p className="text-lg font-semibold" data-testid="text-tournament-joined">
                {isJoined ? "✓ You're in the arena!" : "Join the battle"}
              </p>
              {isJoined && playerRounds.length > 0 && (
                <p className="text-sm text-muted-foreground mt-1">
                  You've completed {playerRounds.length} round{playerRounds.length !== 1 ? "s" : ""}
                </p>
              )}
            </div>
            <div className="flex gap-2">
              {!isJoined ? (
                <Button
                  onClick={onJoin}
                  disabled={isJoining || !wallet}
                  className="bg-gradient-to-r from-destructive to-chart-5"
                  data-testid="button-join-tournament"
                >
                  <Swords className="w-4 h-4 mr-2" />
                  {isJoining ? "Joining..." : "Join Tournament"}
                </Button>
              ) : (
                <Button
                  onClick={onAdvance}
                  disabled={isAdvancing}
                  variant="outline"
                  className="border-destructive/50"
                  data-testid="button-advance-round"
                >
                  <TrendingUp className="w-4 h-4 mr-2" />
                  {isAdvancing ? "Advancing..." : "Advance Round"}
                </Button>
              )}
            </div>
          </div>
        </div>

        {playerRounds.length > 0 && (
          <div className="space-y-2">
            <h3 className="font-semibold flex items-center gap-2">
              <TrendingUp className="w-4 h-4" />
              Your Round History
            </h3>
            <div className="space-y-2">
              {playerRounds
                .sort((a, b) => b.round - a.round)
                .slice(0, 5)
                .map((round, idx) => (
                  <div
                    key={idx}
                    className="flex items-center justify-between p-3 rounded-lg bg-muted/50"
                    data-testid={`tournament-round-${round.round}`}
                  >
                    <div className="flex items-center gap-3">
                      <Badge className="bg-destructive/20 text-destructive border-destructive/50">
                        Round {round.round}
                      </Badge>
                      <span className="text-sm text-muted-foreground">
                        {new Date(round.time).toLocaleString()}
                      </span>
                    </div>
                  </div>
                ))}
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
