import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Scroll, Lock, Unlock, ChevronDown, ChevronUp } from "lucide-react";
import { ShareButton } from "./ShareButton";
import type { LorePiece } from "@shared/schema";

interface LoreSectionProps {
  lore: LorePiece[];
  onUnlock: (id: number) => void;
  isUnlocking?: boolean;
  isLoading?: boolean;
}

export function LoreSection({ lore, onUnlock, isUnlocking = false, isLoading = false }: LoreSectionProps) {
  const [expandedId, setExpandedId] = useState<number | null>(null);

  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="text-2xl font-display flex items-center gap-2">
            <Scroll className="w-6 h-6 text-chart-3" />
            Lore Library
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          {Array.from({ length: 3 }).map((_, i) => (
            <Skeleton key={i} className="h-24 w-full" />
          ))}
        </CardContent>
      </Card>
    );
  }

  const unlockedCount = lore.filter((l) => l.unlocked).length;

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="text-2xl font-display flex items-center gap-2">
            <Scroll className="w-6 h-6 text-chart-3" />
            Lore Library
          </CardTitle>
          <Badge variant="outline" className="bg-chart-3/10 border-chart-3/50">
            {unlockedCount} / {lore.length} Unlocked
          </Badge>
        </div>
      </CardHeader>
      <CardContent className="space-y-3">
        {lore.map((piece) => {
          const isExpanded = expandedId === piece.id;

          return (
            <Card
              key={piece.id}
              className={`transition-all ${
                piece.unlocked
                  ? "hover-elevate border-chart-3/30"
                  : "opacity-60 grayscale"
              }`}
              data-testid={`lore-piece-${piece.id}`}
            >
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-3">
                <div className="flex items-center gap-3 flex-1">
                  {piece.unlocked ? (
                    <Unlock className="w-4 h-4 text-chart-3" />
                  ) : (
                    <Lock className="w-4 h-4 text-muted-foreground" />
                  )}
                  <div className="flex-1">
                    <h3 className="font-semibold" data-testid={`text-lore-title-${piece.id}`}>
                      {piece.unlocked ? piece.title : "???"}
                    </h3>
                  </div>
                  {piece.unlocked && (
                    <Button
                      size="icon"
                      variant="ghost"
                      onClick={() => setExpandedId(isExpanded ? null : piece.id)}
                      className="h-8 w-8"
                      data-testid={`button-expand-lore-${piece.id}`}
                    >
                      {isExpanded ? (
                        <ChevronUp className="w-4 h-4" />
                      ) : (
                        <ChevronDown className="w-4 h-4" />
                      )}
                    </Button>
                  )}
                </div>
              </CardHeader>
              {piece.unlocked && (
                <CardContent className="space-y-3">
                  <p className={`text-sm text-muted-foreground ${isExpanded ? "" : "line-clamp-2"}`}>
                    {piece.text}
                  </p>
                  {isExpanded && (
                    <div className="pt-2 border-t border-border/50">
                      <ShareButton
                        title={`Arena of Thunder - ${piece.title}`}
                        text={`I just unlocked "${piece.title}" in Arena of Thunder! ${piece.text.slice(0, 100)}...`}
                        hashtags={["ArenaOfThunder", "StormLore", "Web3"]}
                        size="sm"
                      />
                    </div>
                  )}
                </CardContent>
              )}
              {!piece.unlocked && (
                <CardContent>
                  <div className="flex items-center gap-3">
                    <p className="text-sm text-muted-foreground flex-1 blur-sm select-none">
                      Hidden lore fragment. Earn more XP to unlock...
                    </p>
                    <Button
                      size="sm"
                      onClick={() => onUnlock(piece.id)}
                      disabled={isUnlocking}
                      data-testid={`button-unlock-lore-${piece.id}`}
                    >
                      <Unlock className="w-3 h-3 mr-1" />
                      {isUnlocking ? "Unlocking..." : "Unlock"}
                    </Button>
                  </div>
                </CardContent>
              )}
            </Card>
          );
        })}
      </CardContent>
    </Card>
  );
}
