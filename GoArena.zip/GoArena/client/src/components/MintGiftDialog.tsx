import { useState } from "react";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Sparkles, Gift as GiftIcon, Loader2 } from "lucide-react";
import { arenaContract } from "@/lib/contract";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { queryClient } from "@/lib/queryClient";

interface MintGiftDialogProps {
  wallet: string;
  onSuccess?: () => void;
}

export function MintGiftDialog({ wallet, onSuccess }: MintGiftDialogProps) {
  const [open, setOpen] = useState(false);
  const [mode, setMode] = useState<"mint" | "gift">("mint");
  const [rarity, setRarity] = useState("0");
  const [recipientAddress, setRecipientAddress] = useState("");
  const [tokenId, setTokenId] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();

  const handleMint = async () => {
    try {
      setIsLoading(true);
      
      // Call smart contract to mint
      const result = await arenaContract.mintMarble(wallet, parseInt(rarity));
      
      // Update backend with mint count
      await apiRequest("POST", "/api/blockchain/mint", { wallet });
      
      // Invalidate queries to refresh UI
      await queryClient.invalidateQueries({ queryKey: ["/api/xp/get"] });
      await queryClient.invalidateQueries({ queryKey: ["/api/leaderboard"] });
      
      toast({
        title: "Marble Minted!",
        description: `Successfully minted Thunder Marble #${result.tokenId}. Transaction: ${result.txHash.slice(0, 10)}...`,
      });
      
      setOpen(false);
      onSuccess?.();
    } catch (error: any) {
      console.error("Mint error:", error);
      
      let errorMessage = "Failed to mint marble";
      if (error.message?.includes("Contract address not configured")) {
        errorMessage = "Smart contract not deployed yet. Please check VITE_CONTRACT_ADDRESS environment variable.";
      } else if (error.message?.includes("user rejected")) {
        errorMessage = "Transaction was rejected";
      }
      
      toast({
        title: "Mint Failed",
        description: errorMessage,
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleGift = async () => {
    if (!recipientAddress || !tokenId) {
      toast({
        title: "Missing Information",
        description: "Please enter both recipient address and token ID",
        variant: "destructive",
      });
      return;
    }

    try {
      setIsLoading(true);
      
      // Call smart contract to gift
      const txHash = await arenaContract.giftMarble(recipientAddress, parseInt(tokenId));
      
      // Update backend with gift count
      await apiRequest("POST", "/api/blockchain/gift", {
        from: wallet,
        to: recipientAddress,
      });
      
      // Invalidate queries to refresh UI
      await queryClient.invalidateQueries({ queryKey: ["/api/xp/get"] });
      await queryClient.invalidateQueries({ queryKey: ["/api/leaderboard"] });
      
      toast({
        title: "Marble Gifted!",
        description: `Successfully gifted Thunder Marble #${tokenId}. Transaction: ${txHash.slice(0, 10)}...`,
      });
      
      setOpen(false);
      setRecipientAddress("");
      setTokenId("");
      onSuccess?.();
    } catch (error: any) {
      console.error("Gift error:", error);
      
      let errorMessage = "Failed to gift marble";
      if (error.message?.includes("Contract address not configured")) {
        errorMessage = "Smart contract not deployed yet. Please check VITE_CONTRACT_ADDRESS environment variable.";
      } else if (error.message?.includes("user rejected")) {
        errorMessage = "Transaction was rejected";
      } else if (error.message?.includes("Not the owner")) {
        errorMessage = "You don't own this marble";
      }
      
      toast({
        title: "Gift Failed",
        description: errorMessage,
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button
          variant="default"
          className="bg-primary/20 hover:bg-primary/30 border-primary/50"
          data-testid="button-mint-gift"
        >
          <Sparkles className="w-4 h-4 mr-2" />
          Mint / Gift Marble
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle>Blockchain Actions</DialogTitle>
          <DialogDescription>
            Mint a new Thunder Marble or gift one to another player
          </DialogDescription>
        </DialogHeader>
        
        <div className="space-y-6 py-4">
          <RadioGroup value={mode} onValueChange={(v) => setMode(v as "mint" | "gift")}>
            <div className="flex items-center space-x-2">
              <RadioGroupItem value="mint" id="mode-mint" data-testid="radio-mint" />
              <Label htmlFor="mode-mint" className="flex items-center gap-2 cursor-pointer">
                <Sparkles className="w-4 h-4 text-primary" />
                Mint New Marble (+10 XP)
              </Label>
            </div>
            <div className="flex items-center space-x-2">
              <RadioGroupItem value="gift" id="mode-gift" data-testid="radio-gift" />
              <Label htmlFor="mode-gift" className="flex items-center gap-2 cursor-pointer">
                <GiftIcon className="w-4 h-4 text-accent" />
                Gift Marble (+5 XP)
              </Label>
            </div>
          </RadioGroup>

          {mode === "mint" && (
            <div className="space-y-4">
              <div>
                <Label>Rarity Level</Label>
                <RadioGroup value={rarity} onValueChange={setRarity} className="mt-2 space-y-2">
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="0" id="rarity-0" />
                    <Label htmlFor="rarity-0" className="cursor-pointer">Common</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="1" id="rarity-1" />
                    <Label htmlFor="rarity-1" className="cursor-pointer">Rare</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="2" id="rarity-2" />
                    <Label htmlFor="rarity-2" className="cursor-pointer">Epic</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="3" id="rarity-3" />
                    <Label htmlFor="rarity-3" className="cursor-pointer">Legendary</Label>
                  </div>
                </RadioGroup>
              </div>
            </div>
          )}

          {mode === "gift" && (
            <div className="space-y-4">
              <div>
                <Label htmlFor="recipient">Recipient Address</Label>
                <Input
                  id="recipient"
                  placeholder="0x..."
                  value={recipientAddress}
                  onChange={(e) => setRecipientAddress(e.target.value)}
                  className="font-mono text-sm"
                  data-testid="input-recipient"
                />
              </div>
              <div>
                <Label htmlFor="tokenId">Token ID</Label>
                <Input
                  id="tokenId"
                  type="number"
                  placeholder="1"
                  value={tokenId}
                  onChange={(e) => setTokenId(e.target.value)}
                  data-testid="input-tokenid"
                />
              </div>
            </div>
          )}
        </div>

        <DialogFooter>
          <Button
            variant="outline"
            onClick={() => setOpen(false)}
            disabled={isLoading}
            data-testid="button-cancel"
          >
            Cancel
          </Button>
          <Button
            onClick={mode === "mint" ? handleMint : handleGift}
            disabled={isLoading}
            data-testid="button-confirm"
          >
            {isLoading && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}
            {mode === "mint" ? "Mint Marble" : "Gift Marble"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
