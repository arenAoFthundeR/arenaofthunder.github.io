import { useState, useEffect } from "react";
import { DollarSign } from "lucide-react";

export function TreasuryTicker() {
  const [value, setValue] = useState(50000);

  useEffect(() => {
    const interval = setInterval(() => {
      setValue((prev) => {
        const change = Math.floor(Math.random() * 100 - 50);
        return Math.max(0, prev + change);
      });
    }, 2500);

    return () => clearInterval(interval);
  }, []);

  return (
    <div className="w-full bg-gradient-to-r from-primary/20 via-accent/20 to-primary/20 border-y border-primary/30 py-4">
      <div className="max-w-7xl mx-auto px-6 flex items-center justify-center gap-3">
        <DollarSign className="w-5 h-5 text-chart-5" />
        <span className="font-display text-lg font-semibold tracking-wide">
          Arena Treasury:
        </span>
        <span
          className="font-mono text-xl font-bold text-chart-5 tabular-nums"
          data-testid="text-treasury-value"
        >
          ${value.toLocaleString()}
        </span>
      </div>
    </div>
  );
}
