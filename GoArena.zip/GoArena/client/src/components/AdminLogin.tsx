import { useState } from "react";
import { useLocation } from "wouter";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Shield, LogOut } from "lucide-react";
import { useAdmin } from "@/lib/adminContext";
import { useToast } from "@/hooks/use-toast";

export function AdminLogin() {
  const [open, setOpen] = useState(false);
  const [password, setPassword] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const { isAdmin, login, logout } = useAdmin();
  const [, setLocation] = useLocation();
  const { toast } = useToast();

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    
    const success = await login(password);
    
    if (success) {
      toast({ title: "Success", description: "Logged in as admin" });
      setOpen(false);
      setPassword("");
      setLocation("/admin");
    } else {
      toast({
        title: "Error",
        description: "Invalid admin password",
        variant: "destructive",
      });
    }
    
    setIsLoading(false);
  };

  const handleLogout = () => {
    logout();
    toast({ title: "Logged out", description: "Admin session ended" });
    setLocation("/");
  };

  if (isAdmin) {
    return (
      <Button variant="outline" size="sm" onClick={handleLogout} data-testid="button-admin-logout">
        <LogOut className="h-4 w-4 mr-2" />
        Admin Logout
      </Button>
    );
  }

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button variant="ghost" size="sm" data-testid="button-admin-login">
          <Shield className="h-4 w-4 mr-2" />
          Admin
        </Button>
      </DialogTrigger>
      <DialogContent data-testid="dialog-admin-login">
        <DialogHeader>
          <DialogTitle>Admin Login</DialogTitle>
          <DialogDescription>
            Enter admin password to access dashboard
          </DialogDescription>
        </DialogHeader>
        <form onSubmit={handleLogin} className="space-y-4">
          <div>
            <Input
              type="password"
              placeholder="Admin password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              disabled={isLoading}
              data-testid="input-admin-password"
            />
          </div>
          <Button type="submit" className="w-full" disabled={isLoading} data-testid="button-submit-admin-login">
            {isLoading ? "Logging in..." : "Login"}
          </Button>
        </form>
      </DialogContent>
    </Dialog>
  );
}
