import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { Smartphone, Plus, Trash2, Edit2, Save, X, Activity, Zap } from "lucide-react";
import type { GyroscopeConfig, GestureTrigger, InsertGestureTrigger } from "@shared/gyro-schema";

export function GyroscopeManager() {
  const { toast } = useToast();
  const [editingTrigger, setEditingTrigger] = useState<string | null>(null);
  const [isCreating, setIsCreating] = useState(false);

  const { data: config, isLoading } = useQuery<GyroscopeConfig>({
    queryKey: ["/api/gyro/config"],
  });

  const updateConfigMutation = useMutation({
    mutationFn: async (updates: Partial<GyroscopeConfig>) =>
      apiRequest("/api/gyro/config", "PATCH", updates),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/gyro/config"] });
      toast({
        title: "Config Updated",
        description: "Gyroscope configuration saved successfully",
      });
    },
  });

  const createTriggerMutation = useMutation({
    mutationFn: async (trigger: InsertGestureTrigger) =>
      apiRequest("/api/gyro/triggers", "POST", trigger),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/gyro/config"] });
      setIsCreating(false);
      toast({
        title: "Trigger Created",
        description: "New gesture trigger created successfully",
      });
    },
  });

  const updateTriggerMutation = useMutation({
    mutationFn: async ({ id, updates }: { id: string; updates: Partial<GestureTrigger> }) =>
      apiRequest(`/api/gyro/triggers/${id}`, "PATCH", updates),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/gyro/config"] });
      setEditingTrigger(null);
      toast({
        title: "Trigger Updated",
        description: "Gesture trigger updated successfully",
      });
    },
  });

  const deleteTriggerMutation = useMutation({
    mutationFn: async (id: string) => apiRequest(`/api/gyro/triggers/${id}`, "DELETE"),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/gyro/config"] });
      toast({
        title: "Trigger Deleted",
        description: "Gesture trigger deleted successfully",
      });
    },
  });

  if (isLoading || !config) {
    return (
      <Card className="bg-slate-900 border-cyan-500/20">
        <CardHeader>
          <CardTitle>Loading gyroscope configuration...</CardTitle>
        </CardHeader>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      <Card className="bg-slate-900 border-cyan-500/20">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-md bg-cyan-500/10">
                <Smartphone className="w-6 h-6 text-cyan-400" />
              </div>
              <div>
                <CardTitle>Gyroscope Code Injection</CardTitle>
                <CardDescription>Configure mobile device motion triggers</CardDescription>
              </div>
            </div>
            <Switch
              checked={config.enabled}
              onCheckedChange={(enabled) =>
                updateConfigMutation.mutate({ enabled })
              }
              data-testid="switch-gyro-enabled"
            />
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between p-3 bg-slate-800 rounded-md">
            <div>
              <div className="text-sm font-medium">System Status</div>
              <div className="text-xs text-slate-400 mt-1">
                {config.enabled ? "Active - monitoring device motion" : "Disabled"}
              </div>
            </div>
            <Badge variant={config.enabled ? "default" : "secondary"}>
              {config.enabled ? "Active" : "Inactive"}
            </Badge>
          </div>

          <div className="flex items-center justify-between p-3 bg-slate-800 rounded-md">
            <div>
              <div className="text-sm font-medium">Debug Mode</div>
              <div className="text-xs text-slate-400 mt-1">
                Log detailed gyroscope readings to console
              </div>
            </div>
            <Switch
              checked={config.debugMode}
              onCheckedChange={(debugMode) =>
                updateConfigMutation.mutate({ debugMode })
              }
              data-testid="switch-debug-mode"
            />
          </div>

          <div className="flex items-center justify-between p-3 bg-slate-800 rounded-md">
            <div>
              <div className="text-sm font-medium">Require Permission</div>
              <div className="text-xs text-slate-400 mt-1">
                Ask for device sensor permission (iOS 13+)
              </div>
            </div>
            <Switch
              checked={config.requirePermission}
              onCheckedChange={(requirePermission) =>
                updateConfigMutation.mutate({ requirePermission })
              }
              data-testid="switch-require-permission"
            />
          </div>
        </CardContent>
      </Card>

      <Card className="bg-slate-900 border-cyan-500/20">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle>Gesture Triggers</CardTitle>
              <CardDescription>
                Define gestures that trigger code execution
              </CardDescription>
            </div>
            <Button
              size="sm"
              onClick={() => setIsCreating(true)}
              data-testid="button-create-trigger"
            >
              <Plus className="w-4 h-4 mr-1.5" />
              New Trigger
            </Button>
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          {config.triggers.length === 0 && !isCreating && (
            <div className="text-center py-8 text-slate-400">
              <Activity className="w-12 h-12 mx-auto mb-3 opacity-50" />
              <div className="text-sm">No gesture triggers configured</div>
              <div className="text-xs mt-1">Create one to get started</div>
            </div>
          )}

          {isCreating && (
            <TriggerEditor
              onSave={(trigger) => createTriggerMutation.mutate(trigger)}
              onCancel={() => setIsCreating(false)}
            />
          )}

          {config.triggers.map((trigger) => (
            <div key={trigger.id}>
              {editingTrigger === trigger.id ? (
                <TriggerEditor
                  trigger={trigger}
                  onSave={(updates) =>
                    updateTriggerMutation.mutate({ id: trigger.id, updates })
                  }
                  onCancel={() => setEditingTrigger(null)}
                />
              ) : (
                <TriggerCard
                  trigger={trigger}
                  onEdit={() => setEditingTrigger(trigger.id)}
                  onDelete={() => deleteTriggerMutation.mutate(trigger.id)}
                  onToggle={(enabled) =>
                    updateTriggerMutation.mutate({
                      id: trigger.id,
                      updates: { enabled },
                    })
                  }
                />
              )}
            </div>
          ))}
        </CardContent>
      </Card>
    </div>
  );
}

function TriggerCard({
  trigger,
  onEdit,
  onDelete,
  onToggle,
}: {
  trigger: GestureTrigger;
  onEdit: () => void;
  onDelete: () => void;
  onToggle: (enabled: boolean) => void;
}) {
  return (
    <div className="p-4 bg-slate-800 rounded-md border border-slate-700">
      <div className="flex items-start justify-between mb-3">
        <div className="flex-1">
          <div className="flex items-center gap-2 mb-1">
            <h4 className="font-medium">{trigger.name}</h4>
            <Badge variant="outline" className="text-xs">
              {trigger.type}
            </Badge>
            {!trigger.enabled && (
              <Badge variant="secondary" className="text-xs">
                Disabled
              </Badge>
            )}
          </div>
          <p className="text-sm text-slate-400">{trigger.description}</p>
        </div>
        <div className="flex items-center gap-2 ml-4">
          <Switch
            checked={trigger.enabled}
            onCheckedChange={onToggle}
            data-testid={`switch-trigger-${trigger.id}`}
          />
          <Button
            size="sm"
            variant="ghost"
            onClick={onEdit}
            data-testid={`button-edit-${trigger.id}`}
          >
            <Edit2 className="w-3 h-3" />
          </Button>
          <Button
            size="sm"
            variant="ghost"
            onClick={onDelete}
            data-testid={`button-delete-${trigger.id}`}
          >
            <Trash2 className="w-3 h-3" />
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-3 text-xs">
        {trigger.cooldown && (
          <div className="flex items-center gap-2">
            <span className="text-slate-500">Cooldown:</span>
            <span>{trigger.cooldown}ms</span>
          </div>
        )}
        {trigger.duration && (
          <div className="flex items-center gap-2">
            <span className="text-slate-500">Duration:</span>
            <span>{trigger.duration}ms</span>
          </div>
        )}
      </div>

      <div className="mt-3 p-2 bg-slate-900 rounded text-xs font-mono">
        <div className="text-slate-500 mb-1">Code to inject:</div>
        <div className="text-cyan-300 line-clamp-2">{trigger.codeToInject}</div>
      </div>
    </div>
  );
}

function TriggerEditor({
  trigger,
  onSave,
  onCancel,
}: {
  trigger?: GestureTrigger;
  onSave: (trigger: InsertGestureTrigger) => void;
  onCancel: () => void;
}) {
  const [name, setName] = useState(trigger?.name || "");
  const [description, setDescription] = useState(trigger?.description || "");
  const [type, setType] = useState<string>(trigger?.type || "shake");
  const [code, setCode] = useState(trigger?.codeToInject || "console.log('Trigger fired!');");
  const [cooldown, setCooldown] = useState(trigger?.cooldown?.toString() || "1000");
  const [threshold, setThreshold] = useState(trigger?.threshold?.acceleration?.toString() || "20");

  const handleSave = () => {
    const triggerData: InsertGestureTrigger = {
      name,
      description,
      enabled: true,
      type: type as any,
      threshold:
        type === "shake"
          ? { acceleration: parseFloat(threshold) }
          : {},
      cooldown: parseInt(cooldown),
      codeToInject: code,
    };
    onSave(triggerData);
  };

  return (
    <div className="p-4 bg-slate-800 rounded-md border-2 border-cyan-500/30">
      <div className="space-y-4">
        <div>
          <Label htmlFor="trigger-name">Name</Label>
          <Input
            id="trigger-name"
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="Shake to refresh"
            className="mt-1"
            data-testid="input-trigger-name"
          />
        </div>

        <div>
          <Label htmlFor="trigger-description">Description</Label>
          <Input
            id="trigger-description"
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            placeholder="Refresh data when device is shaken"
            className="mt-1"
            data-testid="input-trigger-description"
          />
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div>
            <Label htmlFor="trigger-type">Type</Label>
            <Select value={type} onValueChange={setType}>
              <SelectTrigger id="trigger-type" className="mt-1">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="shake">Shake</SelectItem>
                <SelectItem value="orientation">Orientation</SelectItem>
                <SelectItem value="motion">Motion</SelectItem>
                <SelectItem value="tilt">Tilt</SelectItem>
                <SelectItem value="rotation">Rotation</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div>
            <Label htmlFor="trigger-cooldown">Cooldown (ms)</Label>
            <Input
              id="trigger-cooldown"
              type="number"
              value={cooldown}
              onChange={(e) => setCooldown(e.target.value)}
              className="mt-1"
              data-testid="input-trigger-cooldown"
            />
          </div>
        </div>

        {type === "shake" && (
          <div>
            <Label htmlFor="trigger-threshold">Acceleration Threshold</Label>
            <Input
              id="trigger-threshold"
              type="number"
              value={threshold}
              onChange={(e) => setThreshold(e.target.value)}
              className="mt-1"
              data-testid="input-trigger-threshold"
            />
          </div>
        )}

        <div>
          <Label htmlFor="trigger-code">Code to Inject</Label>
          <Textarea
            id="trigger-code"
            value={code}
            onChange={(e) => setCode(e.target.value)}
            placeholder="console.log('Gyroscope trigger fired!');\n// Your code here..."
            className="mt-1 font-mono text-sm"
            rows={6}
            data-testid="textarea-trigger-code"
          />
        </div>

        <div className="flex gap-2 justify-end">
          <Button variant="outline" onClick={onCancel} data-testid="button-cancel-trigger">
            <X className="w-4 h-4 mr-1.5" />
            Cancel
          </Button>
          <Button onClick={handleSave} data-testid="button-save-trigger">
            <Save className="w-4 h-4 mr-1.5" />
            Save
          </Button>
        </div>
      </div>
    </div>
  );
}
