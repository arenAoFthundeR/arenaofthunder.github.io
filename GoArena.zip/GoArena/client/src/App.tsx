import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { WebSocketProvider } from "@/components/WebSocketProvider";
import { AdminProvider } from "@/lib/adminContext";
import { WalletProvider } from "@/lib/walletContext";
import { Layout } from "@/components/Layout";
import Home from "@/pages/Home";
import AdminDashboard from "@/pages/AdminDashboard";
import Marbles from "@/pages/Marbles";
import Dungeons from "@/pages/Dungeons";
import SecurityConsole from "@/pages/SecurityConsole";
import Treasury from "@/pages/Treasury";
import Planning from "@/pages/Planning";
import Activity from "@/pages/Activity";
import NotFound from "@/pages/not-found";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/treasury" component={Treasury} />
      <Route path="/marbles" component={Marbles} />
      <Route path="/dungeons" component={Dungeons} />
      <Route path="/activity" component={Activity} />
      <Route path="/security" component={SecurityConsole} />
      <Route path="/planning" component={Planning} />
      <Route path="/admin" component={AdminDashboard} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <AdminProvider>
          <WebSocketProvider>
            <WalletProvider>
              <Layout>
                <Toaster />
                <Router />
              </Layout>
            </WalletProvider>
          </WebSocketProvider>
        </AdminProvider>
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
