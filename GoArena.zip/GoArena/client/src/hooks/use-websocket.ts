import { useEffect, useRef, useState, useCallback } from "react";

export type WSMessageType = "leaderboard_update" | "tournament_join" | "tournament_advance" | "xp_update" | "connection_established";

export interface WSMessage {
  type: WSMessageType;
  data: any;
}

type MessageHandler = (data: any) => void;

export function useWebSocket() {
  const [isConnected, setIsConnected] = useState(false);
  const [reconnectAttempts, setReconnectAttempts] = useState(0);
  const wsRef = useRef<WebSocket | null>(null);
  const handlersRef = useRef<Map<WSMessageType, Set<MessageHandler>>>(new Map());
  const reconnectTimeoutRef = useRef<NodeJS.Timeout | null>(null);
  const reconnectAttemptsRef = useRef<number>(0);
  const isReconnectingRef = useRef<boolean>(false);

  const connect = useCallback(() => {
    if (wsRef.current?.readyState === WebSocket.OPEN) {
      return;
    }

    if (isReconnectingRef.current) {
      return;
    }

    const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
    const wsUrl = `${protocol}//${window.location.host}/ws`;

    try {
      const ws = new WebSocket(wsUrl);
      wsRef.current = ws;

      ws.onopen = () => {
        console.log("[WebSocket] Connected");
        setIsConnected(true);
        reconnectAttemptsRef.current = 0;
        setReconnectAttempts(0);
        isReconnectingRef.current = false;

        if (reconnectTimeoutRef.current) {
          clearTimeout(reconnectTimeoutRef.current);
          reconnectTimeoutRef.current = null;
        }
      };

      ws.onmessage = (event) => {
        try {
          const message: WSMessage = JSON.parse(event.data);
          console.log("[WebSocket] Message received:", message.type);

          const handlers = handlersRef.current.get(message.type);
          if (handlers) {
            handlers.forEach((handler) => {
              try {
                handler(message.data);
              } catch (error) {
                console.error("[WebSocket] Handler error:", error);
              }
            });
          }
        } catch (error) {
          console.error("[WebSocket] Failed to parse message:", error);
        }
      };

      ws.onerror = (error) => {
        console.error("[WebSocket] Error:", error);
      };

      ws.onclose = () => {
        console.log("[WebSocket] Disconnected");
        setIsConnected(false);
        wsRef.current = null;

        if (isReconnectingRef.current) {
          return;
        }

        const maxAttempts = 5;
        const baseDelay = 2000;
        const maxDelay = 30000;
        const currentAttempts = reconnectAttemptsRef.current;

        if (currentAttempts < maxAttempts) {
          const delay = Math.min(baseDelay * Math.pow(2, currentAttempts), maxDelay);
          console.log(`[WebSocket] Reconnecting in ${delay}ms (attempt ${currentAttempts + 1}/${maxAttempts})`);

          reconnectAttemptsRef.current = currentAttempts + 1;
          setReconnectAttempts(currentAttempts + 1);
          isReconnectingRef.current = true;

          reconnectTimeoutRef.current = setTimeout(() => {
            isReconnectingRef.current = false;
            connect();
          }, delay);
        } else {
          console.log("[WebSocket] Max reconnection attempts reached");
          if (reconnectTimeoutRef.current) {
            clearTimeout(reconnectTimeoutRef.current);
            reconnectTimeoutRef.current = null;
          }
        }
      };
    } catch (error) {
      console.error("[WebSocket] Connection failed:", error);
      isReconnectingRef.current = false;
    }
  }, []);

  const disconnect = useCallback(() => {
    if (reconnectTimeoutRef.current) {
      clearTimeout(reconnectTimeoutRef.current);
      reconnectTimeoutRef.current = null;
    }
    if (wsRef.current) {
      wsRef.current.close();
      wsRef.current = null;
    }
    setIsConnected(false);
    reconnectAttemptsRef.current = 0;
    setReconnectAttempts(0);
    isReconnectingRef.current = false;
  }, []);

  const subscribe = useCallback((type: WSMessageType, handler: MessageHandler) => {
    if (!handlersRef.current.has(type)) {
      handlersRef.current.set(type, new Set());
    }
    handlersRef.current.get(type)!.add(handler);

    return () => {
      const handlers = handlersRef.current.get(type);
      if (handlers) {
        handlers.delete(handler);
        if (handlers.size === 0) {
          handlersRef.current.delete(type);
        }
      }
    };
  }, []);

  useEffect(() => {
    connect();

    return () => {
      disconnect();
    };
  }, [connect, disconnect]);

  return {
    isConnected,
    subscribe,
    reconnectAttempts,
  };
}
