import { useEffect, useState, useRef, useMemo } from "react";
import { useQuery } from "@tanstack/react-query";
import { startGyroscope, stopGyroscope, isGyroscopeSupported, onGyroTrigger } from "@/lib/gyroscope";
import type { GyroscopeConfig } from "@shared/gyro-schema";

export function useGyroscope() {
  const [isActive, setIsActive] = useState(false);
  const [isSupported] = useState(isGyroscopeSupported());
  const configHashRef = useRef<string | null>(null);

  const { data: config } = useQuery<GyroscopeConfig>({
    queryKey: ["/api/gyro/config"],
    refetchInterval: 10000, // Refresh every 10 seconds
  });

  // Memoize config hash to avoid recalculation
  const configHash = useMemo(() => {
    if (!config) return null;
    return JSON.stringify({
      enabled: config.enabled,
      debugMode: config.debugMode,
      requirePermission: config.requirePermission,
      triggers: config.triggers,
    });
  }, [config?.enabled, config?.debugMode, config?.requirePermission, config?.triggers]);

  useEffect(() => {
    if (!isSupported || !config || !config.enabled) {
      stopGyroscope();
      setIsActive(false);
      return;
    }

    // Only restart if config hash actually changed
    if (configHashRef.current === configHash) {
      return;
    }

    configHashRef.current = configHash;

    // Restart gyroscope monitoring with updated config
    stopGyroscope();
    startGyroscope(config).then((started) => {
      setIsActive(started);
      if (started) {
        console.log("⚡ Gyroscope monitoring started");
      } else {
        console.log("❌ Gyroscope permission denied or not available");
      }
    });

    return () => {
      stopGyroscope();
      setIsActive(false);
    };
  }, [configHash, config, isSupported]);

  return {
    isSupported,
    isActive,
    config,
  };
}

export function useGyroTrigger(triggerId: string, callback: (data: any) => void) {
  useEffect(() => {
    onGyroTrigger(triggerId, callback);
  }, [triggerId, callback]);
}
