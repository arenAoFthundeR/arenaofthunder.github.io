import { ethers, Contract } from "ethers";
import { getProvider, getSigner } from "./web3";

// Minimal ABI for Arena Marbles contract
const ARENA_MARBLES_ABI = [
  "function mint(address to, string memory tokenURI, uint8 rarity) public returns (uint256)",
  "function gift(address to, uint256 tokenId) public",
  "function totalSupply() public view returns (uint256)",
  "function tokensOfOwner(address owner) public view returns (uint256[])",
  "function balanceOf(address owner) public view returns (uint256)",
  "function tokenURI(uint256 tokenId) public view returns (string memory)",
  "function marbleRarity(uint256 tokenId) public view returns (uint8)",
  "function ownerOf(uint256 tokenId) public view returns (address)",
  "event MarbleMinted(address indexed to, uint256 indexed tokenId, uint8 rarity)",
  "event MarbleGifted(address indexed from, address indexed to, uint256 indexed tokenId)",
];

// Contract address - Set via environment variable
// Deploy contract and add VITE_CONTRACT_ADDRESS to .env
const CONTRACT_ADDRESS = import.meta.env.VITE_CONTRACT_ADDRESS || "";

export interface MarbleMetadata {
  tokenId: number;
  owner: string;
  tokenURI: string;
  rarity: number;
  rarityName: string;
}

const RARITY_NAMES = ["Common", "Rare", "Epic", "Legendary"];

export class ArenaContract {
  private contract: Contract | null = null;
  
  async getContract(needsSigner = false): Promise<Contract> {
    if (!CONTRACT_ADDRESS) {
      throw new Error("Contract address not configured. Set VITE_CONTRACT_ADDRESS in environment.");
    }
    
    const providerOrSigner = needsSigner ? await getSigner() : await getProvider();
    return new Contract(CONTRACT_ADDRESS, ARENA_MARBLES_ABI, providerOrSigner);
  }
  
  /**
   * Mint a new marble NFT
   */
  async mintMarble(
    to: string,
    rarity: number = 0
  ): Promise<{ tokenId: number; txHash: string }> {
    const contract = await this.getContract(true);
    
    // Generate metadata URI (in production, upload to IPFS)
    const tokenURI = `data:application/json,{"name":"Thunder Marble","description":"A marble from the Arena of Thunder","rarity":${rarity}}`;
    
    const tx = await contract.mint(to, tokenURI, rarity);
    const receipt = await tx.wait();
    
    // Extract tokenId from MarbleMinted event
    const event = receipt.logs
      .map((log: any) => {
        try {
          return contract.interface.parseLog(log);
        } catch {
          return null;
        }
      })
      .find((e: any) => e?.name === "MarbleMinted");
    
    const tokenId = event ? Number(event.args.tokenId) : 0;
    
    return {
      tokenId,
      txHash: receipt.hash,
    };
  }
  
  /**
   * Gift a marble to another address
   */
  async giftMarble(to: string, tokenId: number): Promise<string> {
    const contract = await this.getContract(true);
    const tx = await contract.gift(to, tokenId);
    const receipt = await tx.wait();
    return receipt.hash;
  }
  
  /**
   * Get all marbles owned by an address
   */
  async getOwnedMarbles(owner: string): Promise<MarbleMetadata[]> {
    const contract = await this.getContract(false);
    const tokenIds = await contract.tokensOfOwner(owner);
    
    const marbles = await Promise.all(
      tokenIds.map(async (tokenId: bigint) => {
        const [tokenURI, rarity] = await Promise.all([
          contract.tokenURI(tokenId),
          contract.marbleRarity(tokenId),
        ]);
        
        return {
          tokenId: Number(tokenId),
          owner,
          tokenURI,
          rarity: Number(rarity),
          rarityName: RARITY_NAMES[Number(rarity)] || "Unknown",
        };
      })
    );
    
    return marbles;
  }
  
  /**
   * Get total supply of minted marbles
   */
  async getTotalSupply(): Promise<number> {
    const contract = await this.getContract(false);
    const supply = await contract.totalSupply();
    return Number(supply);
  }
  
  /**
   * Get marble count for an address
   */
  async getMarbleCount(owner: string): Promise<number> {
    const contract = await this.getContract(false);
    const balance = await contract.balanceOf(owner);
    return Number(balance);
  }
}

export const arenaContract = new ArenaContract();
