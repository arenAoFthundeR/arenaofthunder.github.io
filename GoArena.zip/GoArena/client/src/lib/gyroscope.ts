/**
 * Gyroscope Code Injection Infrastructure
 * 
 * Monitors device motion/orientation on mobile devices and triggers
 * code injection when specific gesture patterns are detected.
 */

export interface GyroReading {
  alpha: number;  // z-axis rotation (0-360)
  beta: number;   // x-axis rotation (-180 to 180)
  gamma: number;  // y-axis rotation (-90 to 90)
  timestamp: number;
}

export interface MotionReading {
  acceleration: {
    x: number;
    y: number;
    z: number;
  };
  accelerationIncludingGravity: {
    x: number;
    y: number;
    z: number;
  };
  rotationRate: {
    alpha: number;
    beta: number;
    gamma: number;
  };
  timestamp: number;
}

export interface GestureTrigger {
  id: string;
  name: string;
  description: string;
  enabled: boolean;
  type: 'orientation' | 'motion' | 'shake' | 'tilt' | 'rotation';
  threshold: {
    alpha?: { min?: number; max?: number };
    beta?: { min?: number; max?: number };
    gamma?: { min?: number; max?: number };
    acceleration?: number;
    rotationRate?: number;
  };
  duration?: number; // How long condition must be met (ms)
  cooldown?: number; // Cooldown between triggers (ms)
  codeToInject: string; // JavaScript code to execute
  lastTriggered?: number;
}

export interface GyroscopeConfig {
  enabled: boolean;
  triggers: GestureTrigger[];
  debugMode: boolean;
  requirePermission: boolean;
}

class GyroscopeManager {
  private enabled: boolean = false;
  private debugMode: boolean = false;
  private config: GyroscopeConfig | null = null;
  
  private currentOrientation: GyroReading | null = null;
  private currentMotion: MotionReading | null = null;
  private orientationHistory: GyroReading[] = [];
  private motionHistory: MotionReading[] = [];
  
  private historyMaxLength = 50;
  
  private orientationListener: ((event: DeviceOrientationEvent) => void) | null = null;
  private motionListener: ((event: DeviceMotionEvent) => void) | null = null;
  
  private triggerCallbacks: Map<string, (data: any) => void> = new Map();

  constructor() {
    this.log("GyroscopeManager initialized");
  }

  /**
   * Request permission for device motion/orientation (required on iOS 13+)
   */
  async requestPermission(): Promise<boolean> {
    try {
      // iOS 13+ requires explicit permission
      if (typeof (DeviceOrientationEvent as any).requestPermission === 'function') {
        const orientationPermission = await (DeviceOrientationEvent as any).requestPermission();
        const motionPermission = await (DeviceMotionEvent as any).requestPermission();
        
        if (orientationPermission === 'granted' && motionPermission === 'granted') {
          this.log("✅ Permission granted for device sensors");
          return true;
        } else {
          this.log("❌ Permission denied for device sensors");
          return false;
        }
      } else {
        // Android or older iOS - no permission needed
        this.log("✅ No permission required (Android or older iOS)");
        return true;
      }
    } catch (error) {
      this.log("❌ Error requesting permission:", error);
      return false;
    }
  }

  /**
   * Start monitoring gyroscope
   */
  async start(config: GyroscopeConfig): Promise<boolean> {
    if (this.enabled) {
      this.log("⚠️ Already started");
      return true;
    }

    this.config = config;
    this.debugMode = config.debugMode;
    
    if (config.requirePermission) {
      const hasPermission = await this.requestPermission();
      if (!hasPermission) {
        return false;
      }
    }

    this.setupListeners();
    this.enabled = true;
    this.log("🚀 Gyroscope monitoring started");
    return true;
  }

  /**
   * Stop monitoring gyroscope
   */
  stop(): void {
    if (!this.enabled) return;
    
    this.removeListeners();
    this.enabled = false;
    this.log("🛑 Gyroscope monitoring stopped");
  }

  /**
   * Setup device event listeners
   */
  private setupListeners(): void {
    this.orientationListener = (event: DeviceOrientationEvent) => {
      this.handleOrientation(event);
    };
    
    this.motionListener = (event: DeviceMotionEvent) => {
      this.handleMotion(event);
    };
    
    window.addEventListener('deviceorientation', this.orientationListener);
    window.addEventListener('devicemotion', this.motionListener);
  }

  /**
   * Remove device event listeners
   */
  private removeListeners(): void {
    if (this.orientationListener) {
      window.removeEventListener('deviceorientation', this.orientationListener);
      this.orientationListener = null;
    }
    
    if (this.motionListener) {
      window.removeEventListener('devicemotion', this.motionListener);
      this.motionListener = null;
    }
  }

  /**
   * Handle device orientation event
   */
  private handleOrientation(event: DeviceOrientationEvent): void {
    const reading: GyroReading = {
      alpha: event.alpha || 0,
      beta: event.beta || 0,
      gamma: event.gamma || 0,
      timestamp: Date.now(),
    };
    
    this.currentOrientation = reading;
    this.orientationHistory.push(reading);
    
    if (this.orientationHistory.length > this.historyMaxLength) {
      this.orientationHistory.shift();
    }
    
    this.checkTriggers('orientation', reading);
  }

  /**
   * Handle device motion event
   */
  private handleMotion(event: DeviceMotionEvent): void {
    const reading: MotionReading = {
      acceleration: {
        x: event.acceleration?.x || 0,
        y: event.acceleration?.y || 0,
        z: event.acceleration?.z || 0,
      },
      accelerationIncludingGravity: {
        x: event.accelerationIncludingGravity?.x || 0,
        y: event.accelerationIncludingGravity?.y || 0,
        z: event.accelerationIncludingGravity?.z || 0,
      },
      rotationRate: {
        alpha: event.rotationRate?.alpha || 0,
        beta: event.rotationRate?.beta || 0,
        gamma: event.rotationRate?.gamma || 0,
      },
      timestamp: Date.now(),
    };
    
    this.currentMotion = reading;
    this.motionHistory.push(reading);
    
    if (this.motionHistory.length > this.historyMaxLength) {
      this.motionHistory.shift();
    }
    
    this.checkTriggers('motion', reading);
    this.detectShake(reading);
  }

  /**
   * Detect shake gesture
   */
  private detectShake(reading: MotionReading): void {
    const { x, y, z } = reading.accelerationIncludingGravity;
    const totalAcceleration = Math.sqrt(x * x + y * y + z * z);
    
    // Shake detected if acceleration exceeds threshold
    if (totalAcceleration > 20) {
      this.checkTriggers('shake', { acceleration: totalAcceleration });
    }
  }

  /**
   * Check if any triggers should fire
   */
  private checkTriggers(type: string, data: any): void {
    if (!this.config || !this.config.enabled) return;
    
    for (const trigger of this.config.triggers) {
      if (!trigger.enabled) continue;
      if (trigger.type !== type) continue;
      
      // Check cooldown
      if (trigger.lastTriggered && trigger.cooldown) {
        const timeSinceLastTrigger = Date.now() - trigger.lastTriggered;
        if (timeSinceLastTrigger < trigger.cooldown) {
          continue;
        }
      }
      
      // Check if trigger conditions are met
      if (this.checkTriggerConditions(trigger, data)) {
        this.executeTrigger(trigger, data);
      }
    }
  }

  /**
   * Check if trigger conditions are met
   */
  private checkTriggerConditions(trigger: GestureTrigger, data: any): boolean {
    const { threshold } = trigger;
    
    if (trigger.type === 'orientation' && this.currentOrientation) {
      const { alpha, beta, gamma } = this.currentOrientation;
      
      if (threshold.alpha) {
        if (threshold.alpha.min !== undefined && alpha < threshold.alpha.min) return false;
        if (threshold.alpha.max !== undefined && alpha > threshold.alpha.max) return false;
      }
      
      if (threshold.beta) {
        if (threshold.beta.min !== undefined && beta < threshold.beta.min) return false;
        if (threshold.beta.max !== undefined && beta > threshold.beta.max) return false;
      }
      
      if (threshold.gamma) {
        if (threshold.gamma.min !== undefined && gamma < threshold.gamma.min) return false;
        if (threshold.gamma.max !== undefined && gamma > threshold.gamma.max) return false;
      }
      
      return true;
    }
    
    if (trigger.type === 'shake' && data.acceleration) {
      if (threshold.acceleration && data.acceleration > threshold.acceleration) {
        return true;
      }
    }
    
    if (trigger.type === 'motion' && this.currentMotion) {
      if (threshold.rotationRate) {
        const totalRotation = Math.abs(this.currentMotion.rotationRate.alpha) +
                             Math.abs(this.currentMotion.rotationRate.beta) +
                             Math.abs(this.currentMotion.rotationRate.gamma);
        if (totalRotation > threshold.rotationRate) {
          return true;
        }
      }
    }
    
    return false;
  }

  /**
   * Execute trigger - inject and run code
   */
  private executeTrigger(trigger: GestureTrigger, data: any): void {
    this.log(`🎯 Trigger fired: ${trigger.name}`, data);
    
    // Update last triggered timestamp
    trigger.lastTriggered = Date.now();
    
    // Execute callback if registered
    const callback = this.triggerCallbacks.get(trigger.id);
    if (callback) {
      callback({ trigger, data });
    }
    
    // Inject and execute code
    try {
      // Create isolated scope with context
      const context = {
        trigger,
        data,
        gyroscope: {
          orientation: this.currentOrientation,
          motion: this.currentMotion,
        },
        console: {
          log: (...args: any[]) => this.log('[Injected Code]', ...args),
        },
      };
      
      // Execute code in isolated function scope
      const executeCode = new Function('context', `
        with (context) {
          ${trigger.codeToInject}
        }
      `);
      
      executeCode(context);
      
      this.log(`✅ Code executed successfully for trigger: ${trigger.name}`);
    } catch (error) {
      this.log(`❌ Error executing code for trigger ${trigger.name}:`, error);
    }
  }

  /**
   * Register callback for when a specific trigger fires
   */
  onTrigger(triggerId: string, callback: (data: any) => void): void {
    this.triggerCallbacks.set(triggerId, callback);
  }

  /**
   * Remove trigger callback
   */
  offTrigger(triggerId: string): void {
    this.triggerCallbacks.delete(triggerId);
  }

  /**
   * Get current gyroscope readings
   */
  getCurrentReadings(): { orientation: GyroReading | null; motion: MotionReading | null } {
    return {
      orientation: this.currentOrientation,
      motion: this.currentMotion,
    };
  }

  /**
   * Get gyroscope history
   */
  getHistory(): { orientation: GyroReading[]; motion: MotionReading[] } {
    return {
      orientation: [...this.orientationHistory],
      motion: [...this.motionHistory],
    };
  }

  /**
   * Check if gyroscope is supported
   */
  static isSupported(): boolean {
    return 'DeviceOrientationEvent' in window && 'DeviceMotionEvent' in window;
  }

  /**
   * Debug logging
   */
  private log(...args: any[]): void {
    if (this.debugMode) {
      console.log('[GyroscopeManager]', ...args);
    }
  }
}

// Singleton instance
export const gyroscopeManager = new GyroscopeManager();

// Helper functions
export function startGyroscope(config: GyroscopeConfig): Promise<boolean> {
  return gyroscopeManager.start(config);
}

export function stopGyroscope(): void {
  gyroscopeManager.stop();
}

export function onGyroTrigger(triggerId: string, callback: (data: any) => void): void {
  gyroscopeManager.onTrigger(triggerId, callback);
}

export function getCurrentGyroReadings() {
  return gyroscopeManager.getCurrentReadings();
}

export function isGyroscopeSupported(): boolean {
  return GyroscopeManager.isSupported();
}
