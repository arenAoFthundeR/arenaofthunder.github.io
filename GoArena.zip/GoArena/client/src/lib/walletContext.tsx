import { createContext, useContext, useState, useEffect, ReactNode } from "react";
import { getConnectedAccount } from "@/lib/web3";
import { queryClient } from "@/lib/queryClient";

interface WalletContextType {
  wallet: string | null;
  handleConnect: (address: string) => void;
  handleDisconnect: () => void;
}

const WalletContext = createContext<WalletContextType | undefined>(undefined);

export function WalletProvider({ children }: { children: ReactNode }) {
  const [wallet, setWallet] = useState<string | null>(null);

  useEffect(() => {
    getConnectedAccount().then(setWallet);
  }, []);

  const handleConnect = async (address: string) => {
    setWallet(address);
    await queryClient.invalidateQueries();
  };

  const handleDisconnect = () => {
    setWallet(null);
    queryClient.clear();
  };

  return (
    <WalletContext.Provider value={{ wallet, handleConnect, handleDisconnect }}>
      {children}
    </WalletContext.Provider>
  );
}

export function useWallet() {
  const context = useContext(WalletContext);
  if (context === undefined) {
    throw new Error("useWallet must be used within a WalletProvider");
  }
  return context;
}
