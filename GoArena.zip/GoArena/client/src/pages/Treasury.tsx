import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import { useToast } from "@/hooks/use-toast";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useAdmin } from "@/lib/adminContext";
import { Crown, Coins, Copy, Send, Wallet, Shield, TrendingUp } from "lucide-react";

interface TreasuryInfo {
  address: string;
  balance: string;
}

export default function Treasury() {
  const { toast } = useToast();
  const { isAdmin } = useAdmin();
  const [recipient, setRecipient] = useState("");
  const [amount, setAmount] = useState("");
  const [showAdminPanel, setShowAdminPanel] = useState(false);

  const { data: treasuryInfo, isLoading } = useQuery<TreasuryInfo>({
    queryKey: ["/api/treasury/info"],
    refetchInterval: 10000, // Refresh every 10 seconds
  });

  const sendFundsMutation = useMutation({
    mutationFn: async (data: { recipient: string; amount: string }) => {
      const res = await apiRequest("POST", "/api/treasury/send", data);
      if (!res.ok) {
        const error = await res.json();
        throw new Error(error.error || "Failed to send funds");
      }
      return await res.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ["/api/treasury/info"] });
      toast({
        title: "Reward Sent!",
        description: `Successfully sent ${amount} ETH. Transaction: ${data.txHash?.slice(0, 10)}...`,
      });
      setRecipient("");
      setAmount("");
    },
    onError: (error: Error) => {
      toast({
        title: "Transaction Failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleCopyAddress = () => {
    if (treasuryInfo?.address) {
      navigator.clipboard.writeText(treasuryInfo.address);
      toast({
        title: "Address Copied",
        description: "Treasury address copied to clipboard",
      });
    }
  };

  const handleSendFunds = () => {
    if (!recipient || !amount) {
      toast({
        title: "Invalid Input",
        description: "Please enter both recipient address and amount",
        variant: "destructive",
      });
      return;
    }
    sendFundsMutation.mutate({ recipient, amount });
  };

  const balanceInEth = treasuryInfo?.balance ? parseFloat(treasuryInfo.balance) : 0;
  const balanceInUsd = balanceInEth * 3500; // Rough ETH price estimate

  return (
    <div className="max-w-6xl mx-auto px-6 py-8 space-y-8">
      {/* Hero Section */}
      <div className="text-center space-y-4">
        <div className="flex items-center justify-center gap-3">
          <div className="relative">
            <Crown className="w-16 h-16 text-yellow-500" strokeWidth={1.5} />
            <div className="absolute inset-0 bg-yellow-500/20 blur-xl rounded-full" />
          </div>
          <h1 className="text-5xl font-display font-bold bg-gradient-to-r from-yellow-500 via-yellow-400 to-yellow-600 bg-clip-text text-transparent">
            Royal Treasury
          </h1>
        </div>
        <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
          The kingdom's vault. Support the realm with donations or claim your rewards.
        </p>
      </div>

      {/* Balance Display */}
      <Card className="border-2 border-yellow-500/30 bg-gradient-to-br from-purple-950/30 via-background to-background">
        <CardHeader>
          <div className="flex items-center gap-3">
            <div className="p-3 rounded-lg bg-yellow-500/10 border border-yellow-500/30">
              <Coins className="w-6 h-6 text-yellow-500" />
            </div>
            <div>
              <CardTitle className="text-2xl text-yellow-500">Treasury Balance</CardTitle>
              <CardDescription>Live balance updates every 10 seconds</CardDescription>
            </div>
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          {isLoading ? (
            <div className="flex items-center justify-center py-12">
              <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-yellow-500" />
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-2">
                <div className="text-sm text-muted-foreground flex items-center gap-2">
                  <TrendingUp className="w-4 h-4" />
                  ETH Balance
                </div>
                <div className="text-4xl font-bold font-mono text-yellow-500" data-testid="text-balance-eth">
                  {balanceInEth.toFixed(4)} ETH
                </div>
              </div>
              <div className="space-y-2">
                <div className="text-sm text-muted-foreground flex items-center gap-2">
                  <Wallet className="w-4 h-4" />
                  Estimated Value
                </div>
                <div className="text-4xl font-bold font-mono text-yellow-400/80" data-testid="text-balance-usd">
                  ${balanceInUsd.toFixed(2)}
                </div>
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Donation Section */}
      <Card className="border-purple-500/30">
        <CardHeader>
          <div className="flex items-center gap-3">
            <div className="p-3 rounded-lg bg-purple-500/10 border border-purple-500/30">
              <Shield className="w-6 h-6 text-purple-500" />
            </div>
            <div>
              <CardTitle className="text-2xl">Support the Kingdom</CardTitle>
              <CardDescription>Send ETH donations to the royal treasury</CardDescription>
            </div>
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label className="text-sm font-medium">Treasury Wallet Address</Label>
            <div className="flex gap-2">
              <div className="flex-1 px-4 py-3 bg-muted rounded-lg border border-purple-500/20" data-testid="text-treasury-address">
                <code className="text-sm font-mono break-all text-purple-400">
                  {treasuryInfo?.address}
                </code>
              </div>
              <Button
                variant="outline"
                size="icon"
                onClick={handleCopyAddress}
                className="border-purple-500/30 hover:bg-purple-500/10"
                data-testid="button-copy-address"
              >
                <Copy className="w-4 h-4" />
              </Button>
            </div>
            <p className="text-xs text-muted-foreground">
              Send ETH from any wallet to this address. Transactions are public on the blockchain.
            </p>
          </div>

          <div className="p-4 bg-purple-500/5 rounded-lg border border-purple-500/20">
            <div className="flex items-start gap-3">
              <Crown className="w-5 h-5 text-purple-400 mt-0.5 flex-shrink-0" />
              <div className="text-sm text-muted-foreground">
                <strong className="text-foreground">Noble Patrons:</strong> All donations strengthen the realm 
                and fund player rewards, tournaments, and future expansions. Your generosity is recorded eternally 
                on the Ethereum blockchain.
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Admin Panel */}
      {isAdmin && (
        <Card className="border-red-500/30 bg-gradient-to-br from-red-950/20 via-background to-background">
          <CardHeader>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="p-3 rounded-lg bg-red-500/10 border border-red-500/30">
                  <Send className="w-6 h-6 text-red-500" />
                </div>
                <div>
                  <CardTitle className="text-2xl text-red-500">Admin Controls</CardTitle>
                  <CardDescription>Send rewards from the treasury</CardDescription>
                </div>
              </div>
              <Button
                variant={showAdminPanel ? "destructive" : "outline"}
                onClick={() => setShowAdminPanel(!showAdminPanel)}
                data-testid="button-toggle-admin"
              >
                {showAdminPanel ? "Hide" : "Show"} Panel
              </Button>
            </div>
          </CardHeader>
          {showAdminPanel && (
            <CardContent className="space-y-4">
              <Separator className="bg-red-500/20" />
              <div className="grid gap-4">
                <div className="space-y-2">
                  <Label htmlFor="recipient">Recipient Address</Label>
                  <Input
                    id="recipient"
                    placeholder="0x..."
                    value={recipient}
                    onChange={(e) => setRecipient(e.target.value)}
                    className="font-mono border-red-500/30 focus:border-red-500"
                    data-testid="input-recipient"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="amount">Amount (ETH)</Label>
                  <Input
                    id="amount"
                    type="number"
                    step="0.001"
                    placeholder="0.001"
                    value={amount}
                    onChange={(e) => setAmount(e.target.value)}
                    className="font-mono border-red-500/30 focus:border-red-500"
                    data-testid="input-amount"
                  />
                </div>
                <Button
                  onClick={handleSendFunds}
                  disabled={sendFundsMutation.isPending || !recipient || !amount}
                  className="w-full bg-red-600 hover:bg-red-700"
                  data-testid="button-send-reward"
                >
                  {sendFundsMutation.isPending ? (
                    <>
                      <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2" />
                      Sending...
                    </>
                  ) : (
                    <>
                      <Send className="w-4 h-4 mr-2" />
                      Send Reward
                    </>
                  )}
                </Button>
              </div>
              <div className="p-4 bg-yellow-500/10 rounded-lg border border-yellow-500/30">
                <p className="text-sm text-yellow-500">
                  ⚠️ <strong>Warning:</strong> Transactions are irreversible. Double-check the recipient 
                  address and amount before sending.
                </p>
              </div>
            </CardContent>
          )}
        </Card>
      )}
    </div>
  );
}
