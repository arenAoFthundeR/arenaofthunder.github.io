import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/hooks/use-toast";
import { Shield, Users, Scroll, Trophy, Plus, Trash2, Edit2, Save, Smartphone, Coins } from "lucide-react";
import { GyroscopeManager } from "@/components/GyroscopeManager";
import { useAdmin } from "@/lib/adminContext";
import { queryClient } from "@/lib/queryClient";
import type { WalletMemory, LorePiece, J3CreditBalance } from "@shared/schema";

export default function AdminDashboard() {
  const { token, isAdmin } = useAdmin();
  const { toast } = useToast();
  const [selectedWallet, setSelectedWallet] = useState<string>("");
  const [xpAdjustment, setXpAdjustment] = useState<number>(0);
  const [newLore, setNewLore] = useState({ title: "", text: "" });
  const [editingLore, setEditingLore] = useState<number | null>(null);
  const [editLoreData, setEditLoreData] = useState({ title: "", text: "" });
  const [selectedCreditWallet, setSelectedCreditWallet] = useState<string>("");
  const [creditAmount, setCreditAmount] = useState<number>(0);

  const { data: wallets } = useQuery<WalletMemory[]>({
    queryKey: ["/api/admin/wallets"],
    enabled: isAdmin && !!token,
    queryFn: async () => {
      const res = await fetch("/api/admin/wallets", {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (!res.ok) throw new Error("Failed to fetch wallets");
      return res.json();
    },
  });

  const { data: adminLore } = useQuery<LorePiece[]>({
    queryKey: ["/api/admin/lore"],
    enabled: isAdmin && !!token,
    queryFn: async () => {
      const res = await fetch("/api/admin/lore", {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (!res.ok) throw new Error("Failed to fetch lore");
      return res.json();
    },
  });

  const { data: j3Credits } = useQuery<J3CreditBalance[]>({
    queryKey: ["/api/admin/j3/credits"],
    enabled: isAdmin && !!token,
    queryFn: async () => {
      const res = await fetch("/api/admin/j3/credits", {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (!res.ok) throw new Error("Failed to fetch J3 credits");
      return res.json();
    },
  });

  const updateXpMutation = useMutation({
    mutationFn: async ({ wallet, adjustment }: { wallet: string; adjustment: number }) => {
      const res = await fetch("/api/admin/wallet/xp", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({ wallet, adjustment }),
      });
      if (!res.ok) throw new Error("Failed to update XP");
      return await res.json();
    },
    onSuccess: () => {
      toast({ title: "Success", description: "XP updated successfully" });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/wallets"] });
      queryClient.invalidateQueries({ queryKey: ["/api/leaderboard"] });
      setSelectedWallet("");
      setXpAdjustment(0);
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to update XP", variant: "destructive" });
    },
  });

  const createLoreMutation = useMutation({
    mutationFn: async (lore: { title: string; text: string }) => {
      const res = await fetch("/api/admin/lore", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify(lore),
      });
      if (!res.ok) throw new Error("Failed to create lore");
      return await res.json();
    },
    onSuccess: () => {
      toast({ title: "Success", description: "Lore created successfully" });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/lore"] });
      setNewLore({ title: "", text: "" });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to create lore", variant: "destructive" });
    },
  });

  const updateLoreMutation = useMutation({
    mutationFn: async ({ id, updates }: { id: number; updates: Partial<LorePiece> }) => {
      const res = await fetch(`/api/admin/lore/${id}`, {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify(updates),
      });
      if (!res.ok) throw new Error("Failed to update lore");
      return await res.json();
    },
    onSuccess: () => {
      toast({ title: "Success", description: "Lore updated successfully" });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/lore"] });
      setEditingLore(null);
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to update lore", variant: "destructive" });
    },
  });

  const deleteLoreMutation = useMutation({
    mutationFn: async (id: number) => {
      const res = await fetch(`/api/admin/lore/${id}`, {
        method: "DELETE",
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });
      if (!res.ok) throw new Error("Failed to delete lore");
      return await res.json();
    },
    onSuccess: () => {
      toast({ title: "Success", description: "Lore deleted successfully" });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/lore"] });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to delete lore", variant: "destructive" });
    },
  });

  const resetTournamentMutation = useMutation({
    mutationFn: async () => {
      const res = await fetch("/api/admin/tournament/reset", {
        method: "POST",
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });
      if (!res.ok) throw new Error("Failed to reset tournament");
      return await res.json();
    },
    onSuccess: () => {
      toast({ title: "Success", description: "Tournament reset successfully" });
      queryClient.invalidateQueries({ queryKey: ["/api/tournament/status"] });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to reset tournament", variant: "destructive" });
    },
  });

  const grantCreditsMutation = useMutation({
    mutationFn: async ({ wallet, amount }: { wallet: string; amount: number }) => {
      const res = await fetch("/api/admin/j3/grant", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({ wallet, amount }),
      });
      if (!res.ok) throw new Error("Failed to grant credits");
      return await res.json();
    },
    onSuccess: () => {
      toast({ title: "Success", description: "J3 Credits granted successfully" });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/j3/credits"] });
      setSelectedCreditWallet("");
      setCreditAmount(0);
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to grant credits", variant: "destructive" });
    },
  });

  if (!isAdmin) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Card>
          <CardHeader>
            <CardTitle>Access Denied</CardTitle>
            <CardDescription>You need admin credentials to access this page</CardDescription>
          </CardHeader>
        </Card>
      </div>
    );
  }

  return (
    <div className="container mx-auto p-6 space-y-6">
      <div className="flex items-center gap-3">
        <Shield className="h-8 w-8 text-primary" />
        <h1 className="text-3xl font-bold">Admin Dashboard</h1>
      </div>

      <Tabs defaultValue="users" className="space-y-6">
        <TabsList className="grid w-full grid-cols-5">
          <TabsTrigger value="users" data-testid="tab-users">
            <Users className="h-4 w-4 mr-2" />
            Users
          </TabsTrigger>
          <TabsTrigger value="lore" data-testid="tab-lore">
            <Scroll className="h-4 w-4 mr-2" />
            Lore
          </TabsTrigger>
          <TabsTrigger value="tournament" data-testid="tab-tournament">
            <Trophy className="h-4 w-4 mr-2" />
            Tournament
          </TabsTrigger>
          <TabsTrigger value="j3credits" data-testid="tab-j3credits">
            <Coins className="h-4 w-4 mr-2" />
            J3 Credits
          </TabsTrigger>
          <TabsTrigger value="gyroscope" data-testid="tab-gyroscope">
            <Smartphone className="h-4 w-4 mr-2" />
            Gyroscope
          </TabsTrigger>
        </TabsList>

        <TabsContent value="users" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>User Management</CardTitle>
              <CardDescription>View and manage player wallets and XP</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid gap-4">
                {wallets && wallets.length > 0 ? (
                  wallets.map((wallet) => {
                    const xp = (wallet.mintCount || 0) * 10 + (wallet.giftsSent || 0) * 5 + (wallet.giftsReceived || 0) * 5;
                    const level = Math.floor(xp / 100) + 1;
                    
                    return (
                      <div
                        key={wallet.wallet}
                        className="flex items-center justify-between p-4 rounded-lg border hover-elevate"
                        data-testid={`wallet-${wallet.wallet}`}
                      >
                        <div className="flex-1">
                          <code className="text-sm font-mono">{wallet.wallet}</code>
                          <div className="flex gap-2 mt-2">
                            <Badge variant="secondary" data-testid={`text-xp-${wallet.wallet}`}>Level {level} • {xp} XP</Badge>
                            <Badge variant="outline">Mints: {wallet.mintCount || 0}</Badge>
                            <Badge variant="outline">Gifts: {(wallet.giftsSent || 0) + (wallet.giftsReceived || 0)}</Badge>
                          </div>
                        </div>
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => setSelectedWallet(wallet.wallet)}
                          data-testid={`button-edit-${wallet.wallet}`}
                        >
                          <Edit2 className="h-4 w-4" />
                        </Button>
                      </div>
                    );
                  })
                ) : (
                  <p className="text-muted-foreground text-center py-8">No wallets found</p>
                )}
              </div>

              {selectedWallet && (
                <Card>
                  <CardHeader>
                    <CardTitle>Adjust XP for {selectedWallet}</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div>
                      <label className="text-sm font-medium">XP Adjustment</label>
                      <Input
                        type="number"
                        value={xpAdjustment}
                        onChange={(e) => setXpAdjustment(parseInt(e.target.value) || 0)}
                        placeholder="Enter XP adjustment (+/-)"
                        data-testid="input-xp-adjustment"
                      />
                      <p className="text-xs text-muted-foreground mt-1">
                        Use positive or negative numbers to adjust XP
                      </p>
                    </div>
                    <div className="flex gap-2">
                      <Button
                        onClick={() => updateXpMutation.mutate({ wallet: selectedWallet, adjustment: xpAdjustment })}
                        disabled={updateXpMutation.isPending}
                        data-testid="button-update-xp"
                      >
                        <Save className="h-4 w-4 mr-2" />
                        Update XP
                      </Button>
                      <Button variant="outline" onClick={() => setSelectedWallet("")}>
                        Cancel
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="lore" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Lore Management</CardTitle>
              <CardDescription>Create, edit, and delete lore pieces</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Create New Lore</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <label className="text-sm font-medium">Title</label>
                    <Input
                      value={newLore.title}
                      onChange={(e) => setNewLore({ ...newLore, title: e.target.value })}
                      placeholder="Lore title"
                      data-testid="input-lore-title"
                    />
                  </div>
                  <div>
                    <label className="text-sm font-medium">Text</label>
                    <Textarea
                      value={newLore.text}
                      onChange={(e) => setNewLore({ ...newLore, text: e.target.value })}
                      placeholder="Lore text"
                      rows={4}
                      data-testid="input-lore-text"
                    />
                  </div>
                  <Button
                    onClick={() => createLoreMutation.mutate(newLore)}
                    disabled={!newLore.title || !newLore.text || createLoreMutation.isPending}
                    data-testid="button-create-lore"
                  >
                    <Plus className="h-4 w-4 mr-2" />
                    Create Lore
                  </Button>
                </CardContent>
              </Card>

              <div className="grid gap-4">
                {adminLore && adminLore.length > 0 ? (
                  adminLore.map((lore) => (
                    <div key={lore.id} className="p-4 rounded-lg border" data-testid={`lore-${lore.id}`}>
                      {editingLore === lore.id ? (
                        <div className="space-y-3">
                          <Input
                            value={editLoreData.title}
                            onChange={(e) => setEditLoreData({ ...editLoreData, title: e.target.value })}
                            placeholder="Title"
                            data-testid={`input-edit-title-${lore.id}`}
                          />
                          <Textarea
                            value={editLoreData.text}
                            onChange={(e) => setEditLoreData({ ...editLoreData, text: e.target.value })}
                            placeholder="Text"
                            rows={3}
                            data-testid={`input-edit-text-${lore.id}`}
                          />
                          <div className="flex gap-2">
                            <Button
                              size="sm"
                              onClick={() => updateLoreMutation.mutate({ id: lore.id, updates: editLoreData })}
                              disabled={updateLoreMutation.isPending}
                              data-testid={`button-save-${lore.id}`}
                            >
                              <Save className="h-3 w-3 mr-1" />
                              Save
                            </Button>
                            <Button size="sm" variant="outline" onClick={() => setEditingLore(null)}>
                              Cancel
                            </Button>
                          </div>
                        </div>
                      ) : (
                        <div>
                          <div className="flex items-start justify-between">
                            <div className="flex-1">
                              <h3 className="font-semibold">{lore.title}</h3>
                              <p className="text-sm text-muted-foreground mt-1">{lore.text}</p>
                            </div>
                            <div className="flex gap-2">
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={() => {
                                  setEditingLore(lore.id);
                                  setEditLoreData({ title: lore.title, text: lore.text });
                                }}
                                data-testid={`button-edit-lore-${lore.id}`}
                              >
                                <Edit2 className="h-3 w-3" />
                              </Button>
                              <Button
                                size="sm"
                                variant="destructive"
                                onClick={() => deleteLoreMutation.mutate(lore.id)}
                                disabled={deleteLoreMutation.isPending}
                                data-testid={`button-delete-lore-${lore.id}`}
                              >
                                <Trash2 className="h-3 w-3" />
                              </Button>
                            </div>
                          </div>
                        </div>
                      )}
                    </div>
                  ))
                ) : (
                  <p className="text-muted-foreground text-center py-8">No lore pieces found</p>
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="tournament" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Tournament Management</CardTitle>
              <CardDescription>Manage tournament settings and participants</CardDescription>
            </CardHeader>
            <CardContent>
              <Button
                variant="destructive"
                onClick={() => resetTournamentMutation.mutate()}
                disabled={resetTournamentMutation.isPending}
                data-testid="button-reset-tournament"
              >
                <Trophy className="h-4 w-4 mr-2" />
                Reset Tournament
              </Button>
              <p className="text-sm text-muted-foreground mt-2">
                This will clear all participants and rounds from the current tournament
              </p>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="j3credits" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>J3 Credit Management</CardTitle>
              <CardDescription>View and manage J3 Credits for all wallets</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid gap-4">
                {j3Credits && j3Credits.length > 0 ? (
                  j3Credits.map((credit) => {
                    const tierColors: Record<string, string> = {
                      Novice: "bg-gray-500",
                      Apprentice: "bg-blue-500",
                      Adept: "bg-purple-500",
                      Master: "bg-amber-500",
                      Legend: "bg-red-500",
                    };
                    
                    return (
                      <div
                        key={credit.wallet}
                        className="flex items-center justify-between p-4 rounded-lg border hover-elevate"
                        data-testid={`credit-${credit.wallet}`}
                      >
                        <div className="flex-1">
                          <code className="text-sm font-mono">{credit.wallet}</code>
                          <div className="flex gap-2 mt-2">
                            <Badge className={tierColors[credit.tier] || "bg-gray-500"}>
                              {credit.tier}
                            </Badge>
                            <Badge variant="secondary" data-testid={`text-balance-${credit.wallet}`}>
                              {credit.balance} J3C
                            </Badge>
                            <Badge variant="outline">Earned: {credit.totalEarned}</Badge>
                            <Badge variant="outline">Spent: {credit.totalSpent}</Badge>
                            {credit.gracePeriodMessages > 0 && (
                              <Badge variant="default">+{credit.gracePeriodMessages} free</Badge>
                            )}
                          </div>
                        </div>
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => setSelectedCreditWallet(credit.wallet)}
                          data-testid={`button-grant-${credit.wallet}`}
                        >
                          <Coins className="h-4 w-4 mr-2" />
                          Grant
                        </Button>
                      </div>
                    );
                  })
                ) : (
                  <p className="text-muted-foreground text-center py-8">No credit balances found</p>
                )}
              </div>

              {selectedCreditWallet && (
                <Card>
                  <CardHeader>
                    <CardTitle>Grant Credits to {selectedCreditWallet.slice(0, 8)}...</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div>
                      <label className="text-sm font-medium">Credit Amount</label>
                      <Input
                        type="number"
                        value={creditAmount}
                        onChange={(e) => setCreditAmount(parseInt(e.target.value) || 0)}
                        placeholder="Enter amount to grant (+)"
                        data-testid="input-credit-amount"
                      />
                      <p className="text-xs text-muted-foreground mt-1">
                        Enter positive number to grant credits
                      </p>
                    </div>
                    <div className="flex gap-2">
                      <Button
                        onClick={() => grantCreditsMutation.mutate({ wallet: selectedCreditWallet, amount: creditAmount })}
                        disabled={grantCreditsMutation.isPending || creditAmount <= 0}
                        data-testid="button-submit-grant"
                      >
                        <Save className="h-4 w-4 mr-2" />
                        Grant Credits
                      </Button>
                      <Button variant="outline" onClick={() => setSelectedCreditWallet("")}>
                        Cancel
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="gyroscope" className="space-y-4">
          <GyroscopeManager />
        </TabsContent>
      </Tabs>
    </div>
  );
}
