import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useWallet } from "@/lib/walletContext";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Progress } from "@/components/ui/progress";
import { useToast } from "@/hooks/use-toast";
import type { Marble, DungeonRun } from "@shared/schema";
import {
  Sword,
  Sparkles,
  Trophy,
  Heart,
  Zap,
  Shield as ShieldIcon,
  Gauge,
  Skull,
  Flag,
  History,
} from "lucide-react";

export default function Dungeons() {
  const { wallet } = useWallet();
  const { toast } = useToast();
  const [selectedMarble, setSelectedMarble] = useState<number | null>(null);

  const { data: marbles = [], isLoading: marblesLoading } = useQuery({
    queryKey: ["/api/marbles/list", wallet],
    enabled: !!wallet,
    queryFn: async () => {
      if (!wallet) return [];
      const res = await apiRequest("POST", "/api/marbles/list", { wallet });
      return (await res.json()) as Marble[];
    },
  });

  const { data: activeRun, isLoading: runLoading } = useQuery({
    queryKey: ["/api/dungeons/active", wallet],
    enabled: !!wallet,
    queryFn: async () => {
      if (!wallet) return null;
      const res = await apiRequest("POST", "/api/dungeons/active", { wallet });
      return (await res.json()) as DungeonRun | null;
    },
  });

  const { data: history = [] } = useQuery({
    queryKey: ["/api/dungeons/history", wallet],
    enabled: !!wallet,
    queryFn: async () => {
      if (!wallet) return [];
      const res = await apiRequest("POST", "/api/dungeons/history", { wallet });
      return (await res.json()) as DungeonRun[];
    },
  });

  const startDungeonMutation = useMutation({
    mutationFn: async (marbleId: number) => {
      if (!wallet) throw new Error("Wallet not connected");
      const res = await apiRequest("POST", "/api/dungeons/start", { wallet, marbleId });
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/dungeons/active", wallet] });
      toast({
        title: "Dungeon Started!",
        description: "Your marble enters the storm dungeons",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to start dungeon",
        variant: "destructive",
      });
    },
  });

  const actionMutation = useMutation({
    mutationFn: async (action: "attack" | "defend" | "retreat") => {
      if (!wallet) throw new Error("Wallet not connected");
      if (!activeRun) throw new Error("No active dungeon run");
      const res = await apiRequest("POST", "/api/dungeons/action", { 
        wallet, 
        runId: activeRun.id, 
        action 
      });
      return await res.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ["/api/dungeons/active", wallet] });
      queryClient.invalidateQueries({ queryKey: ["/api/dungeons/history", wallet] });

      if (data.result === "victory") {
        toast({
          title: "Enemy Defeated!",
          description: `Advancing to floor ${data.run.currentFloor}`,
        });
      } else if (data.result === "defeat") {
        toast({
          title: "Defeated",
          description: "Your marble has fallen in battle",
          variant: "destructive",
        });
      } else if (data.result === "retreat") {
        toast({
          title: "Retreated",
          description: data.message,
        });
      }
    },
  });

  if (!wallet) {
    return (
      <div className="container mx-auto max-w-6xl p-4 space-y-6">
        <div className="flex items-center gap-3">
          <Sword className="h-8 w-8 text-primary" data-testid="icon-header" />
          <div>
            <h1 className="text-3xl font-bold bg-gradient-to-r from-primary to-cyan-400 bg-clip-text text-transparent" data-testid="text-title">
              Storm Dungeons
            </h1>
            <p className="text-muted-foreground" data-testid="text-subtitle">Test your marbles in battle</p>
          </div>
        </div>

        <Card>
          <CardHeader>
            <CardTitle data-testid="text-no-wallet-title">Wallet Required</CardTitle>
            <CardDescription data-testid="text-no-wallet-description">
              Connect your wallet to enter the dungeons
            </CardDescription>
          </CardHeader>
        </Card>
      </div>
    );
  }

  if (marblesLoading || runLoading) {
    return (
      <div className="container mx-auto max-w-6xl p-4 space-y-6">
        <Skeleton className="h-20 w-full" data-testid="skeleton-header" />
        <Skeleton className="h-64 w-full" data-testid="skeleton-content" />
      </div>
    );
  }

  if (activeRun && activeRun.isActive) {
    const marble = marbles.find((m) => m.id === activeRun.marbleId);
    const enemy = activeRun.currentEnemy;

    if (!marble || !enemy) {
      return <div>Error loading dungeon state</div>;
    }

    const marbleHealthPercent = (activeRun.marbleCurrentHealth / marble.health) * 100;
    const enemyHealthPercent = (enemy.currentHealth / enemy.health) * 100;

    return (
      <div className="container mx-auto max-w-4xl p-4 space-y-6">
        <div className="text-center">
          <h1 className="text-3xl font-bold bg-gradient-to-r from-primary to-cyan-400 bg-clip-text text-transparent" data-testid="text-dungeon-title">
            Floor {activeRun.currentFloor}
          </h1>
          <p className="text-muted-foreground" data-testid="text-dungeon-subtitle">XP Earned: {activeRun.experienceGained}</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {/* Player Marble */}
          <Card className="border-primary/50" data-testid="card-player">
            <CardHeader>
              <CardTitle className="flex items-center gap-2" data-testid="text-player-name">
                <Sparkles className="h-5 w-5" />
                {marble.name}
              </CardTitle>
              <CardDescription data-testid="text-player-rarity">{marble.rarity}</CardDescription>
            </CardHeader>
            <CardContent className="space-y-3">
              <div>
                <div className="flex justify-between text-sm mb-1">
                  <span data-testid="text-player-health">Health</span>
                  <span data-testid="text-player-health-value">
                    {activeRun.marbleCurrentHealth} / {marble.health}
                  </span>
                </div>
                <Progress value={marbleHealthPercent} className="bg-red-950" data-testid="progress-player-health" />
              </div>
              <div className="grid grid-cols-3 gap-2 text-sm">
                <div data-testid="stat-player-attack">
                  <Zap className="h-4 w-4 inline mr-1 text-orange-500" />
                  {marble.attack}
                </div>
                <div data-testid="stat-player-defense">
                  <ShieldIcon className="h-4 w-4 inline mr-1 text-blue-500" />
                  {marble.defense}
                </div>
                <div data-testid="stat-player-speed">
                  <Gauge className="h-4 w-4 inline mr-1 text-cyan-500" />
                  {marble.speed}
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Enemy */}
          <Card className="border-destructive/50" data-testid="card-enemy">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-destructive" data-testid="text-enemy-name">
                <Skull className="h-5 w-5" />
                {enemy.name}
              </CardTitle>
              <CardDescription data-testid="text-enemy-description">{enemy.description}</CardDescription>
            </CardHeader>
            <CardContent className="space-y-3">
              <div>
                <div className="flex justify-between text-sm mb-1">
                  <span data-testid="text-enemy-health">Health</span>
                  <span data-testid="text-enemy-health-value">
                    {enemy.currentHealth} / {enemy.health}
                  </span>
                </div>
                <Progress value={enemyHealthPercent} className="bg-red-950" data-testid="progress-enemy-health" />
              </div>
              <div className="grid grid-cols-3 gap-2 text-sm">
                <div data-testid="stat-enemy-attack">
                  <Zap className="h-4 w-4 inline mr-1 text-orange-500" />
                  {enemy.attack}
                </div>
                <div data-testid="stat-enemy-defense">
                  <ShieldIcon className="h-4 w-4 inline mr-1 text-blue-500" />
                  {enemy.defense}
                </div>
                <div data-testid="stat-enemy-speed">
                  <Gauge className="h-4 w-4 inline mr-1 text-cyan-500" />
                  {enemy.speed}
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <Card>
          <CardHeader>
            <CardTitle data-testid="text-actions-title">Battle Actions</CardTitle>
          </CardHeader>
          <CardContent className="flex gap-4">
            <Button
              onClick={() => actionMutation.mutate("attack")}
              disabled={actionMutation.isPending}
              className="flex-1"
              data-testid="button-attack"
            >
              <Sword className="h-4 w-4 mr-2" />
              Attack
            </Button>
            <Button
              onClick={() => actionMutation.mutate("defend")}
              disabled={actionMutation.isPending}
              variant="secondary"
              className="flex-1"
              data-testid="button-defend"
            >
              <ShieldIcon className="h-4 w-4 mr-2" />
              Defend
            </Button>
            <Button
              onClick={() => actionMutation.mutate("retreat")}
              disabled={actionMutation.isPending}
              variant="outline"
              className="flex-1"
              data-testid="button-retreat"
            >
              <Flag className="h-4 w-4 mr-2" />
              Retreat
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="container mx-auto max-w-6xl p-4 space-y-6">
      <div className="flex items-center gap-3">
        <Sword className="h-8 w-8 text-primary" data-testid="icon-dungeons" />
        <div>
          <h1 className="text-3xl font-bold bg-gradient-to-r from-primary to-cyan-400 bg-clip-text text-transparent" data-testid="text-dungeons-title">
            Storm Dungeons
          </h1>
          <p className="text-muted-foreground" data-testid="text-dungeons-subtitle">Choose a marble to begin your run</p>
        </div>
      </div>

      {marbles.length === 0 ? (
        <Card>
          <CardContent className="p-12 text-center">
            <Sparkles className="h-16 w-16 mx-auto mb-4 text-primary" data-testid="icon-no-marbles" />
            <h3 className="text-xl font-semibold mb-2" data-testid="text-no-marbles-title">No Marbles Available</h3>
            <p className="text-muted-foreground mb-4" data-testid="text-no-marbles-description">
              Create marbles first to enter the dungeons
            </p>
            <Button asChild data-testid="button-go-marbles">
              <a href="/marbles">Go to Marble Collection</a>
            </Button>
          </CardContent>
        </Card>
      ) : (
        <>
          <Card>
            <CardHeader>
              <CardTitle data-testid="text-select-title">Select Your Marble</CardTitle>
              <CardDescription data-testid="text-select-description">Choose wisely - battles are challenging!</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {marbles.map((marble) => (
                  <Card
                    key={marble.id}
                    className={`cursor-pointer hover-elevate ${
                      selectedMarble === marble.id ? "border-primary" : ""
                    }`}
                    onClick={() => setSelectedMarble(marble.id)}
                    data-testid={`marble-select-${marble.id}`}
                  >
                    <CardHeader>
                      <CardTitle className="text-base" data-testid={`marble-select-name-${marble.id}`}>{marble.name}</CardTitle>
                      <CardDescription data-testid={`marble-select-rarity-${marble.id}`}>{marble.rarity}</CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-2">
                      <div className="grid grid-cols-2 gap-2 text-sm">
                        <div data-testid={`marble-select-attack-${marble.id}`}>
                          <Zap className="h-3 w-3 inline mr-1" /> {marble.attack}
                        </div>
                        <div data-testid={`marble-select-defense-${marble.id}`}>
                          <ShieldIcon className="h-3 w-3 inline mr-1" /> {marble.defense}
                        </div>
                        <div data-testid={`marble-select-speed-${marble.id}`}>
                          <Gauge className="h-3 w-3 inline mr-1" /> {marble.speed}
                        </div>
                        <div data-testid={`marble-select-health-${marble.id}`}>
                          <Heart className="h-3 w-3 inline mr-1" /> {marble.health}
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>

              <div className="flex justify-end mt-4">
                <Button
                  onClick={() => selectedMarble && startDungeonMutation.mutate(selectedMarble)}
                  disabled={!selectedMarble || startDungeonMutation.isPending}
                  data-testid="button-start-dungeon"
                >
                  <Sword className="h-4 w-4 mr-2" />
                  Enter Dungeon
                </Button>
              </div>
            </CardContent>
          </Card>

          {history.length > 0 && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2" data-testid="text-history-title">
                  <History className="h-5 w-5" />
                  Dungeon History
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {history.slice(0, 5).map((run) => (
                    <div
                      key={run.id}
                      className="flex items-center justify-between p-3 rounded-md bg-card hover-elevate"
                      data-testid={`history-${run.id}`}
                    >
                      <div>
                        <p className="font-medium" data-testid={`history-floor-${run.id}`}>
                          Floor {run.maxFloorReached}
                        </p>
                        <p className="text-sm text-muted-foreground" data-testid={`history-xp-${run.id}`}>
                          +{run.experienceGained} XP
                        </p>
                      </div>
                      <Badge
                        variant={
                          run.status === "victory"
                            ? "default"
                            : run.status === "defeat"
                            ? "destructive"
                            : "secondary"
                        }
                        data-testid={`history-status-${run.id}`}
                      >
                        {run.status}
                      </Badge>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}
        </>
      )}
    </div>
  );
}
