import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useWallet } from "@/lib/walletContext";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import type { Marble, MarbleRarity } from "@shared/schema";
import { Sparkles, Zap, Shield, Gauge, Heart, Plus } from "lucide-react";

const rarityColors: Record<MarbleRarity, string> = {
  common: "bg-gray-500",
  uncommon: "bg-green-500",
  rare: "bg-blue-500",
  epic: "bg-purple-500",
  legendary: "bg-orange-500",
  mythic: "bg-pink-500",
};

export default function Marbles() {
  const { wallet } = useWallet();
  const { toast } = useToast();

  const { data: marbles = [], isLoading } = useQuery({
    queryKey: ["/api/marbles/list", wallet],
    enabled: !!wallet,
    queryFn: async () => {
      if (!wallet) return [];
      const res = await apiRequest("POST", "/api/marbles/list", { wallet });
      return (await res.json()) as Marble[];
    },
  });

  const createMarbleMutation = useMutation({
    mutationFn: async () => {
      if (!wallet) throw new Error("Wallet not connected");
      const res = await apiRequest("POST", "/api/marbles/create", { wallet });
      return await res.json();
    },
    onSuccess: (newMarble: Marble) => {
      queryClient.invalidateQueries({ queryKey: ["/api/marbles/list", wallet] });
      toast({
        title: "Marble Created!",
        description: `${newMarble.name} (${newMarble.rarity}) has been added to your collection`,
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to create marble. Try again later.",
        variant: "destructive",
      });
    },
  });

  if (!wallet) {
    return (
      <div className="container mx-auto max-w-6xl p-4 space-y-6">
        <div className="flex items-center gap-3">
          <Sparkles className="h-8 w-8 text-primary" data-testid="icon-header" />
          <div>
            <h1 className="text-3xl font-bold bg-gradient-to-r from-primary to-cyan-400 bg-clip-text text-transparent" data-testid="text-title">
              Marble Collection
            </h1>
            <p className="text-muted-foreground" data-testid="text-subtitle">Your battle-ready marble arsenal</p>
          </div>
        </div>

        <Card>
          <CardHeader>
            <CardTitle data-testid="text-no-wallet-title">Wallet Required</CardTitle>
            <CardDescription data-testid="text-no-wallet-description">
              Connect your wallet to view and create marbles
            </CardDescription>
          </CardHeader>
        </Card>
      </div>
    );
  }

  return (
    <div className="container mx-auto max-w-6xl p-4 space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <Sparkles className="h-8 w-8 text-primary" data-testid="icon-collection" />
          <div>
            <h1 className="text-3xl font-bold bg-gradient-to-r from-primary to-cyan-400 bg-clip-text text-transparent" data-testid="text-collection-title">
              Marble Collection
            </h1>
            <p className="text-muted-foreground" data-testid="text-collection-subtitle">
              {marbles.length} marble{marbles.length !== 1 ? "s" : ""} in your arsenal
            </p>
          </div>
        </div>

        <Button
          onClick={() => createMarbleMutation.mutate()}
          disabled={createMarbleMutation.isPending}
          data-testid="button-create-marble"
        >
          <Plus className="h-4 w-4 mr-2" />
          Create Marble
        </Button>
      </div>

      {isLoading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {Array.from({ length: 6 }).map((_, i) => (
            <Skeleton key={i} className="h-64" data-testid={`skeleton-marble-${i}`} />
          ))}
        </div>
      ) : marbles.length === 0 ? (
        <Card>
          <CardContent className="p-12 text-center">
            <Sparkles className="h-16 w-16 mx-auto mb-4 text-primary" data-testid="icon-empty" />
            <h3 className="text-xl font-semibold mb-2" data-testid="text-empty-title">No Marbles Yet</h3>
            <p className="text-muted-foreground mb-4" data-testid="text-empty-description">
              Click "Create Marble" to generate your first AI-powered battle marble
            </p>
            <Button
              onClick={() => createMarbleMutation.mutate()}
              disabled={createMarbleMutation.isPending}
              data-testid="button-create-first"
            >
              <Plus className="h-4 w-4 mr-2" />
              Create Your First Marble
            </Button>
          </CardContent>
        </Card>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {marbles.map((marble) => (
            <Card key={marble.id} className="hover-elevate" data-testid={`marble-${marble.id}`}>
              <CardHeader>
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <CardTitle className="flex items-center gap-2" data-testid={`marble-name-${marble.id}`}>
                      {marble.name}
                      {marble.isMinted && (
                        <Badge variant="default" className="bg-primary/20" data-testid={`badge-minted-${marble.id}`}>
                          NFT
                        </Badge>
                      )}
                    </CardTitle>
                    <CardDescription data-testid={`marble-description-${marble.id}`}>
                      {marble.description}
                    </CardDescription>
                  </div>
                  <Badge className={rarityColors[marble.rarity]} data-testid={`badge-rarity-${marble.id}`}>
                    {marble.rarity}
                  </Badge>
                </div>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="grid grid-cols-2 gap-3">
                  <div className="flex items-center gap-2">
                    <Zap className="h-4 w-4 text-orange-500" data-testid={`icon-attack-${marble.id}`} />
                    <div>
                      <p className="text-xs text-muted-foreground">Attack</p>
                      <p className="font-semibold" data-testid={`stat-attack-${marble.id}`}>{marble.attack}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <Shield className="h-4 w-4 text-blue-500" data-testid={`icon-defense-${marble.id}`} />
                    <div>
                      <p className="text-xs text-muted-foreground">Defense</p>
                      <p className="font-semibold" data-testid={`stat-defense-${marble.id}`}>{marble.defense}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <Gauge className="h-4 w-4 text-cyan-500" data-testid={`icon-speed-${marble.id}`} />
                    <div>
                      <p className="text-xs text-muted-foreground">Speed</p>
                      <p className="font-semibold" data-testid={`stat-speed-${marble.id}`}>{marble.speed}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <Heart className="h-4 w-4 text-red-500" data-testid={`icon-health-${marble.id}`} />
                    <div>
                      <p className="text-xs text-muted-foreground">Health</p>
                      <p className="font-semibold" data-testid={`stat-health-${marble.id}`}>{marble.health}</p>
                    </div>
                  </div>
                </div>

                {marble.isMinted && marble.tokenId && (
                  <div className="pt-3 border-t">
                    <p className="text-xs text-muted-foreground" data-testid={`token-id-${marble.id}`}>
                      Token ID: #{marble.tokenId}
                    </p>
                    {marble.txHash && (
                      <p className="text-xs text-muted-foreground truncate" data-testid={`tx-hash-${marble.id}`}>
                        Tx: {marble.txHash.substring(0, 10)}...{marble.txHash.substring(marble.txHash.length - 8)}
                      </p>
                    )}
                  </div>
                )}
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
