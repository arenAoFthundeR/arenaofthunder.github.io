import { useWallet } from "@/lib/walletContext";
import ActivityTimeline from "@/components/ActivityTimeline";

export default function Activity() {
  const { wallet } = useWallet();

  return (
    <div className="container mx-auto px-4 py-8 max-w-4xl">
      <div className="mb-6">
        <h1 className="text-3xl font-bold bg-gradient-to-r from-cyan-400 to-blue-500 bg-clip-text text-transparent">
          Activity Timeline
        </h1>
        <p className="text-muted-foreground mt-2">
          Track your journey through the Arena of Thunder
        </p>
      </div>
      
      <ActivityTimeline wallet={wallet} />
    </div>
  );
}
