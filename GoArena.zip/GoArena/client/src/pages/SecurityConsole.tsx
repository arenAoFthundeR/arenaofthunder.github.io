import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useWallet } from "@/lib/walletContext";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import type { SecurityEvent, SecurityEventType, SecuritySeverity } from "@shared/schema";
import { 
  Shield, 
  Wifi, 
  Usb, 
  Bluetooth, 
  HardDrive, 
  AlertTriangle, 
  Info,
  XCircle,
  Trash2,
  Download,
  Zap
} from "lucide-react";

export default function SecurityConsole() {
  const { wallet } = useWallet();
  const { toast } = useToast();
  const [filterType, setFilterType] = useState<SecurityEventType | "all">("all");
  const [filterSeverity, setFilterSeverity] = useState<SecuritySeverity | "all">("all");

  const { data: marbles = [], isLoading: marblesLoading } = useQuery({
    queryKey: ["/api/marbles/list", wallet],
    enabled: !!wallet,
    queryFn: async () => {
      if (!wallet) return [];
      const res = await apiRequest("POST", "/api/marbles/list", { wallet });
      return (await res.json()) as any[];
    },
  });

  const { data: events = [], isLoading: eventsLoading } = useQuery({
    queryKey: ["/api/security/events", wallet],
    enabled: !!wallet,
    queryFn: async () => {
      if (!wallet) return [];
      const res = await apiRequest("POST", "/api/security/events", { wallet });
      return (await res.json()) as SecurityEvent[];
    },
  });

  const createEventMutation = useMutation({
    mutationFn: async (type: SecurityEventType) => {
      if (!wallet) throw new Error("Wallet not connected");
      const res = await apiRequest("POST", "/api/security/create", {
        wallet,
        eventType: type,
        severity: "info",
        message: `Manual ${type.replace(/_/g, " ")} scan initiated`,
        details: { timestamp: Date.now(), manual: true },
      });
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/security/events", wallet] });
      toast({
        title: "Scan Complete",
        description: "Security scan logged successfully",
      });
    },
  });

  const clearEventsMutation = useMutation({
    mutationFn: async () => {
      if (!wallet) throw new Error("Wallet not connected");
      await apiRequest("POST", "/api/security/clear", { wallet });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/security/events", wallet] });
      toast({
        title: "Events Cleared",
        description: "All security events have been cleared",
      });
    },
  });

  const hasMintedMarbles = marbles.some((m: any) => m.isMinted);

  const filteredEvents = events.filter((event) => {
    if (filterType !== "all" && event.eventType !== filterType) return false;
    if (filterSeverity !== "all" && event.severity !== filterSeverity) return false;
    return true;
  });

  const exportToCSV = () => {
    const csv = [
      ["Timestamp", "Type", "Severity", "Message"].join(","),
      ...filteredEvents.map((e) =>
        [
          new Date(e.createdAt).toISOString(),
          e.eventType,
          e.severity,
          `"${e.message}"`,
        ].join(",")
      ),
    ].join("\n");

    const blob = new Blob([csv], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `security-events-${Date.now()}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const getSeverityIcon = (severity: SecuritySeverity) => {
    switch (severity) {
      case "critical":
        return <XCircle className="h-4 w-4 text-red-500" data-testid="icon-critical" />;
      case "warning":
        return <AlertTriangle className="h-4 w-4 text-yellow-500" data-testid="icon-warning" />;
      case "info":
        return <Info className="h-4 w-4 text-blue-500" data-testid="icon-info" />;
    }
  };

  const getTypeIcon = (type: SecurityEventType) => {
    switch (type) {
      case "bluetooth_scan":
        return <Bluetooth className="h-4 w-4" data-testid="icon-bluetooth" />;
      case "usb_detection":
        return <Usb className="h-4 w-4" data-testid="icon-usb" />;
      case "network_monitor":
        return <Wifi className="h-4 w-4" data-testid="icon-network" />;
      case "firmware_check":
        return <HardDrive className="h-4 w-4" data-testid="icon-firmware" />;
      default:
        return <Shield className="h-4 w-4" data-testid="icon-shield" />;
    }
  };

  if (!wallet) {
    return (
      <div className="container mx-auto max-w-6xl p-4 space-y-6">
        <div className="flex items-center gap-3">
          <Shield className="h-8 w-8 text-primary" data-testid="icon-header-shield" />
          <div>
            <h1 className="text-3xl font-bold bg-gradient-to-r from-primary to-cyan-400 bg-clip-text text-transparent" data-testid="text-title">
              Security Console
            </h1>
            <p className="text-muted-foreground" data-testid="text-subtitle">Connect wallet to access security monitoring</p>
          </div>
        </div>

        <Card>
          <CardHeader>
            <CardTitle data-testid="text-no-wallet-title">Wallet Required</CardTitle>
            <CardDescription data-testid="text-no-wallet-description">
              Connect your wallet to access the Security Console
            </CardDescription>
          </CardHeader>
        </Card>
      </div>
    );
  }

  if (marblesLoading) {
    return (
      <div className="container mx-auto max-w-6xl p-4 space-y-6">
        <Skeleton className="h-20 w-full" data-testid="skeleton-header" />
        <Skeleton className="h-64 w-full" data-testid="skeleton-content" />
      </div>
    );
  }

  if (!hasMintedMarbles) {
    return (
      <div className="container mx-auto max-w-6xl p-4 space-y-6">
        <div className="flex items-center gap-3">
          <Shield className="h-8 w-8 text-primary" data-testid="icon-locked-shield" />
          <div>
            <h1 className="text-3xl font-bold bg-gradient-to-r from-primary to-cyan-400 bg-clip-text text-transparent" data-testid="text-locked-title">
              Security Console
            </h1>
            <p className="text-muted-foreground" data-testid="text-locked-subtitle">NFT holder exclusive access</p>
          </div>
        </div>

        <Card className="border-primary/20">
          <CardHeader>
            <div className="flex items-center gap-2">
              <Zap className="h-5 w-5 text-primary" data-testid="icon-locked" />
              <CardTitle data-testid="text-locked-card-title">Access Restricted</CardTitle>
            </div>
            <CardDescription data-testid="text-locked-card-description">
              Mint at least one marble NFT to unlock the Security Console
            </CardDescription>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-muted-foreground mb-4" data-testid="text-locked-explanation">
              The Security Console is an exclusive feature for NFT holders. Visit your marble collection
              to mint your first NFT and gain access to advanced security monitoring.
            </p>
            <Button asChild data-testid="button-go-marbles">
              <a href="/marbles">Go to Marble Collection</a>
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="container mx-auto max-w-6xl p-4 space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <Shield className="h-8 w-8 text-primary" data-testid="icon-console-shield" />
          <div>
            <h1 className="text-3xl font-bold bg-gradient-to-r from-primary to-cyan-400 bg-clip-text text-transparent" data-testid="text-console-title">
              Security Console
            </h1>
            <p className="text-muted-foreground" data-testid="text-console-subtitle">
              Monitor and audit your Arena systems
            </p>
          </div>
        </div>
      </div>

      {/* Quick Actions */}
      <Card>
        <CardHeader>
          <CardTitle data-testid="text-actions-title">Quick Scans</CardTitle>
          <CardDescription data-testid="text-actions-description">Run manual security scans</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <Button
              variant="outline"
              onClick={() => createEventMutation.mutate("bluetooth_scan")}
              disabled={createEventMutation.isPending}
              data-testid="button-scan-bluetooth"
            >
              <Bluetooth className="h-4 w-4 mr-2" />
              Bluetooth
            </Button>
            <Button
              variant="outline"
              onClick={() => createEventMutation.mutate("usb_detection")}
              disabled={createEventMutation.isPending}
              data-testid="button-scan-usb"
            >
              <Usb className="h-4 w-4 mr-2" />
              USB
            </Button>
            <Button
              variant="outline"
              onClick={() => createEventMutation.mutate("network_monitor")}
              disabled={createEventMutation.isPending}
              data-testid="button-scan-network"
            >
              <Wifi className="h-4 w-4 mr-2" />
              Network
            </Button>
            <Button
              variant="outline"
              onClick={() => createEventMutation.mutate("firmware_check")}
              disabled={createEventMutation.isPending}
              data-testid="button-scan-firmware"
            >
              <HardDrive className="h-4 w-4 mr-2" />
              Firmware
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Event Log */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle data-testid="text-log-title">Security Event Log</CardTitle>
              <CardDescription data-testid="text-log-description">
                {filteredEvents.length} event{filteredEvents.length !== 1 ? "s" : ""}
              </CardDescription>
            </div>
            <div className="flex gap-2">
              <Button
                variant="outline"
                size="sm"
                onClick={exportToCSV}
                disabled={filteredEvents.length === 0}
                data-testid="button-export-csv"
              >
                <Download className="h-4 w-4 mr-2" />
                Export
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={() => clearEventsMutation.mutate()}
                disabled={events.length === 0 || clearEventsMutation.isPending}
                data-testid="button-clear-events"
              >
                <Trash2 className="h-4 w-4 mr-2" />
                Clear
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="all" className="w-full">
            <TabsList className="mb-4">
              <TabsTrigger value="all" onClick={() => setFilterType("all")} data-testid="tab-all">
                All
              </TabsTrigger>
              <TabsTrigger value="bluetooth" onClick={() => setFilterType("bluetooth_scan")} data-testid="tab-bluetooth">
                Bluetooth
              </TabsTrigger>
              <TabsTrigger value="usb" onClick={() => setFilterType("usb_detection")} data-testid="tab-usb">
                USB
              </TabsTrigger>
              <TabsTrigger value="network" onClick={() => setFilterType("network_monitor")} data-testid="tab-network">
                Network
              </TabsTrigger>
              <TabsTrigger value="firmware" onClick={() => setFilterType("firmware_check")} data-testid="tab-firmware">
                Firmware
              </TabsTrigger>
            </TabsList>

            <div className="space-y-2">
              {eventsLoading ? (
                Array.from({ length: 3 }).map((_, i) => (
                  <Skeleton key={i} className="h-16 w-full" data-testid={`skeleton-event-${i}`} />
                ))
              ) : filteredEvents.length === 0 ? (
                <div className="text-center py-8 text-muted-foreground" data-testid="text-no-events">
                  No security events logged yet. Run a scan to start monitoring.
                </div>
              ) : (
                filteredEvents.map((event) => (
                  <Card key={event.id} className="hover-elevate" data-testid={`event-${event.id}`}>
                    <CardContent className="p-4">
                      <div className="flex items-start justify-between gap-4">
                        <div className="flex items-start gap-3 flex-1">
                          <div className="mt-0.5">{getTypeIcon(event.eventType)}</div>
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center gap-2 mb-1">
                              <p className="font-medium" data-testid={`event-message-${event.id}`}>{event.message}</p>
                              <Badge variant={event.severity === "critical" ? "destructive" : "default"} data-testid={`badge-severity-${event.id}`}>
                                {event.severity}
                              </Badge>
                            </div>
                            <p className="text-xs text-muted-foreground" data-testid={`event-time-${event.id}`}>
                              {new Date(event.createdAt).toLocaleString()}
                            </p>
                          </div>
                        </div>
                        {getSeverityIcon(event.severity)}
                      </div>
                    </CardContent>
                  </Card>
                ))
              )}
            </div>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
}
