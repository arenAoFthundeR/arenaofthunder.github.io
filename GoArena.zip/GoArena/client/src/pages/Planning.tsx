import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";
import { FileText, Zap, Calendar, FileCheck, Loader2 } from "lucide-react";
import { useAdmin } from "@/lib/adminContext";
import { marked } from "marked";
import DOMPurify from "dompurify";

export default function Planning() {
  const [selectedDoc, setSelectedDoc] = useState("summary");
  const { token, isAdmin } = useAdmin();

  const docs = [
    {
      id: "summary",
      title: "Planning Summary",
      icon: FileCheck,
      description: "Executive overview of J3 Allowance planning",
      filename: "PLANNING_SUMMARY.md",
    },
    {
      id: "allowance",
      title: "J3 Allowance Plan",
      icon: Zap,
      description: "Complete J3SSICA3 credit system specification",
      filename: "J3SSICA3_ALLOWANCE_PLAN.md",
    },
    {
      id: "roadmap",
      title: "Arena Roadmap",
      icon: Calendar,
      description: "7-phase development roadmap",
      filename: "ARENA_ROADMAP.md",
    },
    {
      id: "articles",
      title: "Article Analysis",
      icon: FileText,
      description: "Architectural insights from research",
      filename: "ARTICLE_NOTES.md",
    },
  ];

  const selectedDocData = docs.find((d) => d.id === selectedDoc);

  return (
    <div className="min-h-screen bg-slate-950 pt-8 pb-24">
      <div className="max-w-7xl mx-auto px-6">
        <div className="mb-8">
          <h1 className="text-4xl font-display font-bold mb-2 bg-gradient-to-r from-cyan-400 to-blue-500 bg-clip-text text-transparent">
            Planning Documents
          </h1>
          <p className="text-slate-400 text-lg">
            Comprehensive planning for J3SSICA3 Allowance System and Arena development
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          <div className="lg:col-span-1">
            <Card className="bg-slate-900 border-cyan-500/20">
              <CardHeader>
                <CardTitle className="text-lg">Documents</CardTitle>
                <CardDescription>Select a planning document</CardDescription>
              </CardHeader>
              <CardContent className="space-y-2">
                {docs.map((doc) => {
                  const Icon = doc.icon;
                  return (
                    <button
                      key={doc.id}
                      onClick={() => setSelectedDoc(doc.id)}
                      className={`w-full text-left p-3 rounded-md transition-all hover-elevate ${
                        selectedDoc === doc.id
                          ? "bg-cyan-500/10 border border-cyan-500/30"
                          : "bg-slate-800/50 border border-transparent"
                      }`}
                      data-testid={`doc-select-${doc.id}`}
                    >
                      <div className="flex items-start gap-3">
                        <Icon className={`w-5 h-5 mt-0.5 ${selectedDoc === doc.id ? "text-cyan-400" : "text-slate-400"}`} />
                        <div className="flex-1 min-w-0">
                          <div className={`font-medium text-sm mb-1 ${selectedDoc === doc.id ? "text-cyan-300" : "text-white"}`}>
                            {doc.title}
                          </div>
                          <div className="text-xs text-slate-400 line-clamp-2">
                            {doc.description}
                          </div>
                        </div>
                      </div>
                    </button>
                  );
                })}
              </CardContent>
            </Card>
          </div>

          <div className="lg:col-span-3">
            <Card className="bg-slate-900 border-cyan-500/20">
              <CardHeader>
                <CardTitle>{selectedDocData?.title}</CardTitle>
                <CardDescription>{selectedDocData?.description}</CardDescription>
              </CardHeader>
              <CardContent>
                <ScrollArea className="h-[600px] w-full rounded-md border border-slate-800 bg-slate-950 p-4">
                  {selectedDocData && <DocumentViewer filename={selectedDocData.filename} token={token} />}
                </ScrollArea>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}

function DocumentViewer({ filename, token }: { filename: string; token?: string }) {
  const { data, isLoading, error } = useQuery<{ content: string }>({
    queryKey: ["/api/planning", filename],
    queryFn: async () => {
      const res = await fetch(`/api/planning/${filename}`, {
        headers: token ? { Authorization: `Bearer ${token}` } : {},
      });
      if (!res.ok) {
        if (res.status === 401) {
          throw new Error("Admin authentication required");
        }
        throw new Error(`Failed to load ${filename}`);
      }
      return res.json();
    },
    enabled: !!token, // Only fetch if authenticated
  });

  if (!token) {
    return (
      <div className="text-center py-12">
        <p className="text-slate-400 mb-2">Admin authentication required</p>
        <p className="text-sm text-slate-500">Please log in as admin to view planning documents</p>
      </div>
    );
  }

  if (isLoading) {
    return (
      <div className="flex items-center justify-center py-12">
        <Loader2 className="w-8 h-8 text-cyan-400 animate-spin" />
      </div>
    );
  }

  if (error) {
    return (
      <div className="text-center py-12">
        <p className="text-red-400 mb-2">Failed to load document</p>
        <p className="text-sm text-slate-400">{error instanceof Error ? error.message : "Unknown error"}</p>
      </div>
    );
  }

  // Parse and sanitize markdown
  const rawHtml = marked.parse(data?.content || "");
  const sanitizedHtml = DOMPurify.sanitize(rawHtml);

  return (
    <div 
      className="prose prose-invert prose-cyan max-w-none"
      dangerouslySetInnerHTML={{ __html: sanitizedHtml }}
    />
  );
}
