import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { 
  Zap, 
  Sparkles, 
  Crown, 
  Sword, 
  Shield, 
  Brain, 
  Code, 
  Gamepad2, 
  Rocket,
  Mail,
  ArrowRight,
  Github,
  Twitter,
  Twitch,
  Send
} from "lucide-react";

import stormBg from '@assets/stock_images/storm_clouds_lightni_0fd6b3a5.jpg';

export default function Home() {
  return (
    <div className="min-h-screen">
      {/* HERO SECTION - ELECTRIC STORM ENTRY */}
      <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
        {/* Storm Photo Background */}
        <div 
          className="absolute inset-0 bg-cover bg-center bg-no-repeat"
          style={{ backgroundImage: `url(${stormBg})` }}
        />
        
        {/* Dark gradient wash overlay for text readability */}
        <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/60 to-transparent" />
        
        {/* Electric particles effect */}
        <div className="absolute inset-0 opacity-30">
          <div className="absolute top-1/4 left-1/4 w-1 h-1 bg-cyan-400 rounded-full animate-pulse" />
          <div className="absolute top-1/3 right-1/3 w-1 h-1 bg-blue-400 rounded-full animate-pulse delay-100" />
          <div className="absolute bottom-1/4 right-1/4 w-1 h-1 bg-cyan-500 rounded-full animate-pulse delay-200" />
        </div>

        <div className="relative z-10 max-w-6xl mx-auto px-6 text-center">
          {/* Pretitle */}
          <div className="mb-6 flex items-center justify-center gap-3">
            <div className="h-px w-12 bg-gradient-to-r from-transparent to-cyan-500" />
            <p className="text-sm font-medium tracking-[0.3em] uppercase text-cyan-400/90">
              Game Designer • AI Tinkerer • Story Architect • Streamer
            </p>
            <div className="h-px w-12 bg-gradient-to-l from-transparent to-cyan-500" />
          </div>

          {/* Main headline with electric glow */}
          <h1 
            className="text-7xl md:text-8xl font-display font-extrabold tracking-tight mb-4 text-white"
            style={{
              textShadow: '0 0 30px rgba(56, 189, 248, 0.5), 0 0 60px rgba(6, 182, 212, 0.3)'
            }}
          >
            ALEXANDER CAMPBELL
          </h1>

          {/* thundergod subtitle */}
          <div className="mb-8">
            <h2 
              className="text-5xl md:text-6xl font-display font-bold bg-gradient-to-r from-blue-400 via-cyan-400 to-blue-500 bg-clip-text text-transparent"
              style={{
                textShadow: '0 0 40px rgba(6, 182, 212, 0.4)'
              }}
            >
              aka thundergod
            </h2>
          </div>

          {/* Tagline */}
          <p className="text-xl md:text-2xl text-slate-300 max-w-3xl mx-auto mb-12 leading-relaxed">
            I build worlds, systems, and stories that collide — from competitive games and AI characters 
            to longform fiction and experimental streams. <span className="text-cyan-400 font-semibold">Arena of Thunder</span> is my playground for all of it.
          </p>

          {/* CTAs */}
          <div className="flex flex-wrap items-center justify-center gap-4">
            <Button 
              asChild
              size="lg" 
              className="bg-gradient-to-r from-blue-600 to-cyan-500 text-white font-semibold px-8 shadow-lg shadow-cyan-500/30"
              data-testid="button-view-projects"
            >
              <a href="#projects">
                <Sparkles className="w-5 h-5 mr-2" />
                View My Projects
              </a>
            </Button>
            <Button 
              asChild
              size="lg" 
              variant="outline"
              className="border-2 border-cyan-400/60 text-cyan-400 font-semibold px-8 backdrop-blur-sm"
              data-testid="button-work-with-me"
            >
              <a href="#contact">
                Work With Me
                <ArrowRight className="w-5 h-5 ml-2" />
              </a>
            </Button>
          </div>

          {/* Scroll indicator */}
          <div className="absolute bottom-12 left-1/2 -translate-x-1/2 animate-bounce">
            <Zap className="w-6 h-6 text-cyan-400/60" />
          </div>
        </div>
      </section>

      {/* ABOUT SECTION */}
      <section id="about" className="py-24 bg-gradient-to-b from-slate-950 to-slate-900">
        <div className="max-w-7xl mx-auto px-6">
          <div className="text-center mb-16">
            <h2 className="text-5xl font-display font-bold mb-4 text-white">
              About Me
            </h2>
            <div className="h-1 w-24 bg-gradient-to-r from-blue-500 to-cyan-400 mx-auto rounded-full" />
          </div>

          <div className="max-w-4xl mx-auto">
            <Card className="bg-slate-900/50 border-2 border-slate-800 shadow-xl shadow-blue-900/20">
              <CardContent className="p-8 md:p-12">
                <div className="space-y-6 text-lg text-slate-300 leading-relaxed">
                  <p>
                    I'm Alexander <span className="text-cyan-400 font-semibold">"thundergod"</span> Campbell — a designer, writer, and builder obsessed with games, AI, and stories that bleed across mediums.
                  </p>
                  <p>
                    I've studied game design and interactive media, built prototypes in Unreal and on the web, and experimented with AI-driven characters that live inside my worlds.
                  </p>
                  <p className="border-l-4 border-cyan-500 pl-6 italic text-cyan-100">
                    My work lives under one umbrella: <span className="font-bold">Arena of Thunder</span> — a growing ecosystem of games, digital collectibles, AI personas, and narrative experiments. I want to create things that feel alive, that people can explore, play, and revisit over time.
                  </p>
                </div>

                {/* Quick tags */}
                <div className="flex flex-wrap gap-2 mt-8 pt-8 border-t border-slate-700">
                  <Badge className="bg-blue-500/20 border-blue-400/50 text-blue-300">
                    <Gamepad2 className="w-3 h-3 mr-1" />
                    Game Design
                  </Badge>
                  <Badge className="bg-cyan-500/20 border-cyan-400/50 text-cyan-300">
                    <Brain className="w-3 h-3 mr-1" />
                    AI Systems
                  </Badge>
                  <Badge className="bg-blue-500/20 border-blue-400/50 text-blue-300">
                    <Code className="w-3 h-3 mr-1" />
                    Web3 / Blockchain
                  </Badge>
                  <Badge className="bg-cyan-500/20 border-cyan-400/50 text-cyan-300">
                    <Sparkles className="w-3 h-3 mr-1" />
                    Narrative Design
                  </Badge>
                  <Badge className="bg-blue-500/20 border-blue-400/50 text-blue-300">
                    <Twitch className="w-3 h-3 mr-1" />
                    Content Creation
                  </Badge>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* FEATURED PROJECTS SECTION */}
      <section id="projects" className="py-24 bg-slate-900">
        <div className="max-w-7xl mx-auto px-6">
          <div className="text-center mb-16">
            <h2 className="text-5xl font-display font-bold mb-4 text-white">
              Featured Work
            </h2>
            <div className="h-1 w-24 bg-gradient-to-r from-blue-500 to-cyan-400 mx-auto rounded-full" />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {/* Arena of Thunder - Main Feature */}
            <Card 
              className="md:col-span-2 bg-gradient-to-br from-blue-950/40 to-slate-900/60 border-2 border-cyan-500/40 shadow-2xl shadow-cyan-900/30 hover-elevate"
              data-testid="card-project-arena"
            >
              <CardHeader>
                <div className="flex items-start justify-between gap-4">
                  <div className="flex-1">
                    <CardTitle className="text-3xl font-display font-bold mb-2 flex items-center gap-3">
                      <Zap className="w-8 h-8 text-cyan-400" />
                      Arena of Thunder — Prototype Hub
                    </CardTitle>
                    <Badge className="bg-green-500/20 border-green-400/50 text-green-300 mb-4">
                      <div className="w-2 h-2 bg-green-400 rounded-full mr-2 animate-pulse" />
                      Live Demo
                    </Badge>
                  </div>
                </div>
                <CardDescription className="text-base text-slate-300">
                  A modular universe where I connect my experiments: marble tournaments, interactive terminals, 
                  narrative modules, and future multiplayer experiences. Built as a living tree of "programs" 
                  that can grow over time.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div>
                    <p className="text-sm font-semibold text-cyan-400 uppercase tracking-wide mb-2">Focus Areas:</p>
                    <p className="text-slate-300">Worldbuilding • UX Structure • Game Systems • Web3 Integration</p>
                  </div>
                  
                  <div className="flex flex-wrap gap-2">
                    <Badge variant="secondary">React</Badge>
                    <Badge variant="secondary">TypeScript</Badge>
                    <Badge variant="secondary">ethers.js</Badge>
                    <Badge variant="secondary">OpenAI</Badge>
                    <Badge variant="secondary">Solidity</Badge>
                    <Badge variant="secondary">WebSockets</Badge>
                  </div>

                  {/* Demo buttons */}
                  <div className="grid grid-cols-1 sm:grid-cols-4 gap-3 pt-4">
                    <Button asChild variant="outline" className="w-full border-cyan-400/50 text-cyan-400" data-testid="link-demo-marbles">
                      <Link href="/marbles">
                        <Sparkles className="w-4 h-4 mr-2" />
                        Marbles
                      </Link>
                    </Button>
                    <Button asChild variant="outline" className="w-full border-cyan-400/50 text-cyan-400" data-testid="link-demo-dungeons">
                      <Link href="/dungeons">
                        <Sword className="w-4 h-4 mr-2" />
                        Dungeons
                      </Link>
                    </Button>
                    <Button asChild variant="outline" className="w-full border-cyan-400/50 text-cyan-400" data-testid="link-demo-treasury">
                      <Link href="/treasury">
                        <Crown className="w-4 h-4 mr-2" />
                        Treasury
                      </Link>
                    </Button>
                    <Button asChild variant="outline" className="w-full border-cyan-400/50 text-cyan-400" data-testid="link-demo-security">
                      <Link href="/security">
                        <Shield className="w-4 h-4 mr-2" />
                        Security
                      </Link>
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* J3SSICA3 AI Persona */}
            <Card className="bg-slate-900/50 border-2 border-slate-700 hover-elevate" data-testid="card-project-j3ssica3">
              <CardHeader>
                <CardTitle className="text-2xl font-display font-bold flex items-center gap-2">
                  <Brain className="w-6 h-6 text-purple-400" />
                  J3SSICA3 — AI Persona
                </CardTitle>
                <CardDescription className="text-slate-300">
                  A custom AI character designed to live inside my site, respond to visitors, and eventually 
                  connect to on-chain systems and interactive modules.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-sm font-semibold text-cyan-400 uppercase tracking-wide mb-2">Focus:</p>
                <p className="text-slate-300 mb-4">Conversational Design • Personality Systems • Technical Integration Planning</p>
                <div className="flex flex-wrap gap-2">
                  <Badge variant="secondary">OpenAI GPT-4</Badge>
                  <Badge variant="secondary">Context Awareness</Badge>
                  <Badge variant="secondary">Memory Systems</Badge>
                </div>
              </CardContent>
            </Card>

            {/* Machine Lullabies */}
            <Card className="bg-slate-900/50 border-2 border-slate-700 hover-elevate" data-testid="card-project-machine-lullabies">
              <CardHeader>
                <CardTitle className="text-2xl font-display font-bold flex items-center gap-2">
                  <Sparkles className="w-6 h-6 text-pink-400" />
                  Machine Lullabies — Story Experiments
                </CardTitle>
                <CardDescription className="text-slate-300">
                  A series of written and visual pieces exploring late-night conversations with AI, memory, 
                  and the feeling of existing between human and machine.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-sm font-semibold text-cyan-400 uppercase tracking-wide mb-2">Focus:</p>
                <p className="text-slate-300 mb-4">Narrative Design • Voice • Emotional Mood</p>
                <div className="flex flex-wrap gap-2">
                  <Badge variant="secondary">Creative Writing</Badge>
                  <Badge variant="secondary">AI Collaboration</Badge>
                  <Badge variant="secondary">Experimental Fiction</Badge>
                </div>
              </CardContent>
            </Card>

            {/* thundergod Streams */}
            <Card className="md:col-span-2 bg-slate-900/50 border-2 border-slate-700 hover-elevate" data-testid="card-project-streams">
              <CardHeader>
                <CardTitle className="text-2xl font-display font-bold flex items-center gap-2">
                  <Twitch className="w-6 h-6 text-purple-500" />
                  thundergod Streams — Competitive & Creative
                </CardTitle>
                <CardDescription className="text-slate-300">
                  Streams that blend high-intensity games with behind-the-scenes building: talking through design, 
                  strategy, and the business side of creative work.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-sm font-semibold text-cyan-400 uppercase tracking-wide mb-2">Focus:</p>
                <p className="text-slate-300 mb-4">Performance • Community Building • Content Strategy</p>
                <div className="flex flex-wrap gap-2">
                  <Badge variant="secondary">Overwatch</Badge>
                  <Badge variant="secondary">Game Design Discussion</Badge>
                  <Badge variant="secondary">Live Development</Badge>
                  <Badge variant="secondary">Audience Engagement</Badge>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* SKILLS SECTION */}
      <section id="skills" className="py-24 bg-gradient-to-b from-slate-900 to-slate-950 relative overflow-hidden">
        {/* Subtle electric particles background */}
        <div className="absolute inset-0 opacity-20">
          <div className="absolute top-1/4 left-1/4 w-1 h-1 bg-cyan-400 rounded-full animate-pulse" />
          <div className="absolute top-2/3 right-1/3 w-1 h-1 bg-blue-400 rounded-full animate-pulse" style={{ animationDelay: '0.5s' }} />
          <div className="absolute bottom-1/3 left-2/3 w-1 h-1 bg-cyan-500 rounded-full animate-pulse" style={{ animationDelay: '1s' }} />
        </div>

        <div className="max-w-7xl mx-auto px-6 relative z-10">
          <div className="text-center mb-16">
            <h2 className="text-5xl font-display font-bold mb-4 text-white">
              Skills & Focus
            </h2>
            <div className="h-1 w-24 bg-gradient-to-r from-blue-500 to-cyan-400 mx-auto rounded-full" />
            <p className="text-slate-400 mt-6 max-w-2xl mx-auto">
              A blend of design thinking, technical experimentation, and narrative craft
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {/* Game & Systems Design */}
            <Card className="bg-slate-900/50 border-2 border-slate-800 hover-elevate active-elevate-2 group transition-all duration-300" data-testid="card-skill-game-design">
              <CardHeader>
                <div className="w-12 h-12 rounded-lg bg-cyan-500/10 border border-cyan-500/30 flex items-center justify-center mb-4 group-hover:bg-cyan-500/20 transition-colors">
                  <Gamepad2 className="w-6 h-6 text-cyan-400" />
                </div>
                <CardTitle className="text-xl font-display">
                  Game & Systems Design
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-2 text-sm text-slate-300">
                <p>• Prototype design (Unreal / game systems)</p>
                <p>• Economy & progression ideas (RPGs, roguelites, competitive loops)</p>
                <p>• Moment-to-moment feel: feedback, flow, and player motivation</p>
              </CardContent>
            </Card>

            {/* AI & Web Experiments */}
            <Card className="bg-slate-900/50 border-2 border-slate-800 hover-elevate active-elevate-2 group transition-all duration-300" data-testid="card-skill-ai-web">
              <CardHeader>
                <div className="w-12 h-12 rounded-lg bg-purple-500/10 border border-purple-500/30 flex items-center justify-center mb-4 group-hover:bg-purple-500/20 transition-colors">
                  <Brain className="w-6 h-6 text-purple-400" />
                </div>
                <CardTitle className="text-xl font-display">
                  AI & Web Experiments
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-2 text-sm text-slate-300">
                <p>• Designing AI personas and behaviors</p>
                <p>• Integrating chatbots and tools into web experiences</p>
                <p>• Planning modular site architectures (GitHub Pages, "program branches")</p>
              </CardContent>
            </Card>

            {/* Worldbuilding & Writing */}
            <Card className="bg-slate-900/50 border-2 border-slate-800 hover-elevate active-elevate-2 group transition-all duration-300" data-testid="card-skill-worldbuilding">
              <CardHeader>
                <div className="w-12 h-12 rounded-lg bg-pink-500/10 border border-pink-500/30 flex items-center justify-center mb-4 group-hover:bg-pink-500/20 transition-colors">
                  <Sparkles className="w-6 h-6 text-pink-400" />
                </div>
                <CardTitle className="text-xl font-display">
                  Worldbuilding & Writing
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-2 text-sm text-slate-300">
                <p>• Longform narrative concepts & worlds</p>
                <p>• Character-driven stories across multiple formats</p>
                <p>• Tone, voice, and emotional through-lines</p>
              </CardContent>
            </Card>

            {/* Content & Streaming */}
            <Card className="bg-slate-900/50 border-2 border-slate-800 hover-elevate active-elevate-2 group transition-all duration-300" data-testid="card-skill-content">
              <CardHeader>
                <div className="w-12 h-12 rounded-lg bg-orange-500/10 border border-orange-500/30 flex items-center justify-center mb-4 group-hover:bg-orange-500/20 transition-colors">
                  <Rocket className="w-6 h-6 text-orange-400" />
                </div>
                <CardTitle className="text-xl font-display">
                  Content & Streaming
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-2 text-sm text-slate-300">
                <p>• Competitive game POV (Overwatch, mobile games, etc.)</p>
                <p>• Audience engagement and segment ideas</p>
                <p>• Concept pitches for school/brand collabs</p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* CONTACT SECTION */}
      <section id="contact" className="py-24 bg-gradient-to-br from-slate-950 via-blue-950/30 to-slate-950">
        <div className="max-w-7xl mx-auto px-6">
          <div className="text-center mb-16">
            <Zap className="w-16 h-16 text-cyan-400 mx-auto mb-6 animate-pulse" />
            <h2 className="text-5xl font-display font-bold mb-4 text-white">
              Let's Build Something
            </h2>
            <div className="h-1 w-24 bg-gradient-to-r from-blue-500 to-cyan-400 mx-auto rounded-full" />
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 max-w-6xl mx-auto">
            {/* Left: Contact Form */}
            <Card className="bg-slate-900/50 border-2 border-cyan-500/30 shadow-2xl shadow-cyan-900/20">
              <CardHeader>
                <CardTitle className="text-2xl font-display">Send a Message</CardTitle>
                <CardDescription className="text-slate-400">
                  Got a project idea, collaboration proposal, or just want to chat? Drop me a line.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <form className="space-y-4" onSubmit={(e) => e.preventDefault()}>
                  <div>
                    <Label htmlFor="contact-name" className="text-slate-300">Name</Label>
                    <Input 
                      id="contact-name" 
                      placeholder="Your name" 
                      className="bg-slate-800/50 border-slate-700 text-white mt-1"
                      data-testid="input-contact-name"
                    />
                  </div>
                  <div>
                    <Label htmlFor="contact-email" className="text-slate-300">Email</Label>
                    <Input 
                      id="contact-email" 
                      type="email" 
                      placeholder="your.email@example.com" 
                      className="bg-slate-800/50 border-slate-700 text-white mt-1"
                      data-testid="input-contact-email"
                    />
                  </div>
                  <div>
                    <Label htmlFor="contact-message" className="text-slate-300">Message</Label>
                    <textarea 
                      id="contact-message"
                      rows={5}
                      placeholder="Tell me about your idea..."
                      className="w-full bg-slate-800/50 border-2 border-slate-700 rounded-md p-3 text-white mt-1 resize-none focus:outline-none focus:ring-2 focus:ring-cyan-500"
                      data-testid="input-contact-message"
                    />
                  </div>
                  <Button 
                    type="submit" 
                    className="w-full bg-gradient-to-r from-blue-600 to-cyan-500 text-white font-semibold shadow-lg shadow-cyan-500/30"
                    data-testid="button-send-message"
                  >
                    <Send className="w-4 h-4 mr-2" />
                    Send Message
                  </Button>
                  <p className="text-xs text-slate-500 text-center">
                    This form is currently for display purposes
                  </p>
                </form>
              </CardContent>
            </Card>

            {/* Right: Contact Info & Social */}
            <div className="space-y-6">
              <Card className="bg-slate-900/50 border-2 border-slate-800">
                <CardHeader>
                  <CardTitle className="text-xl font-display">I'm Open To</CardTitle>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-3 text-slate-300">
                    <li className="flex items-start gap-3">
                      <ArrowRight className="w-5 h-5 text-cyan-400 mt-0.5 flex-shrink-0" />
                      <span>Game / prototype collaboration</span>
                    </li>
                    <li className="flex items-start gap-3">
                      <ArrowRight className="w-5 h-5 text-cyan-400 mt-0.5 flex-shrink-0" />
                      <span>AI-driven character or narrative experiments</span>
                    </li>
                    <li className="flex items-start gap-3">
                      <ArrowRight className="w-5 h-5 text-cyan-400 mt-0.5 flex-shrink-0" />
                      <span>Streaming, podcast, and content segments</span>
                    </li>
                    <li className="flex items-start gap-3">
                      <ArrowRight className="w-5 h-5 text-cyan-400 mt-0.5 flex-shrink-0" />
                      <span>Creative consulting around games, stories, and audience engagement</span>
                    </li>
                  </ul>
                </CardContent>
              </Card>

              <Card className="bg-slate-900/50 border-2 border-slate-800">
                <CardHeader>
                  <CardTitle className="text-xl font-display">Direct Contact</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <Button 
                    asChild
                    size="lg" 
                    className="w-full bg-gradient-to-r from-blue-600 to-cyan-500 text-white font-semibold shadow-lg shadow-cyan-500/30"
                    data-testid="button-email-direct"
                  >
                    <a href="mailto:your-email@example.com">
                      <Mail className="w-5 h-5 mr-2" />
                      your-email@example.com
                    </a>
                  </Button>
                  <div>
                    <p className="text-sm text-slate-400 mb-3 text-center">Or connect on social platforms:</p>
                    <div className="flex gap-3 justify-center">
                      <Button asChild variant="outline" size="icon" className="border-slate-600 hover:border-cyan-500" data-testid="button-github-social">
                        <a href="https://github.com" target="_blank" rel="noopener noreferrer">
                          <Github className="w-5 h-5" />
                        </a>
                      </Button>
                      <Button asChild variant="outline" size="icon" className="border-slate-600 hover:border-cyan-500" data-testid="button-twitter-social">
                        <a href="https://twitter.com" target="_blank" rel="noopener noreferrer">
                          <Twitter className="w-5 h-5" />
                        </a>
                      </Button>
                      <Button asChild variant="outline" size="icon" className="border-slate-600 hover:border-cyan-500" data-testid="button-twitch-social">
                        <a href="https://twitch.tv" target="_blank" rel="noopener noreferrer">
                          <Twitch className="w-5 h-5" />
                        </a>
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <p className="text-sm text-slate-500 text-center px-4">
                Feel free to reach out through whatever channel works best for you
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* FOOTER */}
      <footer className="bg-slate-950 border-t border-cyan-500/20 py-8">
        <div className="max-w-7xl mx-auto px-6 text-center">
          <div className="flex items-center justify-center gap-2 mb-4">
            <Zap className="w-5 h-5 text-cyan-400" />
            <p className="text-slate-400 font-medium">
              Alexander "thundergod" Campbell
            </p>
          </div>
          <p className="text-sm text-slate-500">
            Portfolio + Arena of Thunder © 2025 • Powered by Storm Energy ⚡
          </p>
        </div>
      </footer>
    </div>
  );
}
