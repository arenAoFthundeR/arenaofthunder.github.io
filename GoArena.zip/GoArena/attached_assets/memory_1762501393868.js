import { Router } from "express";
import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const memoryPath = path.join(__dirname, "..", "data", "memory.json");

function getMemoryStore() {
  try {
    if (!fs.existsSync(memoryPath)) {
      fs.mkdirSync(path.dirname(memoryPath), { recursive: true });
      fs.writeFileSync(memoryPath, JSON.stringify({ wallets: {} }, null, 2), "utf8");
    }
    return JSON.parse(fs.readFileSync(memoryPath, "utf8") || '{"wallets":{}}');
  } catch (err) {
    console.error("[MEMORY] Failed to read memory store:", err);
    return { wallets: {} };
  }
}

function saveMemoryStore(store) {
  fs.writeFileSync(memoryPath, JSON.stringify(store, null, 2), "utf8");
}

const router = Router();

router.post("/get", (req, res) => {
  const { wallet } = req.body || {};
  if (!wallet || typeof wallet !== "string") {
    return res.status(400).json({ error: "wallet must be string" });
  }
  const key = wallet.toLowerCase();
  const store = getMemoryStore();
  const data = store.wallets[key] ?? {};
  res.json(data);
});

router.post("/set", (req, res) => {
  const { wallet, changes } = req.body || {};
  if (!wallet || typeof wallet !== "string") {
    return res.status(400).json({ error: "wallet must be string" });
  }
  if (!changes || typeof changes !== "object") {
    return res.status(400).json({ error: "changes must be object" });
  }
  const key = wallet.toLowerCase();
  const store = getMemoryStore();
  const now = new Date().toISOString();
  const current = store.wallets[key] ?? {
    wallet,
    mintCount: 0,
    giftCount: 0,
    seenLoreIds: [],
    firstSeen: now,
    lastSeen: now,
  };
  Object.entries(changes).forEach(([field, value]) => {
    if (Array.isArray(value)) {
      current[field] = Array.from(new Set(value));
    } else {
      current[field] = value;
    }
  });
  current.lastSeen = now;
  store.wallets[key] = current;
  saveMemoryStore(store);
  res.json(current);
});

export default router;
