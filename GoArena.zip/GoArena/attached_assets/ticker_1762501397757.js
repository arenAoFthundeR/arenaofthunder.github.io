// assets/js/ticker.js
document.addEventListener("DOMContentLoaded", () => {
  const el = document.getElementById("ticker-bar");
  if (!el) {
    console.warn("[Ticker] #ticker-bar not found");
    return;
  }
  let val = 50000;
  function animateTicker() {
    val += Math.floor(Math.random() * 100 - 50);
    el.textContent = `Arena Treasury: $${val.toLocaleString()}`;
    setTimeout(animateTicker, 2500);
  }
  animateTicker();
});
