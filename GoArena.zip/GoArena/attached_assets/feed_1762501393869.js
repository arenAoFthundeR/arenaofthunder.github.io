// server/services/feed.js
export async function sendDiscordEvent(event) {
  const hookUrl = process.env.DISCORD_WEBHOOK_URL;
  if (!hookUrl) return;
  try {
    await fetch(hookUrl, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        content: `[Storm Feed] ${event.type}: ${event.text}`,
      }),
    });
  } catch (err) {
    console.error("[FEED] Failed to send Discord event:", err);
  }
}
