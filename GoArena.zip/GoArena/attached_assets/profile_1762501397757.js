// assets/js/profile.js

const API_BASE = window.API_BASE ?? "";

async function apiJson(path, options = {}) {
  const res = await fetch(`${API_BASE}${path}`, {
    headers: { "Content-Type": "application/json" },
    ...options,
  });
  if (!res.ok) {
    const txt = await res.text();
    throw new Error(`[Profile] ${path} → HTTP ${res.status}: ${txt || "no body"}`);
  }
  return res.json();
}

async function initPlayerProfile(walletAddress) {
  const walletEl = document.getElementById("profile-wallet");
  const levelEl = document.getElementById("profile-level");
  const xpEl = document.getElementById("profile-xp");
  const rankEl = document.getElementById("profile-rank");
  const badgesEl = document.getElementById("profile-badges");
  const loreProgressEl = document.getElementById("profile-lore-progress");
  const loreSnippetsEl = document.getElementById("profile-lore-snippets");
  const tourneyStatusEl = document.getElementById("profile-tournament-status");
  const tourneyRoundsEl = document.getElementById("profile-tournament-rounds");

  if (
    !walletEl || !levelEl || !xpEl || !rankEl ||
    !badgesEl || !loreProgressEl || !loreSnippetsEl ||
    !tourneyStatusEl || !tourneyRoundsEl
  ) {
    console.warn("[Profile] Missing profile DOM nodes, skipping init");
    return;
  }

  if (!walletAddress) {
    walletEl.textContent = "Not connected";
    return;
  }

  walletEl.textContent = walletAddress;

  try {
    const [xpData, leaderboard, loreList, tournament] = await Promise.all([
      apiJson("/api/xp/get", {
        method: "POST",
        body: JSON.stringify({ wallet: walletAddress }),
      }),
      apiJson("/api/leaderboard"),
      apiJson("/api/lore/list", {
        method: "POST",
        body: JSON.stringify({ wallet: walletAddress }),
      }),
      apiJson("/api/tournament/status"),
    ]);

    xpEl.textContent = `XP – ${xpData.xp}`;
    levelEl.textContent = `Level – ${xpData.level}`;
    badgesEl.innerHTML = (xpData.badges || []).map((b) =>
      `<span class="badge">${b}</span>`).join("");

    let rank = "?";
    if (Array.isArray(leaderboard)) {
      const idx = leaderboard.findIndex(
        (row) => row.wallet?.toLowerCase() === walletAddress.toLowerCase()
      );
      if (idx !== -1) {
        rank = `#${idx + 1} of ${leaderboard.length}`;
      } else if (leaderboard.length > 0) {
        rank = `Unranked (top ${leaderboard.length})`;
      }
    }
    rankEl.textContent = `Rank – ${rank}`;

    const totalLore = Array.isArray(loreList) ? loreList.length : 0;
    const unlocked = Array.isArray(loreList)
      ? loreList.filter((l) => l.unlocked).length : 0;

    loreProgressEl.textContent = `${unlocked} / ${totalLore} lore unlocked`;

    loreSnippetsEl.innerHTML = (loreList || [])
      .filter((l) => l.unlocked)
      .slice(0, 3)
      .map((l) =>
        `<div class="lore-snippet">
          <h4>${l.title}</h4>
          <p>${l.text.length > 160 ? l.text.slice(0, 157) + "..." : l.text}</p>
        </div>`
      ).join("");

    if (unlocked === 0) {
      loreSnippetsEl.innerHTML =
        `<p class="muted">No lore unlocked yet. Mint or play to reveal the first fragment.</p>`;
    }

    let joined = false;
    let roundsForWallet = [];
    if (tournament && Array.isArray(tournament.participants)) {
      joined = tournament.participants.includes(walletAddress);
    }
    if (tournament && Array.isArray(tournament.rounds)) {
      roundsForWallet = tournament.rounds.filter(
        (r) => r.wallet === walletAddress
      );
    }

    tourneyStatusEl.textContent = joined ? "Joined" : "Not joined";
    if (roundsForWallet.length > 0) {
      tourneyRoundsEl.innerHTML = roundsForWallet
        .map((r) =>
          `<div class="round-row">Round ${r.round} – ${new Date(r.time).toLocaleString()}</div>`
        ).join("");
    } else {
      tourneyRoundsEl.innerHTML = `<p class="muted">No rounds played yet.</p>`;
    }
  } catch (err) {
    console.error("[Profile] Failed to load profile:", err);
    xpEl.textContent = "XP – error";
    levelEl.textContent = "Level – error";
    rankEl.textContent = "Rank – error";
  }
}

window.initPlayerProfile = initPlayerProfile;
