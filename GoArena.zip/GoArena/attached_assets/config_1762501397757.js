// assets/js/config.js
(function () {
  const FRONTEND_ORIGIN = window.location.origin;

  const PROD_FRONTEND = "https://arenaofthunder.github.io"; // adjust if needed
  const PROD_API      = "https://your-backend-url.example.com"; // Replit backend URL

  let apiBase = "";

  if (
    FRONTEND_ORIGIN === "http://localhost:5173" ||
    FRONTEND_ORIGIN === "http://localhost:3000" ||
    FRONTEND_ORIGIN === "http://localhost:4173"
  ) {
    apiBase = "http://localhost:4000";
  } else if (FRONTEND_ORIGIN === PROD_FRONTEND) {
    apiBase = PROD_API;
  } else {
    apiBase = "";
  }

  window.API_BASE = apiBase;
  console.log("[Config] API_BASE =", window.API_BASE);
})();
