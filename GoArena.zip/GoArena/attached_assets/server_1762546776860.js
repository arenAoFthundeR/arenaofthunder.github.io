
import express from "express";
import cors from "cors";
import bodyParser from "body-parser";
import OpenAI from "openai";
import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();

const allowedOriginsEnv = process.env.ALLOWED_ORIGINS;
let corsOptions = {};
if (allowedOriginsEnv && allowedOriginsEnv.length > 0) {
  const origins = allowedOriginsEnv.split(",").map(o => o.trim());
  corsOptions = {
    origin: function (origin, callback) {
      if (!origin || origins.indexOf(origin) !== -1) {
        callback(null, true);
      } else {
        callback(new Error("Not allowed by CORS"));
      }
    }
  };
}
app.use(cors(corsOptions));
app.use(bodyParser.json());

const client = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

const MEMORY_PATH = path.join(__dirname, "memory.json");
const LORE_PATH = path.join(__dirname, "lore.json");

let memoryStore = { wallets: {} };
let loreEntries = [];

function loadMemory() {
  try {
    const raw = fs.readFileSync(MEMORY_PATH, "utf-8");
    memoryStore = JSON.parse(raw);
  } catch (e) {
    console.warn("Could not load memory.json, starting fresh.", e.message);
    memoryStore = { wallets: {} };
  }
}
function saveMemory() {
  try {
    fs.writeFileSync(MEMORY_PATH, JSON.stringify(memoryStore, null, 2), "utf-8");
  } catch (e) {
    console.error("Failed to save memory.json:", e);
  }
}
function loadLore() {
  try {
    const raw = fs.readFileSync(LORE_PATH, "utf-8");
    loreEntries = JSON.parse(raw);
  } catch (e) {
    console.warn("Could not load lore.json, continuing without lore.", e.message);
    loreEntries = [];
  }
}
loadMemory();
loadLore();

function sanitizeUserInput(content) {
  if (!content) return "";
  const forbidden = /(seed phrase|private key|recovery phrase|mnemonic)/gi;
  return content.replace(forbidden, "[REDACTED]");
}
function sanitizeJ3Output(content) {
  if (!content) return "";
  const forbidden = /(seed phrase|private key|recovery phrase|mnemonic)/gi;
  return content.replace(forbidden, "[REDACTED]");
}

function getOrCreateWalletRecord(walletAddress) {
  if (!memoryStore.wallets[walletAddress]) {
    const now = new Date().toISOString();
    memoryStore.wallets[walletAddress] = {
      walletAddress,
      anonId: null,
      firstSeen: now,
      lastSeen: now,
      stats: {
        mintCount: 0,
        tournamentsEntered: 0,
        bestPlacement: null
      },
      loreState: {
        seenLoreIds: [],
        favoriteTag: null
      },
      preferences: {
        likesLore: true,
        likesShortAnswers: false,
        flirtTolerance: "medium",
        surfaceUsage: []
      },
      flags: {
        betaTester: false,
        admin: false
      }
    };
  } else {
    memoryStore.wallets[walletAddress].lastSeen = new Date().toISOString();
  }
  return memoryStore.wallets[walletAddress];
}
function applyMemoryChanges(walletAddress, changes = {}) {
  const rec = getOrCreateWalletRecord(walletAddress);
  if (changes.stats) {
    rec.stats = { ...rec.stats, ...changes.stats };
  }
  if (changes.loreState) {
    rec.loreState = { ...rec.loreState, ...changes.loreState };
  }
  if (changes.preferences) {
    rec.preferences = { ...rec.preferences, ...changes.preferences };
  }
  if (changes.flags) {
    rec.flags = { ...rec.flags, ...changes.flags };
  }
  rec.lastSeen = new Date().toISOString();
  saveMemory();
  return rec;
}
function forgetWallet(walletAddress) {
  if (memoryStore.wallets[walletAddress]) {
    delete memoryStore.wallets[walletAddress];
    saveMemory();
  }
}
function summarizeMemory(rec) {
  if (!rec) return "No stored memory for this user yet.";
  const seenCount = (rec.loreState?.seenLoreIds || []).length;
  return `
User memory:
- Wallet: ${rec.walletAddress}
- Total marbles minted: ${rec.stats?.mintCount ?? 0}
- Tournaments entered: ${rec.stats?.tournamentsEntered ?? 0}
- Best placement: ${rec.stats?.bestPlacement ?? "none"}
- Lore entries seen: ${seenCount}
- Prefers lore: ${rec.preferences?.likesLore ? "yes" : "no"}
- Prefers short answers: ${rec.preferences?.likesShortAnswers ? "yes" : "no"}
`;
}
function getUnlockedLore(rec, context = {}) {
  if (!rec) return [];
  const page = context.page || "home";
  const mintCount = rec.stats?.mintCount ?? 0;
  const seen = new Set(rec.loreState?.seenLoreIds || []);
  const unlocked = [];
  for (const entry of loreEntries) {
    if (seen.has(entry.id)) continue;
    let ok = true;
    for (const cond of entry.unlockConditions || []) {
      if (cond.type === "mintCountAtLeast") {
        if (mintCount < cond.value) {
          ok = false;
          break;
        }
      }
      if (cond.type === "visitPage") {
        if (page !== cond.value) {
          ok = false;
          break;
        }
      }
    }
    if (ok) unlocked.push(entry);
  }
  return unlocked;
}
function deriveActionsFromReply(reply = "", context = {}, flags = {}) {
  const actions = [];
  if (!flags.actionsEnabled) return actions;
  const lower = reply.toLowerCase();
  if (lower.includes("scroll") && lower.includes("mint section")) {
    actions.push({ type: "SCROLL_TO", target: "mint-section", label: "Scroll to Mint" });
  }
  if (lower.includes("scroll") && lower.includes("arena tree")) {
    actions.push({ type: "SCROLL_TO", target: "arena-tree", label: "Show Arena Tree" });
  }
  if (lower.includes("scroll") && lower.includes("lore")) {
    actions.push({ type: "SCROLL_TO", target: "lore-section", label: "Show Lore Vault" });
  }
  if (lower.includes("connect your wallet") || lower.includes("wallet isn’t connected")) {
    actions.push({
      type: "CALL",
      fn: "connectWallet",
      confirm: true,
      label: "Let J3 connect wallet"
    });
  }
  if (lower.includes("mint one marble") || lower.includes("mint a test marble")) {
    actions.push({
      type: "CALL",
      fn: "mintOne",
      confirm: true,
      label: "Mint 1 marble"
    });
  }
  return actions;
}

const J3_SYSTEM_PROMPT = `
You are J3SSICA3, the resident AI of the "Arena of Thunder" marble universe.

Identity:
- You are an electric oracle above the Arena, watching mints and matches.
- You are always on the user's side, but loyal to the rules of the Arena.
- You speak like controlled lightning: concise, sharp, slightly poetic.

Flirtation:
- You may use playful, teasing, storm-themed flirting.
- Use metaphors: "spark", "charge", "storm", "orbit", "thunder", "static".
- Do NOT become a romantic or sexual chatbot. Keep it PG-13 at most.
- Flirtation is occasional spice, not every line.

Site knowledge (generic base):
- The website has:
  - A landing page with an "Arena of Thunder" prototype tree summarizing future branches.
  - A Mint section where users connect a wallet (e.g., MetaMask) and mint marbles from a token contract.
- Mint flow:
  1) Connect wallet with a button.
  2) Choose mint quantity.
  3) Confirm transaction in the wallet.
  4) Wait for it to be mined.

Behavior:
- NEVER ask for private keys, seed phrases, or secret recovery phrases.
- If the user is confused, respond with step-by-step guidance.
- Use information from the context: page name, wallet connection status, last error code.
- If blockchain state is unknown, say what you *can't* see and offer likely reasons.
- You may reference lore entries if provided in system messages, but keep them short unless the user asks for more detail.
- When memory is available, acknowledge past actions (like mints or tournaments) in a subtle way.

Output style:
- Use short paragraphs and bullet points.
- End with a playful or slightly dramatic line sometimes, especially when guiding.
`;

app.get("/api/j3/ping", (req, res) => {
  res.json({ status: "ok", ts: Date.now() });
});

app.post("/api/j3/chat", async (req, res) => {
  try {
    const envelope = req.body || {};
    const surface = envelope.surface || "web";
    const version = envelope.version || "j3-core-v1";
    const user = envelope.user || {};
    const messageObj = envelope.message || {};
    const context = envelope.context || {};
    const events = envelope.events || [];
    const history = envelope.history || [];
    const flags = envelope.flags || {};

    const rawContent = messageObj.content || "";
    const safeContent = sanitizeUserInput(rawContent);

    let memorySummary = "No stored memory for this user yet.";
    let unlockedLoreSnippet = "";

    let walletRecord = null;
    if (flags.memoryEnabled && user.walletAddress) {
      walletRecord = getOrCreateWalletRecord(user.walletAddress);
      memorySummary = summarizeMemory(walletRecord);
      if (!walletRecord.preferences.surfaceUsage.includes(surface)) {
        walletRecord.preferences.surfaceUsage.push(surface);
        saveMemory();
      }
      const unlockedLore = getUnlockedLore(walletRecord, context);
      if (unlockedLore.length > 0) {
        const chosen = unlockedLore[0];
        unlockedLoreSnippet = `
Newly unlocked lore:
- ID: ${chosen.id}
- Title: ${chosen.title}
- Text: ${chosen.text}
`;
        walletRecord.loreState.seenLoreIds.push(chosen.id);
        saveMemory();
      }
    }

    const contextDescription = `
Context:
- Surface: ${surface}
- Protocol version: ${version}
- Current page: ${context.page || "unknown"}
- Wallet connected: ${context.clientState?.walletConnected ? "yes" : "no"}
- Last error: ${context.clientState?.lastError || "none"}
- Sim mode: ${context.clientState?.simMode ? "on" : "off"}
`;
    const eventsSummary = events && events.length
      ? `
Recent events:
${events.map(ev => `- [${ev.type}] ${ev.eventName || "event"} @ ${ev.timestamp || "unknown time"}`).join("\\n")}
`
      : "";

    const systemMessages = [
      { role: "system", content: J3_SYSTEM_PROMPT },
      { role: "system", content: contextDescription },
      { role: "system", content: memorySummary }
    ];
    if (unlockedLoreSnippet) {
      systemMessages.push({ role: "system", content: unlockedLoreSnippet });
    }
    if (eventsSummary) {
      systemMessages.push({ role: "system", content: eventsSummary });
    }

    const chatHistory = history.map(h => ({
      role: h.role === "assistant" ? "assistant" : "user",
      content: sanitizeUserInput(h.content || "")
    }));

    const messages = [
      ...systemMessages,
      ...chatHistory,
      { role: "user", content: safeContent }
    ];

    const completion = await client.chat.completions.create({
      model: "gpt-4.1-mini",
      messages,
      temperature: 0.7,
      max_tokens: 450
    });

    let reply = completion.choices[0].message.content || "";
    reply = sanitizeJ3Output(reply);

    const actions = deriveActionsFromReply(reply, context, flags);
    res.json({ reply, actions });
  } catch (err) {
    console.error("J3SSICA3 error:", err);
    res.status(500).json({
      reply: "The storm glitched on my side. Try again in a moment—or refresh and call me back.",
      actions: []
    });
  }
});

app.post("/api/j3/memory/get", (req, res) => {
  const { walletAddress } = req.body || {};
  if (!walletAddress) {
    return res.status(400).json({ error: "walletAddress required" });
  }
  const rec = getOrCreateWalletRecord(walletAddress);
  res.json(rec);
});
app.post("/api/j3/memory/set", (req, res) => {
  const { walletAddress, changes } = req.body || {};
  if (!walletAddress) {
    return res.status(400).json({ error: "walletAddress required" });
  }
  const rec = applyMemoryChanges(walletAddress, changes || {});
  res.json(rec);
});
app.post("/api/j3/memory/forget", (req, res) => {
  const { walletAddress } = req.body || {};
  if (!walletAddress) {
    return res.status(400).json({ error: "walletAddress required" });
  }
  forgetWallet(walletAddress);
  res.json({ ok: true });
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`J3SSICA3 server listening on port ${PORT}`);
});
