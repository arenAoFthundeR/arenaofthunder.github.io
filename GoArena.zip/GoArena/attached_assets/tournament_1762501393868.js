import { Router } from "express";
import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const tourneyPath = path.join(__dirname, "..", "data", "tournament.json");

function getTourneyDb() {
  if (!fs.existsSync(tourneyPath)) {
    fs.mkdirSync(path.dirname(tourneyPath), { recursive: true });
    fs.writeFileSync(tourneyPath, JSON.stringify({ participants: [], rounds: [] }, null, 2), "utf8");
  }
  return JSON.parse(fs.readFileSync(tourneyPath, "utf8"));
}
function saveTourneyDb(db) {
  fs.writeFileSync(tourneyPath, JSON.stringify(db, null, 2), "utf8");
}

const router = Router();

router.post("/join", (req, res) => {
  const { wallet } = req.body || {};
  if (!wallet) return res.status(400).json({ error: "wallet required" });

  const db = getTourneyDb();
  if (!db.participants.includes(wallet)) db.participants.push(wallet);
  saveTourneyDb(db);
  res.json({ success: true, participants: db.participants });
});

router.post("/advance", (req, res) => {
  const { wallet } = req.body || {};
  if (!wallet) return res.status(400).json({ error: "wallet required" });

  const db = getTourneyDb();
  db.rounds = db.rounds || [];
  db.rounds.push({ wallet, round: db.rounds.length + 1, time: Date.now() });
  saveTourneyDb(db);
  res.json({ success: true, currentRound: db.rounds.length });
});

router.get("/status", (_req, res) => {
  const db = getTourneyDb();
  res.json(db);
});

export default router;
