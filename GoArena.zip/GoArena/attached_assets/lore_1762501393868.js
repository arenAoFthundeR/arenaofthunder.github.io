import { Router } from "express";
import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const memoryPath = path.join(__dirname, "..", "data", "memory.json");
const lorePath = path.join(__dirname, "..", "data", "lore.json");

const router = Router();

function getMemoryStore() {
  try {
    if (!fs.existsSync(memoryPath)) {
      fs.mkdirSync(path.dirname(memoryPath), { recursive: true });
      fs.writeFileSync(memoryPath, JSON.stringify({ wallets: {} }, null, 2), "utf8");
    }
    return JSON.parse(fs.readFileSync(memoryPath, "utf8") || '{"wallets":{}}');
  } catch (err) {
    console.error("[LORE] Failed to read memory store:", err);
    return { wallets: {} };
  }
}

function saveMemoryStore(store) {
  fs.writeFileSync(memoryPath, JSON.stringify(store, null, 2), "utf8");
}

function getLoreDb() {
  try {
    if (!fs.existsSync(lorePath)) {
      fs.writeFileSync(
        lorePath,
        JSON.stringify(
          [
            { id: 1, title: "Genesis of the Storm", text: "When the first marble shattered..." },
            { id: 2, title: "Pantheon", text: "Within thunder lived the seven original marbles..." }
          ],
          null,
          2
        ),
        "utf8"
      );
    }
    return JSON.parse(fs.readFileSync(lorePath, "utf8"));
  } catch (err) {
    console.error("[LORE] Failed to read lore db:", err);
    return [];
  }
}

router.post("/list", (req, res) => {
  const { wallet } = req.body || {};
  if (!wallet) return res.status(400).json({ error: "wallet required" });
  const store = getMemoryStore();
  const mem = store.wallets[wallet.toLowerCase()] || {};
  const seen = new Set(mem.seenLoreIds || []);
  const loreDb = getLoreDb();
  res.json(
    loreDb.map((l) => ({
      ...l,
      unlocked: seen.has(l.id),
    }))
  );
});

router.post("/unlock", (req, res) => {
  const { wallet, id } = req.body || {};
  if (!wallet || !id) {
    return res.status(400).json({ error: "wallet and id required" });
  }
  const store = getMemoryStore();
  const key = wallet.toLowerCase();
  const now = new Date().toISOString();
  const current = store.wallets[key] || {
    wallet,
    mintCount: 0,
    giftCount: 0,
    seenLoreIds: [],
    firstSeen: now,
  };
  if (!Array.isArray(current.seenLoreIds)) {
    current.seenLoreIds = [];
  }
  if (!current.seenLoreIds.includes(id)) {
    current.seenLoreIds.push(id);
  }
  current.lastSeen = now;
  store.wallets[key] = current;
  saveMemoryStore(store);
  res.json({ success: true, seenLoreIds: current.seenLoreIds });
});

export default router;
