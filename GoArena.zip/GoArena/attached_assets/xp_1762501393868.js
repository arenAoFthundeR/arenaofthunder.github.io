import { Router } from "express";
import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const memoryPath = path.join(__dirname, "..", "data", "memory.json");

function getMemoryStore() {
  try {
    if (!fs.existsSync(memoryPath)) {
      fs.mkdirSync(path.dirname(memoryPath), { recursive: true });
      fs.writeFileSync(memoryPath, JSON.stringify({ wallets: {} }, null, 2), "utf8");
    }
    return JSON.parse(fs.readFileSync(memoryPath, "utf8") || '{"wallets":{}}');
  } catch (err) {
    console.error("[XP] Failed to read memory store:", err);
    return { wallets: {} };
  }
}

function calcXp(memory) {
  const mints = memory.mintCount || 0;
  const gifts = memory.giftCount || 0;
  return mints * 10 + gifts * 5;
}

function getBadges(xp) {
  if (xp >= 1000) return ["Storm Titan", "Arena Master"];
  if (xp >= 500) return ["Thunder Adept"];
  if (xp >= 100) return ["Marble Initiate"];
  return [];
}

const router = Router();

router.post("/get", (req, res) => {
  const { wallet } = req.body || {};
  if (!wallet || typeof wallet !== "string") {
    return res.status(400).json({ error: "wallet required" });
  }
  const store = getMemoryStore();
  const record = store.wallets[wallet.toLowerCase()] || {};
  const xp = calcXp(record);
  const level = Math.floor(xp / 100) + 1;
  res.json({ wallet, xp, level, badges: getBadges(xp) });
});

export default router;
