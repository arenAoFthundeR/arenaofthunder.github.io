import { Router } from "express";
import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const memoryPath = path.join(__dirname, "..", "data", "memory.json");

function getMemoryStore() {
  try {
    if (!fs.existsSync(memoryPath)) {
      fs.mkdirSync(path.dirname(memoryPath), { recursive: true });
      fs.writeFileSync(memoryPath, JSON.stringify({ wallets: {} }, null, 2), "utf8");
    }
    return JSON.parse(fs.readFileSync(memoryPath, "utf8") || '{"wallets":{}}');
  } catch (err) {
    console.error("[LEADERBOARD] Failed to read memory store:", err);
    return { wallets: {} };
  }
}

const router = Router();

router.get("/", (_req, res) => {
  const store = getMemoryStore();
  const wallets = store.wallets || {};
  const board = Object.values(wallets)
    .map((mem) => {
      const mints = mem.mintCount || 0;
      const gifts = mem.giftCount || 0;
      const xp = mints * 10 + gifts * 5;
      return {
        wallet: mem.wallet,
        xp,
        level: Math.floor(xp / 100) + 1,
        mints,
        gifts,
        lastSeen: mem.lastSeen,
      };
    })
    .sort((a, b) => b.xp - a.xp)
    .slice(0, 50);
  res.json(board);
});

export default router;
