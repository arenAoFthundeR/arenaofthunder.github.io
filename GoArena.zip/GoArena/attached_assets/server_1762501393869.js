import express from "express";
import { applySecurityMiddleware } from "./middleware/security.js";
import apiRouter from "./routes/index.js";

const app = express();

app.use(express.json());
applySecurityMiddleware(app);

app.get("/health", (req, res) => {
  res.json({ status: "ok", service: "arena-of-thunder-backend" });
});

app.use("/api", apiRouter);

const PORT = process.env.PORT || 4000;
if (process.env.NODE_ENV !== "test") {
  app.listen(PORT, () => {
    console.log(`[Server] Listening on port ${PORT}`);
  });
}

export default app;
