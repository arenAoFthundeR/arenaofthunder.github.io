import helmet from "helmet";
import cors from "cors";
import rateLimit from "express-rate-limit";

export function applySecurityMiddleware(app) {
  app.use(
    helmet({
      contentSecurityPolicy: false,
    })
  );

  const allowedOrigins = [
    "https://arenaofthunder.github.io",
    "http://localhost:3000",
    "http://localhost:4173",
    "http://localhost:5173"
  ];

  app.use(
    cors({
      origin(origin, callback) {
        if (!origin || allowedOrigins.includes(origin)) return callback(null, true);
        callback(new Error("Not allowed by CORS"));
      },
      credentials: false,
    })
  );

  const apiLimiter = rateLimit({
    windowMs: 15 * 60 * 1000,
    max: 200,
    standardHeaders: true,
    legacyHeaders: false,
  });

  app.use("/api/", apiLimiter);
}
