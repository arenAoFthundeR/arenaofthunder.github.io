// mint.js – client-side mint button for Arena of Thunder
import { ethers } from "https://cdn.jsdelivr.net/npm/ethers@6.7.0/dist/ethers.min.js";

// TODO: replace with your deployed contract address on Base/Base Sepolia
const CONTRACT_ADDRESS = "0xYOUR_MARBLETOKEN_CONTRACT_ADDRESS";

const CONTRACT_ABI = [
  "function mintPrice() view returns (uint256)",
  "function mintMarble(string tokenURI) external payable"
];

async function mintMarble() {
  const statusEl = document.getElementById("mint-status");

  try {
    if (!window.ethereum) {
      alert("MetaMask not detected. Install it first.");
      return;
    }

    await window.ethereum.request({ method: "eth_requestAccounts" });

    const provider = new ethers.BrowserProvider(window.ethereum);
    const signer = await provider.getSigner();
    const contract = new ethers.Contract(CONTRACT_ADDRESS, CONTRACT_ABI, signer);

    const tokenURI = prompt(
      "Enter marble metadata URL (IPFS or HTTPS, e.g. https://.../alexander.json):"
    );
    if (!tokenURI) return;

    statusEl.textContent = "Checking mint price…";

    let mintPrice;
    try {
      mintPrice = await contract.mintPrice();
    } catch {
      mintPrice = ethers.parseEther("0.01");
    }

    statusEl.textContent = "Sending mint transaction…";

    const tx = await contract.mintMarble(tokenURI, { value: mintPrice });
    statusEl.textContent = "Waiting for confirmation…";

    await tx.wait();
    statusEl.textContent = "✅ Marble minted successfully!";
  } catch (err) {
    console.error(err);
    statusEl.textContent =
      "❌ Mint failed: " + (err?.reason || err?.message || "Unknown error");
  }
}

// expose for HTML onclick
window.mintMarble = mintMarble;
