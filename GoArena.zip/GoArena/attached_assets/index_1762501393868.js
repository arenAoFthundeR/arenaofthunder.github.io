import { Router } from "express";
import xpRouter from "./xp.js";
import leaderboardRouter from "./leaderboard.js";
import loreRouter from "./lore.js";
import tournamentRouter from "./tournament.js";
import memoryRouter from "./memory.js";

const router = Router();

router.use("/xp", xpRouter);
router.use("/leaderboard", leaderboardRouter);
router.use("/lore", loreRouter);
router.use("/tournament", tournamentRouter);
router.use("/j3/memory", memoryRouter);

export default router;
