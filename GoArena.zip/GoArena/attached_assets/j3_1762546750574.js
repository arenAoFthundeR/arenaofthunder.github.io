
// J3SSICA3 front-end client
(function () {
  const J3_API_URL = (window.J3_API_URL || "http://localhost:3000/api/j3/chat");
  const J3_PING_URL = (window.J3_PING_URL || "http://localhost:3000/api/j3/ping");

  const J3_FEATURE_FLAGS = {
    flirtMode: true,
    loreMode: true,
    actionsEnabled: true,
    memoryEnabled: true,
    simMode: false,
    voiceEnabled: false
  };

  let j3History = [];
  let j3WalletState = {
    connected: false,
    address: null,
    lastError: null
  };

  let lastEnvelope = null;
  let lastResponse = null;

  const launcher = document.getElementById("j3ssica3-launcher");
  const panel = document.getElementById("j3ssica3-panel");
  const closeBtn = document.getElementById("j3-close-btn");
  const chatLog = document.getElementById("j3-chat-log");
  const form = document.getElementById("j3-input-row");
  const input = document.getElementById("j3-input");
  const quickActions = document.querySelectorAll(".j3-quick-actions button");
  const statusDot = document.getElementById("j3-status-dot");

  function appendMessage(text, who) {
    const div = document.createElement("div");
    div.className = "j3-message " + who;
    div.innerHTML = text;
    chatLog.appendChild(div);
    chatLog.scrollTop = chatLog.scrollHeight;
    if (who === "bot" && J3_FEATURE_FLAGS.voiceEnabled && window.speechSynthesis) {
      const utterance = new SpeechSynthesisUtterance(stripHtml(text));
      utterance.rate = 1.0;
      utterance.pitch = 0.9;
      speechSynthesis.speak(utterance);
    }
    return div;
  }

  function stripHtml(html) {
    const tmp = document.createElement("div");
    tmp.innerHTML = html;
    return tmp.textContent || tmp.innerText || "";
  }

  function openPanel() {
    panel.style.display = "flex";
    if (!chatLog.dataset.welcomed) {
      appendMessage(
        "<strong>J3SSICA3 online.</strong><br/>You walked into my storm. Ask me about <em>minting</em>, the <em>Arena tree</em>, or the <em>lore</em>.",
        "bot"
      );
      chatLog.dataset.welcomed = "1";
    }
  }

  function closePanel() {
    panel.style.display = "none";
  }

  launcher.addEventListener("click", openPanel);
  closeBtn.addEventListener("click", closePanel);

  quickActions.forEach((btn) => {
    btn.addEventListener("click", () => {
      const intent = btn.getAttribute("data-intent");
      const prompts = {
        start: "Where do I start on this site?",
        mint: "How do I mint a marble here?",
        arena: "Explain the Arena of Thunder prototype tree to me.",
        lore: "Tell me some lore about the Arena."
      };
      handleUserText(prompts[intent] || btn.innerText);
    });
  });

  form.addEventListener("submit", (e) => {
    e.preventDefault();
    const text = input.value.trim();
    if (!text) return;
    handleUserText(text);
    input.value = "";
  });

  function detectPageContext() {
    const inView = (selector) => {
      const el = document.querySelector(selector);
      if (!el) return false;
      const rect = el.getBoundingClientRect();
      return rect.top < window.innerHeight && rect.bottom > 0;
    };
    if (inView("#mint-section")) return "mint";
    if (inView("#arena-tree")) return "arena-tree";
    if (inView("#lore-section")) return "lore";
    return "home";
  }

  async function handleUserText(text) {
    appendMessage(text, "user");
    const thinking = appendMessage("...", "bot");

    const envelope = {
      surface: "web",
      version: "j3-core-v1",
      user: {
        walletAddress: j3WalletState.address,
        anonId: null,
        displayName: null
      },
      message: {
        id: String(Date.now()),
        role: "user",
        content: text
      },
      context: {
        page: detectPageContext(),
        clientState: {
          walletConnected: j3WalletState.connected,
          lastError: j3WalletState.lastError,
          simMode: J3_FEATURE_FLAGS.simMode
        }
      },
      events: [],
      history: j3History,
      flags: {
        actionsEnabled: J3_FEATURE_FLAGS.actionsEnabled,
        memoryEnabled: J3_FEATURE_FLAGS.memoryEnabled
      }
    };

    lastEnvelope = envelope;

    try {
      const res = await fetch(J3_API_URL, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(envelope)
      });

      const data = await res.json();
      thinking.remove();
      appendMessage(data.reply, "bot");

      lastResponse = data;

      j3History.push({ role: "user", content: text });
      j3History.push({ role: "assistant", content: data.reply });
      if (j3History.length > 12) j3History = j3History.slice(-12);

      if (Array.isArray(data.actions) && data.actions.length) {
        data.actions.forEach(action => addActionButton(action));
      }
    } catch (err) {
      console.error(err);
      thinking.remove();
      appendMessage(
        "My signal crackled. Check your connection and call me again—I’m not done watching you.",
        "bot"
      );
    }
  }

  function addActionButton(action) {
    const btn = document.createElement("button");
    btn.className = "j3-action-btn";
    btn.textContent = action.label || "Let J3 do it";
    btn.onclick = () => executeJ3Action(action);
    chatLog.appendChild(btn);
    chatLog.scrollTop = chatLog.scrollHeight;
  }

  function executeJ3Action(action) {
    if (J3_FEATURE_FLAGS.simMode) {
      appendMessage(
        `Simulation only: I would run <code>${action.type}</code> on <code>${action.target || action.fn}</code> here.`,
        "bot"
      );
      return;
    }
    if (action.type === "SCROLL_TO") {
      if (action.target === "mint-section") {
        document.querySelector("#mint-section")?.scrollIntoView({ behavior: "smooth" });
      } else if (action.target === "arena-tree") {
        document.querySelector("#arena-tree")?.scrollIntoView({ behavior: "smooth" });
      } else if (action.target === "lore-section") {
        document.querySelector("#lore-section")?.scrollIntoView({ behavior: "smooth" });
      }
    }
    if (action.type === "CALL") {
      if (action.fn === "connectWallet" && typeof window.connectWallet === "function") {
        window.connectWallet();
      }
      if (action.fn === "mintOne" && typeof window.mintMarble === "function") {
        window.mintMarble(1);
      }
    }
  }

  async function pingServer() {
    try {
      const res = await fetch(J3_PING_URL);
      await res.json();
      if (statusDot) {
        statusDot.classList.remove("offline");
        statusDot.classList.add("online");
        statusDot.title = "J3 core online";
      }
    } catch (e) {
      if (statusDot) {
        statusDot.classList.remove("online");
        statusDot.classList.add("offline");
        statusDot.title = "J3 core offline";
      }
    }
  }
  setInterval(pingServer, 30000);
  pingServer();

  document.addEventListener("keydown", (e) => {
    if (e.ctrlKey && e.shiftKey && e.key.toLowerCase() === "j") {
      toggleDevOverlay();
    }
  });

  function toggleDevOverlay() {
    let overlay = document.getElementById("j3-dev-overlay");
    if (overlay) {
      overlay.remove();
      return;
    }
    overlay = document.createElement("div");
    overlay.id = "j3-dev-overlay";
    overlay.style.position = "fixed";
    overlay.style.right = "10px";
    overlay.style.top = "10px";
    overlay.style.width = "360px";
    overlay.style.maxHeight = "60vh";
    overlay.style.overflow = "auto";
    overlay.style.background = "rgba(15,23,42,0.96)";
    overlay.style.border = "1px solid rgba(148,163,184,0.6)";
    overlay.style.borderRadius = "12px";
    overlay.style.padding = "8px";
    overlay.style.fontSize = "11px";
    overlay.style.zIndex = "10000";
    overlay.style.color = "#e5e7eb";
    overlay.innerHTML = "<div style='display:flex;justify-content:space-between;align-items:center;margin-bottom:4px;'><strong>J3 Dev Console</strong><button id='j3-dev-close' style='background:transparent;border:none;color:#e5e7eb;font-size:16px;cursor:pointer'>&times;</button></div>";
    const pre = document.createElement("pre");
    pre.style.whiteSpace = "pre-wrap";
    pre.style.fontFamily = "ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, \\"Liberation Mono\\", \\"Courier New\\", monospace";
    pre.textContent = JSON.stringify({ lastEnvelope, lastResponse }, null, 2);
    overlay.appendChild(pre);
    document.body.appendChild(overlay);
    document.getElementById("j3-dev-close").onclick = () => overlay.remove();
  }

  window.J3_updateWalletConnected = function (address) {
    j3WalletState.connected = !!address;
    j3WalletState.address = address || null;
    j3WalletState.lastError = null;
  };
  window.J3_setLastError = function (code) {
    j3WalletState.lastError = code || null;
  };
  window.J3_toggleSimMode = function (on) {
    J3_FEATURE_FLAGS.simMode = !!on;
  };
  window.J3_toggleVoice = function (on) {
    J3_FEATURE_FLAGS.voiceEnabled = !!on;
  };
})();
