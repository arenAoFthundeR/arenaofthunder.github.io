
const fs = require('fs');
const path = require('path');
const archiver = require('archiver');

function createBundle() {
  const output = fs.createWriteStream('xumm-withdrawal-app.zip');
  const archive = archiver('zip', {
    zlib: { level: 9 } // Maximum compression
  });

  output.on('close', function() {
    console.log('Bundle created successfully!');
    console.log('File: xumm-withdrawal-app.zip');
    console.log('Size: ' + archive.pointer() + ' total bytes');
    console.log('\nYour XUMM withdrawal app has been bundled.');
    console.log('Extract the zip file and run "npm install" to set up dependencies.');
  });

  archive.on('error', function(err) {
    throw err;
  });

  archive.pipe(output);

  // Add all necessary files
  archive.file('index.js', { name: 'index.js' });
  archive.file('validate.js', { name: 'validate.js' });
  archive.file('package.json', { name: 'package.json' });
  archive.file('.replit', { name: '.replit' });
  
  // Create a README for the bundle
  const readme = `# XUMM Withdrawal Service

## Setup
1. Extract this zip file
2. Run: npm install
3. Add your XUMM API credentials to the code
4. Run: node index.js

## Endpoints
- GET / - Health check
- GET /test - Create safe test XUMM link
- POST /withdraw - Create withdrawal XUMM link

## Configuration
- Server runs on port 5000
- Update API credentials in index.js before use
- Ensure you have valid XUMM API key and secret

## Dependencies
- express: Web server framework
- xumm-sdk: XUMM API integration
- dotenv: Environment variables (optional)
`;

  archive.append(readme, { name: 'README.md' });
  
  archive.finalize();
}

// Install archiver if needed, then create bundle
const { execSync } = require('child_process');

try {
  require('archiver');
  createBundle();
} catch (err) {
  console.log('Installing archiver package...');
  execSync('npm install archiver', { stdio: 'inherit' });
  console.log('Creating bundle...');
  createBundle();
}
