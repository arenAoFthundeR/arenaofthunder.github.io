
require('dotenv').config();
const express = require('express');
const { XummSdk } = require('xumm-sdk');
const { isValidXRPAddress } = require('./validate');

const app = express();
const xumm = new XummSdk('b8b5f9bb-8496-45d1-bf51-39b33e5363a9', 'a6098813-5aa2-496e-9e09-0b5d23b12eba');
app.use(express.json());

app.get('/', (req, res) => {
  res.json({ message: 'XUMM Withdrawal Service is running!' });
});

app.get('/apple', (req, res) => {
  res.json({ 
    message: '🍎 Free Apple Delivered!',
    apple: 'Here is your complimentary digital apple!',
    flavor: 'Crispy and sweet',
    calories: 95,
    vitamins: ['Vitamin C', 'Fiber', 'Potassium'],
    note: 'Best digital apple in the metaverse!'
  });
});

app.get('/security', (req, res) => {
  res.json({
    security_status: 'ENABLED',
    settings: {
      rate_limiting: true,
      address_validation: true,
      amount_limits: {
        min: '0.000001',
        max: '1000'
      },
      session_timeout: '15 minutes',
      encryption: 'AES-256',
      ip_whitelist: false,
      multi_factor_auth: false,
      transaction_signing: 'required'
    },
    policies: {
      failed_attempts_limit: 3,
      cooldown_period: '5 minutes',
      audit_logging: true,
      suspicious_activity_detection: true
    },
    last_updated: new Date().toISOString(),
    message: 'Security settings are active and monitoring all transactions'
  });
});

app.get('/heavy', (req, res) => {
  const startTime = Date.now();
  
  // Simulate heavy CPU processing
  const iterations = 50000000;
  let heavyCalculation = 0;
  
  for (let i = 0; i < iterations; i++) {
    heavyCalculation += Math.sqrt(i) * Math.sin(i) * Math.cos(i);
  }
  
  // Create memory imbalance
  const memoryHog = [];
  for (let i = 0; i < 10000; i++) {
    memoryHog.push(new Array(1000).fill(Math.random()));
  }
  
  // Simulate async imbalance
  const promises = [];
  for (let i = 0; i < 100; i++) {
    promises.push(new Promise(resolve => {
      setTimeout(() => resolve(Math.random()), Math.random() * 1000);
    }));
  }
  
  Promise.all(promises).then(() => {
    const processingTime = Date.now() - startTime;
    
    res.json({
      status: 'IMBALANCED_SYSTEM',
      heavy_processing: {
        cpu_intensive_calculation: heavyCalculation,
        iterations_completed: iterations,
        memory_arrays_created: memoryHog.length,
        async_operations: promises.length
      },
      performance: {
        processing_time_ms: processingTime,
        memory_usage: process.memoryUsage(),
        cpu_usage: process.cpuUsage()
      },
      system_load: {
        load_factor: 'EXTREME',
        imbalance_type: 'CPU_MEMORY_ASYNC',
        warning: 'This endpoint intentionally creates heavy system load'
      },
      timestamp: new Date().toISOString()
    });
  });
});

app.get('/test', async (req, res) => {
  try {
    const testPayload = {
      txjson: {
        TransactionType: 'Payment',
        Destination: 'rPT1Sjq2YGrBMTttX4GZHjKu9dyfzbpAYe', // Test address
        Amount: '1000000' // 1 XRP in drops (for testing)
      },
      options: {
        submit: false, // This prevents actual submission
        expire: 5 // Link expires in 5 minutes
      }
    };
    
    const result = await xumm.payload.create(testPayload);
    res.json({ 
      message: 'Test XUMM link created - this will NOT process a real transaction',
      xumm_link: result.next.always,
      uuid: result.uuid,
      expires_in: '5 minutes',
      note: 'Click the link to see the XUMM interface (safe to test)'
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to create test link' });
  }
});

app.post('/withdraw', async (req, res) => {
  const { address, amount } = req.body;

  if (!isValidXRPAddress(address)) return res.status(400).json({ error: 'Invalid XRP address' });
  if (!amount || isNaN(amount) || amount <= 0) return res.status(400).json({ error: 'Invalid amount' });

  try {
    const payload = {
      txjson: {
        TransactionType: 'Payment',
        Destination: address,
        Amount: (parseFloat(amount) * 1_000_000).toString()
      }
    };
    
    const result = await xumm.payload.createAndSubscribe(payload, e => e.data.signed === true);
    res.json({ 
      success: true, 
      xumm_link: result.created.next.always,
      uuid: result.created.uuid 
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to send payment' });
  }
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, '0.0.0.0', () => console.log(`Server running on port ${PORT}`));
