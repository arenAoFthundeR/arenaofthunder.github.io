
const crypto = require('crypto');

function isValidXRPAddress(address) {
  // Basic XRP address validation
  if (!address || typeof address !== 'string') {
    return false;
  }
  
  // Classic address should start with 'r' and be 25-34 characters
  if (address.startsWith('r') && address.length >= 25 && address.length <= 34) {
    // Basic check for valid base58 characters (excluding 0, O, I, l)
    const base58Pattern = /^[123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz]+$/;
    return base58Pattern.test(address);
  }
  
  // X-address format (starts with X)
  if (address.startsWith('X') && address.length >= 47 && address.length <= 55) {
    return true;
  }
  
  return false;
}

module.exports = { isValidXRPAddress };
